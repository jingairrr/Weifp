package com.homesoft.photo.libraw;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class LibRaw implements AutoCloseable {
    static {
        // 加载底层核心库，必须和 jniLibs 里的 libandroidraw.so 名字对应
        System.loadLibrary("androidraw");
    }

    private long mNativeContext;

    public LibRaw() {
        this(1);
    }

    public LibRaw(int flags) {
        mNativeContext = init(flags);
    }

    // --- 核心生命周期 ---
    public native long init(int flags);
    public native int open(String path);
    public native int dcrawProcess();
    public native void recycle();

    // --- 参数设置 (解决偏黄、死白的关键) ---
    public native void setQuality(int quality);
    public native void setHalfSize(boolean halfSize);
    public native void setCameraWhiteBalance(boolean useCameraWb);
    public native void setAutoWhiteBalance(boolean autoWb);
    public native void setOutputColorSpace(int colorSpace);
    public native void setUseCameraMatrix(int matrix);
    public native void setGamma(double gamma, double linear);
    public native void setBrightness(float brightness);

    // --- 获取结果 ---
    public native Bitmap getMutableBitmap(Bitmap.Config config);

    @Override
    public void close() {
        recycle();
        mNativeContext = 0;
    }
}
