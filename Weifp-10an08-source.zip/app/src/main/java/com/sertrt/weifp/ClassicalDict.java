package com.sertrt.weifp;

public class ClassicalDict {
    public static String get(int resId) {
        if (resId == R.string.app_name) return "未复";
        if (resId == R.string.recent_edit) return "近之所修";
        if (resId == R.string.multi_select) return "择多";
        if (resId == R.string.selected_count) return "已择 %1$d 物";
        if (resId == R.string.confirm) return "善";
        if (resId == R.string.cancel) return "罢";
        if (resId == R.string.save) return "存也";
        if (resId == R.string.share) return "共赏";
        if (resId == R.string.layer) return "层峦";

        if (resId == R.string.delete_confirm) return "去之确否";
        if (resId == R.string.sure_to_delete) return "定欲去之乎？";
        if (resId == R.string.rename) return "易名";
        if (resId == R.string.new_project) return "新启";
        if (resId == R.string.copy) return "复刻";
        if (resId == R.string.delete) return "毁去";
        if (resId == R.string.history_version) return "往昔残卷";
        if (resId == R.string.import_wp) return "引入工图";
        if (resId == R.string.import_wpc) return "引入卷宗";
        if (resId == R.string.export_wp) return "呈递工图";
        if (resId == R.string.export_wpc) return "呈递卷宗";
        if (resId == R.string.blank_canvas) return "素纸一张";
        if (resId == R.string.import_image) return "引入画影";

        if (resId == R.string.basic) return "基";
        if (resId == R.string.advanced) return "高深";
        if (resId == R.string.draw) return "丹青";
        if (resId == R.string.export) return "导出";
        if (resId == R.string.brightness) return "明暗";
        if (resId == R.string.contrast) return "强弱";
        if (resId == R.string.saturation) return "浓淡";
        if (resId == R.string.shadows) return "暗影";
        if (resId == R.string.highlights) return "高光";
        if (resId == R.string.temperature) return "冷暖";
        if (resId == R.string.tint) return "偏色";
        if (resId == R.string.sharpness) return "锋芒";
        if (resId == R.string.curve) return "曲直之法";
        if (resId == R.string.vibrance) return "自然之韵";
        if (resId == R.string.split_toning) return "暗明分色";
        if (resId == R.string.hsl) return "五彩调和";
        if (resId == R.string.cube_lut) return "异彩之卷";
        if (resId == R.string.adjust_size) return "缩扩形体";
        if (resId == R.string.crop) return "裁切";
        if (resId == R.string.overlay_image) return "叠加画影";
        if (resId == R.string.overlay_text) return "叠加墨迹";
        if (resId == R.string.reset) return "归初";

        if (resId == R.string.brush) return "毫";
        if (resId == R.string.eraser) return "拭";
        if (resId == R.string.bucket) return "泼墨";
        if (resId == R.string.draw_width) return "毫锋：";
        if (resId == R.string.draw_alpha) return "墨韵：";
        if (resId == R.string.erase_width) return "拭锋：";
        if (resId == R.string.bucket_tolerance) return "融墨：";
        if (resId == R.string.undo_stroke) return "抹去一毫";
        if (resId == R.string.clear_draw) return "尽褪丹青";

        if (resId == R.string.export_format) return "呈递法度";
        if (resId == R.string.quality) return "品阶：";
        if (resId == R.string.save_return) return "存之并返";
        if (resId == R.string.png_no_quality) return "品阶：极（无损也）";

        if (resId == R.string.theme_title) return "观形与术法";
        if (resId == R.string.save_settings_title) return "存档法度";
        if (resId == R.string.theme_dark) return "暗夜幽色";
        if (resId == R.string.theme_light) return "白昼明光";
        if (resId == R.string.theme_auto) return "顺应天时";
        if (resId == R.string.histogram_on) return "显象直方图：启";
        if (resId == R.string.histogram_off) return "显象直方图：闭";
        if (resId == R.string.wpc_save_per_action) return "每行一步即存档";
        if (resId == R.string.wpc_save_on_exit) return "退隐之时方存档";
        if (resId == R.string.wpb_on) return "启用高阶秘术：启";
        if (resId == R.string.wpb_off) return "启用高阶秘术：闭";
        if (resId == R.string.about_app) return "关于未复";
        if (resId == R.string.lang_title) return "言语";
        if (resId == R.string.lang_select) return "择选言语";
        if (resId == R.string.easter_egg_title) return "大道至简";
        if (resId == R.string.easter_egg_msg) return "善哉！妙哉！汝已勘破天机，此间言语将复归上古雅言。";

        if (resId == R.string.layer_invisible_title) return "此层不显";
        if (resId == R.string.layer_invisible_msg) return "墨韵尽隐，难施丹青。是否复墨韵至十足？";
        if (resId == R.string.layer_invisible_fix) return "复墨韵至十足";
        if (resId == R.string.layer_max_reached) return "层峦已极，廿层为限";
        if (resId == R.string.layer_need_wpb) return "多图需启高阶秘术，往设置中启之";
        if (resId == R.string.layer_main_locked) return "主图为底，不可直编，请点上方丹青层";
        if (resId == R.string.layer_already_top) return "已在极上";
        if (resId == R.string.layer_already_bottom) return "已在极下";
        if (resId == R.string.opacity_restored) return "已复墨韵至十足";
        if (resId == R.string.opacity_dialog_title) return "层之墨韵";
        if (resId == R.string.opacity_display_prefix) return "墨韵：";
        if (resId == R.string.opacity_hint) return "零则尽隐";
        if (resId == R.string.layer_menu_title) return "层之事";
        if (resId == R.string.layer_menu_opacity) return "墨韵";
        if (resId == R.string.layer_menu_hide) return "隐此层";
        if (resId == R.string.layer_menu_show) return "显此层";
        if (resId == R.string.layer_menu_up) return "上移一层";
        if (resId == R.string.layer_menu_down) return "下移一层";
        if (resId == R.string.layer_menu_delete) return "毁去此层";
        if (resId == R.string.layer_editing_prefix) return "今之所编：";
        if (resId == R.string.layer_list_hint) return "层峦（自上而下 = 前景至背景，点行 = 今之所编）";
        if (resId == R.string.layer_add_blank) return "+ 素层";
        if (resId == R.string.layer_add_image) return "+ 画影层";
        if (resId == R.string.layer_filter_off) return "不纳异彩";
        if (resId == R.string.layer_filter_on) return "纳异彩";

        if (resId == R.string.preset_save_title) return "存为法度";
        if (resId == R.string.preset_save_msg) return "将今滤镜曲直异彩五彩之法一并存之";
        if (resId == R.string.preset_apply_title) return "施法度";
        if (resId == R.string.preset_default_prefix) return "法度";
        if (resId == R.string.preset_saved_prefix) return "已存法度：";
        if (resId == R.string.preset_save_fail) return "法度存档未成";
        if (resId == R.string.preset_save_error) return "法度存档有异：";
        if (resId == R.string.preset_none) return "尚无成法，请先存一道";
        if (resId == R.string.preset_applied_prefix) return "已施法度：";

        if (resId == R.string.raw_load_fail) return "原图读取不果";
        if (resId == R.string.render_oom_fail) return "渲染不果，内存不足";
        if (resId == R.string.save_fail) return "存档未成";
        if (resId == R.string.save_empty_fail) return "所存之物有异，空卷，已罢";
        if (resId == R.string.share_load_fail) return "原图读取不果，难共赏";
        if (resId == R.string.share_render_fail) return "渲染不果，难共赏";
        if (resId == R.string.share_save_fail) return "共赏之卷未成";
        if (resId == R.string.share_fail_prefix) return "共赏不果：";
        if (resId == R.string.lut_loaded_prefix) return "已纳异彩之卷：";
        if (resId == R.string.lut_parse_fail) return "异彩之卷解析不果";
        if (resId == R.string.crop_start_fail) return "裁切未启：";
        if (resId == R.string.crop_no_image) return "今无可裁之图";
        if (resId == R.string.raw_preparing) return "正传 RAW 之数...";
        if (resId == R.string.resize_invalid) return "广狭须大于零";
        if (resId == R.string.resize_invalid_number) return "请入有效之数";
        if (resId == R.string.wb_preset_applied) return "已成法度，可往基础微调";
        if (resId == R.string.unsaved_title) return "尚未存档";
        if (resId == R.string.unsaved_discard) return "弃改";

        // ===== 5A 新增：基础页按钮 =====
        if (resId == R.string.rotate_90) return "旋九秩";
        if (resId == R.string.flip_horizontal) return "横转";
        if (resId == R.string.flip_vertical) return "纵转";
        if (resId == R.string.reset_view) return "归位";

        // ===== 5A 新增：高级页 =====
        if (resId == R.string.noise_color_title) return "彩噪";
        if (resId == R.string.noise_luma_title) return "明噪";
        if (resId == R.string.levels_title) return "阶调";
        if (resId == R.string.levels_black_label) return "黑场";
        if (resId == R.string.levels_gray_label) return "灰场";
        if (resId == R.string.levels_white_label) return "白场";
        if (resId == R.string.levels_reset) return "归阶";
        if (resId == R.string.wb_title) return "白衡彩均";
        if (resId == R.string.wb_daylight) return "日光";
        if (resId == R.string.wb_cloudy) return "阴天";
        if (resId == R.string.wb_tungsten) return "钨丝";
        if (resId == R.string.wb_fluorescent) return "荧光";
        if (resId == R.string.cb_shadows) return "暗影";
        if (resId == R.string.cb_mids) return "中调";
        if (resId == R.string.cb_highlights) return "高光";
        if (resId == R.string.cb_cyan_red) return "青赤";
        if (resId == R.string.cb_magenta_green) return "洋绿";
        if (resId == R.string.cb_yellow_blue) return "黄蓝";
        if (resId == R.string.split_shadow_hue) return "暗影色相";
        if (resId == R.string.split_shadow_sat) return "暗影浓淡";
        if (resId == R.string.split_highlight_hue) return "高光色相";
        if (resId == R.string.split_highlight_sat) return "高光浓淡";
        if (resId == R.string.split_balance) return "平衡";
        if (resId == R.string.hsl_hue_shift) return "色相偏移";
        if (resId == R.string.hsl_sat_label) return "浓淡";
        if (resId == R.string.hsl_lum_label) return "明暗";
        if (resId == R.string.cube_import) return "纳异彩";
        if (resId == R.string.cube_strength_label) return "异彩之力";
        if (resId == R.string.preset_save_btn) return "存法度";
        if (resId == R.string.preset_apply_btn) return "施法度";
        if (resId == R.string.reset_hsl_btn) return "归五彩";

        // ===== 5A 新增：涂鸦页 =====
        if (resId == R.string.draw_colors_label) return "色";
        if (resId == R.string.draw_custom_rgb) return "自定三色";
        if (resId == R.string.draw_channel_r) return "赤";
        if (resId == R.string.draw_channel_g) return "绿";
        if (resId == R.string.draw_channel_b) return "蓝";
        if (resId == R.string.draw_fill_hint) return "以今色填之";
        if (resId == R.string.draw_on_prefix) return "正绘于";

        // ===== 5A 新增：图层后缀 =====
        if (resId == R.string.layer_base_suffix) return "（底图）";
        if (resId == R.string.layer_hidden_suffix) return "（隐）";
        if (resId == R.string.layer_default_name) return "层";

        // ===== 5A 新增：主页 Toast / 弹窗 =====
        if (resId == R.string.toast_no_selection) return "未择图也";
        if (resId == R.string.toast_too_many) return "择多矣";
        if (resId == R.string.toast_max_copy_5) return "一次至多复刻五";
        if (resId == R.string.toast_copy_success) return "复刻成矣";
        if (resId == R.string.toast_copy_fail) return "复刻不果";
        if (resId == R.string.toast_deleted) return "已毁";
        if (resId == R.string.toast_pack_fail) return "打包不果";
        if (resId == R.string.toast_import_success) return "引入成矣";
        if (resId == R.string.toast_import_fail) return "引入不果";
        if (resId == R.string.toast_export_success) return "导出成矣";
        if (resId == R.string.toast_select_wp) return "请择 .wp 之卷";
        if (resId == R.string.toast_select_wpc) return "请择 .wpc 之卷";
        if (resId == R.string.toast_rename_fail) return "易名不果";
        if (resId == R.string.loading_copying) return "正复刻...";
        if (resId == R.string.loading_packing_wp) return "正打包工图...";
        if (resId == R.string.loading_packing_wpc) return "正打包卷宗...";
        if (resId == R.string.loading_unpacking_wp) return "正解工图...";
        if (resId == R.string.loading_unpacking_wpc) return "正解卷宗...";
        if (resId == R.string.loading_saving) return "正存档...";
        if (resId == R.string.dialog_cannot_copy) return "难复刻";
        if (resId == R.string.dialog_history_over_5) return "往昔已逾五，请先毁之";
        if (resId == R.string.dialog_no_record) return "无记也";
        if (resId == R.string.dialog_no_record_hint) return "须于编辑页按【存】，方记其步";
        if (resId == R.string.dialog_choose_source) return "择图之所";
        if (resId == R.string.dialog_from_album) return "自相册择";
        if (resId == R.string.dialog_from_file) return "自卷择";
        if (resId == R.string.dialog_batch_delete) return "批量毁之";
        if (resId == R.string.dialog_batch_delete_msg) return "定欲毁所选 %1$d 图乎？";

        // ===== 5A 新增：图片信息 =====
        if (resId == R.string.info_title) return "图之详";
        if (resId == R.string.info_filename) return "卷名";
        if (resId == R.string.info_size) return "大小";
        if (resId == R.string.info_model) return "器";
        if (resId == R.string.info_width) return "广";
        if (resId == R.string.info_height) return "狭";
        if (resId == R.string.info_aperture) return "光圈";
        if (resId == R.string.info_exposure) return "快门";
        if (resId == R.string.info_iso) return "感光";
        if (resId == R.string.info_focal) return "焦距";
        if (resId == R.string.info_no_exif) return "（无相机之记）";
        if (resId == R.string.info_no_exif_hint) return "或截屏、或 PNG、或导出之图。";
        if (resId == R.string.info_kb_unit) return "KB";

        // ===== 5A 新增：overlayActivity =====
        if (resId == R.string.overlay_pick) return "择叠加";
        if (resId == R.string.overlay_done) return "成";
        if (resId == R.string.overlay_reset_x) return "归 X";
        if (resId == R.string.overlay_reset_y) return "归 Y";
        if (resId == R.string.overlay_reset_rot) return "归转";
        if (resId == R.string.overlay_reset_scale) return "归形";
        if (resId == R.string.overlay_reset_all) return "尽归";
        if (resId == R.string.overlay_abandon_title) return "弃编";
        if (resId == R.string.overlay_abandon_msg) return "未存之叠将失，定退？";
        if (resId == R.string.overlay_exit) return "定退";
        if (resId == R.string.overlay_base_fail) return "底图加载不果";
        if (resId == R.string.overlay_overlay_fail) return "叠图加载不果";
        if (resId == R.string.overlay_compose_fail) return "合成不果";
        if (resId == R.string.overlay_reset_x_toast) return "X 已归";
        if (resId == R.string.overlay_reset_y_toast) return "Y 已归";
        if (resId == R.string.overlay_reset_rot_toast) return "转已归";
        if (resId == R.string.overlay_reset_scale_toast) return "形已归";
        if (resId == R.string.overlay_reset_all_toast) return "尽归矣";

        // ===== 5A 新增：textOverlayActivity =====
        if (resId == R.string.text_input_hint) return "入文";
        if (resId == R.string.text_size_hint) return "字号";
        if (resId == R.string.text_set) return "定";
        if (resId == R.string.text_preset_color) return "预设色";
        if (resId == R.string.text_current) return "今";
        if (resId == R.string.text_done_return) return "成而返";
        if (resId == R.string.text_abandon_title) return "弃编";
        if (resId == R.string.text_abandon_msg) return "未存之文将失，定退？";
        if (resId == R.string.text_base_fail) return "底图加载不果";
        if (resId == R.string.text_compose_fail) return "合成不果";

        // ===== 5A 新增：CropActivity =====
        if (resId == R.string.crop_load_fail) return "图加载不果";
        if (resId == R.string.crop_fail_msg) return "裁切不果";

        if (resId == R.string.clear_cache_btn) return "清缓存";
        if (resId == R.string.toast_cache_cleared) return "已清缓存";
        if (resId == R.string.app_version_label) return "版本";
        
        if (resId == R.string.info_author_label) return "著者";
        if (resId == R.string.info_email_label) return "传书";
        if (resId == R.string.changelog_title) return "更迭之记";
        if (resId == R.string.changelog_10an00) return "· 增层峦撤术。· 增彩噪明噪。· 善言语于诸页。· 修缩形后难画新境。· 修旋镜后高深失效。· 修撤法度不复异彩五彩阶调。· 底钮改手绘圆角。· 更包名为 com.sertrt.weifp。· 增启动之页、清缓存。";
        if (resId == R.string.changelog_70) return "· 增阶调（四道）。· 增叠层异彩之启。· WPC 引入补层峦。· 历史版层峦相绑。· 主页效能之优。";
        if (resId == R.string.changelog_60) return "· 增层峦之制。· 增 WPB 存卷。· 增 WPC 新式。· 丹青法度统入史。";
        if (resId == R.string.changelog_50) return "· 基法度。· 丹青：毫/拭/泼墨。· 导出 JPG/PNG/WEBP。";
        
        if (resId == R.string.open_source_title) return "借力之开源";
        
        if (resId == R.string.changelog_10an01) return "· 增 RAW 解析之能。· 丹青线条得圆滑之法。· 修缩放误触丹青。· 毫与拭之宽各记。· 底栏可藏，藏则画布广。· 丹青页增对称辅。· 高深页解缩放之锁。· 增开源声明之页。";
        return null;
    }
}
