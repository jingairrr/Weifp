package com.sertrt.weifp;

public class HslAdjust {

    public static final float[] CENTER_HUE = {0f, 30f, 60f, 120f, 180f, 240f, 270f, 300f};
    public static final String[] HUE_NAMES = {"红", "橙", "黄", "绿", "青", "蓝", "紫", "品红"};

    public float[] hue = new float[8];
    public float[] sat = new float[8];
    public float[] lum = new float[8];

    // ★ 预计算权重表：360 个色相角 × 8 个色相区间，一次算好永久查
    private static final float[][] WEIGHT_TABLE;

    static {
        WEIGHT_TABLE = new float[360][8];
        for (int h = 0; h < 360; h++) {
            for (int i = 0; i < 8; i++) {
                WEIGHT_TABLE[h][i] = computeWeight((float) h, i);
            }
        }
    }

    private static float computeWeight(float h, int i) {
        float center = CENTER_HUE[i];
        float diff = Math.abs(h - center);
        if (diff > 180f) diff = 360f - diff;
        float radius;
        switch (i) {
            case 0: radius = 30f; break;
            case 1: radius = 30f; break;
            case 2: radius = 45f; break;
            case 3: radius = 60f; break;
            case 4: radius = 60f; break;
            case 5: radius = 60f; break;
            case 6: radius = 30f; break;
            case 7: radius = 30f; break;
            default: radius = 45f;
        }
        if (diff >= radius) return 0f;
        return 0.5f * (1f + (float) Math.cos(Math.PI * diff / radius));
    }

    // ★ 哪些色相被调过（跳过没调的）
    private boolean[] hueActive = new boolean[8];
    private boolean hasAny = false;

    private void refreshActive() {
        hasAny = false;
        for (int i = 0; i < 8; i++) {
            hueActive[i] = Math.abs(hue[i]) > 0.01f || Math.abs(sat[i]) > 0.01f || Math.abs(lum[i]) > 0.01f;
            if (hueActive[i]) hasAny = true;
        }
    }

    public boolean isEmpty() {
        refreshActive();
        return !hasAny;
    }

    public void reset() {
        for (int i = 0; i < 8; i++) {
            hue[i] = 0f;
            sat[i] = 0f;
            lum[i] = 0f;
        }
        refreshActive();
    }

    public int applyPixel(int r8, int g8, int b8) {
        if (!hasAny) return (r8 << 16) | (g8 << 8) | b8;

        float rf = r8 / 255f;
        float gf = g8 / 255f;
        float bf = b8 / 255f;

        float max = Math.max(rf, Math.max(gf, bf));
        float min = Math.min(rf, Math.min(gf, bf));
        float l = (max + min) / 2f;
        float h = 0f, s = 0f;
        float d = max - min;

        if (d > 0.00001f) {
            if (l > 0.5f) s = d / (2f - max - min);
            else s = d / (max + min);

            if (max == rf) {
                h = (gf - bf) / d + (gf < bf ? 6f : 0f);
            } else if (max == gf) {
                h = (bf - rf) / d + 2f;
            } else {
                h = (rf - gf) / d + 4f;
            }
            h *= 60f;
        }

        int hInt = (int) h;
        if (hInt < 0) hInt = 0;
        if (hInt >= 360) hInt = 359;
        float[] w = WEIGHT_TABLE[hInt];

        float hShift = 0f, sAdd = 0f, lAdd = 0f;
        for (int i = 0; i < 8; i++) {
            if (!hueActive[i]) continue;  // ★ 跳过没调的
            float wi = w[i];
            if (wi < 0.001f) continue;
            hShift += wi * hue[i];
            sAdd += wi * sat[i];
            lAdd += wi * lum[i];
        }

        if (Math.abs(hShift) < 0.01f && Math.abs(sAdd) < 0.01f && Math.abs(lAdd) < 0.01f) {
            return (r8 << 16) | (g8 << 8) | b8;
        }

        h = (h + hShift) % 360f;
        if (h < 0f) h += 360f;
        s = s + sAdd / 100f * (1f - s);
        if (s < 0f) s = 0f;
        if (s > 1f) s = 1f;
        l = l + lAdd / 100f * 0.5f;
        if (l < 0f) l = 0f;
        if (l > 1f) l = 1f;

        float c = (1f - Math.abs(2f * l - 1f)) * s;
        float x = c * (1f - Math.abs((h / 60f) % 2f - 1f));
        float m = l - c / 2f;
        float rr = 0, gg = 0, bb = 0;
        if (h < 60f) { rr = c; gg = x; bb = 0; }
        else if (h < 120f) { rr = x; gg = c; bb = 0; }
        else if (h < 180f) { rr = 0; gg = c; bb = x; }
        else if (h < 240f) { rr = 0; gg = x; bb = c; }
        else if (h < 300f) { rr = x; gg = 0; bb = c; }
        else { rr = c; gg = 0; bb = x; }

        int nr = (int)((rr + m) * 255f);
        int ng = (int)((gg + m) * 255f);
        int nb = (int)((bb + m) * 255f);
        if (nr < 0) nr = 0; if (nr > 255) nr = 255;
        if (ng < 0) ng = 0; if (ng > 255) ng = 255;
        if (nb < 0) nb = 0; if (nb > 255) nb = 255;

        return (nr << 16) | (ng << 8) | nb;
    }
}
