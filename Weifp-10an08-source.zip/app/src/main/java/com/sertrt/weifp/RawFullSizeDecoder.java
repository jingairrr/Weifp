package com.sertrt.weifp;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * RAW 全尺寸解码（超分专用）。
 *
 * 编辑页加载 RAW 时用的是半尺寸（省内存），所以原图分辨率是砍半的。
 * 超分需要更高保真的源，这里从原始 RAW 文件重新按全尺寸解一次。
 *
 * 纯新增类，不改动现有解码流程；失败返回 null，调用方回退到已有底图。
 */
public final class RawFullSizeDecoder {

    private RawFullSizeDecoder() {
    }

    /** 判断 Uri 是否指向 RAW 文件。 */
    public static boolean isRawUri(Context ctx, Uri uri) {
        if (ctx == null || uri == null) return false;
        String name = null;
        try {
            name = HistoryManager.getFileNameFromUri(ctx, uri);
        } catch (Throwable ignored) {
        }
        if (name == null) {
            String p = uri.getPath();
            name = p != null ? new File(p).getName() : "";
        }
        return isRawName(name);
    }

    public static boolean isRawName(String name) {
        if (name == null) return false;
        String n = name.toLowerCase();
        return n.endsWith(".dng") || n.endsWith(".cr2") || n.endsWith(".cr3")
                || n.endsWith(".nef") || n.endsWith(".arw") || n.endsWith(".orf")
                || n.endsWith(".raf") || n.endsWith(".pef") || n.endsWith(".rw2")
                || n.endsWith(".srw") || n.endsWith(".srf") || n.endsWith(".3fr")
                || n.endsWith(".erf") || n.endsWith(".mef") || n.endsWith(".mos")
                || n.endsWith(".mrw") || n.endsWith(".x3f") || n.endsWith(".kdc")
                || n.endsWith(".dcr") || n.endsWith(".iiq");
    }

    /**
     * 按全尺寸解码 RAW。
     *
     * @return 解码成功的 Bitmap；失败返回 null（调用方回退到已有底图）
     */
    public static Bitmap decodeFullSize(Context ctx, Uri uri) {
        if (ctx == null || uri == null) return null;

        String filePath = null;
        boolean isTemp = false;
        try {
            if ("file".equals(uri.getScheme())) {
                filePath = uri.getPath();
            } else {
                String name = HistoryManager.getFileNameFromUri(ctx, uri);
                if (name == null || name.isEmpty()) name = "temp_raw.dng";
                File temp = new File(ctx.getCacheDir(), "superres_" + name);
                InputStream is = ctx.getContentResolver().openInputStream(uri);
                if (is == null) return null;
                FileOutputStream fos = new FileOutputStream(temp);
                byte[] buf = new byte[8192];
                int len;
                while ((len = is.read(buf)) > 0) fos.write(buf, 0, len);
                fos.close();
                is.close();
                filePath = temp.getAbsolutePath();
                isTemp = true;
            }

            if (filePath == null) return null;

            com.homesoft.photo.libraw.LibRaw raw = null;
            try {
                raw = new com.homesoft.photo.libraw.LibRaw();
                if (raw.open(filePath) != 0) return null;
                raw.setQuality(3);
                // ★ 与编辑页不同：这里不降采样，保留完整分辨率
                raw.setHalfSize(false);
                raw.setCameraWhiteBalance(true);
                raw.setAutoWhiteBalance(false);
                raw.setUseCameraMatrix(1);
                raw.setOutputColorSpace(1);
                if (raw.dcrawProcess() != 0) return null;
                return raw.getMutableBitmap(Bitmap.Config.ARGB_8888);
            } finally {
                if (raw != null) {
                    try {
                        raw.close();
                    } catch (Throwable ignored) {
                    }
                }
            }
        } catch (Throwable t) {
            return null;
        } finally {
            if (isTemp && filePath != null) {
                try {
                    new File(filePath).delete();
                } catch (Throwable ignored) {
                }
            }
        }
    }
}
