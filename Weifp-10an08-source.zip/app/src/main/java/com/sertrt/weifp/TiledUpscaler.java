package com.sertrt.weifp;

import android.graphics.Bitmap;
import java.io.File;
import java.io.FileOutputStream;

/**
 * 分块落盘式超分：把成品图按条带逐块写进磁盘，计算阶段不再需要整张成品常驻内存。
 *
 * 用途：突破 Android 单进程堆上限（512MB 级），让 4 倍大图也能算。
 *
 * 用法：
 *   1. {@link #renderToTiles} 逐块算好并写文件，返回索引文件；
 *   2. {@link #assemble} 在有足够内存时把分块拼回整张 Bitmap。
 *
 * 注意：拼回整张图仍需一次整图大小的内存（这是给用户看/继续编辑所必需的），
 * 但"计算过程"的峰值被压到只有一个分块的大小。
 */
public final class TiledUpscaler {

    private TiledUpscaler() {
    }

    /** 分块索引文件名后缀。 */
    private static final String META_SUFFIX = ".tmeta";

    /** 分块输出宽度的上限（8MP 一个块）。 */
    private static final long MAX_TILE_PIXELS = 8L * 1000 * 1000;

    /**
     * 逐块超分并写入 workDir。
     *
     * @return 索引文件；失败返回 null
     */
    public static File renderToTiles(int[] src, int w, int h, SuperResolution.Options opt,
                                     File workDir, String tag) {
        if (src == null || w <= 0 || h <= 0 || workDir == null) return null;
        if (!workDir.exists() && !workDir.mkdirs()) return null;

        SuperResolution.Options o = opt != null ? opt : new SuperResolution.Options();
        final int dstW = Math.max(1, (int) Math.round(w * o.scale));
        final int dstH = Math.max(1, (int) Math.round(h * o.scale));
        final int bandRows = (int) Math.max(32L, Math.min(dstH,
                MAX_TILE_PIXELS / Math.max(1L, dstW)));

        File meta = new File(workDir, tag + META_SUFFIX);
        FileOutputStream metaOut = null;
        try {
            metaOut = new FileOutputStream(meta);
            metaOut.write((dstW + " " + dstH + " " + bandRows + " "
                    + o.scale + " " + w + " " + h + "\n").getBytes("UTF-8"));

            int[] buf = null;
            int y = 0;
            while (y < dstH) {
                int rows = Math.min(bandRows, dstH - y);
                if (buf == null || buf.length < dstW * rows) {
                    buf = new int[dstW * rows];
                }
                SuperResolution.renderBand(src, w, h, o, y, rows, buf, dstW);

                Bitmap tile = Bitmap.createBitmap(dstW, rows, Bitmap.Config.ARGB_8888);
                tile.setPixels(buf, 0, dstW, 0, 0, dstW, rows);

                File tileFile = new File(workDir, tag + "_" + y + ".png");
                FileOutputStream fos = new FileOutputStream(tileFile);
                // 用 PNG 无损压缩；质量参数对 PNG 无意义，实际是最高压缩
                tile.compress(Bitmap.CompressFormat.PNG, 100, fos);
                fos.close();
                tile.recycle();
                tile = null;

                y += rows;
                // 每块结束主动让出，避免碎片堆积
                Thread.yield();
            }
            buf = null;
            return meta;
        } catch (Throwable t) {
            try {
                if (metaOut != null) metaOut.close();
            } catch (Throwable ignored) {
            }
            cleanup(meta);
            return null;
        } finally {
            try {
                if (metaOut != null) metaOut.close();
            } catch (Throwable ignored) {
            }
        }
    }

    /**
     * 把分块拼回整张 Bitmap。调用方需确保内存足够（约 dstW*dstH*4 字节）。
     */
    public static Bitmap assemble(File meta) {
        if (meta == null || !meta.exists()) return null;
        java.io.BufferedReader br = null;
        try {
            br = new java.io.BufferedReader(new java.io.InputStreamReader(
                    new java.io.FileInputStream(meta), "UTF-8"));
            String line = br.readLine();
            br.close();
            br = null;
            if (line == null) return null;
            String[] p = line.trim().split("\\s+");
            int dstW = Integer.parseInt(p[0]);
            int dstH = Integer.parseInt(p[1]);

            Bitmap out = Bitmap.createBitmap(dstW, dstH, Bitmap.Config.ARGB_8888);
            File dir = meta.getParentFile();
            String base = meta.getName().substring(0,
                    meta.getName().length() - META_SUFFIX.length());
            File[] files = dir.listFiles();
            if (files == null) return null;
            int[] buf = new int[dstW * dstH];
            int filled = 0;
            for (File f : files) {
                String n = f.getName();
                if (!n.startsWith(base + "_") || !n.endsWith(".png")) continue;
                String yStr = n.substring(base.length() + 1, n.length() - 4);
                int y = Integer.parseInt(yStr);
                Bitmap tile = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath());
                if (tile == null) continue;
                int rows = tile.getHeight();
                // 直接读进整图缓冲的对应行
                tile.getPixels(buf, y * dstW, dstW, 0, 0, dstW, Math.min(rows, dstH - y));
                filled += rows;
                tile.recycle();
                f.delete();
            }
            out.setPixels(buf, 0, dstW, 0, 0, dstW, dstH);
            buf = null;
            meta.delete();
            return out;
        } catch (Throwable t) {
            return null;
        } finally {
            try {
                if (br != null) br.close();
            } catch (Throwable ignored) {
            }
        }
    }

    /** 清理分块临时文件。 */
    public static void cleanup(File meta) {
        if (meta == null) return;
        try {
            String base = meta.getName().substring(0,
                    Math.max(0, meta.getName().length() - META_SUFFIX.length()));
            File dir = meta.getParentFile();
            if (dir != null) {
                File[] files = dir.listFiles();
                if (files != null) {
                    for (File f : files) {
                        if (f.getName().startsWith(base)) f.delete();
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }
}
