package com.sertrt.weifp;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;

/**
 * 更新提示弹窗：显示新版本号、更新说明、下载进度。
 */
public final class UpdateDialog {

    private UpdateDialog() {
    }

    /** Activity 是否还能安全更新 UI。 */
    private static boolean alive(Activity a) {
        if (a == null) return false;
        if (a.isFinishing()) return false;
        if (Build.VERSION.SDK_INT >= 17 && a.isDestroyed()) return false;
        return true;
    }

    /**
     * 显示"发现新版本"弹窗。
     *
     * @param downloadUrl APK 直链；若是 html_url 则退化为打开浏览器
     */
    public static void show(final Activity act, final String versionName, final int versionCode,
                            final String downloadUrl, final String releaseNotes) {
        if (!alive(act)) return;
        final float d = act.getResources().getDisplayMetrics().density;

        final Dialog dlg = new Dialog(act);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dlg.setCancelable(true);

        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiSpec.dpi(act, 20), UiSpec.dpi(act, 18),
                UiSpec.dpi(act, 20), UiSpec.dpi(act, 16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.getSurfaceColor(act));
        bg.setCornerRadius(UiSpec.dp(act, UiSpec.RADIUS_L));
        root.setBackground(bg);

        TextView tvTitle = new TextView(act);
        tvTitle.setText(LanguageManager.getString(act, R.string.update_found));
        tvTitle.setTextSize(17);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(ThemeManager.getTextColor(act));
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        TextView tvVer = new TextView(act);
        tvVer.setText(LanguageManager.getString(act, R.string.update_current)
                + " " + AppVersion.VERSION_NAME
                + "  →  " + versionName);
        tvVer.setTextSize(13);
        tvVer.setTextColor(0xFFFFB615);
        tvVer.setGravity(Gravity.CENTER);
        tvVer.setPadding(0, UiSpec.dpi(act, 6), 0, UiSpec.dpi(act, 10));
        root.addView(tvVer);

        // 更新说明
        if (releaseNotes != null && releaseNotes.trim().length() > 0) {
            ScrollView sv = new ScrollView(act);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, UiSpec.dpi(act, 160));
            sv.setLayoutParams(slp);
            TextView tvNotes = new TextView(act);
            tvNotes.setText(releaseNotes.trim());
            tvNotes.setTextSize(12);
            tvNotes.setTextColor(ThemeManager.getTextColor(act));
            tvNotes.setTextIsSelectable(true);
            sv.addView(tvNotes);
            GradientDrawable nb = new GradientDrawable();
            nb.setColor(ThemeManager.getButtonColor(act));
            nb.setCornerRadius(UiSpec.dp(act, UiSpec.RADIUS_S));
            sv.setBackground(nb);
            sv.setPadding(UiSpec.dpi(act, 10), UiSpec.dpi(act, 8),
                    UiSpec.dpi(act, 10), UiSpec.dpi(act, 8));
            root.addView(sv);
        }

        // 进度条（下载时才显示）
        final ProgressBar progress = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, UiSpec.dpi(act, 6));
        plp.topMargin = UiSpec.dpi(act, 10);
        progress.setLayoutParams(plp);
        root.addView(progress);

        final TextView tvStatus = new TextView(act);
        tvStatus.setTextSize(11);
        tvStatus.setTextColor(0xFF9E9E9E);
        tvStatus.setGravity(Gravity.CENTER);
        tvStatus.setVisibility(View.GONE);
        root.addView(tvStatus);

        // 按钮行
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, UiSpec.dpi(act, 14), 0, 0);

        Button btnLater = new Button(act);
        btnLater.setText(LanguageManager.getString(act, R.string.update_later));
        btnLater.setTextSize(14);
        btnLater.setAllCaps(false);
        btnLater.setStateListAnimator(null);
        btnLater.setTextColor(ThemeManager.getTextColor(act));
        btnLater.setBackground(UiSpec.pressable(act, ThemeManager.getButtonColor(act), UiSpec.RADIUS_S));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        blp.setMargins(0, 0, UiSpec.dpi(act, 6), 0);
        btnLater.setLayoutParams(blp);
        btnLater.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dlg.dismiss(); }
            });
        row.addView(btnLater);

        final Button btnUpdate = new Button(act);
        btnUpdate.setText(LanguageManager.getString(act, R.string.update_now));
        btnUpdate.setTextSize(14);
        btnUpdate.setAllCaps(false);
        btnUpdate.setStateListAnimator(null);
        btnUpdate.setTextColor(Color.BLACK);
        btnUpdate.setBackground(UiSpec.pressable(act, UiSpec.ACCENT, UiSpec.RADIUS_S));
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f);
        ulp.setMargins(UiSpec.dpi(act, 6), 0, 0, 0);
        btnUpdate.setLayoutParams(ulp);
        row.addView(btnUpdate);
        root.addView(row);

        final boolean isDirectApk = downloadUrl != null
                && downloadUrl.toLowerCase().endsWith(".apk");

        btnUpdate.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!isDirectApk) {
                        // 没有 APK 直链：打开浏览器
                        try {
                            act.startActivity(new Intent(Intent.ACTION_VIEW,
                                    Uri.parse(downloadUrl)));
                        } catch (Throwable t) {
                            Toast.makeText(act, R.string.update_open_fail, Toast.LENGTH_SHORT).show();
                        }
                        dlg.dismiss();
                        return;
                    }
                    btnUpdate.setEnabled(false);
                    btnUpdate.setText(LanguageManager.getString(act, R.string.update_downloading));
                    progress.setVisibility(View.VISIBLE);
                    tvStatus.setVisibility(View.VISIBLE);
                    tvStatus.setText("0%");
                    UpdateChecker.download(act, downloadUrl, new UpdateChecker.Progress() {
                            @Override public void onProgress(final int percent) {
                                act.runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            if (!alive(act) || !dlg.isShowing()) return;
                                            progress.setProgress(percent);
                                            tvStatus.setText(percent + "%");
                                        }
                                    });
                            }
                            @Override public void onDone(final String apkPath) {
                                act.runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            if (!alive(act)) return;
                                            if (dlg.isShowing()) {
                                                tvStatus.setText(LanguageManager.getString(act,
                                                        R.string.update_done));
                                                dlg.dismiss();
                                            }
                                            installApk(act, apkPath);
                                        }
                                    });
                            }
                            @Override public void onFail(final String reason) {
                                act.runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            if (!alive(act) || !dlg.isShowing()) return;
                                            btnUpdate.setEnabled(true);
                                            btnUpdate.setText(LanguageManager.getString(act,
                                                    R.string.update_now));
                                            progress.setVisibility(View.GONE);
                                            tvStatus.setText(LanguageManager.getString(act,
                                                    R.string.update_fail) + " (" + reason + ")");
                                        }
                                    });
                            }
                        });
                }
            });

        dlg.setContentView(root);
        dlg.show();
    }

    /**
     * 调起系统安装器。
     *
     * Android 7+ 不允许直接传 file:// Uri（会抛 FileUriExposedException），
     * 必须走 content:// + 授权。这里用自带的 ApkFileProvider。
     */
    static void installApk(Activity act, String path) {
        try {
            File f = new File(path);
            if (!f.exists() || f.length() <= 0) {
                Toast.makeText(act, R.string.update_install_fail, Toast.LENGTH_LONG).show();
                return;
            }
            // Android 8+ 必须先允许本应用安装未知来源应用
            if (Build.VERSION.SDK_INT >= 26 && !act.getPackageManager().canRequestPackageInstalls()) {
                try {
                    Intent setting = new Intent(
                            android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:" + act.getPackageName()));
                    setting.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(setting);
                    Toast.makeText(act, R.string.update_need_permission, Toast.LENGTH_LONG).show();
                } catch (Throwable t2) {
                    Toast.makeText(act, R.string.update_install_fail, Toast.LENGTH_LONG).show();
                }
                return;
            }
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (Build.VERSION.SDK_INT >= 24) {
                Uri contentUri = ApkFileProvider.uriFor(f);
                intent.setDataAndType(contentUri, "application/vnd.android.package-archive");
                act.grantUriPermission(act.getPackageName(), contentUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else {
                intent.setDataAndType(Uri.fromFile(f), "application/vnd.android.package-archive");
            }
            act.startActivity(intent);
        } catch (Throwable t) {
            // 装不上时给出路径，让用户自己去文件管理器点
            try {
                Toast.makeText(act, act.getString(R.string.update_manual_hint)
                        + "\n" + path, Toast.LENGTH_LONG).show();
            } catch (Throwable ignored) {
            }
        }
    }
}
