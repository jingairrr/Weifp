package com.sertrt.weifp;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Debug;

/**
 * 内存探测：把「Java 堆」和「native 堆（Bitmap 真正占的地方）」都算进来。
 *
 * 背景：Android 8+ 里 Bitmap 的像素数据在 native 堆，不受 Runtime.maxMemory 限制，
 * 所以只按 Java 堆估算会严重高估可用内存（这正是 4 倍崩溃、超分后显示异常的原因）。
 *
 * 这里的策略：
 *  1. 用 ActivityManager.getMemoryInfo 拿系统的 lowMemory / threshold；
 *  2. 用 Debug.getNativeHeapAllocatedSize 拿 native 已用；
 *  3. 保守估计一次大图超分需要的 native 峰值为「成品图 + 源图 + 余量」；
 *  4. 任一条件不满足就判定为「不够」，宁可提示也不崩。
 */
public final class MemoryProbe {

    private MemoryProbe() {
    }

    /** 一次探测的结果。 */
    public static class Snapshot {
        public long javaUsed;
        public long javaMax;
        public long nativeAllocated;
        public long availMem;        // 系统剩余可用内存（全机）
        public long threshold;       // 系统 lowMemory 阈值
        public boolean lowMemory;    // 系统是否已在低内存状态

        @Override
        public String toString() {
            return "java " + (javaUsed >> 20) + "/" + (javaMax >> 20) + "MB"
                    + ", native " + (nativeAllocated >> 20) + "MB"
                    + ", avail " + (availMem >> 20) + "MB"
                    + (lowMemory ? " (lowMemory)" : "");
        }
    }

    public static Snapshot snapshot(Context ctx) {
        Snapshot s = new Snapshot();
        Runtime rt = Runtime.getRuntime();
        s.javaMax = rt.maxMemory();
        s.javaUsed = rt.totalMemory() - rt.freeMemory();
        try {
            s.nativeAllocated = Debug.getNativeHeapAllocatedSize();
        } catch (Throwable ignored) {
            s.nativeAllocated = 0;
        }
        try {
            if (ctx != null) {
                ActivityManager am = (ActivityManager) ctx
                        .getSystemService(Context.ACTIVITY_SERVICE);
                if (am != null) {
                    ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                    am.getMemoryInfo(mi);
                    s.availMem = mi.availMem;
                    s.threshold = mi.threshold;
                    s.lowMemory = mi.lowMemory;
                }
            }
        } catch (Throwable ignored) {
        }
        return s;
    }

    /**
     * 判断能否完成一次超分。
     *
     * @param srcW 源宽
     * @param srcH 源高
     * @param scale 倍率
     * @return true = 可以；false = 内存不够，应该提示用户
     */
    public static boolean canUpscale(Context ctx, int srcW, int srcH, double scale) {
        return canUpscale(ctx, srcW, srcH, scale, false);
    }

    /**
     * @param compact565 是否使用 RGB_565（成品字节数减半）
     */
    public static boolean canUpscale(Context ctx, int srcW, int srcH, double scale,
                                     boolean compact565) {
        if (srcW <= 0 || srcH <= 0 || scale <= 1.0) return false;
        Snapshot s = snapshot(ctx);

        long outPixels = (long) Math.round(srcW * scale) * Math.round(srcH * scale);
        if (outPixels > SuperResolution.MAX_OUTPUT_PIXELS) return false;

        long outBytes = outPixels * (compact565 ? 2L : 4L);   // 成品 Bitmap（native）
        long srcBytes = (long) srcW * srcH * 4L;  // 源图（native + 一份 int[]）

        // native 侧峰值：成品 + 源图 + 分块缓冲 + 现有 native（含其他 Bitmap）
        long nativeNeed = outBytes + srcBytes + 60L * 1024 * 1024 + s.nativeAllocated;
        // 系统整体必须留有余量（否则会触发 LMK 杀进程 / 显示异常）
        long systemNeed = outBytes * 2L;          // 留一倍余量给系统和其他进程

        // 1) 系统层面：剩余内存必须够，且不在低内存状态
        if (s.lowMemory) return false;
        if (s.availMem > 0 && s.availMem < systemNeed) return false;

        // 2) 进程层面：native 总需求不能超过剩余可用内存的 60%
        //    （Bitmap 走 native，无法精确拆分，保守起见按全机余量算）
        if (s.availMem > 0 && nativeNeed > s.availMem * 60L / 100L) return false;

        // 3) Java 侧仍要留够（分块用 int[]，这部分确实在 Java 堆）
        long javaNeed = srcBytes + 40L * 1024 * 1024;
        if (javaNeed > (s.javaMax - s.javaUsed)) return false;

        return true;
    }

    /**
     * 是否需要省内存模式（RGB_565）。
     *
     * 逻辑：ARGB_8888 装不下、但 RGB_565 装得下时，提示用户可以用省内存模式跑。
     */
    public static boolean needsLowMemory(Context ctx, int srcW, int srcH, double scale) {
        if (canUpscale(ctx, srcW, srcH, scale)) return false;
        Snapshot s = snapshot(ctx);
        long outPixels = (long) Math.round(srcW * scale) * Math.round(srcH * scale);
        if (outPixels > SuperResolution.MAX_OUTPUT_PIXELS) return false;
        // 565 的成品只有一半
        long outBytes565 = outPixels * 2L;
        long srcBytes = (long) srcW * srcH * 4L;
        if (s.lowMemory) return false;
        long nativeNeed = outBytes565 + srcBytes + 60L * 1024 * 1024 + s.nativeAllocated;
        if (s.availMem <= 0) return false;
        return s.availMem > outBytes565 * 2L
                && nativeNeed <= s.availMem * 60L / 100L;
    }

    /** 给出拒绝原因（用于提示文案）。 */
    public static String rejectReason(Context ctx, int srcW, int srcH, double scale) {
        Snapshot s = snapshot(ctx);
        long outPixels = (long) Math.round(srcW * scale) * Math.round(srcH * scale);
        long outMB = outPixels * 4L / (1024 * 1024);
        if (outPixels > SuperResolution.MAX_OUTPUT_PIXELS) {
            return "too_large";
        }
        if (s.lowMemory) {
            return "system_low";
        }
        if (s.availMem > 0 && s.availMem < outMB * 2L * 1024 * 1024) {
            return "system_mem";
        }
        return "native_mem";
    }
}
