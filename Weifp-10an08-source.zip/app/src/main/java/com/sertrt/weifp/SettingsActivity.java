package com.sertrt.weifp;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private TextView btnRefined;
    private TextView btnCrashLog;
    private TextView btnCheckUpdate;
    private TextView btnHighPerf;
    private TextView itemTitleView;
    private TextView btnGrid;
    private TextView tvAppNameView, tvVersionView;


    private LinearLayout rootLayout;
    private TextView btnDark, btnLight, btnAuto, btnHistogram;
    private TextView btnStepPerAction, btnStepOnExit, btnWpbToggle;
    private TextView btnLanguage, btnClearCache;

    private int classicClickCount = 0;
    private long lastClassicClickTime = 0;
    private float density;

    private Handler langClickHandler = new Handler();
    private Runnable langCloseRunnable = null;
    private static final long LANG_CLOSE_DELAY = 300;
    private static final long CLASSIC_COUNT_RESET_MS = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            buildUi(savedInstanceState);
            // 设置页自己也要应用用户选的界面字体，否则选完看不到效果
            final View contentView = findViewById(android.R.id.content);
            if (contentView != null) {
                contentView.post(new Runnable() {
                        @Override public void run() { applyGlobalFont(contentView); }
                    });
            }
        } catch (Throwable t) {
            // 兜底：设置页构建失败时至少显示错误信息，而不是直接闪退
            try { CrashLogger.log("设置页构建失败", t); } catch (Throwable ignored) {}
            TextView err = new TextView(this);
            err.setText("设置页加载失败：" + t + "\n已记录到错误日志");
            err.setTextSize(13);
            err.setTextColor(ThemeManager.getTextColor(this));
            err.setPadding(30, 120, 30, 30);
            try { err.setBackgroundColor(ThemeManager.getBgColor(this)); } catch (Throwable ignored) {}
            setContentView(err);
        }
    }


    /** 把用户选的界面字体应用到整个视图树。 */
    private void applyGlobalFont(View root) {
        try {
            android.graphics.Typeface tf = ThemeManager.getUiTypeface(this);
            applyFontRecursive(root, tf);
        } catch (Throwable ignored) {}
    }

    private void applyFontRecursive(View v, android.graphics.Typeface tf) {
        if (v == null || tf == null) return;
        try {
            if (v instanceof TextView) {
                TextView tv = (TextView) v;
                int style = tv.getTypeface() != null ? tv.getTypeface().getStyle()
                        : android.graphics.Typeface.NORMAL;
                tv.setTypeface(tf, style);   // 保留原有粗细
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    applyFontRecursive(g.getChildAt(i), tf);
                }
            }
        } catch (Throwable ignored) {}
    }

    private void buildUi(Bundle savedInstanceState) {
        // 同步"精致界面"开关到 UiSpec
        try {
            UiSpec.setRefined(getSharedPreferences("weifp_theme", MODE_PRIVATE)
                    .getBoolean("ui_refined", true));
        } catch (Throwable ignored) {
        }
        super.onCreate(savedInstanceState);

        getBaseContext().getResources().updateConfiguration(
            LanguageManager.wrap(this).getResources().getConfiguration(),
            getBaseContext().getResources().getDisplayMetrics()
        );

        density = getResources().getDisplayMetrics().density;

        ScrollView scrollView = new ScrollView(this);
        rootScrollView = scrollView;
        scrollView.setLayoutParams(new ScrollView.LayoutParams(
                                       ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.MATCH_PARENT));

        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        rootLayout.setPadding((int)(30*density), (int)(60*density), (int)(30*density), (int)(30*density));
        rootLayout.setLayoutParams(new ScrollView.LayoutParams(
                                       ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        ImageView logo = new ImageView(this);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams((int)(100*density), (int)(100*density));
        logoLp.setMargins(0, 0, 0, (int)(20*density));
        logo.setLayoutParams(logoLp);
        logo.setImageResource(R.drawable.ic_launcher);
        rootLayout.addView(logo);

        tvAppNameView = new TextView(this);
        TextView tvAppName = tvAppNameView;
        tvAppName.setText("Weifp");
        tvAppName.setTextSize(22);
        tvAppName.setTypeface(null, android.graphics.Typeface.BOLD);
        tvAppName.setGravity(Gravity.CENTER);
        rootLayout.addView(tvAppName);

        tvVersionView = new TextView(this);
        TextView tvVersion = tvVersionView;
        tvVersion.setText(AppVersion.VERSION_NAME);
        tvVersion.setTextSize(13);
        tvVersion.setGravity(Gravity.CENTER);
        tvVersion.setPadding(0, (int)(10*density), 0, (int)(40*density));
        rootLayout.addView(tvVersion);

        addSection(LanguageManager.getString(this, R.string.section_general));
        btnLanguage = addSettingItem(
                LanguageManager.getString(this, R.string.language_title),
                LanguageManager.getCurrentLangName(this), null,
                new View.OnClickListener() {
                    @Override public void onClick(View v) { showLanguageDialog(); }
                });
        // 语言名要跟着变，btnLanguage 就是这一行的标题

        addSection(LanguageManager.getString(this, R.string.theme_title));

        btnDark = createSettingsButton(LanguageManager.getString(this, R.string.theme_dark));
        onClickRow(btnDark, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ThemeManager.setThemeMode(SettingsActivity.this, ThemeManager.THEME_DARK);
                    updateThemeUI();
                }
            });

        btnLight = createSettingsButton(LanguageManager.getString(this, R.string.theme_light));
        onClickRow(btnLight, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ThemeManager.setThemeMode(SettingsActivity.this, ThemeManager.THEME_LIGHT);
                    updateThemeUI();
                }
            });

        btnAuto = createSettingsButton(LanguageManager.getString(this, R.string.theme_auto));
        onClickRow(btnAuto, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ThemeManager.setThemeMode(SettingsActivity.this, ThemeManager.THEME_AUTO);
                    updateThemeUI();
                }
            });

        addSection(LanguageManager.getString(this, R.string.section_display));
        btnHistogram = createSettingsButton("");
        onClickRow(btnHistogram, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean current = ThemeManager.isHistogramEnabled(SettingsActivity.this);
                    ThemeManager.setHistogramEnabled(SettingsActivity.this, !current);
                    updateThemeUI();
                }
            });

        // 精致模式：控制细描边等观感增强，关掉回到原来的纯色块
        btnRefined = createSettingsButton("");
        final java.lang.String refinedOn = LanguageManager.getString(this, R.string.refined_on);
        final java.lang.String refinedOff = LanguageManager.getString(this, R.string.refined_off);
        final Runnable refreshRefined = new Runnable() {
            @Override public void run() {
                boolean on = getSharedPreferences("weifp_theme", MODE_PRIVATE)
                        .getBoolean("ui_refined", true);
                String state = on ? refinedOn : refinedOff;
                String def = on ? "" : LanguageManager.getString(SettingsActivity.this,
                        R.string.refined_default_on);
                btnRefined.setText(LanguageManager.getString(SettingsActivity.this,
                        R.string.refined_title) + "：" + state + def);
            }
        };
        refreshRefined.run();
        onClickRow(btnRefined, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    android.content.SharedPreferences sp =
                            getSharedPreferences("weifp_theme", MODE_PRIVATE);
                    boolean on = sp.getBoolean("ui_refined", true);
                    sp.edit().putBoolean("ui_refined", !on).commit();
                    UiSpec.setRefined(!on);
                    refreshRefined.run();
                    updateThemeUI();   // 立即刷新开/关配色
                    Toast.makeText(SettingsActivity.this,
                            getString(R.string.refined_tip), Toast.LENGTH_SHORT).show();
                }
            });

        // 高性能模式：影响抠图/蒙版/锐化等是否用多核
        btnHighPerf = createSettingsButton("");
        onClickRow(btnHighPerf, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    boolean on = Parallel.isHighPerformance(SettingsActivity.this);
                    Parallel.setHighPerformance(SettingsActivity.this, !on);
                    updateThemeUI();
                    Toast.makeText(SettingsActivity.this,
                            LanguageManager.getString(SettingsActivity.this,
                                on ? R.string.high_perf_off : R.string.high_perf_on),
                            Toast.LENGTH_SHORT).show();
                }
            });

        // 对齐网格开关
        boolean gridOn = getSharedPreferences("weifp_theme", MODE_PRIVATE)
                .getBoolean("grid_on", false);
        btnGrid = createSettingsButton(LanguageManager.getString(this, R.string.grid_title));
        {
            View.OnClickListener gl = new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        boolean cur = getSharedPreferences("weifp_theme", MODE_PRIVATE)
                                .getBoolean("grid_on", false);
                        getSharedPreferences("weifp_theme", MODE_PRIVATE)
                                .edit().putBoolean("grid_on", !cur).commit();
                        Toast.makeText(SettingsActivity.this,
                                LanguageManager.getString(SettingsActivity.this,
                                    !cur ? R.string.grid_on : R.string.grid_off),
                                Toast.LENGTH_SHORT).show();
                        updateThemeUI();   // 直接刷新胶囊状态，不重建页面
                    }
            };
            LinearLayout gRow = settingsRowOf(btnGrid);
            if (gRow != null) gRow.setOnClickListener(gl);
        }

        // ==================== AI 指令集 ====================
        addSection(str(R.string.ai_section_title));

        // 总开关
        boolean aiOn = ThemeManager.isAiEnabled(this);
        addSettingItem(str(R.string.ai_enable_title),
                str(R.string.ai_enable_hint), aiOn,
                new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        boolean cur = ThemeManager.isAiEnabled(SettingsActivity.this);
                        ThemeManager.setAiEnabled(SettingsActivity.this, !cur);
                        if (!cur) {
                            // 打开时自动创建文件夹和说明文件
                            try { CommandBridge.ensureStructure(SettingsActivity.this); } catch (Throwable ignored) {}
                            Toast.makeText(SettingsActivity.this,
                                    str(R.string.ai_enabled_toast), Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(SettingsActivity.this,
                                    str(R.string.ai_disabled_toast), Toast.LENGTH_SHORT).show();
                        }
                        rebuildKeepingScroll();
                    }
                });

        if (aiOn) {
            // 说明文件路径 + 复制按钮
            final String docPath = CommandBridge.docPath();
            addSettingItem(str(R.string.ai_doc_title), docPath, null,
                    new View.OnClickListener() {
                        @Override public void onClick(View v) { copyToClipboard(docPath); }
                    });

            // 给用户/其他 AI 的提示语，一键复制
            final String promptText = buildAiPrompt(docPath);
            addSettingItem(str(R.string.ai_prompt_title),
                    str(R.string.ai_prompt_hint), null,
                    new View.OnClickListener() {
                        @Override public void onClick(View v) { copyToClipboard(promptText); }
                    });

            // 后台监听开关（带警告）
            boolean watching = CommandWatchService.isActive(this);
            String watchHint = str(R.string.ai_watch_hint);
            if (watching) {
                try {
                    long start = getSharedPreferences(CommandWatchService.PREF, MODE_PRIVATE)
                            .getLong(CommandWatchService.KEY_WATCH_START, 0L);
                    long left = CommandWatchService.MAX_WATCH_MS - (System.currentTimeMillis() - start);
                    if (left > 0) {
                        long h = left / (60L * 60L * 1000L);
                        long m = (left / (60L * 1000L)) % 60L;
                        watchHint = "剩余 " + h + " 小时 " + m + " 分自动关闭";
                    }
                } catch (Throwable ignored) {}
            }
            addSettingItem(str(R.string.ai_watch_title), watchHint, watching,
                    new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            final boolean cur = CommandWatchService.isActive(SettingsActivity.this);
                            if (cur) {
                                CommandWatchService.setEnabled(SettingsActivity.this, false);
                                CommandWatchService.apply(SettingsActivity.this);
                                Toast.makeText(SettingsActivity.this,
                                        str(R.string.ai_watch_off_toast), Toast.LENGTH_SHORT).show();
                                rebuildKeepingScroll();
                            } else {
                                showWatchWarning();
                            }
                        }
                    });

            // 执行模式（从原来的位置移过来）
            final int mode = ThemeManager.getAiExecMode(this);
            String modeName = mode == ThemeManager.AI_EXEC_AUTO ? str(R.string.ai_exec_auto)
                    : (mode == ThemeManager.AI_EXEC_ASK ? str(R.string.ai_exec_ask)
                                                        : str(R.string.ai_exec_off));
            addSettingItem(str(R.string.ai_exec_title), modeName, null,
                    new View.OnClickListener() {
                        @Override public void onClick(View v) { showAiExecModeDialog(); }
                    });

            // 已处理记录
            addSettingItem(str(R.string.ai_history_title),
                    str(R.string.ai_history_hint), null,
                    new View.OnClickListener() {
                        @Override public void onClick(View v) { showAiHistory(); }
                    });
        }

        // 界面字体（中英文分开）
        addSettingItem("界面字体·中文", ThemeManager.getFontCjk(this), null,
                new View.OnClickListener() {
                    @Override public void onClick(View v) { showFontPicker(true); }
                });
        addSettingItem("界面字体·英文", ThemeManager.getFontLatin(this), null,
                new View.OnClickListener() {
                    @Override public void onClick(View v) { showFontPicker(false); }
                });

        // 错误日志：出问题时可以查看原因
        addSection(LanguageManager.getString(this, R.string.section_other));
        btnCrashLog = createSettingsButton(LanguageManager.getString(this, R.string.crash_log_title));
        onClickRow(btnCrashLog, new View.OnClickListener() {
                @Override public void onClick(View v) { showCrashLogDialog(); }
            });

        btnCheckUpdate = createSettingsButton(
                LanguageManager.getString(this, R.string.update_check_title));
        onClickRow(btnCheckUpdate, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Toast.makeText(SettingsActivity.this,
                            R.string.update_downloading, Toast.LENGTH_SHORT).show();
                    UpdateChecker.check(new UpdateChecker.Callback() {
                            @Override public void onUpdateAvailable(final String vn, final int vc,
                                                                    final String url, final String notes) {
                                runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            UpdateDialog.show(SettingsActivity.this, vn, vc, url, notes);
                                        }
                                    });
                            }
                            @Override public void onUpToDate() {
                                runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            Toast.makeText(SettingsActivity.this,
                                                    R.string.update_current, Toast.LENGTH_SHORT).show();
                                        }
                                    });
                            }
                            @Override public void onError(final String reason) {
                                runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            Toast.makeText(SettingsActivity.this,
                                                    R.string.update_fail, Toast.LENGTH_SHORT).show();
                                        }
                                    });
                            }
                        });
                }
            });


        addSection(LanguageManager.getString(this, R.string.save_settings_title));

        btnStepPerAction = createSettingsButton(LanguageManager.getString(this, R.string.wpc_save_per_action));
        onClickRow(btnStepPerAction, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ThemeManager.setStepPerActionEnabled(SettingsActivity.this, true);
                    updateThemeUI();
                }
            });

        btnStepOnExit = createSettingsButton(LanguageManager.getString(this, R.string.wpc_save_on_exit));
        onClickRow(btnStepOnExit, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ThemeManager.setStepPerActionEnabled(SettingsActivity.this, false);
                    updateThemeUI();
                }
            });

        btnWpbToggle = createSettingsButton("");
        onClickRow(btnWpbToggle, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean current = ThemeManager.isWpbEnabled(SettingsActivity.this);
                    ThemeManager.setWpbEnabled(SettingsActivity.this, !current);
                    updateThemeUI();
                }
            });

        btnClearCache = createSettingsButton(LanguageManager.getString(this, R.string.clear_cache_btn));
        onClickRow(btnClearCache, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    clearAppCache();
                }
            });

        // 「关于」行：整行可点，走卡片行样式
        final TextView btnBottom = createSettingsButton(
                LanguageManager.getString(this, R.string.about_app));
        {
            LinearLayout aboutRow = settingsRowOf(btnBottom);
            View.OnClickListener aboutClick = new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        startActivity(new Intent(SettingsActivity.this, AboutActivity.class));
                    }
                };
            if (aboutRow != null) aboutRow.setOnClickListener(aboutClick);
            else onClickRow(btnBottom, aboutClick);
        }

        scrollView.addView(rootLayout);
        setContentView(scrollView);
        updateThemeUI();

        BackButtonHelper.addBackButton(this, null);
    }

    private void showLanguageDialog() {
        final String[] items = {"简体中文", "繁體中文", "English (US)"};
        int current = LanguageManager.getLanguage(this);
        if (current == LanguageManager.LANG_CLASSICAL) current = LanguageManager.LANG_SIMPLIFIED;
        final int[] selectedIndex = {current};
        classicClickCount = 0;
        
        // ★ 新增：只要打开语言弹窗，先撤销彩蛋计数，防止误触
        classicClickCount = 0;
        lastClassicClickTime = 0;

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCanceledOnTouchOutside(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getRoundBg(ThemeManager.getPanelColor(this)));
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(20*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(LanguageManager.getString(this, R.string.lang_select));
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(Gravity.CENTER);
        tvTitle.setPadding(0, 0, 0, (int)(20*density));
        root.addView(tvTitle);

        for (int i = 0; i < items.length; i++) {
            final int index = i;
            TextView tvItem = new TextView(this);
            tvItem.setText(items[i]);
            tvItem.setTextSize(15);
            tvItem.setTextColor(ThemeManager.getTextColor(this));
            tvItem.setGravity(Gravity.CENTER);
            tvItem.setPadding(0, (int)(15*density), 0, (int)(15*density));
            tvItem.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, (int)(10*density));
            tvItem.setLayoutParams(lp);

            tvItem.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (langCloseRunnable != null) {
                            langClickHandler.removeCallbacks(langCloseRunnable);
                            langCloseRunnable = null;
                        }

                        if (index == LanguageManager.LANG_TRADITIONAL) {
                            long now = System.currentTimeMillis();
                            if (now - lastClassicClickTime > CLASSIC_COUNT_RESET_MS) classicClickCount = 0;
                            lastClassicClickTime = now;
                            classicClickCount++;

                            if (classicClickCount >= 10) {
                                classicClickCount = 0;
                                dialog.dismiss();
                                triggerEasterEgg();
                                return;
                            }
                        } else {
                            classicClickCount = 0;
                        }

                        selectedIndex[0] = index;

                        langCloseRunnable = new Runnable() {
                            @Override public void run() {
                                langCloseRunnable = null;
                                LanguageManager.setLanguage(SettingsActivity.this, selectedIndex[0]);
                                if (dialog.isShowing()) dialog.dismiss();
                                rebuildKeepingScroll();
                            }
                        };
                        langClickHandler.postDelayed(langCloseRunnable, LANG_CLOSE_DELAY);
                    }
                });
            root.addView(tvItem);
        }

        dialog.setContentView(root);
        dialog.setCancelable(false);
        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.8);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void triggerEasterEgg() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getRoundBg(ThemeManager.getPanelColor(this)));
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(10*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(LanguageManager.getString(this, R.string.easter_egg_title));
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        TextView tvMsg = new TextView(this);
        tvMsg.setText(LanguageManager.getString(this, R.string.easter_egg_msg));
        tvMsg.setTextSize(13);
        tvMsg.setTextColor(ThemeManager.getTextColor(this));
        tvMsg.setGravity(Gravity.CENTER);
        tvMsg.setPadding(0, (int)(10*density), 0, (int)(20*density));
        root.addView(tvMsg);

        TextView btnOk = new TextView(this);
        btnOk.setText(LanguageManager.getString(this, R.string.confirm));
        btnOk.setTextSize(15);
        btnOk.setTextColor(Color.BLACK);
        btnOk.setGravity(Gravity.CENTER);
        btnOk.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnOk.setBackground(getRoundBg(0xFFFFB615));
        onClickRow(btnOk, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    LanguageManager.setLanguage(SettingsActivity.this, LanguageManager.LANG_CLASSICAL);
                    dialog.dismiss();
                    rebuildKeepingScroll();
                }
            });
        root.addView(btnOk);

        dialog.setContentView(root);
        dialog.setCancelable(false);
        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.8);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void clearAppCache() {
        long totalSize = 0L;
        try {
            java.io.File cacheDir = getCacheDir();
            if (cacheDir != null) {
                java.io.File[] files = cacheDir.listFiles();
                if (files != null) {
                    for (java.io.File f : files) {
                        totalSize += f.length();
                        f.delete();
                    }
                }
            }
            java.io.File extCache = getExternalCacheDir();
            if (extCache != null) {
                java.io.File[] files = extCache.listFiles();
                if (files != null) {
                    for (java.io.File f : files) {
                        totalSize += f.length();
                        f.delete();
                    }
                }
            }
        } catch (Throwable e) {}
        float mb = totalSize / 1024f / 1024f;
        Toast.makeText(this,
                       LanguageManager.getString(this, R.string.toast_cache_cleared)
                       + " " + String.format("%.1f", mb) + " MB",
                       Toast.LENGTH_SHORT).show();
    }

    /** 分组标题（小字灰色）。 */
    private TextView addSection(String title) {
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(12);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setTextColor(ThemeManager.getTextSecondaryColor(this));
        // 分组之间留白，视觉上把各块分开
        t.setPadding(UiSpec.dpi(this, 6), UiSpec.dpi(this, 26), 0, UiSpec.dpi(this, 10));
        rootLayout.addView(t);
        sectionHeaders.add(t);
        return t;
    }

    /** 分组标题列表（主题切换时统一改色）。 */
    private final java.util.List<TextView> sectionHeaders = new java.util.ArrayList<TextView>();

    /**
     * 卡片式设置行：标题 + 副标题 + 右侧状态胶囊。
     *
     * @param on    当前状态；null 表示这一行不是开关（只显示箭头）
     * @param click 点击回调
     */
    private TextView addSettingItem(String title, String sub, Boolean on,
                                    View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(UiSpec.dpi(this, 14), UiSpec.dpi(this, 11),
                UiSpec.dpi(this, 12), UiSpec.dpi(this, 11));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.setMargins(0, 0, 0, UiSpec.dpi(this, 8));
        row.setLayoutParams(rlp);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView tvT = new TextView(this);
        tvT.setText(title);
        tvT.setTextSize(14);
        tvT.setTextColor(ThemeManager.getTextColor(this));
        col.addView(tvT);
        if (sub != null && sub.length() > 0) {
            TextView tvS = new TextView(this);
            tvS.setText(sub);
            tvS.setTextSize(11);
            tvS.setTextColor(ThemeManager.getTextSecondaryColor(this));
            tvS.setPadding(0, UiSpec.dpi(this, 3), 0, 0);
            col.addView(tvS);
        }
        row.addView(col);

        if (on != null) {
            TextView pill = new TextView(this);
            String txt = LanguageManager.getString(this,
                    on ? R.string.pill_on : R.string.pill_off);
            pill.setText(txt);
            pill.setTextSize(12);
            pill.setGravity(Gravity.CENTER);
            pill.setTypeface(null, android.graphics.Typeface.BOLD);
            pill.setPadding(UiSpec.dpi(this, 13), UiSpec.dpi(this, 4),
                    UiSpec.dpi(this, 13), UiSpec.dpi(this, 4));
            pill.setTextColor(on ? Color.BLACK : ThemeManager.getTextSecondaryColor(this));
            pill.setBackground(UiSpec.chip(this, on, UiSpec.ACCENT,
                    ThemeManager.isDark(this)));
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            plp.setMargins(UiSpec.dpi(this, 8), 0, UiSpec.dpi(this, 4), 0);
            row.addView(pill, plp);
        }
        TextView chev = new TextView(this);
        chev.setText("›");
        chev.setTextSize(18);
        chev.setTextColor(ThemeManager.getTextSecondaryColor(this));
        chev.setPadding(UiSpec.dpi(this, 4), 0, 0, 0);
        row.addView(chev);

        row.setClickable(true);
        row.setFocusable(true);
        if (click != null) row.setOnClickListener(click);
        row.setBackground(getRoundBg(ThemeManager.getCardColor(this)));
        settingRows.add(row);
        rootLayout.addView(row);
        return tvT;
    }

    /** 卡片行列表（主题切换时统一改背景）。 */
    private final java.util.List<LinearLayout> settingRows = new java.util.ArrayList<LinearLayout>();

    /**
     * 设置行（HMCLgo 风格）：卡片底 + 左侧标题/副标题 + 右侧状态胶囊 + 箭头。
     *
     * 返回的是标题 TextView，方便调用方 setText 改文案；
     * 整行容器通过 settingsRowOf(title) 取回，用来设点击和状态。
     */
    /** 复制文字到剪贴板。 */
    private void copyToClipboard(String text) {
        try {
            android.content.ClipboardManager cm =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Weifp", text));
                Toast.makeText(this, str(R.string.ai_copied), Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable t) {
            Toast.makeText(this, "复制失败", Toast.LENGTH_SHORT).show();
        }
    }

    /** 生成给 AI 的说明词（用户复制后发给任意 AI）。 */
    private String buildAiPrompt(String docPath) {
        return "我想用 Weifp 处理图片。\n"
                + "Weifp 的 AI 指令说明在这里：" + docPath + "\n"
                + "请先读那个文件了解怎么下指令，然后帮我把图片处理好。";
    }

    /** 字体选择：cjk=true 选中文，false 选英文。 */
    private void showFontPicker(final boolean cjk) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(row);
        box.addView(hs);

        java.util.List<FontManager.FontItem> fonts;
        try { fonts = FontManager.all(this); }
        catch (Throwable t) { fonts = new java.util.ArrayList<FontManager.FontItem>(); }

        final String current = cjk ? ThemeManager.getFontCjk(this) : ThemeManager.getFontLatin(this);
        for (final FontManager.FontItem it : fonts) {
            TextView chip = new TextView(this);
            chip.setText(it.name);
            chip.setTextSize(13);
            chip.setPadding(UiSpec.dpi(this, 14), UiSpec.dpi(this, 9),
                    UiSpec.dpi(this, 14), UiSpec.dpi(this, 9));
            try { chip.setTypeface(it.face); } catch (Throwable ignored) {}
            boolean sel = it.name.equals(current);
            chip.setTextColor(sel ? Color.BLACK : ThemeManager.getTextColor(this));
            chip.setBackground(UiSpec.pressable(this,
                    sel ? 0xFFFFB615 : ThemeManager.getButtonColor(this), UiSpec.RADIUS_S));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, UiSpec.dpi(this, 8), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (cjk) ThemeManager.setFontCjk(SettingsActivity.this, it.name);
                        else ThemeManager.setFontLatin(SettingsActivity.this, it.name);
                        FontManager.invalidate();
                        dismissCurrentDialog();
                        Toast.makeText(SettingsActivity.this,
                                "已应用：" + it.name, Toast.LENGTH_SHORT).show();
                        rebuildKeepingScroll();
                    }
                });
            row.addView(chip);
        }
        showSimpleDialog(cjk ? "界面字体·中文" : "界面字体·英文", box);
    }

    /** Android 13+ 需要通知权限才能显示前台服务通知。 */
    private void requestNotificationPermission() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(
                            new String[]{"android.permission.POST_NOTIFICATIONS"}, 9001);
                }
            }
        } catch (Throwable ignored) {}
    }

    /** 开启后台监听前的警告弹窗。 */
    /**
     * 重新构建页面但保持滚动位置（替代 recreate()，避免跳回顶部）。
     */
    /** 页面根 ScrollView（存一份方便恢复滚动位置）。 */
    private ScrollView rootScrollView = null;

    private void rebuildKeepingScroll() {
        int scrollY = 0;
        try {
            if (rootScrollView != null) scrollY = rootScrollView.getScrollY();
        } catch (Throwable ignored) {}

        try {
            settingsRows.clear();
            rowPills.clear();
            rowTitles.clear();
            rowChevs.clear();
            sectionHeaders.clear();
            rootScrollView = null;
            setContentView(android.R.layout.simple_list_item_1);   // 清空
            buildUi(getIntent() != null ? getIntent().getExtras() : null);
        } catch (Throwable t) {
            try { rebuildKeepingScroll(); } catch (Throwable ignored) {}
            return;
        }

        final int target = scrollY;
        if (target > 0) {
            try {
                rootLayout.post(new Runnable() {
                        @Override public void run() {
                            try {
                                if (rootScrollView != null) rootScrollView.scrollTo(0, target);
                            } catch (Throwable ignored) {}
                        }
                    });
            } catch (Throwable ignored) {}
        }
    }

    private void showWatchWarning() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        TextView msg = new TextView(this);
        msg.setText(str(R.string.ai_watch_warning));
        msg.setTextSize(13);
        msg.setTextColor(ThemeManager.getTextColor(this));
        msg.setPadding(UiSpec.dpi(this, 4), UiSpec.dpi(this, 8),
                UiSpec.dpi(this, 4), UiSpec.dpi(this, 12));
        box.addView(msg);

        TextView btnOn = new TextView(this);
        btnOn.setText(str(R.string.ai_watch_confirm));
        btnOn.setTextSize(14);
        btnOn.setGravity(Gravity.CENTER);
        btnOn.setTextColor(Color.BLACK);
        btnOn.setPadding(0, UiSpec.dpi(this, 12), 0, UiSpec.dpi(this, 12));
        btnOn.setBackground(UiSpec.pressable(this, 0xFFFFB615, UiSpec.RADIUS_S));
        btnOn.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    CommandWatchService.setEnabled(SettingsActivity.this, true);
                    requestNotificationPermission();
                    CommandWatchService.apply(SettingsActivity.this);
                    dismissCurrentDialog();
                    Toast.makeText(SettingsActivity.this,
                            str(R.string.ai_watch_on_toast), Toast.LENGTH_SHORT).show();
                    rebuildKeepingScroll();
                }
            });
        box.addView(btnOn);

        TextView btnCancel = new TextView(this);
        btnCancel.setText(str(R.string.dialog_cancel));
        btnCancel.setTextSize(14);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setTextColor(ThemeManager.getTextColor(this));
        btnCancel.setPadding(0, UiSpec.dpi(this, 12), 0, UiSpec.dpi(this, 12));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.topMargin = UiSpec.dpi(this, 8);
        btnCancel.setLayoutParams(clp);
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dismissCurrentDialog(); }
            });
        box.addView(btnCancel);

        showSimpleDialog(str(R.string.ai_watch_title), box);
    }

    /** AI 执行模式选择。 */
    private void showAiExecModeDialog() {
        final String[] opts = {
            str(R.string.ai_exec_auto),
            str(R.string.ai_exec_ask),
            str(R.string.ai_exec_off)
        };
        final int[] modes = {
            ThemeManager.AI_EXEC_AUTO,
            ThemeManager.AI_EXEC_ASK,
            ThemeManager.AI_EXEC_OFF
        };
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < opts.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(opts[i]);
            t.setTextSize(14);
            t.setTextColor(ThemeManager.getTextColor(this));
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, UiSpec.dpi(this, 14), 0, UiSpec.dpi(this, 14));
            t.setBackground(UiSpec.pressable(this,
                    ThemeManager.getButtonColor(this), UiSpec.RADIUS_S));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = UiSpec.dpi(this, 8);
            t.setLayoutParams(lp);
            t.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        ThemeManager.setAiExecMode(SettingsActivity.this, modes[idx]);
                        Toast.makeText(SettingsActivity.this,
                                opts[idx], Toast.LENGTH_SHORT).show();
                        dismissCurrentDialog();
                        rebuildKeepingScroll();
                    }
                });
            box.addView(t);
        }
        showSimpleDialog(str(R.string.ai_exec_title), box);
    }

    /** 显示已执行的 AI 指令记录。 */
    private void showAiHistory() {
        StringBuilder sb = new StringBuilder();
        try {
            java.io.File done = CommandBridge.doneDir();
            java.io.File[] files = done == null ? null : done.listFiles();
            if (files == null || files.length == 0) {
                sb.append("还没有执行过任何 AI 指令");
            } else {
                java.util.Arrays.sort(files, new java.util.Comparator<java.io.File>() {
                        @Override public int compare(java.io.File a, java.io.File b) {
                            return Long.compare(b.lastModified(), a.lastModified());
                        }
                    });
                java.text.SimpleDateFormat fmt =
                        new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.US);
                for (java.io.File f : files) {
                    sb.append(fmt.format(new java.util.Date(f.lastModified())))
                      .append("  ").append(f.getName()).append("\n");
                }
            }
        } catch (Throwable t) {
            sb.append("读取失败: ").append(t);
        }
        showSimpleDialog(str(R.string.ai_history_title),
                textBlock(sb.toString()));
    }

    /** 生成一个可滚动、可复制的文本块。 */
    private View textBlock(String content) {
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(content);
        tv.setTextSize(12);
        tv.setTextColor(ThemeManager.getTextColor(this));
        tv.setTextIsSelectable(true);
        tv.setPadding(UiSpec.dpi(this, 10), UiSpec.dpi(this, 8),
                UiSpec.dpi(this, 10), UiSpec.dpi(this, 8));
        sv.addView(tv);
        sv.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, UiSpec.dpi(this, 200)));
        return sv;
    }

    private String str(int resId) {
        try { return LanguageManager.getString(this, resId); }
        catch (Throwable t) { return ""; }
    }

    private TextView createSettingsButton(String text) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(UiSpec.dpi(this, 14), UiSpec.dpi(this, 12),
                UiSpec.dpi(this, 12), UiSpec.dpi(this, 12));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.setMargins(0, 0, 0, UiSpec.dpi(this, 8));
        row.setLayoutParams(rlp);
        row.setClickable(true);
        row.setFocusable(true);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = new TextView(this);
        title.setText(text);
        title.setTextSize(14);
        title.setTextColor(ThemeManager.getTextColor(this));
        col.addView(title);

        row.addView(col);

        // 右侧状态胶囊（默认隐藏，开关类才显示）
        TextView pill = new TextView(this);
        pill.setVisibility(View.GONE);
        pill.setTextSize(12);
        pill.setGravity(Gravity.CENTER);
        pill.setTypeface(null, android.graphics.Typeface.BOLD);
        pill.setPadding(UiSpec.dpi(this, 13), UiSpec.dpi(this, 4),
                UiSpec.dpi(this, 13), UiSpec.dpi(this, 4));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        plp.setMargins(UiSpec.dpi(this, 8), 0, UiSpec.dpi(this, 4), 0);
        row.addView(pill, plp);

        TextView chev = new TextView(this);
        chev.setText("\u203A");
        chev.setTextSize(18);
        chev.setTextColor(ThemeManager.getTextSecondaryColor(this));
        chev.setPadding(UiSpec.dpi(this, 4), 0, 0, 0);
        row.addView(chev);

        row.setBackground(UiSpec.pressable(this, ThemeManager.getCardColor(this),
                UiSpec.RADIUS_M));

        settingsRows.add(row);
        rowPills.put(row, pill);
        rowTitles.put(row, title);
        rowChevs.put(row, chev);
        rootLayout.addView(row);   // 工厂自己负责加到页面里
        return title;
    }

    // 卡片行映射表
    private final java.util.List<LinearLayout> settingsRows = new java.util.ArrayList<LinearLayout>();
    private final java.util.HashMap<View, TextView> rowPills =
            new java.util.HashMap<View, TextView>();
    private final java.util.HashMap<View, TextView> rowTitles =
            new java.util.HashMap<View, TextView>();
    private final java.util.HashMap<View, TextView> rowChevs =
            new java.util.HashMap<View, TextView>();

    /** 由标题 TextView 反查所在的卡片行。 */
    private LinearLayout settingsRowOf(View title) {
        if (title == null) return null;
        View v = title;
        for (int i = 0; i < 4 && v != null; i++) {
            if (v instanceof LinearLayout && settingsRows.contains(v)) return (LinearLayout) v;
            if (!(v.getParent() instanceof View)) break;
            v = (View) v.getParent();
        }
        return null;
    }

    /** 把点击事件绑到整行（标题只是行的一小部分，绑在标题上很难点）。 */
    private void onClickRow(View title, View.OnClickListener l) {
        LinearLayout row = settingsRowOf(title);
        if (row != null) row.setOnClickListener(l);
        else if (title != null) title.setOnClickListener(l);
    }

    /** 设置某一行的状态胶囊（null = 隐藏胶囊，纯跳转行）。 */
    private void setRowState(View titleOrRow, Boolean on) {
        LinearLayout row = (titleOrRow instanceof LinearLayout
                && settingsRows.contains(titleOrRow))
                ? (LinearLayout) titleOrRow : settingsRowOf(titleOrRow);
        if (row == null) return;
        TextView pill = rowPills.get(row);
        if (pill == null) return;
        if (on == null) {
            pill.setVisibility(View.GONE);
            return;
        }
        pill.setVisibility(View.VISIBLE);
        pill.setText(LanguageManager.getString(this, on ? R.string.pill_on : R.string.pill_off));
        pill.setTextColor(on ? Color.BLACK : ThemeManager.getTextSecondaryColor(this));
        pill.setBackground(UiSpec.chip(this, on, UiSpec.ACCENT, ThemeManager.isDark(this)));
    }

    private GradientDrawable getRoundBg(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(UiSpec.dp(this, UiSpec.RADIUS_M));
        bg.setColor(color);
        return bg;
    }

    private void updateThemeUI() {
        rootLayout.setBackgroundColor(ThemeManager.getBgColor(this));
        int textColor = ThemeManager.getTextColor(this);
        int currentSetting = ThemeManager.getThemeModeSetting(this);

        // 顶部的应用名和版本号
        if (tvAppNameView != null) tvAppNameView.setTextColor(ThemeManager.getTextColor(this));
        if (tvVersionView != null) tvVersionView.setTextColor(ThemeManager.getTextSecondaryColor(this));

        // 分组标题统一用次要文字色
        for (TextView h : sectionHeaders) {
            if (h != null) h.setTextColor(ThemeManager.getTextSecondaryColor(this));
        }
        // 卡片行背景跟随主题
        for (LinearLayout r : settingsRows) {
            if (r == null) continue;
            r.setBackground(UiSpec.pressable(this, ThemeManager.getCardColor(this),
                    UiSpec.RADIUS_M));
        }
        // 箭头颜色跟随主题
        for (TextView cv : rowChevs.values()) {
            if (cv != null) cv.setTextColor(ThemeManager.getTextSecondaryColor(this));
        }
        // 卡片行标题
        for (TextView tv : rowTitles.values()) {
            if (tv != null) tv.setTextColor(ThemeManager.getTextColor(this));
        }

        // ===== 统一用卡片行 + 右侧状态胶囊（HMCLgo 风格）=====
        if (btnLanguage != null) {
            btnLanguage.setText(LanguageManager.getCurrentLangName(this));
            setRowState(btnLanguage, null);      // 纯跳转行，不显示胶囊
        }

        if (btnRefined != null) {
            boolean refinedOn = getSharedPreferences("weifp_theme", MODE_PRIVATE)
                    .getBoolean("ui_refined", true);
            btnRefined.setText(LanguageManager.getString(this, R.string.refined_title));
            setRowState(btnRefined, refinedOn);
        }
        if (btnCrashLog != null) {
            btnCrashLog.setText(LanguageManager.getString(this, R.string.crash_log_title));
            setRowState(btnCrashLog, null);
        }
        if (btnCheckUpdate != null) {
            btnCheckUpdate.setText(LanguageManager.getString(this, R.string.update_check_title));
            setRowState(btnCheckUpdate, null);
        }
        if (btnHighPerf != null) {
            boolean perf = Parallel.isHighPerformance(this);
            btnHighPerf.setText(LanguageManager.getString(this, R.string.high_perf_title));
            setRowState(btnHighPerf, perf);
        }
        if (btnGrid != null) {
            boolean g = getSharedPreferences("weifp_theme", MODE_PRIVATE)
                    .getBoolean("grid_on", false);
            btnGrid.setText(LanguageManager.getString(this, R.string.grid_title));
            setRowState(btnGrid, g);
        }

        // 主题：三行各带一个胶囊，选中的那个为"开"
        btnDark.setText(LanguageManager.getString(this, R.string.theme_dark));
        btnLight.setText(LanguageManager.getString(this, R.string.theme_light));
        btnAuto.setText(LanguageManager.getString(this, R.string.theme_auto));
        setRowState(btnDark, currentSetting == ThemeManager.THEME_DARK);
        setRowState(btnLight, currentSetting == ThemeManager.THEME_LIGHT);
        setRowState(btnAuto, currentSetting == ThemeManager.THEME_AUTO);

        boolean hist = ThemeManager.isHistogramEnabled(this);
        btnHistogram.setText(LanguageManager.getString(this, R.string.histogram_title));
        setRowState(btnHistogram, hist);

        boolean stepPerAction = ThemeManager.isStepPerActionEnabled(this);
        btnStepPerAction.setText(LanguageManager.getString(this, R.string.wpc_save_per_action_short));
        btnStepOnExit.setText(LanguageManager.getString(this, R.string.wpc_save_on_save_short));
        setRowState(btnStepPerAction, stepPerAction);
        setRowState(btnStepOnExit, !stepPerAction);

        boolean wpb = ThemeManager.isWpbEnabled(this);
        btnWpbToggle.setText(LanguageManager.getString(this, R.string.wpb_title));
        setRowState(btnWpbToggle, wpb);

        btnClearCache.setText(LanguageManager.getString(this, R.string.clear_cache_btn));
        setRowState(btnClearCache, null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (langClickHandler != null) {
            if (langCloseRunnable != null) {
                langClickHandler.removeCallbacks(langCloseRunnable);
                langCloseRunnable = null;
            }
            langClickHandler.removeCallbacksAndMessages(null);
        }
    }

    /** 查看/清空错误日志。 */
    private void showCrashLogDialog() {
        String path = CrashLogger.logPath();
        String content = "（暂无记录）";
        try {
            java.io.File f = new java.io.File(path);
            if (f.exists() && f.length() > 0) {
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                java.io.FileInputStream fis = new java.io.FileInputStream(f);
                byte[] buf = new byte[4096];
                int n;
                while ((n = fis.read(buf)) > 0) bos.write(buf, 0, n);
                fis.close();
                String all = bos.toString("UTF-8");
                // 只显示最后 4000 字，避免弹窗过大
                content = all.length() > 4000 ? all.substring(all.length() - 4000) : all;
            }
        } catch (Throwable ignored) {
        }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        TextView tvPath = new TextView(this);
        tvPath.setText(LanguageManager.getString(this, R.string.crash_log_path) + "\n" + path);
        tvPath.setTextSize(11);
        tvPath.setTextColor(ThemeManager.getTextSecondaryColor(this));
        box.addView(tvPath);

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        TextView tvBody = new TextView(this);
        tvBody.setText(content);
        tvBody.setTextSize(10);
        tvBody.setTextColor(ThemeManager.getTextColor(this));
        tvBody.setTextIsSelectable(true);
        sv.addView(tvBody);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (int)(260 * density));
        sv.setLayoutParams(slp);
        box.addView(sv);

        TextView tvClear = new TextView(this);
        tvClear.setText(LanguageManager.getString(this, R.string.crash_log_clear));
        tvClear.setTextSize(14);
        tvClear.setGravity(Gravity.CENTER);
        tvClear.setPadding(0, (int)(12*density), 0, (int)(12*density));
        tvClear.setBackgroundColor(0xFFB61515);
        tvClear.setTextColor(Color.WHITE);
        tvClear.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    CrashLogger.clear();
                    Toast.makeText(SettingsActivity.this,
                            getString(R.string.crash_log_cleared), Toast.LENGTH_SHORT).show();
                    dismissCurrentDialog();
                }
            });
        box.addView(tvClear);

        showSimpleDialog(LanguageManager.getString(this, R.string.crash_log_title), box);
    }

    private Dialog currentDialog;
    private void dismissCurrentDialog() {
        try { if (currentDialog != null) currentDialog.dismiss(); } catch (Throwable ignored) {}
    }

    /** 统一的简单弹窗。 */
    private void showSimpleDialog(String title, View content) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        currentDialog = d;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding((int)(16*density), (int)(16*density), (int)(16*density), (int)(12*density));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.getSurfaceColor(this));
        bg.setCornerRadius(UiSpec.dp(this, UiSpec.RADIUS_L));
        root.setBackground(bg);
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(15);
        tv.setGravity(Gravity.CENTER);
        tv.setTextColor(ThemeManager.getTextColor(this));
        tv.setPadding(0, 0, 0, (int)(10*density));
        root.addView(tv);
        root.addView(content);
        d.setContentView(root);
        d.show();
    }
}
