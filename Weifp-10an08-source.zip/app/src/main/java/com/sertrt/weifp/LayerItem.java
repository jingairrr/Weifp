package com.sertrt.weifp;

import android.graphics.Bitmap;

public class LayerItem {

    public static final int TYPE_DRAW = 0;
    public static final int TYPE_IMAGE = 1;
    public static final int TYPE_TEXT = 2;

    public int type;

    // 涂鸦层 / 图片层：bitmap 是内容
    public Bitmap bitmap;

    // 图片层：bitmap 存成 stepsDir/layer_N.png，这里记文件名
    public String imageFile;

    // 文字层
    public String text;
    public int textColor = 0xFF000000;
    public float textSize = 80f;

    // 变换（图片层/文字层用，涂鸦层不用）
    public float x = 0f;
    public float y = 0f;
    public float scale = 1.0f;
    public float rotation = 0f;
    public int alpha = 255;

    public boolean visible = true;

    public LayerItem(int type) {
        this.type = type;
    }

    public LayerItem copyMeta() {
        LayerItem c = new LayerItem(type);
        c.imageFile = imageFile;
        c.text = text;
        c.textColor = textColor;
        c.textSize = textSize;
        c.x = x;
        c.y = y;
        c.scale = scale;
        c.rotation = rotation;
        c.alpha = alpha;
        c.visible = visible;
        return c;
    }
}
