package com.sertrt.weifp;

import android.graphics.Bitmap;

/**
 * 纯 Java 超分辨率（不依赖 JNI / 第三方库）。
 *
 * 做法：Lanczos3（a=3）可分离重采样放大 + USM 锐化。
 *  - 内部为整数定点运算（重采样 14 位、USM 10 位），比浮点快数倍；
 *  - 按条带处理，条带之间完全独立，可多线程并行；
 *  - 照片完全不透明时跳过 alpha 通道。
 *
 * 只吃 ARGB_8888 像素数组，所以既能被 App 调用，也能离线用 javac 单测。
 *
 * 安全约定：
 *  - 纯新增类，不碰任何现有代码路径。
 *  - 实际接入 UI 时必须默认关闭，失败就回退原图。
 */
public final class SuperResolution {

    /**
     * 输出像素总数硬上限（防止异常参数把内存打爆）。
     * 4 倍放在上限外，实际由 capacityPixels() 按真实堆决定能否跑。
     */
    public static final int MAX_OUTPUT_PIXELS = 400 * 1000 * 1000;

    /**
     * 单个 Bitmap 的单边上限。
     *
     * 很多 Android 设备在 compress / 绘制 / 硬件纹理上传时对单边 8192 有限制，
     * 超过后可能表现为"内存明明够却闪退"。取 8192 作为安全上限。
     */
    public static final int MAX_SIDE = 8192;

    /** 并行线程上限（再多收益小、还费电）。 */
    public static final int MAX_THREADS = 4;

    private static final int LANCZOS_A = 3;
    private static final int STRIP_ROWS = 64;

    /** 流式处理时内层并行线程数上限（内存与速度的折中）。 */
    private static final int LIGHT_THREADS = 2;

    /** 重采样权重的定点位数。 */
    private static final int FIX_BITS = 14;
    private static final int FIX_ONE = 1 << FIX_BITS;
    private static final int FIX_HALF = 1 << (FIX_BITS - 1);

    /** USM 卷积核的定点位数。 */
    private static final int K_BITS = 10;
    private static final int K_ONE = 1 << K_BITS;
    /** 水平模糊额外保留的小数位（6 位，short 装得下）。 */
    private static final int HB_BITS = 6;
    /** 垂直累加后的总小数位：HB_BITS + K_BITS。 */
    private static final int VERT_BITS = HB_BITS + K_BITS;
    private static final int VERT_HALF = 1 << (VERT_BITS - 1);

    /** 关掉可用于排查问题（并行只是快慢，不影响结果）。 */
    private static volatile boolean sParallel = true;

    /** 测试用：强制块大小（0 = 按内存自动算）。 */
    private static volatile int sForceBlockPx = 0;

    /** 轻量模式：限制内层并行线程数（流式处理时降到 2，兼顾速度与内存）。 */
    private static final ThreadLocal<Integer> sLightThreads = new ThreadLocal<Integer>() {
        @Override protected Integer initialValue() { return 0; }
    };

    /** 仅测试用：强制分块大小，验证分块与整图结果一致。 */
    static void setForceBlockPxForTest(int px) {
        sForceBlockPx = px;
    }

    private SuperResolution() {
    }

    /** 关闭/开启并行（结果完全一致，仅影响耗时）。 */
    public static void setParallelEnabled(boolean enabled) {
        sParallel = enabled;
    }

    /** 超分参数。 */
    public static class Options {
        /** 放大倍数，1.0 ~ 8.0。 */
        public double scale = 2.0;
        /** 是否在放大后做 USM 锐化。 */
        public boolean usm = true;
        /** USM 半径（sigma，像素）。 */
        public double usmRadius = 1.0;
        /** USM 强度，0 = 不锐化。 */
        public double usmAmount = 0.5;
        /** USM 阈值，差异小于它的地方不锐化（0~255）。 */
        public int usmThreshold = 0;
        /**
         * 省内存模式：成品图用 RGB_565（每像素 2 字节，内存减半），
         * 代价是每个通道精度降低（8→5/6 位）。
         */
        public boolean lowMemory = false;

        /** 按本参数应使用的位图配置。 */
        public Bitmap.Config targetConfig() {
            return lowMemory ? Bitmap.Config.RGB_565 : Bitmap.Config.ARGB_8888;
        }

        public Options() {
        }

        public Options(double scale) {
            this.scale = scale;
        }
    }

    // ==================== Bitmap 入口 ====================

    /** 默认参数（2x + USM）。 */
    public static Bitmap upscale(Bitmap src) {
        return upscale(src, new Options());
    }

    /**
     * 放大一张 Bitmap，返回新图；src 不会被回收。
     *
     * @throws IllegalArgumentException 参数非法或输出过大
     */
    public static Bitmap upscale(Bitmap src, Options opt) {
        if (src == null) {
            throw new IllegalArgumentException("src bitmap is null");
        }
        if (opt == null) {
            opt = new Options();
        }
        int w = src.getWidth();
        int h = src.getHeight();
        if (w <= 0 || h <= 0 || opt.scale <= 1.0) {
            return src;
        }
        int[] pixels = new int[w * h];
        src.getPixels(pixels, 0, w, 0, 0, w, h);

        int[] out = upscalePixels(pixels, w, h, opt);

        int dstW = (int) Math.round(w * opt.scale);
        int dstH = (int) Math.round(h * opt.scale);
        Bitmap dst = Bitmap.createBitmap(dstW, dstH, opt.targetConfig());
        dst.setPixels(out, 0, dstW, 0, 0, dstW, dstH);
        return dst;
    }

    /**
     * 估算能安全处理的输出像素上限。
     *
     * 注意：这只是"空闲时"的理论上限。真实场景里原图、图层、历史快照都占着堆，
     * 所以 UI 判断必须用 {@link #canHandleNow}，它按真实剩余堆算。
     */
    public static long capacityPixels() {
        long maxHeap = Runtime.getRuntime().maxMemory();
        long budgetBytes = (long) (maxHeap * 0.50);
        long px = budgetBytes / 4L;
        return Math.min(MAX_OUTPUT_PIXELS, Math.max(500000L, px));
    }

    /**
     * 分块流式超分：不整张持有源图/成品图，每处理一段就把结果交给回调。
     *
     * 内存峰值只跟 band 高度有关，与整图大小无关，适用于大图。
     *
     * @param src      源像素
     * @param w        源宽
     * @param h        源高
     * @param opt      参数
     * @param bandRows 每次处理的源行数（越小越省内存，太小会变慢）
     * @param sink     每段结果回调：startRow 为该段第一行的全局输出行号
     */
    public static void upscaleStreaming(int[] src, int w, int h, Options opt,
                                        int bandRows, BandSink sink) {
        if (src == null || w <= 0 || h <= 0 || sink == null) {
            throw new IllegalArgumentException("bad args");
        }
        final Options o = opt != null ? opt : new Options();
        final double scale = o.scale;
        final boolean usm = o.usm && o.usmAmount > 0;
        final int dstW = Math.max(1, (int) Math.round(w * scale));
        final int dstH = Math.max(1, (int) Math.round(h * scale));
        // 按可用内存反推每条带最多处理多少输出像素（约 28 字节/像素开销）
        long free = Runtime.getRuntime().maxMemory() - usedHeapBytes();
        // 每条带的输出平方像素上限：按剩余堆 45% / 每个输出像素约 24 字节（2 线程并行）
        long maxBandPx = Math.max(1024L * 1024L, (long) (free * 0.45) / 24L);
        int maxRowsByMem = (int) Math.max(1, maxBandPx / dstW);
        final int rows = Math.max(1, Math.min(Math.min(bandRows, h), maxRowsByMem));
        final int pad = usm ? usmPad(o) : 0;
        final boolean opaque = isOpaque(src, w * h);

        // 水平方向与整图共用同一张权重表
        final Axis ax = buildAxisWithPhase(w, dstW, scale, 0);

        sLightThreads.set(Integer.valueOf(LIGHT_THREADS));
        try {
        int y = 0;
        while (y < h) {
            final int yEnd = Math.min(h, y + rows);
            final int outStart = Math.round(y * (float) scale);
            final int outEnd = Math.round(yEnd * (float) scale);
            final int outRows = outEnd - outStart;
            if (outRows <= 0) { y = yEnd; continue; }

            // 需要重采样的源行：本段 + 边界外推（重采样抽头最多 2 行）
            int rs0 = Math.max(0, y - 2);
            int rs1 = Math.min(h, yEnd + 2);
            // 需要锐化的输出行：本段 + pad
            int os0 = Math.max(0, outStart - pad);
            int os1 = Math.min(dstH, outEnd + pad);
            int osRows = os1 - os0;

            // 反推覆盖 [os0,os1) 的源行（重采样按 clamp 复制，边界不会越界）
            int ss0 = Math.max(0, rs0 - Math.max(0, (int) Math.floor((outStart - os0) / scale)) - 2);
            int ss1 = Math.min(h, rs1 + Math.max(0, (int) Math.ceil((os1 - outEnd) / scale)) + 2);
            int sh = ss1 - ss0;
            if (sh <= 0) { y = yEnd; continue; }

            int[] sub = new int[w * sh];
            System.arraycopy(src, ss0 * w, sub, 0, w * sh);

            // 本段的整图输出起点是 os0，子图源起点是 ss0：
            // 相位按整图坐标算（globalBase=os0），再减去子图源偏移（srcBase=ss0）
            Axis ay = buildAxisWithPhase(sh, osRows, scale, os0, ss0);
            int[] out = new int[dstW * osRows];
            resampleBand(sub, w, sh, dstW, osRows, 0, osRows, ax, ay, out, opaque);

            if (usm) {
                out = unsharpMaskInternal(out, dstW, osRows, o.usmRadius,
                        o.usmAmount, o.usmThreshold, opaque);
            }

            // 交出本段自己那几行
            int from = outStart - os0;
            int[] band = new int[dstW * outRows];
            System.arraycopy(out, from * dstW, band, 0, dstW * outRows);
            sink.onBand(outStart, band, outRows, dstW, dstW, dstH);
            y = yEnd;
        }
        } finally {
            sLightThreads.remove();
        }
    }

    /**
     * 分块超分并**直接写进目标 Bitmap**：不创建整张 int[]，省掉一份满尺寸缓冲。
     *
     * 相比 upscalePixels + 转 Bitmap：内存峰值从"输出int[] + Bitmap"降到"Bitmap + 一个分块"。
     *
     * @return 成功返回 true；内存不足等失败返回 false 并尽力回收
     */
    public static boolean upscaleIntoBitmap(int[] src, int w, int h, Options opt,
                                            Bitmap target, int[] scratch) {
        if (src == null || w <= 0 || h <= 0 || target == null) return false;
        Options o = opt != null ? opt : new Options();
        final double scale = o.scale;
        final boolean usm = o.usm && o.usmAmount > 0;
        final int dstW = Math.max(1, (int) Math.round(w * scale));
        final int dstH = Math.max(1, (int) Math.round(h * scale));
        if (target.getWidth() != dstW || target.getHeight() != dstH) return false;
        final int pad = usm ? usmPad(o) : 0;
        final boolean opaque = isOpaque(src, w * h);
        final Axis ax = buildAxisWithPhase(w, dstW, scale, 0);

        // 每次处理的输出行数：取固定上限（约 8MP 输出），不随堆放大。
        // 块越大重叠重算越少、越快；但过大会白占内存，8MP 是速度与内存的平衡点。
        final long MAX_BAND_PX = 8L * 1000 * 1000;
        int rowsByMem = (int) Math.max(32L, Math.min(dstH, MAX_BAND_PX / Math.max(1L, dstW)));
        // 内存特别紧张时再收缩
        long free = Runtime.getRuntime().maxMemory() - usedHeapBytes();
        long perRow = (long) dstW * 12L;
        int rowsByFree = (int) Math.max(32L, (long) (free * 0.30) / Math.max(1L, perRow));
        if (rowsByFree < rowsByMem) rowsByMem = rowsByFree;

        int[] subBuf = null;
        int[] outBuf = null;
        int outY = 0;
        while (outY < dstH) {
            int outEnd = Math.min(dstH, outY + rowsByMem);
            // 反推源行范围（含 pad）
            int sy0 = Math.max(0, (int) Math.floor((outY - pad) / scale) - 2);
            int sy1 = Math.min(h, (int) Math.ceil((outEnd + pad) / scale) + 2);
            int sh = sy1 - sy0;
            if (sh <= 0) return false;

            // 复用缓冲：每段新开会频繁触发 GC
            if (subBuf == null || subBuf.length < w * sh) {
                subBuf = new int[w * sh];
            }
            int[] sub = subBuf;
            System.arraycopy(src, sy0 * w, sub, 0, w * sh);

            int subStart = (int) Math.round(sy0 * scale);
            int subOutH = Math.max(1, (int) Math.round(sy1 * scale) - subStart);
            Axis ay = buildAxisWithPhase(sh, subOutH, scale, subStart, sy0);
            // 缓冲必须精确匹配本段尺寸：复用长度不符的旧数组会读到上一段的残留数据，
            // 表现为下半部分重复/拉伸（必须只在长度"正好够且未超"时复用）。
            int need = dstW * subOutH;
            int[] band;
            if (outBuf != null && outBuf.length == need) {
                band = outBuf;
            } else {
                try {
                    band = new int[need];
                } catch (OutOfMemoryError e) {
                    return false;
                }
            }
            resampleBand(sub, w, sh, dstW, subOutH, 0, subOutH, ax, ay, band, opaque);
            int[] work = band;
            if (usm) {
                try {
                    work = unsharpMaskInternal(band, dstW, subOutH, o.usmRadius,
                            o.usmAmount, o.usmThreshold, opaque);
                } catch (OutOfMemoryError e) {
                    return false;
                }
            }
            outBuf = work;   // 仅当长度精确等于 need 时下次才复用
            // 只把本段行写进 Bitmap
            int from = outY - subStart;
            if (from < 0) from = 0;
            int avail = Math.min(outEnd - outY, subOutH - from);
            if (avail > 0) {
                target.setPixels(work, from * dstW, dstW, 0, outY, dstW, avail);
            }
            outY += avail > 0 ? avail : (outEnd - outY);
        }
        return true;
    }

    /**
     * 渲染一个输出条带（供分块落盘使用）。
     *
     * @param src         源像素
     * @param w           源宽
     * @param h           源高
     * @param outY0       本带在整图中的起始输出行
     * @param outRows     本带输出行数
     * @param dst         输出缓冲（长度 >= dstW * outRows）
     * @param dstW        整图输出宽
     */
    public static void renderBand(int[] src, int w, int h, Options opt,
                                  int outY0, int outRows, int[] dst, int dstW) {
        Options o = opt != null ? opt : new Options();
        double scale = o.scale;
        boolean usm = o.usm && o.usmAmount > 0;
        int pad = usm ? usmPad(o) : 0;
        boolean opaque = isOpaque(src, w * h);

        int os0 = Math.max(0, outY0 - pad);
        int os1 = Math.min((int) Math.round(h * scale), outY0 + outRows + pad);
        int ss0 = Math.max(0, (int) Math.floor(os0 / scale) - 2);
        int ss1 = Math.min(h, (int) Math.ceil(os1 / scale) + 2);
        int sh = ss1 - ss0;
        if (sh <= 0) return;

        int[] sub = new int[w * sh];
        System.arraycopy(src, ss0 * w, sub, 0, w * sh);

        // 子图在整图输出坐标中的起点与行数
        int subStart = (int) Math.round(ss0 * scale);
        int subRows = Math.max(1, (int) Math.round(ss1 * scale) - subStart);
        Axis ax = buildAxisWithPhase(w, dstW, scale, 0);
        // 轴的长度必须与子图源行数 sh 对应，输出长度用 subRows
        Axis ay = buildAxisWithPhase(sh, subRows, scale, subStart, ss0);
        int[] tmp = new int[dstW * subRows];
        resampleBand(sub, w, sh, dstW, subRows, 0, subRows, ax, ay, tmp, opaque);
        int[] work = tmp;
        if (usm) {
            work = unsharpMaskInternal(tmp, dstW, subRows, o.usmRadius, o.usmAmount,
                    o.usmThreshold, opaque);
        }
        int from = outY0 - subStart;
        if (from < 0) from = 0;
        if (from >= subRows) return;
        int n = Math.min(outRows, subRows - from);
        if (n > 0) {
            System.arraycopy(work, from * dstW, dst, 0, dstW * n);
        }
    }

    /** 流式输出的回调。 */
    public interface BandSink {
        /**
         * @param startRow 全局输出起始行
         * @param band     本段像素（每条 subW 宽）
         * @param rows     本段行数
         * @param subW     本段每行的像素数（可能因取整比 dstW 差 1）
         * @param dstW     全局输出宽
         * @param dstH     全局输出高
         */
        void onBand(int startRow, int[] band, int rows, int subW, int dstW, int dstH);
    }

    /** 进程当前已用的堆字节数，用于判断真实余量。 */
    public static long usedHeapBytes() {
        Runtime rt = Runtime.getRuntime();
        return rt.totalMemory() - rt.freeMemory();
    }

    /**
     * 按"真实剩余堆"判断能否处理：比固定比例更准。
     *
     * @param srcW       已合并成品图的宽
     * @param srcH       高
     * @param scale      倍率
     * @param extraBytes 额外要预留的字节（例如原文档残留）
     */
    public static boolean canHandleNow(int srcW, int srcH, double scale, long extraBytes) {
        // 说明：这里只做"明显的物理上限"判断（成品图必须能装进整个堆），
        // 不再猜"能释放多少"。真实的可行性在超分过程中按剩余内存动态处理：
        // 见 upscalePixels 内的 backoff 逻辑（放不下就自动降档，而不是崩）。
        long outPixels = (long) Math.round(srcW * scale) * Math.round(srcH * scale);
        if (outPixels > MAX_OUTPUT_PIXELS) {
            return false;
        }
        long needBytes = outPixels * 4L;
        long maxHeap = Runtime.getRuntime().maxMemory();
        // 成品图至少要能占堆的 85%（留 15% 给源图、分块缓冲和运行时）
        return needBytes <= maxHeap * 0.85;
    }

    /** 输出单边是否超限。 */
    public static boolean sideExceeded(int srcW, int srcH, double scale) {
        long dw = Math.round(srcW * scale);
        long dh = Math.round(srcH * scale);
        return dw > MAX_SIDE || dh > MAX_SIDE;
    }

    /** 建议的最大整数倍率（不超过单边限制）。 */
    public static int maxSafeScale(int srcW, int srcH) {
        return Math.max(1, (int) Math.floor((double) MAX_SIDE / Math.max(srcW, srcH)));
    }

    /** 给定源尺寸和倍率，能否安全处理。 */
    public static boolean canHandle(int srcW, int srcH, double scale) {
        long outPixels = Math.round(srcW * scale) * Math.round(srcH * scale);
        return outPixels <= capacityPixels();
    }

    // ==================== 纯数组入口（可离线测试） ====================

    /**
     * 放大 ARGB 像素数组。返回长度 = dstW * dstH 的新数组，src 不改动。
     */
    public static int[] upscalePixels(int[] src, int w, int h, Options opt) {
        if (src == null || w <= 0 || h <= 0) {
            throw new IllegalArgumentException("bad source");
        }
        if (src.length < w * h) {
            throw new IllegalArgumentException("src too short: " + src.length + " < " + (w * h));
        }
        if (opt == null) {
            opt = new Options();
        }
        double scale = opt.scale;
        if (scale < 1.0) {
            scale = 1.0;
        }
        if (scale > 8.0) {
            scale = 8.0;
        }
        int dstW = (int) Math.round(w * scale);
        int dstH = (int) Math.round(h * scale);
        if (dstW < 1) {
            dstW = 1;
        }
        if (dstH < 1) {
            dstH = 1;
        }
        long total = (long) dstW * dstH;
        if (total > MAX_OUTPUT_PIXELS) {
            throw new IllegalArgumentException(
                    "output too large: " + dstW + "x" + dstH + " = " + total + " px (limit "
                            + MAX_OUTPUT_PIXELS + ")");
        }
        if (dstW == w && dstH == h) {
            int[] same = new int[w * h];
            System.arraycopy(src, 0, same, 0, w * h);
            if (opt.usm && opt.usmAmount > 0) {
                return unsharpMaskInternal(same, w, h, opt.usmRadius, opt.usmAmount,
                        opt.usmThreshold, isOpaque(same, w * h));
            }
            return same;
        }

        final boolean opaque = isOpaque(src, w * h);
        final int dw = dstW;

        // 分配成品图前确保有足够连续内存：不够就先 GC 一次再试
        long needBytes = (long) dstW * dstH * 4L;
        final int[] out = tryAlloc(needBytes, dstW * dstH);
        if (out == null) {
            throw new OutOfMemoryError("cannot allocate output " + dstW + "x" + dstH);
        }

        // 是否整图一次算完（够小就走原路径，最快）
        long wholeCost = estimateCost(dstW, dstH + usmPad(opt), opt);
        if (wholeCost <= memoryBudget()) {
            resample(src, w, h, dstW, dstH, opaque, new RowSink() {
                public void rows(int startRow, int[] pixels, int count) {
                    System.arraycopy(pixels, 0, out, startRow * dw, count * dw);
                }
            });
            if (opt.usm && opt.usmAmount > 0) {
                int[] sharpened = unsharpMaskInternal(out, dstW, dstH, opt.usmRadius,
                        opt.usmAmount, opt.usmThreshold, opaque);
                return sharpened;
            }
            return out;
        }

        // 大图：切成带边距的块，逐块放大 + 锐化，直接写进输出。
        // 每块都带足邻域边距，接缝处的值与整图一次算完全一致。
        int bs = blockPxSize(memoryBudget(), opt);
        for (int by = 0; by < dstH; by += bs) {
            int bh = Math.min(bs, dstH - by);
            for (int bx = 0; bx < dstW; bx += bs) {
                int bw = Math.min(bs, dstW - bx);
                upscaleBlock(src, w, h, bx, by, bw, bh, scale, opt, opaque, out, dstW, dstH);
            }
        }
        return out;
    }

    /** 申请大的 int 数组，失败时先 GC 再试一次。 */
    private static int[] tryAlloc(long needBytes, int length) {
        try {
            return new int[length];
        } catch (OutOfMemoryError e) {
            System.gc();
            System.runFinalization();
            try {
                return new int[length];
            } catch (OutOfMemoryError e2) {
                return null;
            }
        }
    }

    /** 按内存预算算每边最多处理多少输出像素（再留锐化边距）。 */
    private static int blockPxSize(long budget, Options opt) {
        if (sForceBlockPx > 0) {
            return sForceBlockPx;
        }
        // 块内峰值 ≈ 输出块(4B/px) + 源子图(4B/px÷scale²) + 锐化缓冲(约12B/px)
        // 按 24 字节/像素留足余量，再扣掉 6MB 杂项（JVM/临时对象）
        long usable = Math.max(6L * 1024 * 1024, budget - 6L * 1024 * 1024);
        long px = usable / 24L;
        if (px < 256L * 256L) px = 256L * 256L;
        int side = (int) Math.sqrt((double) px);
        if (side > 1536) side = 1536;
        int pad = usmPad(opt) * 2;
        if (side < pad * 4) side = pad * 4;
        return side;
    }

    /**
     * 处理一个输出块 [bx,bx+bw) x [by,by+bh)：
     * 算出这块所需的源范围（含锐化边距），只处理这一小片，写进 out 的对应位置。
     */
    private static void upscaleBlock(int[] src, int sw, int sh,
                                     int bx, int by, int bw, int bh,
                                     double scale, Options opt, boolean opaque,
                                     int[] out, int dstW, int dstH) {
        int pad = usmPad(opt);

        // 1) 本块需要产出的输出范围（含锐化边距）
        int ex0 = Math.max(0, bx - pad);
        int ey0 = Math.max(0, by - pad);
        int ex1 = Math.min(dstW, bx + bw + pad);
        int ey1 = Math.min(dstH, by + bh + pad);
        if (ex1 <= ex0 || ey1 <= ey0) return;

        // 2) 反推源范围：再多留 2px，保证权重表的首尾夹紧与整图一致
        int sx0 = clamp((int) Math.floor(ex0 / scale) - 2, 0, sw - 1);
        int sy0 = clamp((int) Math.floor(ey0 / scale) - 2, 0, sh - 1);
        int sx1 = clamp((int) Math.ceil(ex1 / scale) + 2, 0, sw);
        int sy1 = clamp((int) Math.ceil(ey1 / scale) + 2, 0, sh);
        int cw = sx1 - sx0;
        int chh = sy1 - sy0;
        if (cw <= 0 || chh <= 0) return;

        // 3) 拷出这块源图（多留的边在采样时用 clamp 复制，结果与整图一致）
        int[] sub = new int[cw * chh];
        for (int y = 0; y < chh; y++) {
            System.arraycopy(src, (sy0 + y) * sw + sx0, sub, y * cw, cw);
        }

        // 4) 子图按“整图输出坐标”对齐：子图原点对应整图输出坐标 (sx0,sy0)*scale 取整
        //    为保证与整图重采样坐标一致，这里用整图坐标直接算每个输出点的采样位置，
        //    所以子图输出尺寸按整图坐标区间 [ex0,ex1) x [ey0,ey1) 反推。
        int baseX = (int) Math.round(sx0 * scale);
        int baseY = (int) Math.round(sy0 * scale);
        int subOutW = Math.max(1, (int) Math.round(cw * scale) + 1);
        int subOutH = Math.max(1, (int) Math.round(chh * scale) + 1);
        int[] blockPx = resampleAligned(sub, cw, chh, subOutW, subOutH, opaque,
                                        baseX, baseY, scale);

        if (opt.usm && opt.usmAmount > 0 && pad > 0) {
            blockPx = unsharpMaskInternal(blockPx, subOutW, subOutH, opt.usmRadius,
                    opt.usmAmount, opt.usmThreshold, opaque);
        }

        // 5) 只把本块自己的输出范围拷进最终结果
        for (int y = by; y < by + bh; y++) {
            int sy = y - baseY;
            if (sy < 0 || sy >= subOutH) continue;
            int dstRow = y * dstW;
            int srcRow = sy * subOutW;
            int xs = Math.max(bx, baseX);
            int xe = Math.min(bx + bw, baseX + subOutW);
            for (int x = xs; x < xe; x++) {
                out[dstRow + x] = blockPx[srcRow + (x - baseX)];
            }
        }
    }

    /**
     * 与整图坐标对齐的重采样：输出像素 (gx,gy) 的采样中心按整图公式
     * center = (gx + 0.5) / scale - 0.5 计算，再换算到子图坐标系。
     * 这样每块的相位与整图完全一致，接缝不会错位。
     */
    private static int[] resampleAligned(int[] sub, int cw, int chh, int outW, int outH,
                                         boolean opaque, int baseX, int baseY, double scale) {
        Axis ax = buildAxisWithPhase(cw, outW, scale, baseX);
        Axis ay = buildAxisWithPhase(chh, outH, scale, baseY);
        int[] out = new int[outW * outH];
        resampleBand(sub, cw, chh, outW, outH, 0, outH, ax, ay, out, opaque);
        return out;
    }

    /** 锐化需要的边距（输出像素）。 */
    private static int usmPad(Options opt) {
        if (opt == null || !opt.usm || opt.usmAmount <= 0) return 0;
        double sigma = opt.usmRadius > 0.1 ? opt.usmRadius : 0.1;
        int r = (int) Math.ceil(3.0 * sigma);
        if (r < 1) r = 1;
        if (r > 32) r = 32;
        return r;
    }

    /** 估算处理一块 dstW x dstH 需要多少字节（经验值）。 */
    private static long estimateCost(int dstW, int dstH, Options opt) {
        long px = (long) dstW * dstH;
        return px * 16L + 8L * 1024 * 1024;
    }

    /** 当前可用的处理预算：默认堆的一半。 */
    private static long memoryBudget() {
        long max = Runtime.getRuntime().maxMemory();
        return Math.max(24L * 1024 * 1024, max / 2);
    }

    // ==================== Lanczos3 重采样 ====================

    /** 轴向权重表：每个输出位置对应若干源位置和归一化定点权重。 */
    private static final class Axis {
        final int[][] taps;
        final int[][] weights;

        Axis(int dstLen) {
            taps = new int[dstLen][];
            weights = new int[dstLen][];
        }
    }

    private static Axis buildAxis(int srcLen, int dstLen, double scale) {
        return buildAxisWithPhase(srcLen, dstLen, scale, 0);
    }

    /**
     * 构建权重表。
     *
     * @param globalBase 输出轴在整图中的起点（分块时为块的全局输出坐标）。
     *                   采样中心按整图公式算完再平移到子图坐标，保证相位一致。
     */
    private static Axis buildAxisWithPhase(int srcLen, int dstLen, double scale, int globalBase) {
        return buildAxisWithPhase(srcLen, dstLen, scale, globalBase, 0);
    }

    /**
     * @param globalBase 输出轴在整图中的起点（用于确定采样相位）
     * @param srcBase    子图源行/列在整图中的起点（分块时非 0）
     */
    private static Axis buildAxisWithPhase(int srcLen, int dstLen, double scale,
                                           int globalBase, int srcBase) {
        Axis axis = new Axis(dstLen);
        // 缩小的时候要把核撑宽，否则会混叠；放大时保持 a=3。
        double widen = scale < 1.0 ? 1.0 / scale : 1.0;
        double radius = LANCZOS_A * widen;

        for (int d = 0; d < dstLen; d++) {
            int g = d + globalBase;
            // 整图输出坐标 g 对应的整图源坐标，再减掉子图起点得到子图内坐标
            double center = (g + 0.5) / scale - 0.5 - srcBase;
            int left = (int) Math.ceil(center - radius);
            int right = (int) Math.floor(center + radius);
            int n = right - left + 1;
            if (n < 1) {
                n = 1;
                left = (int) Math.round(center);
            }
            double[] tmp = new double[n];
            double sum = 0.0;
            for (int i = 0; i < n; i++) {
                double x = ((left + i) - center) / widen;
                double v = lanczos3(x);
                tmp[i] = v;
                sum += v;
            }
            if (sum == 0.0) {
                int ni = clamp(left, 0, srcLen - 1);
                axis.taps[d] = new int[]{ni};
                axis.weights[d] = new int[]{FIX_ONE};
                continue;
            }
            int[] t = new int[n];
            int[] wt = new int[n];
            int acc = 0;
            int maxAt = 0;
            for (int i = 0; i < n; i++) {
                t[i] = clamp(left + i, 0, srcLen - 1);
                wt[i] = (int) Math.round(tmp[i] / sum * FIX_ONE);
                acc += wt[i];
                if (wt[i] > wt[maxAt]) {
                    maxAt = i;
                }
            }
            wt[maxAt] += FIX_ONE - acc;
            axis.taps[d] = t;
            axis.weights[d] = wt;
        }
        return axis;
    }

    private static double lanczos3(double x) {
        if (x < 0) {
            x = -x;
        }
        if (x >= LANCZOS_A) {
            return 0.0;
        }
        if (x < 1e-9) {
            return 1.0;
        }
        double px = Math.PI * x;
        return (Math.sin(px) / px) * (Math.sin(px / LANCZOS_A) / (px / LANCZOS_A));
    }

    /** 流式接收重采样结果。 */
    private interface RowSink {
        void rows(int startRow, int[] pixels, int count);
    }

    private static void resample(int[] src, int w, int h, int dstW, int dstH, boolean opaque,
                                 final RowSink sink) {
        final double scaleX = (double) dstW / w;
        final double scaleY = (double) dstH / h;
        final Axis ax = buildAxis(w, dstW, scaleX);
        final Axis ay = buildAxis(h, dstH, scaleY);
        final boolean op = opaque;
        final int[] s = src;
        final int sw = w;
        final int sh = h;
        final int dw = dstW;
        final int dh = dstH;

        parallelRows(dstH, new BandTask() {
            public void run(int from, int to) {
                int ys = from;
                while (ys < to) {
                    int ye = Math.min(ys + STRIP_ROWS, to);
                    int n = ye - ys;
                    int[] band = new int[n * dw];
                    resampleBand(s, sw, sh, dw, dh, ys, ye, ax, ay, band, op);
                    synchronized (sink) {
                        sink.rows(ys, band, n);
                    }
                    ys = ye;
                }
            }
        });
    }

    private static void resampleBand(int[] src, int w, int h, int dstW, int dstH,
                                     int fromRow, int toRow, Axis ax, Axis ay, int[] out,
                                     boolean opaque) {
        int ch = opaque ? 3 : 4;
        int ys = fromRow;
        while (ys < toRow) {
            int ye = Math.min(ys + STRIP_ROWS, toRow);
            int minSrc = Integer.MAX_VALUE;
            int maxSrc = Integer.MIN_VALUE;
            for (int y = ys; y < ye; y++) {
                int[] t = ay.taps[y];
                for (int k = 0; k < t.length; k++) {
                    if (t[k] < minSrc) {
                        minSrc = t[k];
                    }
                    if (t[k] > maxSrc) {
                        maxSrc = t[k];
                    }
                }
            }
            int rows = maxSrc - minSrc + 1;
            byte[] tmp = new byte[rows * dstW * ch];

            int o = 0;
            for (int r = 0; r < rows; r++) {
                int base = (minSrc + r) * w;
                for (int d = 0; d < dstW; d++) {
                    int[] t = ax.taps[d];
                    int[] wt = ax.weights[d];
                    int sa = 0, sr = 0, sg = 0, sb = 0;
                    for (int k = 0; k < t.length; k++) {
                        int p = src[base + t[k]];
                        int kk = wt[k];
                        sr += ((p >> 16) & 0xFF) * kk;
                        sg += ((p >> 8) & 0xFF) * kk;
                        sb += (p & 0xFF) * kk;
                        if (!opaque) {
                            sa += ((p >>> 24) & 0xFF) * kk;
                        }
                    }
                    if (!opaque) {
                        tmp[o++] = (byte) clamp((sa + FIX_HALF) >> FIX_BITS, 0, 255);
                    }
                    tmp[o++] = (byte) clamp((sr + FIX_HALF) >> FIX_BITS, 0, 255);
                    tmp[o++] = (byte) clamp((sg + FIX_HALF) >> FIX_BITS, 0, 255);
                    tmp[o++] = (byte) clamp((sb + FIX_HALF) >> FIX_BITS, 0, 255);
                }
            }

            for (int y = ys; y < ye; y++) {
                int[] t = ay.taps[y];
                int[] wt = ay.weights[y];
                int dstBase = (y - fromRow) * dstW;
                for (int d = 0; d < dstW; d++) {
                    int sa = 0, sr = 0, sg = 0, sb = 0;
                    for (int k = 0; k < t.length; k++) {
                        int ti = ((t[k] - minSrc) * dstW + d) * ch;
                        int kk = wt[k];
                        if (opaque) {
                            sr += (tmp[ti] & 0xFF) * kk;
                            sg += (tmp[ti + 1] & 0xFF) * kk;
                            sb += (tmp[ti + 2] & 0xFF) * kk;
                        } else {
                            sa += (tmp[ti] & 0xFF) * kk;
                            sr += (tmp[ti + 1] & 0xFF) * kk;
                            sg += (tmp[ti + 2] & 0xFF) * kk;
                            sb += (tmp[ti + 3] & 0xFF) * kk;
                        }
                    }
                    int ia = opaque ? 0xFF : clamp((sa + FIX_HALF) >> FIX_BITS, 0, 255);
                    int ir = clamp((sr + FIX_HALF) >> FIX_BITS, 0, 255);
                    int ig = clamp((sg + FIX_HALF) >> FIX_BITS, 0, 255);
                    int ib = clamp((sb + FIX_HALF) >> FIX_BITS, 0, 255);
                    out[dstBase + d] = (ia << 24) | (ir << 16) | (ig << 8) | ib;
                }
            }
            ys = ye;
        }
    }

    // ==================== USM 锐化 ====================

    /**
     * Unsharp Mask。只锐化 RGB，不锐化 alpha（避免边缘出现半透明光晕）。
     */
    public static int[] unsharpMask(int[] src, int w, int h, double radius, double amount,
                                    int threshold) {
        if (src == null || w <= 0 || h <= 0 || amount <= 0.0) {
            return src;
        }
        return unsharpMaskInternal(src, w, h, radius, amount, threshold, isOpaque(src, w * h));
    }

    private static int[] unsharpMaskInternal(int[] src, final int w, final int h,
                                             double radius, double amount, int threshold,
                                             boolean opaque) {
        if (src == null || w <= 0 || h <= 0 || amount <= 0.0) {
            return src;
        }
        double sigma = radius > 0.1 ? radius : 0.1;
        int r = (int) Math.ceil(3.0 * sigma);
        if (r < 1) {
            r = 1;
        }
        if (r > 32) {
            r = 32;
        }
        final int[] kernel = gaussianKernelFixed(sigma, r);
        final int rr = r;
        final int taps = r * 2 + 1;
        final int ch = opaque ? 3 : 4;

        // 水平方向的抽头索引表（所有行复用）
        final int[] xIdx = new int[w * taps];
        for (int i = 0; i < taps; i++) {
            int off = i - r;
            for (int x = 0; x < w; x++) {
                xIdx[i * w + x] = clamp(x + off, 0, w - 1);
            }
        }

        int amt = (int) Math.round(amount * 256.0);
        if (amt < 0) {
            amt = 0;
        }
        final int amtF = amt;
        final int th = threshold < 0 ? 0 : threshold;

        final int[] out = new int[w * h];
        final int[] s = src;
        final boolean op = opaque;

        parallelRows(h, new BandTask() {
            public void run(int from, int to) {
                unsharpBand(s, w, from, to, h, rr, taps, kernel, xIdx, amtF, th, out, op, ch);
            }
        });
        return out;
    }

    private static void unsharpBand(int[] src, int w, int fromRow, int toRow, int h,
                                    int r, int taps, int[] kernel, int[] xIdx,
                                    int amt, int th, int[] out, boolean opaque, int ch) {
        // 水平模糊缓冲：值域 0..255，带 HB_BITS 位小数，short 足够（<=255*64）
        short[] hb = new short[(STRIP_ROWS + 2 * r) * w * ch];
        int[] acc = new int[w * ch];

        int ys = fromRow;
        while (ys < toRow) {
            int ye = Math.min(ys + STRIP_ROWS, toRow);
            int hbRows = (ye - ys) + 2 * r;
            if (hb.length < hbRows * w * ch) {
                hb = new short[hbRows * w * ch];
            }

            // ---- 水平模糊 ----
            for (int k = 0; k < hbRows; k++) {
                int row = clamp(ys - r + k, 0, h - 1);
                int rowBase = row * w;
                java.util.Arrays.fill(acc, 0);
                for (int i = 0; i < taps; i++) {
                    int kk = kernel[i];
                    int xb = i * w;
                    if (opaque) {
                        for (int x = 0; x < w; x++) {
                            int p = src[rowBase + xIdx[xb + x]];
                            int o3 = x * 3;
                            acc[o3] += ((p >> 16) & 0xFF) * kk;
                            acc[o3 + 1] += ((p >> 8) & 0xFF) * kk;
                            acc[o3 + 2] += (p & 0xFF) * kk;
                        }
                    } else {
                        for (int x = 0; x < w; x++) {
                            int p = src[rowBase + xIdx[xb + x]];
                            int o4 = x * 4;
                            acc[o4] += ((p >>> 24) & 0xFF) * kk;
                            acc[o4 + 1] += ((p >> 16) & 0xFF) * kk;
                            acc[o4 + 2] += ((p >> 8) & 0xFF) * kk;
                            acc[o4 + 3] += (p & 0xFF) * kk;
                        }
                    }
                }
                int o = k * w * ch;
                int n = w * ch;
                int shift = K_BITS - HB_BITS;
                int half = 1 << (shift - 1);
                for (int x = 0; x < n; x++) {
                    // acc 是 K_BITS 位定点，右移若干位变成 HB_BITS 位小数
                    hb[o + x] = (short) ((acc[x] + half) >> shift);
                }
            }

            // ---- 垂直模糊 + 合成 ----
            for (int y = ys; y < ye; y++) {
                java.util.Arrays.fill(acc, 0);
                // hb 第 k 行对应源行 (ys-r+k)；输出行 y 的抽头 i 对应源行 y+i-r
                int hbBase = (y - ys) * w * ch;
                int n = w * ch;
                for (int i = 0; i < taps; i++) {
                    int kk = kernel[i];
                    int ro = hbBase + i * w * ch;
                    for (int x = 0; x < n; x++) {
                        acc[x] += hb[ro + x] * kk;
                    }
                }
                int base = y * w;
                if (opaque) {
                    for (int x = 0; x < w; x++) {
                        int o3 = x * 3;
                        int br = (acc[o3] + VERT_HALF) >> VERT_BITS;
                        int bg = (acc[o3 + 1] + VERT_HALF) >> VERT_BITS;
                        int bb = (acc[o3 + 2] + VERT_HALF) >> VERT_BITS;

                        int p = src[base + x];
                        int rr2 = (p >> 16) & 0xFF;
                        int gg = (p >> 8) & 0xFF;
                        int bl = p & 0xFF;
                        int dr = rr2 - br;
                        int dg = gg - bg;
                        int db = bl - bb;
                        int nr = rr2;
                        int ng = gg;
                        int nb = bl;
                        if (dr >= th || -dr >= th) {
                            nr = clamp(rr2 + ((dr * amt) >> 8), 0, 255);
                        }
                        if (dg >= th || -dg >= th) {
                            ng = clamp(gg + ((dg * amt) >> 8), 0, 255);
                        }
                        if (db >= th || -db >= th) {
                            nb = clamp(bl + ((db * amt) >> 8), 0, 255);
                        }
                        out[base + x] = 0xFF000000 | (nr << 16) | (ng << 8) | nb;
                    }
                } else {
                    for (int x = 0; x < w; x++) {
                        int o4 = x * 4;
                        int br = (acc[o4 + 1] + VERT_HALF) >> VERT_BITS;
                        int bg = (acc[o4 + 2] + VERT_HALF) >> VERT_BITS;
                        int bb = (acc[o4 + 3] + VERT_HALF) >> VERT_BITS;

                        int p = src[base + x];
                        int a = (p >>> 24) & 0xFF;
                        int rr2 = (p >> 16) & 0xFF;
                        int gg = (p >> 8) & 0xFF;
                        int bl = p & 0xFF;
                        int dr = rr2 - br;
                        int dg = gg - bg;
                        int db = bl - bb;
                        int nr = rr2;
                        int ng = gg;
                        int nb = bl;
                        if (dr >= th || -dr >= th) {
                            nr = clamp(rr2 + ((dr * amt) >> 8), 0, 255);
                        }
                        if (dg >= th || -dg >= th) {
                            ng = clamp(gg + ((dg * amt) >> 8), 0, 255);
                        }
                        if (db >= th || -db >= th) {
                            nb = clamp(bl + ((db * amt) >> 8), 0, 255);
                        }
                        // alpha 不参与锐化，原样保留
                        out[base + x] = (a << 24) | (nr << 16) | (ng << 8) | nb;
                    }
                }
            }
            ys = ye;
        }
    }

    // ==================== 并行 / 工具 ====================

    private interface BandTask {
        void run(int from, int to);
    }

    /** 把 [0, rows) 切成若干段并行跑；线程数受限，出错则回退单线程。 */
    private static void parallelRows(int rows, BandTask task) {
        int cores = Runtime.getRuntime().availableProcessors();
        int limit = sLightThreads.get();
        int threads = Math.min(MAX_THREADS, cores);
        if (limit > 0 && threads > limit) {
            threads = limit;
        }
        if (!sParallel || threads <= 1 || rows < STRIP_ROWS * 2) {
            task.run(0, rows);
            return;
        }
        Thread[] ts = new Thread[threads];
        final Throwable[] workerError = new Throwable[threads];
        for (int i = 0; i < threads; i++) {
            final int from = (int) ((long) rows * i / threads);
            final int to = (int) ((long) rows * (i + 1) / threads);
            final int idx = i;
            final BandTask t = task;
            ts[i] = new Thread(new Runnable() {
                public void run() {
                    try {
                        t.run(from, to);
                    } catch (Throwable e) {
                        // 并行线程里的 OOM 等异常不能悄悄丢弃
                        workerError[idx] = e;
                    }
                }
            }, "sr-band-" + i);
            ts[i].start();
        }
        boolean interrupted = false;
        Throwable thrown = null;
        for (int i = 0; i < threads; i++) {
            try {
                ts[i].join();
            } catch (InterruptedException e) {
                interrupted = true;
            }
            if (workerError[i] != null && thrown == null) {
                thrown = workerError[i];
            }
        }
        if (interrupted) {
            Thread.currentThread().interrupt();
        }
        if (thrown != null) {
            if (thrown instanceof RuntimeException) {
                throw (RuntimeException) thrown;
            }
            if (thrown instanceof Error) {
                throw (Error) thrown;
            }
            throw new RuntimeException(thrown);
        }
    }

    private static boolean isOpaque(int[] src, int n) {
        for (int i = 0; i < n; i++) {
            if ((src[i] >>> 24) != 0xFF) {
                return false;
            }
        }
        return true;
    }

    private static int clamp(int v, int lo, int hi) {
        if (v < lo) {
            return lo;
        }
        if (v > hi) {
            return hi;
        }
        return v;
    }

    private static int[] gaussianKernelFixed(double sigma, int r) {
        int n = r * 2 + 1;
        int[] k = new int[n];
        double twoSigma2 = 2.0 * sigma * sigma;
        double[] d = new double[n];
        double sum = 0.0;
        for (int i = 0; i < n; i++) {
            double dd = i - r;
            double v = Math.exp(-(dd * dd) / twoSigma2);
            d[i] = v;
            sum += v;
        }
        int acc = 0;
        int maxAt = 0;
        for (int i = 0; i < n; i++) {
            k[i] = (int) Math.round(d[i] / sum * K_ONE);
            acc += k[i];
            if (k[i] > k[maxAt]) {
                maxAt = i;
            }
        }
        k[maxAt] += K_ONE - acc;
        return k;
    }
}
