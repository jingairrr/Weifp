package com.sertrt.weifp;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.FileObserver;
import android.os.IBinder;
import java.io.File;

/**
 * 后台指令监听服务。
 *
 * 用 FileObserver 盯着命令目录，一出现 command.json 就执行。
 * 这样 AI 写完指令，不用等用户手动去点。
 *
 * 重要限制（和用户约好的）：
 *   - 只在本次 App 运行期间有效
 *   - 用户关掉设置开关就停
 *   - App 被系统杀死后不强制重启（不申请前台服务，避免常驻耗电）
 *   - 重启设备后需要重新打开 App
 *
 * 这是刻意设计：不常驻后台，把控制权留给用户。
 */
public class CommandWatchService extends Service {

    public static final String PREF = "weifp_theme";
    public static final String KEY_WATCH = "ai_watch_enabled";
    /** 开启时刻（毫秒）。超过 24 小时自动关闭。 */
    public static final String KEY_WATCH_START = "ai_watch_start";
    /** 最长有效时间：24 小时。 */
    public static final long MAX_WATCH_MS = 24L * 60 * 60 * 1000;

    private FileObserver dirObserver = null;
    /** 上次触发时间，用于防抖。 */
    private long lastTriggerTime = 0L;
    private static final long TRIGGER_DEBOUNCE_MS = 500L;

    public static boolean isEnabled(Context ctx) {
        try {
            return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .getBoolean(KEY_WATCH, false);
        } catch (Throwable t) {
            return false;
        }
    }

    public static void setEnabled(Context ctx, boolean on) {
        try {
            android.content.SharedPreferences.Editor e =
                    ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit();
            e.putBoolean(KEY_WATCH, on);
            if (on) {
                e.putLong(KEY_WATCH_START, System.currentTimeMillis());
            } else {
                e.remove(KEY_WATCH_START);
            }
            e.commit();
        } catch (Throwable ignored) {}
    }

    /**
     * 开关是否仍然有效：开着且在 24 小时内。
     * 超时就自动关掉并返回 false。
     */
    public static boolean isActive(Context ctx) {
        if (!isEnabled(ctx)) return false;
        try {
            long start = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .getLong(KEY_WATCH_START, 0L);
            if (start <= 0L) return false;
            if (System.currentTimeMillis() - start > MAX_WATCH_MS) {
                setEnabled(ctx, false);
                return false;
            }
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 按当前开关状态启动或停止服务。 */
    public static void apply(Context ctx) {
        if (ctx == null) return;
        try {
            Intent i = new Intent(ctx, CommandWatchService.class);
            if (isActive(ctx)) {
                ctx.startService(i);
            } else {
                ctx.stopService(i);
            }
        } catch (Throwable ignored) {}
    }

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            // 前台服务：让系统不轻易杀掉，同时在状态栏给用户一个明确提示
            android.app.Notification n;
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationChannel ch =
                        new android.app.NotificationChannel("weifp_ai_watch",
                                "AI 指令监听", android.app.NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("AI 指令后台监听运行中");
                android.app.NotificationManager nm =
                        (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (nm != null) nm.createNotificationChannel(ch);
                n = new android.app.Notification.Builder(this, "weifp_ai_watch")
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle("Weifp 正在监听 AI 指令")
                        .setContentText("最多 24 小时，可随时在设置里关闭")
                        .setOngoing(true)
                        .build();
            } else {
                n = new android.app.Notification.Builder(this)
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle("Weifp 正在监听 AI 指令")
                        .setContentText("最多 24 小时，可随时在设置里关闭")
                        .setOngoing(true)
                        .build();
            }
            startForeground(1002, n);
        } catch (Throwable t) {
            try { CrashLogger.log("前台服务启动失败", t); } catch (Throwable ignored) {}
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 每次都检查是否过期（超过 24 小时就自己停掉）
        if (!isActive(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startWatching();
        scheduleExpiryCheck();
        return START_NOT_STICKY;
    }

    /** 定时检查是否过期（每小时查一次就够）。 */
    private void scheduleExpiryCheck() {
        try {
            android.os.Handler h = new android.os.Handler();
            h.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (!isActive(CommandWatchService.this)) {
                            stopSelf();
                        } else {
                            scheduleExpiryCheck();
                        }
                    }
                }, 60L * 60L * 1000L);
        } catch (Throwable ignored) {}
    }

    private void startWatching() {
        stopWatching();
        try {
            File dir = CommandBridge.dir();
            if (dir == null) return;
            final String target = CommandBridge.CMD_FILE;
            // 只监听 CLOSE_WRITE：文件写完关闭时触发一次。
            // 监听 MODIFY 会在写入过程中触发多次，导致同一条指令被执行好几遍。
            dirObserver = new FileObserver(dir.getAbsolutePath(),
                    FileObserver.CLOSE_WRITE | FileObserver.MOVED_TO) {
                @Override public void onEvent(int event, String path) {
                    try {
                        CrashLogger.logInfo("监听", "事件 event=" + event + " path=" + path);
                    } catch (Throwable ignored) {}
                    if (path == null) return;
                    if (!target.equals(path)) return;
                    // 防抖：500ms 内的多次事件只处理一次
                    long now = System.currentTimeMillis();
                    if (now - lastTriggerTime < TRIGGER_DEBOUNCE_MS) return;
                    lastTriggerTime = now;
                    handleTrigger();
                }
            };
            dirObserver.startWatching();
            try {
                CrashLogger.logInfo("监听", "开始监听目录: " + dir.getAbsolutePath()
                        + " 目标文件: " + target);
            } catch (Throwable ignored) {}
        } catch (Throwable t) {
            try { CrashLogger.log("指令监听启动失败", t); } catch (Throwable ignored) {}
        }
    }

    private void stopWatching() {
        try {
            if (dirObserver != null) dirObserver.stopWatching();
        } catch (Throwable ignored) {}
        dirObserver = null;
    }

    /** 收到文件变化：按模式处理。 */
    private void handleTrigger() {
        new Thread(new Runnable() {
                @Override public void run() {
                    try { Thread.sleep(600); } catch (Throwable ignored) {}  // 等写完
                    if (!CommandBridge.hasPending()) return;
                    int mode = ThemeManager.getAiExecMode(CommandWatchService.this);
                    if (mode == ThemeManager.AI_EXEC_OFF) return;
                    if (mode == ThemeManager.AI_EXEC_ASK) {
                        // 后台没法弹窗，改为发通知提醒用户打开 App
                        notifyPending();
                        return;
                    }
                    CommandExecutor.Result r =
                            CommandBridge.runPending(CommandWatchService.this);
                    if (r != null && r.ok && r.outputPath != null) {
                        try {
                            HistoryManager.importExternalImage(CommandWatchService.this,
                                    new File(r.outputPath), r.adjustments);
                        } catch (Throwable ignored) {}
                    }
                }
            }).start();
    }

    /** 发一条通知，提醒用户有待确认的指令。 */
    private void notifyPending() {
        try {
            android.app.NotificationManager nm =
                    (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            android.app.Notification.Builder b = new android.app.Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.ic_dialog_info);
            b.setContentTitle("Weifp 有 AI 指令待确认");
            b.setContentText("打开 Weifp 确认执行");
            b.setAutoCancel(true);
            nm.notify(1001, b.build());
        } catch (Throwable ignored) {}
    }

    @Override
    public void onDestroy() {
        stopWatching();
        try {
            // 退出前台状态并把通知撤掉，否则状态栏会留一条僵尸通知
            stopForeground(true);
        } catch (Throwable ignored) {}
        try {
            android.app.NotificationManager nm =
                    (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(1002);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
