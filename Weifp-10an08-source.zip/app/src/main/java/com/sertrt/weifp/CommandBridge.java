package com.sertrt.weifp;

import android.os.Environment;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 指令接口：通过 JSON 文件和外部交互。
 *
 * 协议（放在公共下载目录）：
 *
 *   /sdcard/Download/Weifp/命令.json
 *   {
 *     "id": "任意标识",
 *     "input": "/sdcard/DCIM/photo.jpg",
 *     "output": "/sdcard/Download/Weifp/out.jpg",
 *     "cmds": [
 *        {"cmd":"brightness", "value":50},
 *        {"cmd":"rotate", "value":90}
 *     ]
 *   }
 *
 *   执行完写回：
 *   /sdcard/Download/Weifp/结果.json
 *   {"id":"...","ok":true,"output":"...","message":"完成"}
 *
 * 使用方式：把命令.json 放进去 → 打开 Weifp → 自动执行 → 看结果.json
 */
public final class CommandBridge {

    public static final String DIR_NAME = "WeifpAI";
    public static final String CMD_FILE = "command.json";
    public static final String RESULT_FILE = "result.txt";
    public static final String DICT_FILE = "README.txt";
    /**
     * 说明书版本号。
     *
     * 每次改动指令集或说明内容就要 +1：
     * 应用启动时会比对文件里的版本，不一致就把旧文件备份成
     * README.old.txt 再写入新的，保证 AI 读到的永远是最新规格。
     */
    public static final int DOC_VERSION = 1;
    private static final String DOC_VERSION_PREFIX = "DOC_VERSION=";
    public static final String IMG_DIR = "images";
    public static final String DONE_DIR = "done";

    private CommandBridge() {
    }

    /** 指令目录（公共下载目录下的 Weifp）。 */
    public static File dir() {
        try {
            File d = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), DIR_NAME);
            if (!d.exists()) d.mkdirs();
            return d;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 已执行指令的归档目录（写不进去就返回 null，由调用方直接删文件）。 */
    public static File doneDir() {
        try {
            File d = dir();
            if (d == null) return null;
            File sub = new File(d, DONE_DIR);
            if (!sub.exists() && !sub.mkdirs()) return null;
            // 验证真的能写：分区存储下 mkdirs 可能"成功"但写入失败
            if (!sub.isDirectory() || !sub.canWrite()) return null;
            return sub;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 读文件里记录的说明书版本；没有返回 0。 */
    public static int readDocVersion(File doc) {
        if (doc == null || !doc.exists()) return 0;
        java.io.InputStream in = null;
        try {
            in = new java.io.FileInputStream(doc);
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.InputStreamReader(in, "UTF-8"));
            String line = br.readLine();
            br.close();
            in = null;
            if (line != null && line.startsWith(DOC_VERSION_PREFIX)) {
                return Integer.parseInt(line.substring(DOC_VERSION_PREFIX.length()).trim());
            }
        } catch (Throwable ignored) {
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
        }
        return 0;
    }

    /**
     * 检查并更新说明书。
     *
     * @return true 表示这次做了更新
     */
    public static boolean syncDoc(android.content.Context ctx) {
        try {
            File d = dir();
            if (d == null) return false;
            File doc = new File(d, DICT_FILE);
            int onDisk = readDocVersion(doc);
            if (doc.exists() && onDisk == DOC_VERSION) return false;

            // 旧文件备份一份，方便用户回看
            if (doc.exists()) {
                File old = new File(d, "README.old.txt");
                try {
                    if (old.exists()) old.delete();
                    doc.renameTo(old);
                } catch (Throwable ignored) {}
                doc = new File(d, DICT_FILE);
            }

            java.io.FileOutputStream fos = null;
            try {
                fos = new java.io.FileOutputStream(doc);
                fos.write(defaultDoc(ctx).getBytes("UTF-8"));
                fos.flush();
            } finally {
                try { if (fos != null) fos.close(); } catch (Throwable ignored) {}
            }
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 说明文件的完整路径（给用户复制用）。 */
    public static String docPath() {
        File d = dir();
        return d == null ? "" : new File(d, DICT_FILE).getAbsolutePath();
    }

    /** 放图片的子目录。 */
    public static File imageDir() {
        File d = dir();
        if (d == null) return null;
        File img = new File(d, IMG_DIR);
        if (!img.exists()) img.mkdirs();
        return img;
    }

    public static File cmdFile() {
        File d = dir();
        return d == null ? null : new File(d, CMD_FILE);
    }

    public static File resultFile() {
        File d = dir();
        return d == null ? null : new File(d, RESULT_FILE);
    }

    /**
     * 确保文件夹和说明文件存在（只在缺失时创建，不覆盖用户/AI 改过的内容）。
     */
    public static void ensureStructure(android.content.Context ctx) {
        try {
            File d = dir();
            if (d == null) return;
            imageDir();
            doneDir();
            File doc = new File(d, DICT_FILE);
            if (!doc.exists()) {
                java.io.FileOutputStream fos = null;
                try {
                    fos = new java.io.FileOutputStream(doc);
                    fos.write(defaultDoc(ctx).getBytes("UTF-8"));
                    fos.flush();
                } finally {
                    try { if (fos != null) fos.close(); } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {
        }
    }

    /**
     * 内置说明书内容：优先从 assets/weifp_ai_readme.txt 读（保证和文档同步），
     * 读不到就退回一个极简版本。
     */
    private static String defaultDoc(android.content.Context ctx) {
        if (ctx != null) {
            java.io.InputStream in = null;
            try {
                in = ctx.getAssets().open("weifp_ai_readme.txt");
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                String content = bos.toString("UTF-8");
                if (content != null && content.length() > 0) return content;
            } catch (Throwable ignored) {
            } finally {
                try { if (in != null) in.close(); } catch (Throwable ignored) {}
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append(DOC_VERSION_PREFIX).append(DOC_VERSION).append('\n');
        sb.append("Weifp AI Command Reference\n\n");
        sb.append("Write commands to ").append(CMD_FILE)
          .append(", put images in ").append(IMG_DIR).append("/.\n\n");
        sb.append("Format:\n{\n  \"image\": \"photo.jpg\",\n");
        sb.append("  \"commands\": [ {\"cmd\":\"brightness\", \"value\":30} ]\n}\n\n");
        sb.append("Available commands:\n");
        sb.append(CommandDict.describeAll());
        return sb.toString();
    }

    /** 是否有待执行的命令。 */
    public static boolean hasPending() {
        try {
            File f = cmdFile();
            return f != null && f.exists() && f.length() > 0;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 读取待执行命令的文字预览（给确认弹窗用）。 */
    public static String describePending() {
        try {
            File f = cmdFile();
            if (f == null || !f.exists()) return "";
            String json = readAll(f);
            if (json == null) return "";
            String input = Json.str(json, "input");
            List<CommandExecutor.Cmd> cmds = parseCmds(json);
            StringBuilder sb = new StringBuilder();
            sb.append("输入：").append(input == null ? "?" : input).append("\n\n指令：\n");
            for (int i = 0; i < cmds.size(); i++) {
                CommandExecutor.Cmd c = cmds.get(i);
                sb.append("  ").append(i + 1).append(". ").append(c.key);
                if (c.value != 0) sb.append(" = ").append((int) c.value);
                sb.append('\n');
            }
            return sb.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    /** 丢弃待执行命令（用户取消）。 */
    public static void discardPending() {
        try {
            File f = cmdFile();
            if (f != null) f.delete();
        } catch (Throwable ignored) {}
    }

    /** 执行命令文件里的指令，结果写回结果.json，然后删除命令文件。 */
    public static CommandExecutor.Result runPending() {
        return runPending(null);
    }

    /** 防止同一时刻重复执行（后台服务 + 前台检查可能撞车）。 */
    private static final java.util.concurrent.atomic.AtomicBoolean RUNNING =
            new java.util.concurrent.atomic.AtomicBoolean(false);

    public static CommandExecutor.Result runPending(android.content.Context ctx) {
        if (!RUNNING.compareAndSet(false, true)) {
            CrashLogger.logInfo("指令", "已有指令在执行，跳过本次");
            return null;
        }
        try {
            // 第二道保险：同样的内容（大小+修改时间）执行过一次就不再执行。
            // 防止归档失败、旋转屏幕、多入口并发等情况下重复跑同一份指令。
            File f = cmdFile();
            if (ctx != null && f != null && f.exists()) {
                String sig = f.length() + "|" + f.lastModified();
                android.content.SharedPreferences sp =
                        ctx.getSharedPreferences("weifp_ai_executed", android.content.Context.MODE_PRIVATE);
                if (sig.equals(sp.getString("last", ""))) {
                    CrashLogger.logInfo("指令", "这份指令已执行过，跳过");
                    try { f.delete(); } catch (Throwable ignored) {}
                    return null;
                }
                sp.edit().putString("last", sig).commit();
            }
            return doRunPending(ctx);
        } finally {
            RUNNING.set(false);
        }
    }

    private static CommandExecutor.Result doRunPending(android.content.Context ctx) {
        File cmd = cmdFile();
        CrashLogger.logInfo("指令", "检查命令文件: " + (cmd == null ? "null" : cmd.getAbsolutePath())
                + " 存在=" + (cmd != null && cmd.exists()));
        if (cmd == null || !cmd.exists()) return null;
        CommandExecutor.Result result = new CommandExecutor.Result();
        try {
            String json = readAll(cmd);
            if (json == null || json.trim().length() == 0) return null;

            // 英文键优先，兼容旧的中文键
            String input = Json.str(json, "image");
            if (input == null) input = Json.str(json, "图片");
            if (input == null) input = Json.str(json, "input");
            // 只写了文件名的话，去「图片」子目录找
            if (input != null && input.indexOf('/') < 0) {
                File img = imageDir();
                if (img != null) {
                    File f = new File(img, input);
                    if (f.exists()) input = f.getAbsolutePath();
                }
            }
            String output = Json.str(json, "输出");
            if (output == null) output = Json.str(json, "output");
            List<CommandExecutor.Cmd> cmds = parseCmds(json);

            if (input == null || input.length() == 0) {
                result.message = "命令文件缺少 input 字段";
            } else if (cmds.isEmpty()) {
                result.message = "命令文件里没有有效指令";
            } else {
                result = CommandExecutor.run(input, output, cmds, ctx);
            }
            writeResult(json, result);
            CrashLogger.logInfo("指令", "执行完成 ok=" + result.ok + " msg=" + result.message);
            // 归档到「已处理」子目录（带时间戳），然后删掉原文件
            archive(cmd);
            return result;
        } catch (Throwable t) {
            result.message = "解析命令失败: " + t;
            try { writeResult(null, result); } catch (Throwable ignored) {}
            return result;
        }
    }

    /** 解析 cmds 数组。 */
    static List<CommandExecutor.Cmd> parseCmds(String json) {
        List<CommandExecutor.Cmd> list = new ArrayList<CommandExecutor.Cmd>();
        try {
            int arr = json.indexOf("\"commands\"");
            if (arr < 0) arr = json.indexOf("\"指令\"");
            if (arr < 0) arr = json.indexOf("\"cmds\"");
            if (arr < 0) return list;
            int lb = json.indexOf('[', arr);
            int rb = json.lastIndexOf(']');
            if (lb < 0 || rb < 0 || rb <= lb) return list;
            String arrBody = json.substring(lb + 1, rb);

            int i = 0;
            while (i < arrBody.length()) {
                int ob = arrBody.indexOf('{', i);
                if (ob < 0) break;
                int oe = arrBody.indexOf('}', ob);
                if (oe < 0) break;
                String objBody = arrBody.substring(ob + 1, oe);
                CommandExecutor.Cmd c = new CommandExecutor.Cmd();

                String name = Json.str(objBody, "cmd");
                if (name == null) name = Json.str(objBody, "命令");
                if (name == null) name = Json.str(objBody, "指令");
                CommandDict.Def def = CommandDict.find(name);
                c.key = def != null ? def.key : name;

                c.value = (float) Json.num(objBody, "value", Json.num(objBody, "值", 0));
                c.text = Json.str(objBody, "text");
                if (c.text == null) c.text = Json.str(objBody, "name");
                c.x = (float) Json.num(objBody, "x", 0);
                c.y = (float) Json.num(objBody, "y", 0);
                c.w = (float) Json.num(objBody, "w", 0);
                c.h = (float) Json.num(objBody, "h", 0);
                String col = Json.str(objBody, "color");
                if (col != null) c.color = Json.parseColor(col);

                if (c.key != null && c.key.length() > 0) list.add(c);
                i = oe + 1;
            }
        } catch (Throwable ignored) {
        }
        return list;
    }

    /** 把已执行的指令文件移到「已处理」目录，文件名带时间戳。 */
    private static void archive(File cmd) {
        try {
            File done = doneDir();
            if (done == null) { cmd.delete(); return; }
            String stamp = new java.text.SimpleDateFormat("MMdd_HHmmss",
                    java.util.Locale.US).format(new java.util.Date());
            File target = new File(done, "cmd_" + stamp + ".json");
            boolean moved = false;
            try {
                if (target.exists()) target.delete();
                moved = cmd.renameTo(target);
            } catch (Throwable ignored) {
                moved = false;
            }
            if (!moved) {
                // rename 失败就复制再删
                try {
                    byte[] data = readAll(cmd).getBytes("UTF-8");
                    java.io.FileOutputStream fos = null;
                    try {
                        fos = new java.io.FileOutputStream(target);
                        fos.write(data);
                        fos.flush();
                    } finally {
                        try { if (fos != null) fos.close(); } catch (Throwable ignored) {}
                    }
                    cmd.delete();
                } catch (Throwable t) {
                    cmd.delete();
                }
            }
            // 归档超过 50 个就清理最旧的
            trimDone(done);
        } catch (Throwable t) {
            try { cmd.delete(); } catch (Throwable ignored) {}
        } finally {
            // 兜底：不管上面有没有成功，源文件都必须消失，
            // 否则下次打开 App 会把同一条指令再执行一遍。
            try {
                if (cmd.exists()) cmd.delete();
            } catch (Throwable ignored) {}
        }
    }

    /** 归档目录只留最近 50 份。 */
    private static void trimDone(File done) {
        try {
            File[] files = done.listFiles();
            if (files == null || files.length <= 50) return;
            java.util.Arrays.sort(files, new java.util.Comparator<File>() {
                    @Override public int compare(File a, File b) {
                        return Long.compare(a.lastModified(), b.lastModified());
                    }
                });
            for (int i = 0; i < files.length - 50; i++) {
                try { files[i].delete(); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {
        }
    }

    private static void writeResult(String cmdJson, CommandExecutor.Result r) {
        try {
            File f = resultFile();
            if (f == null) return;
            StringBuilder sb = new StringBuilder();
            sb.append(r.ok ? "执行成功\n" : "执行失败\n");
            sb.append("时间: ").append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
                    java.util.Locale.US).format(new java.util.Date())).append('\n');
            if (r.outputPath != null) sb.append("输出: ").append(r.outputPath).append('\n');
            if (r.message != null) sb.append("说明: ").append(r.message).append('\n');
            java.io.FileOutputStream fos = null;
            try {
                fos = new java.io.FileOutputStream(f);
                fos.write(sb.toString().getBytes("UTF-8"));
                fos.flush();
            } finally {
                try { if (fos != null) fos.close(); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {
        }
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String readAll(File f) {
        java.io.InputStream in = null;
        try {
            in = new java.io.FileInputStream(f);
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toString("UTF-8");
        } catch (Throwable t) {
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
        }
    }
}
