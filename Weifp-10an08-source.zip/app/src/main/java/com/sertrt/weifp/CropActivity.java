package com.sertrt.weifp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.io.InputStream;

public class CropActivity extends Activity {

    private CropView cropView;
    private Bitmap sourceBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Uri uri = getIntent().getData();
        if (uri != null) {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                sourceBitmap = BitmapFactory.decodeStream(is);
                if (is != null) is.close();
            } catch (Throwable e) {}
        }

        if (sourceBitmap == null) {
            Toast.makeText(this, LanguageManager.getString(this, R.string.crop_load_fail), Toast.LENGTH_SHORT).show();
            setResult(RESULT_CANCELED);
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF1E1E1E);

        FrameLayout preview = new FrameLayout(this);
        preview.setLayoutParams(new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        cropView = new CropView(this, sourceBitmap);
        preview.addView(cropView, new FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(preview);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setBackgroundColor(0xFF2A2A2A);
        btnRow.setPadding(16, 16, 16, 16);

        Button btnReset = new Button(this);
        btnReset.setText(LanguageManager.getString(this, R.string.reset));
        btnReset.setStateListAnimator(null);
        btnReset.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { cropView.resetCrop(); }
            });
        btnRow.addView(btnReset, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button btnCancel = new Button(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setStateListAnimator(null);
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    setResult(RESULT_CANCELED);
                    finish();
                }
            });
        btnRow.addView(btnCancel, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button btnOk = new Button(this);
        btnOk.setText(LanguageManager.getString(this, R.string.confirm));
        btnOk.setTextColor(Color.BLACK);
        btnOk.setBackgroundColor(0xFFFFB615);
        btnOk.setStateListAnimator(null);
        btnOk.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { doCrop(); }
            });
        btnRow.addView(btnOk, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(btnRow);
        setContentView(root);
    }

    private void doCrop() {
        float[] ratio = cropView.getCropRatio();
        if (ratio == null) {
            Toast.makeText(this, LanguageManager.getString(this, R.string.crop_fail_msg), Toast.LENGTH_SHORT).show();
            return;
        }
        Intent result = new Intent();
        result.putExtra("crop_ratio", ratio);
        setResult(RESULT_OK, result);
        finish();
    }

    private static class CropView extends View {
        private Bitmap bitmap;
        private Matrix displayMatrix = new Matrix();
        private RectF cropRect = new RectF();
        private Paint maskPaint, borderPaint, handlePaint;
        private float handleRadius;

        private static final int NONE = 0, MOVE = 1, TL = 2, TR = 3, BL = 4, BR = 5;
        private int activeMode = NONE;
        private float lastX, lastY;

        public CropView(Context ctx, Bitmap bmp) {
            super(ctx);
            this.bitmap = bmp;

            float density = ctx.getResources().getDisplayMetrics().density;
            handleRadius = 20 * density;

            maskPaint = new Paint();
            maskPaint.setColor(0xAA000000);
            maskPaint.setStyle(Paint.Style.FILL);

            borderPaint = new Paint();
            borderPaint.setColor(0xFFFFB615);
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(3 * density);
            borderPaint.setAntiAlias(true);

            handlePaint = new Paint();
            handlePaint.setColor(0xFFFFB615);
            handlePaint.setStyle(Paint.Style.FILL);
            handlePaint.setAntiAlias(true);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            if (w > 0 && h > 0) {
                fitCenter();
                if (cropRect.isEmpty()) resetCrop();
            }
        }

        private void fitCenter() {
            float vw = getWidth(), vh = getHeight();
            float iw = bitmap.getWidth(), ih = bitmap.getHeight();
            float scale = Math.min(vw / iw, vh / ih);
            displayMatrix.reset();
            displayMatrix.postScale(scale, scale);
            displayMatrix.postTranslate((vw - iw * scale) / 2f, (vh - ih * scale) / 2f);
        }

        public void resetCrop() {
            float vw = getWidth(), vh = getHeight();
            float iw = bitmap.getWidth(), ih = bitmap.getHeight();
            float scale = Math.min(vw / iw, vh / ih);
            float dw = iw * scale, dh = ih * scale;
            float left = (vw - dw) / 2f, top = (vh - dh) / 2f;
            float padX = dw * 0.05f, padY = dh * 0.05f;
            cropRect.set(left + padX, top + padY, left + dw - padX, top + dh - padY);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawBitmap(bitmap, displayMatrix, null);

            int w = getWidth(), h = getHeight();
            canvas.drawRect(0, 0, w, cropRect.top, maskPaint);
            canvas.drawRect(0, cropRect.bottom, w, h, maskPaint);
            canvas.drawRect(0, cropRect.top, cropRect.left, cropRect.bottom, maskPaint);
            canvas.drawRect(cropRect.right, cropRect.top, w, cropRect.bottom, maskPaint);

            canvas.drawRect(cropRect, borderPaint);

            canvas.drawCircle(cropRect.left, cropRect.top, handleRadius, handlePaint);
            canvas.drawCircle(cropRect.right, cropRect.top, handleRadius, handlePaint);
            canvas.drawCircle(cropRect.left, cropRect.bottom, handleRadius, handlePaint);
            canvas.drawCircle(cropRect.right, cropRect.bottom, handleRadius, handlePaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX(), y = event.getY();
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    activeMode = hitTest(x, y);
                    lastX = x; lastY = y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (activeMode == MOVE) {
                        cropRect.offset(x - lastX, y - lastY);
                        clampToView();
                        lastX = x; lastY = y;
                        invalidate();
                    } else if (activeMode != NONE) {
                        float minSize = handleRadius * 2.5f;
                        if (activeMode == TL) {
                            cropRect.left = Math.min(x, cropRect.right - minSize);
                            cropRect.top = Math.min(y, cropRect.bottom - minSize);
                        } else if (activeMode == TR) {
                            cropRect.right = Math.max(x, cropRect.left + minSize);
                            cropRect.top = Math.min(y, cropRect.bottom - minSize);
                        } else if (activeMode == BL) {
                            cropRect.left = Math.min(x, cropRect.right - minSize);
                            cropRect.bottom = Math.max(y, cropRect.top + minSize);
                        } else if (activeMode == BR) {
                            cropRect.right = Math.max(x, cropRect.left + minSize);
                            cropRect.bottom = Math.max(y, cropRect.top + minSize);
                        }
                        lastX = x; lastY = y;
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    activeMode = NONE;
                    return true;
            }
            return super.onTouchEvent(event);
        }

        private int hitTest(float x, float y) {
            float r = handleRadius * 2f;
            if (Math.hypot(x - cropRect.left, y - cropRect.top) < r) return TL;
            if (Math.hypot(x - cropRect.right, y - cropRect.top) < r) return TR;
            if (Math.hypot(x - cropRect.left, y - cropRect.bottom) < r) return BL;
            if (Math.hypot(x - cropRect.right, y - cropRect.bottom) < r) return BR;
            if (cropRect.contains(x, y)) return MOVE;
            return NONE;
        }

        private void clampToView() {
            if (cropRect.left < 0) cropRect.offset(-cropRect.left, 0);
            if (cropRect.top < 0) cropRect.offset(0, -cropRect.top);
            if (cropRect.right > getWidth()) cropRect.offset(getWidth() - cropRect.right, 0);
            if (cropRect.bottom > getHeight()) cropRect.offset(0, getHeight() - cropRect.bottom);
        }

        public float[] getCropRatio() {
            Matrix inv = new Matrix();
            if (!displayMatrix.invert(inv)) return null;
            float[] pts = {cropRect.left, cropRect.top, cropRect.right, cropRect.bottom};
            inv.mapPoints(pts);
            float iw = bitmap.getWidth(), ih = bitmap.getHeight();
            return new float[]{pts[0] / iw, pts[1] / ih, pts[2] / iw, pts[3] / ih};
        }
    }
}
