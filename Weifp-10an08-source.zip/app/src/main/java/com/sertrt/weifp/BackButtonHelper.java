package com.sertrt.weifp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

public class BackButtonHelper {

    public interface OnBackListener {
        void onBack();
    }

    public static void addBackButton(final Activity activity, final OnBackListener listener) {
        try {
            View rootView = activity.findViewById(android.R.id.content);
            if (!(rootView instanceof FrameLayout)) return;
            final FrameLayout root = (FrameLayout) rootView;

            final Button btn = new Button(activity);
            btn.setText("←");
            btn.setTextSize(18);
            btn.setTextColor(Color.BLACK);
            btn.setPadding(0, 0, 0, 0);
            btn.setStateListAnimator(null);

            float density = activity.getResources().getDisplayMetrics().density;
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(8 * density);
            bg.setColor(0xCCFFB615);
            btn.setBackground(bg);

            int size = (int)(42 * density);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.setMargins((int)(8 * density), (int)(8 * density), 0, 0);
            btn.setLayoutParams(lp);

            btn.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (listener != null) listener.onBack();
                        else activity.finish();
                    }
                });

            root.addView(btn);
        } catch (Throwable e) {}
    }

    public static void confirmExit(final Activity activity, String title, String message) {
        try {
            new AlertDialog.Builder(activity)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(LanguageManager.getString(activity, R.string.unsaved_discard),
                    new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { activity.finish(); }
                    })
                .setNegativeButton(LanguageManager.getString(activity, R.string.dialog_cancel), null)
                .show();
        } catch (Throwable e) {}
    }
}
