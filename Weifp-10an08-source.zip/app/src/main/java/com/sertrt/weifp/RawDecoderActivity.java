package com.sertrt.weifp;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import android.util.Base64;

public class RawDecoderActivity extends Activity {

    private WebView webView;
    private ImageView imageView;
    private String rawFilePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        rawFilePath = getIntent().getStringExtra("raw_file_path");

        FrameLayout rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(0xFF1E1E1E);

        imageView = new ImageView(this);
        FrameLayout.LayoutParams imgLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT);
        imgLp.gravity = Gravity.CENTER;
        imageView.setLayoutParams(imgLp);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        rootLayout.addView(imageView);

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    if (rawFilePath != null && !rawFilePath.isEmpty()) {
                        sendFileToJs(rawFilePath);
                    }
                }
            });
        webView.loadUrl("file:///android_asset/raw_decoder.html");
        webView.setLayoutParams(new FrameLayout.LayoutParams(1, 1));
        rootLayout.addView(webView);

        setContentView(rootLayout);

        BackButtonHelper.addBackButton(this, null);
    }

    private void sendFileToJs(final String path) {
        new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        File file = new File(path);
                        FileInputStream fis = new FileInputStream(file);
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        byte[] buffer = new byte[8192];
                        int len;
                        while ((len = fis.read(buffer)) != -1) {
                            bos.write(buffer, 0, len);
                        }
                        fis.close();

                        String base64Data = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);

                        final String jsCode = "javascript:decodeRawImage('" + base64Data + "')";
                        runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(RawDecoderActivity.this, "数据已送达 JS 引擎", Toast.LENGTH_SHORT).show();
                                    webView.evaluateJavascript(jsCode, null);
                                }
                            });
                    } catch (Throwable e) {
                        Log.e("RAW_TEST", "读取文件错误", e);
                    }
                }
            }).start();
    }

    private class Bridge {
        @JavascriptInterface
        public void onDecodeSuccess(final String resultMsg) {
            runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(RawDecoderActivity.this, "引擎测试成功！\n" + resultMsg, Toast.LENGTH_LONG).show();
                    }
                });
        }

        @JavascriptInterface
        public void onDecodeError(final String errorMsg) {
            runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(RawDecoderActivity.this, "报错：" + errorMsg, Toast.LENGTH_LONG).show();
                    }
                });
        }
    }
}
