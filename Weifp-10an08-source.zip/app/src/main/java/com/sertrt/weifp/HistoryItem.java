package com.sertrt.weifp;

import java.io.File;

public class HistoryItem {
    public File file;
    public String displayName;

    public HistoryItem(File file, String displayName) {
        this.file = file;
        this.displayName = displayName;
    }

    // ★ 核心修复：根据文件路径判断是否为同一个对象
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        HistoryItem that = (HistoryItem) obj;
        if (file == null || that.file == null) return false;
        return file.getAbsolutePath().equals(that.file.getAbsolutePath());
    }

    @Override
    public int hashCode() {
        return file != null ? file.getAbsolutePath().hashCode() : 0;
    }
}
