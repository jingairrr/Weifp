package com.sertrt.weifp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class PresetManager {

    public static File getPresetDir(android.content.Context context) {
        File dir = new File(context.getExternalFilesDir(null), "Presets");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static List<Preset> getAllPresets(android.content.Context context) {
        List<Preset> list = new ArrayList<Preset>();
        File dir = getPresetDir(context);
        File[] files = dir.listFiles();
        if (files != null) {
            java.util.Arrays.sort(files, new java.util.Comparator<File>() {
                    @Override
                    public int compare(File a, File b) {
                        return a.getName().compareTo(b.getName());
                    }
                });
            for (File f : files) {
                if (f.isFile() && f.getName().toLowerCase().endsWith(".preset")) {
                    String name = f.getName();
                    if (name.toLowerCase().endsWith(".preset")) {
                        name = name.substring(0, name.length() - 7);
                    }
                    list.add(new Preset(name, f));
                }
            }
        }
        return list;
    }

    public static File generatePresetFile(android.content.Context context, String baseName) {
        File dir = getPresetDir(context);
        String safeName = baseName.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (safeName.length() == 0) safeName = "预设";
        File f = new File(dir, safeName + ".preset");
        int count = 1;
        while (f.exists()) {
            f = new File(dir, safeName + " (" + count + ").preset");
            count++;
        }
        return f;
    }

    public static boolean savePreset(File file, Preset p) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("bright=").append(p.brightness).append("\n");
            sb.append("cont=").append(p.contrast).append("\n");
            sb.append("sat=").append(p.saturation).append("\n");
            sb.append("shadow=").append(p.shadows).append("\n");
            sb.append("high=").append(p.highlights).append("\n");
            sb.append("temp=").append(p.temperature).append("\n");
            sb.append("tint=").append(p.tint).append("\n");
            sb.append("sharp=").append(p.sharpness).append("\n");
            if (p.lutM != null) sb.append("lut_m=").append(p.lutM).append("\n");
            if (p.lutR != null) sb.append("lut_r=").append(p.lutR).append("\n");
            if (p.lutG != null) sb.append("lut_g=").append(p.lutG).append("\n");
            if (p.lutB != null) sb.append("lut_b=").append(p.lutB).append("\n");
            if (p.ptsM != null) sb.append("pts_m=").append(p.ptsM).append("\n");
            if (p.ptsR != null) sb.append("pts_r=").append(p.ptsR).append("\n");
            if (p.ptsG != null) sb.append("pts_g=").append(p.ptsG).append("\n");
            if (p.ptsB != null) sb.append("pts_b=").append(p.ptsB).append("\n");
            if (p.cubePath != null) sb.append("cube_path=").append(p.cubePath).append("\n");
            sb.append("cube_strength=").append(p.cubeStrength).append("\n");
            if (p.cropRatio != null && p.cropRatio.length == 4) {
                sb.append("crop_l=").append(p.cropRatio[0]).append("\n");
                sb.append("crop_t=").append(p.cropRatio[1]).append("\n");
                sb.append("crop_r=").append(p.cropRatio[2]).append("\n");
                sb.append("crop_b=").append(p.cropRatio[3]).append("\n");
            }

            if (p.hslHue != null && p.hslSat != null && p.hslLum != null) {
                for (int i = 0; i < 8; i++) {
                    sb.append("hsl_hue_").append(i).append("=").append(p.hslHue[i]).append("\n");
                    sb.append("hsl_sat_").append(i).append("=").append(p.hslSat[i]).append("\n");
                    sb.append("hsl_lum_").append(i).append("=").append(p.hslLum[i]).append("\n");
                }
            }

            if (p.cbShadow != null && p.cbMid != null && p.cbHigh != null) {
                for (int i = 0; i < 3; i++) {
                    sb.append("cb_s_").append(i).append("=").append(p.cbShadow[i]).append("\n");
                    sb.append("cb_m_").append(i).append("=").append(p.cbMid[i]).append("\n");
                    sb.append("cb_h_").append(i).append("=").append(p.cbHigh[i]).append("\n");
                }
            }

            // ★ 色阶
            if (p.lvBlack != null && p.lvGray != null && p.lvWhite != null) {
                for (int i = 0; i < 4; i++) {
                    sb.append("lv_b_").append(i).append("=").append(p.lvBlack[i]).append("\n");
                    sb.append("lv_g_").append(i).append("=").append(p.lvGray[i]).append("\n");
                    sb.append("lv_w_").append(i).append("=").append(p.lvWhite[i]).append("\n");
                }
            }

            FileOutputStream fos = new FileOutputStream(file);
            fos.write(sb.toString().getBytes("UTF-8"));
            fos.close();
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    public static Preset loadPreset(File file) {
        try {
            String name = file.getName();
            if (name.toLowerCase().endsWith(".preset")) {
                name = name.substring(0, name.length() - 7);
            }
            Preset p = new Preset(name, file);

            float cl = -1, ct = -1, cr = -1, cb = -1;

            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=", 2);
                if (parts.length != 2) continue;
                String k = parts[0];
                String v = parts[1];
                try {
                    if (k.equals("bright")) p.brightness = Float.parseFloat(v);
                    else if (k.equals("cont")) p.contrast = Float.parseFloat(v);
                    else if (k.equals("sat")) p.saturation = Float.parseFloat(v);
                    else if (k.equals("shadow")) p.shadows = Float.parseFloat(v);
                    else if (k.equals("high")) p.highlights = Float.parseFloat(v);
                    else if (k.equals("temp")) p.temperature = Float.parseFloat(v);
                    else if (k.equals("tint")) p.tint = Float.parseFloat(v);
                    else if (k.equals("sharp")) p.sharpness = Float.parseFloat(v);
                    else if (k.equals("lut_m")) p.lutM = v;
                    else if (k.equals("lut_r")) p.lutR = v;
                    else if (k.equals("lut_g")) p.lutG = v;
                    else if (k.equals("lut_b")) p.lutB = v;
                    else if (k.equals("pts_m")) p.ptsM = v;
                    else if (k.equals("pts_r")) p.ptsR = v;
                    else if (k.equals("pts_g")) p.ptsG = v;
                    else if (k.equals("pts_b")) p.ptsB = v;
                    else if (k.equals("cube_path")) p.cubePath = v;
                    else if (k.equals("cube_strength")) p.cubeStrength = Float.parseFloat(v);
                    else if (k.equals("crop_l")) cl = Float.parseFloat(v);
                    else if (k.equals("crop_t")) ct = Float.parseFloat(v);
                    else if (k.equals("crop_r")) cr = Float.parseFloat(v);
                    else if (k.equals("crop_b")) cb = Float.parseFloat(v);
                    else if (k.startsWith("hsl_hue_")) p.hslHue[Integer.parseInt(k.substring(8))] = Float.parseFloat(v);
                    else if (k.startsWith("hsl_sat_")) p.hslSat[Integer.parseInt(k.substring(8))] = Float.parseFloat(v);
                    else if (k.startsWith("hsl_lum_")) p.hslLum[Integer.parseInt(k.substring(8))] = Float.parseFloat(v);
                    else if (k.startsWith("cb_s_")) p.cbShadow[Integer.parseInt(k.substring(5))] = Float.parseFloat(v);
                    else if (k.startsWith("cb_m_")) p.cbMid[Integer.parseInt(k.substring(5))] = Float.parseFloat(v);
                    else if (k.startsWith("cb_h_")) p.cbHigh[Integer.parseInt(k.substring(5))] = Float.parseFloat(v);
                    // ★ 色阶
                    else if (k.startsWith("lv_b_")) p.lvBlack[Integer.parseInt(k.substring(5))] = Integer.parseInt(v);
                    else if (k.startsWith("lv_g_")) p.lvGray[Integer.parseInt(k.substring(5))] = Integer.parseInt(v);
                    else if (k.startsWith("lv_w_")) p.lvWhite[Integer.parseInt(k.substring(5))] = Integer.parseInt(v);
                } catch (Throwable ignored) {}
            }
            reader.close();

            if (cl >= 0 && ct >= 0 && cr > cl && cb > ct) {
                p.cropRatio = new float[]{cl, ct, cr, cb};
            }
            return p;
        } catch (Throwable e) {
            return null;
        }
    }

    public static boolean deletePreset(Preset p) {
        if (p == null || p.file == null || !p.file.exists()) return false;
        return p.file.delete();
    }

    public static boolean renamePreset(Preset p, String newName) {
        try {
            if (p == null || p.file == null || !p.file.exists()) return false;
            String safeName = newName.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
            if (safeName.length() == 0) return false;
            File newFile = new File(p.file.getParentFile(), safeName + ".preset");
            if (newFile.exists() && !newFile.getAbsolutePath().equals(p.file.getAbsolutePath())) return false;
            boolean ok = p.file.renameTo(newFile);
            if (ok) {
                p.file = newFile;
                p.name = safeName;
            }
            return ok;
        } catch (Throwable e) {
            return false;
        }
    }
}
