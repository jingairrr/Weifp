package com.sertrt.weifp;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 并行计算工具：统一管理线程数与「高性能 / 省电」模式。
 *
 * 设计要点：
 *  - 按行切分任务，每个线程处理一段连续的行（图像处理天然适合）。
 *  - 小任务不开线程（线程创建开销比计算本身还大）。
 *  - 线程里的异常会被收集起来，全部结束后一次性抛出，
 *    避免异常被单个线程吞掉导致结果出错却没人知道。
 *
 * 模式：
 *  - 高性能（默认开）：用 min(6, 核心数-2) 个线程，吃不饱的机器也不会把系统卡死。
 *  - 省电：最多 2 个线程，减少发热和耗电。
 */
public final class Parallel {

    private static final String PREF = "weifp_theme";
    private static final String KEY_HIGH_PERF = "high_performance";

    /** 低于这个像素数就不值得开线程。 */
    private static final long MIN_PIXELS_FOR_THREADS = 300000L;

    private Parallel() {
    }

    /** 是否开启高性能模式（默认开）。 */
    public static boolean isHighPerformance(Context ctx) {
        try {
            if (ctx == null) return true;
            return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .getBoolean(KEY_HIGH_PERF, true);
        } catch (Throwable ignored) {
            return true;
        }
    }

    public static void setHighPerformance(Context ctx, boolean on) {
        try {
            if (ctx == null) return;
            SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            sp.edit().putBoolean(KEY_HIGH_PERF, on).commit();
        } catch (Throwable ignored) {
        }
    }

    /** 当前可用 CPU 核心数。 */
    public static int cores() {
        try {
            int n = Runtime.getRuntime().availableProcessors();
            return n > 0 ? n : 1;
        } catch (Throwable t) {
            return 1;
        }
    }

    /**
     * 按当前模式计算建议线程数。
     *
     * @param pixelCount 参与计算的像素总数，用来决定是否有必要并行
     */
    public static int threadCount(Context ctx, long pixelCount) {
        if (pixelCount < MIN_PIXELS_FOR_THREADS) return 1;
        int nc = cores();
        if (nc <= 1) return 1;
        int wanted;
        if (isHighPerformance(ctx)) {
            // 高性能：留 2 个核给系统/UI，最多 6
            wanted = Math.min(6, nc - 2);
        } else {
            // 省电：最多 2 个
            wanted = Math.min(2, Math.max(1, nc / 4));
        }
        if (wanted < 1) wanted = 1;
        // 线程数不要超过行数太多
        return wanted;
    }

    /** 任务回调：处理 [y0, y1) 这些行。 */
    public interface RowTask {
        void run(int y0, int y1, int threadIndex) throws Exception;
    }

    /**
     * 按行并行执行任务。会等所有线程结束再返回。
     *
     * @param totalRows 总行数
     * @param threads   线程数（由 {@link #threadCount} 给出）
     * @param task      具体任务
     */
    public static void runRows(int totalRows, int threads, final RowTask task) throws Exception {
        if (totalRows <= 0 || task == null) return;
        if (threads <= 1 || totalRows < 2) {
            task.run(0, totalRows, 0);
            return;
        }
        if (threads > totalRows) threads = totalRows;

        final Throwable[] error = new Throwable[threads];
        Thread[] ts = new Thread[threads];
        int chunk = (totalRows + threads - 1) / threads;

        for (int i = 0; i < threads; i++) {
            final int ti = i;
            final int y0 = i * chunk;
            final int y1 = Math.min(totalRows, y0 + chunk);
            if (y0 >= y1) {
                ts[i] = null;
                continue;
            }
            ts[i] = new Thread(new Runnable() {
                    @Override public void run() {
                        try {
                            task.run(y0, y1, ti);
                        } catch (Throwable t) {
                            error[ti] = t;
                        }
                    }
                }, "weifp-worker-" + i);
            try {
                ts[i].start();
            } catch (Throwable t) {
                // 线程创建失败（通常是内存不足）：把这个分段交给主线程自己算，
                // 不能直接抛出去，否则前面已启动的线程还在跑，数据会算一半。
                ts[i] = null;
                try {
                    task.run(y0, y1, ti);
                } catch (Throwable t2) {
                    error[ti] = t2;
                }
            }
        }

        // 等待全部完成
        for (Thread t : ts) {
            if (t == null) continue;
            try {
                t.join();
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                break;
            }
        }

        // 任何一个线程出错都要抛出去，不能静默失败
        for (Throwable t : error) {
            if (t != null) {
                if (t instanceof Exception) throw (Exception) t;
                throw new RuntimeException(t);
            }
        }
    }
}
