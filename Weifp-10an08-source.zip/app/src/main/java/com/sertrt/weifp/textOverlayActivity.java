package com.sertrt.weifp;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;

public class textOverlayActivity extends Activity {

    private ImageView baseView;
    private ImageView textView;
    private FrameLayout previewArea;

    private Bitmap baseBitmap;
    private Bitmap textBitmap;
    private Bitmap scaledText;

    private Matrix textMatrix = new Matrix();
    private ScaleGestureDetector scaleDetector;

    private float lastX, lastY;
    private float textScale = 1.0f;
    private float textRotation = 0f;

    private String currentText = "Hello";
    private int currentTextColor = Color.RED;
    private float currentTextSize = 80f;

    private int drawR = 255, drawG = 0, drawB = 0;
    private View colorPreview;
    private EditText etHexRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getBaseContext().getResources().updateConfiguration(
            LanguageManager.wrap(this).getResources().getConfiguration(),
            getBaseContext().getResources().getDisplayMetrics()
        );

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF1E1E1E);

        previewArea = new FrameLayout(this);
        previewArea.setLayoutParams(new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        // 预览区不要额外 padding：底部工具栏已经占了不少高度，
        // 再留 50dp 空白图片会显得特别小
        previewArea.setPadding(0, (int)(8 * getResources().getDisplayMetrics().density), 0, 0);

        baseView = new ImageView(this);
        baseView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        previewArea.addView(baseView);

        textView = new ImageView(this);
        textView.setScaleType(ImageView.ScaleType.MATRIX);
        previewArea.addView(textView);

        root.addView(previewArea);

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setBackgroundColor(0xFF2A2A2A);
        inputRow.setPadding(10, 10, 10, 10);

        final EditText etText = new EditText(this);
        etText.setHint(LanguageManager.getString(this, R.string.text_input_hint));
        etText.setText("Hello");
        etText.setTextColor(Color.WHITE);
        etText.setBackground(getRoundBg(0xFF3A3A3A));
        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(0,
                                                                       LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        etLp.setMargins(0, 0, 10, 0);
        etText.setLayoutParams(etLp);
        inputRow.addView(etText);

        // 字号输入框：加宽，方便直接敲大数字（Procreate 那种不设上限）
        final EditText etSize = new EditText(this);
        etSize.setHint(LanguageManager.getString(this, R.string.text_size_hint));
        etSize.setText("80");
        etSize.setInputType(InputType.TYPE_CLASS_NUMBER);
        etSize.setTextColor(Color.WHITE);
        etSize.setTextSize(15);
        etSize.setGravity(android.view.Gravity.CENTER);
        etSize.setBackground(getRoundBg(0xFF3A3A3A));
        LinearLayout.LayoutParams szLp = new LinearLayout.LayoutParams(
                (int)(90 * getResources().getDisplayMetrics().density),
                LinearLayout.LayoutParams.WRAP_CONTENT);
        szLp.setMargins(0, 0, 10, 0);
        etSize.setLayoutParams(szLp);
        inputRow.addView(etSize);

        // 字号 +/- 按钮：小步微调不用打字
        TextView btnSizeDown = makeChip("−");
        btnSizeDown.setPadding(UiSpec.dpi(this, 14), UiSpec.dpi(this, 8),
                UiSpec.dpi(this, 14), UiSpec.dpi(this, 8));
        btnSizeDown.setOnClickListener(new android.view.View.OnClickListener() {
                @Override public void onClick(android.view.View v) {
                    try {
                        int cur = Integer.parseInt(etSize.getText().toString().trim());
                        // 数值越大步进越大，大字号时不会一点点挪
                        int step = cur >= 500 ? 50 : (cur >= 100 ? 10 : 2);
                        int nv = Math.max(1, cur - step);
                        etSize.setText(String.valueOf(nv));
                    } catch (Throwable ignored) {}
                }
            });
        inputRow.addView(btnSizeDown);

        TextView btnSizeUp = makeChip("+");
        btnSizeUp.setPadding(UiSpec.dpi(this, 14), UiSpec.dpi(this, 8),
                UiSpec.dpi(this, 14), UiSpec.dpi(this, 8));
        btnSizeUp.setOnClickListener(new android.view.View.OnClickListener() {
                @Override public void onClick(android.view.View v) {
                    try {
                        int cur = Integer.parseInt(etSize.getText().toString().trim());
                        int step = cur >= 500 ? 50 : (cur >= 100 ? 10 : 2);
                        etSize.setText(String.valueOf(Math.min(5000, cur + step)));
                    } catch (Throwable ignored) {}
                }
            });
        inputRow.addView(btnSizeUp);

        // ★ 去掉"设置"按钮：输入内容/字号变化时立即刷新，所见即所得。
        //   定义为字段，字体选择等其它控件也要触发刷新。
        applyInput = new Runnable() {
            @Override public void run() {
                try {
                    String t = etText.getText().toString();
                    currentText = t.isEmpty() ? " " : t;
                    try {
                        int sz = Integer.parseInt(etSize.getText().toString().trim());
                        currentTextSize = sz > 0 ? sz : 80;
                    } catch (Throwable e) {
                        // 输入到一半（空或非数字）时保持上次字号，避免画面闪来闪去
                    }
                    refreshTextBitmap();
                    centerText();
                } catch (Throwable ignored) {
                }
            }
        };
        android.text.TextWatcher watcher = new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
            @Override public void afterTextChanged(android.text.Editable s) {
                applyInput.run();
            }
        };
        etText.addTextChangedListener(watcher);
        etSize.addTextChangedListener(watcher);

        // 控件区放进一个可折叠的容器，默认收起，只留输入框
        root.addView(inputRow);

        // ==================== 折叠区：样式/字号/字体/颜色 ====================
        // 默认收起，让预览图占满屏幕；点「样式」展开。
        final LinearLayout foldBox = new LinearLayout(this);
        foldBox.setOrientation(LinearLayout.VERTICAL);
        foldBox.setVisibility(android.view.View.GONE);

        final TextView btnFold = new TextView(this);
        btnFold.setText("▾ 样式与颜色");
        btnFold.setTextSize(13);
        btnFold.setTextColor(Color.WHITE);
        btnFold.setGravity(android.view.Gravity.CENTER);
        btnFold.setPadding(0, UiSpec.dpi(this, 10), 0, UiSpec.dpi(this, 10));
        btnFold.setBackground(UiSpec.pressable(this, 0xFF2C2C2E, UiSpec.RADIUS_S));
        btnFold.setOnClickListener(new android.view.View.OnClickListener() {
                @Override public void onClick(android.view.View v) {
                    boolean show = foldBox.getVisibility() != android.view.View.VISIBLE;
                    foldBox.setVisibility(show ? android.view.View.VISIBLE : android.view.View.GONE);
                    btnFold.setText(show ? "▴ 收起" : "▾ 样式与颜色");
                }
            });
        root.addView(btnFold);
        root.addView(foldBox);

        // ==================== 文字样式预设（参考 HTMLGo）====================
        foldBox.addView(makeSectionLabel("文字样式"));
        android.widget.HorizontalScrollView styleScroll = new android.widget.HorizontalScrollView(this);
        styleScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout styleRow = new LinearLayout(this);
        styleRow.setOrientation(LinearLayout.HORIZONTAL);
        styleScroll.addView(styleRow);
        final String[][] styles = {
            {"标题",   "48", "#FFFFFF"},
            {"副标题", "28", "#E8E8E8"},
            {"正文",   "18", "#FFFFFF"},
            {"强调",   "24", "#FFB615"}
        };
        for (int i = 0; i < styles.length; i++) {
            final String[] st = styles[i];
            TextView chip = makeChip(st[0]);
            chip.setOnClickListener(new android.view.View.OnClickListener() {
                    @Override public void onClick(android.view.View v) {
                        etText.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,
                                Float.parseFloat(st[1]) * 0.5f);
                        etSize.setText(st[1]);
                        int c = Color.parseColor(st[2]);
                        drawR = Color.red(c); drawG = Color.green(c); drawB = Color.blue(c);
                        try { if (applyInput != null) applyInput.run(); } catch (Throwable ignored) {}
                        applyCustomColor();
                    }
                });
            styleRow.addView(chip);
        }
        foldBox.addView(styleScroll);

        // ==================== 快捷字号 ====================
        foldBox.addView(makeSectionLabel("字号"));
        android.widget.HorizontalScrollView sizeScroll = new android.widget.HorizontalScrollView(this);
        sizeScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout sizeRow = new LinearLayout(this);
        sizeRow.setOrientation(LinearLayout.HORIZONTAL);
        sizeScroll.addView(sizeRow);
        // 快捷字号：一直排到 2000，大标题也能一键选
        String[] quickSizes = {"14", "16", "18", "22", "28", "36", "44", "56",
                               "72", "96", "128", "160", "220", "320", "480", "800", "1200", "2000"};
        for (int i = 0; i < quickSizes.length; i++) {
            final String sz = quickSizes[i];
            TextView chip = makeChip(sz);
            chip.setOnClickListener(new android.view.View.OnClickListener() {
                    @Override public void onClick(android.view.View v) {
                        etSize.setText(sz);
                    }
                });
            sizeRow.addView(chip);
        }
        foldBox.addView(sizeScroll);

        // ==================== 字体 ====================
        foldBox.addView(makeSectionLabel("字体"));
        android.widget.HorizontalScrollView fontScroll = new android.widget.HorizontalScrollView(this);
        fontScroll.setHorizontalScrollBarEnabled(false);
        final LinearLayout fontRow = new LinearLayout(this);
        fontRow.setOrientation(LinearLayout.HORIZONTAL);
        fontScroll.addView(fontRow);
        // rebuildFontChips 内部会自己补上「+ 添加字体」按钮
        rebuildFontChips(fontRow);
        foldBox.addView(fontScroll);

        LinearLayout colorRow = new LinearLayout(this);
        colorRow.setOrientation(LinearLayout.HORIZONTAL);
        colorRow.setBackgroundColor(0xFF1E1E1E);
        colorRow.setPadding(10, 10, 10, 10);

        TextView tvPreset = new TextView(this);
        tvPreset.setText(LanguageManager.getString(this, R.string.text_preset_color));
        tvPreset.setTextColor(Color.WHITE);
        colorRow.addView(tvPreset);

        // 与涂鸦面板同一套调色板（按色谱排列）+ 圆形色块
        final int[] colors = {
            0xFF000000, 0xFF808080, 0xFFFFFFFF,
            0xFFF44336, 0xFF795548, 0xFFFFB615,
            0xFF4CAF50, 0xFF06D6A0, 0xFF4A90D9,
            0xFF3F51B5, 0xFF9C27B0, 0xFFFF69B4,
        };
        for (int c : colors) {
            final int color = c;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    UiSpec.dpi(this, 26), UiSpec.dpi(this, 26));
            lp.setMargins(UiSpec.dpi(this, 3), 0, UiSpec.dpi(this, 3), 0);
            View sw = UiSpec.swatch(this, color, 26, false, true);
            sw.setLayoutParams(lp);
            sw.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        drawR = Color.red(color);
                        drawG = Color.green(color);
                        drawB = Color.blue(color);
                        applyCustomColor();
                    }
                });
            colorRow.addView(sw);
        }
        foldBox.addView(colorRow);

        addRgbRow(root, "R", drawR, new OnSeekBarChangeListener() {
                @Override public void onProgressChanged(int value) { drawR = value; applyCustomColor(); }
            });
        addRgbRow(root, "G", drawG, new OnSeekBarChangeListener() {
                @Override public void onProgressChanged(int value) { drawG = value; applyCustomColor(); }
            });
        addRgbRow(root, "B", drawB, new OnSeekBarChangeListener() {
                @Override public void onProgressChanged(int value) { drawB = value; applyCustomColor(); }
            });

        LinearLayout previewRow = new LinearLayout(this);
        previewRow.setOrientation(LinearLayout.HORIZONTAL);
        previewRow.setPadding(10, 10, 10, 10);
        previewRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        TextView tvPreviewLabel = new TextView(this);
        tvPreviewLabel.setText(LanguageManager.getString(this, R.string.text_current));
        tvPreviewLabel.setTextColor(Color.WHITE);
        previewRow.addView(tvPreviewLabel);

        colorPreview = new View(this);
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(80, 50);
        previewLp.setMargins(10, 0, 10, 0);
        colorPreview.setLayoutParams(previewLp);
        colorPreview.setBackground(getRoundBg(Color.rgb(drawR, drawG, drawB)));
        previewRow.addView(colorPreview);

        TextView tvHash = new TextView(this);
        tvHash.setText("#");
        tvHash.setTextColor(Color.WHITE);
        previewRow.addView(tvHash);

        etHexRef = new EditText(this);
        LinearLayout.LayoutParams hexLp = new LinearLayout.LayoutParams(180,
                                                                        LinearLayout.LayoutParams.WRAP_CONTENT);
        etHexRef.setLayoutParams(hexLp);
        etHexRef.setText(String.format("%02X%02X%02X", drawR, drawG, drawB));
        etHexRef.setInputType(InputType.TYPE_CLASS_TEXT);
        etHexRef.setTextColor(Color.WHITE);
        etHexRef.setBackground(getRoundBg(0xFF3A3A3A));
        etHexRef.setMaxEms(6);
        previewRow.addView(etHexRef);

        etHexRef.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override
                public void afterTextChanged(Editable s) {
                    String str = s.toString().replace("#", "").trim();
                    if (str.length() == 6) {
                        try {
                            int r = Integer.parseInt(str.substring(0, 2), 16);
                            int g = Integer.parseInt(str.substring(2, 4), 16);
                            int b = Integer.parseInt(str.substring(4, 6), 16);
                            if (r != drawR || g != drawG || b != drawB) {
                                drawR = r; drawG = g; drawB = b;
                                currentTextColor = Color.rgb(drawR, drawG, drawB);
                                if (colorPreview != null) {
                                    colorPreview.setBackground(getRoundBg(currentTextColor));
                                }
                                refreshTextBitmap();
                            }
                        } catch (Throwable ignored) {}
                    }
                }
            });

        root.addView(previewRow);

        LinearLayout resetRow = new LinearLayout(this);
        resetRow.setOrientation(LinearLayout.HORIZONTAL);
        resetRow.setBackgroundColor(0xFF1E1E1E);
        resetRow.setPadding(10, 10, 10, 10);

        Button btnResetX = new Button(this);
        btnResetX.setText(LanguageManager.getString(this, R.string.overlay_reset_x));
        btnResetX.setAllCaps(false);
        btnResetX.setStateListAnimator(null);
        btnResetX.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetX.setTextColor(0xFFFFFFFF);
        btnResetX.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetX(); }
            });
        resetRow.addView(btnResetX);

        Button btnResetY = new Button(this);
        btnResetY.setText(LanguageManager.getString(this, R.string.overlay_reset_y));
        btnResetY.setAllCaps(false);
        btnResetY.setStateListAnimator(null);
        btnResetY.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetY.setTextColor(0xFFFFFFFF);
        btnResetY.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetY(); }
            });
        resetRow.addView(btnResetY);

        Button btnResetRot = new Button(this);
        btnResetRot.setText(LanguageManager.getString(this, R.string.overlay_reset_rot));
        btnResetRot.setAllCaps(false);
        btnResetRot.setStateListAnimator(null);
        btnResetRot.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetRot.setTextColor(0xFFFFFFFF);
        btnResetRot.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetRotation(); }
            });
        resetRow.addView(btnResetRot);

        Button btnResetScale = new Button(this);
        btnResetScale.setText(LanguageManager.getString(this, R.string.overlay_reset_scale));
        btnResetScale.setAllCaps(false);
        btnResetScale.setStateListAnimator(null);
        btnResetScale.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetScale.setTextColor(0xFFFFFFFF);
        btnResetScale.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetScale(); }
            });
        resetRow.addView(btnResetScale);

        root.addView(resetRow);

        Button btnDone = new Button(this);
        btnDone.setText(LanguageManager.getString(this, R.string.text_done_return));
        btnDone.setAllCaps(false);
        btnDone.setStateListAnimator(null);
        btnDone.setBackground(getRoundBg(0xFFFFB615));
        btnDone.setTextColor(0xFF000000);
        LinearLayout.LayoutParams doneLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        doneLp.setMargins(10, 10, 10, 10);
        btnDone.setLayoutParams(doneLp);
        btnDone.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { finishAndReturn(); }
            });
        root.addView(btnDone);

        setContentView(root);

        BackButtonHelper.addBackButton(this, new BackButtonHelper.OnBackListener() {
                @Override
                public void onBack() {
                    showExitDialog();
                }
            });

        Uri baseUri = getIntent().getData();
        if (baseUri != null) {
            try {
                InputStream is = getContentResolver().openInputStream(baseUri);
                baseBitmap = BitmapFactory.decodeStream(is);
                if (is != null) is.close();
                baseView.setImageBitmap(baseBitmap);
            } catch (Throwable e) {
                Toast.makeText(this, LanguageManager.getString(this, R.string.text_base_fail), Toast.LENGTH_SHORT).show();
            }
        }

        refreshTextBitmap();

        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector detector) {
                    if (textBitmap == null) return false;
                    float factor = detector.getScaleFactor();
                    textScale *= factor;
                    if (textScale < 0.2f) textScale = 0.2f;
                    if (textScale > 8.0f) textScale = 8.0f;

                    int w = (int) (textBitmap.getWidth() * textScale);
                    int h = (int) (textBitmap.getHeight() * textScale);
                    if (w > 0 && h > 0) {
                        scaledText = Bitmap.createScaledBitmap(textBitmap, w, h, true);
                        textView.setImageBitmap(scaledText);
                    }
                    return true;
                }
            });

        textView.setOnTouchListener(new View.OnTouchListener() {
                private float lastRotate = 0f;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if (textBitmap == null) return false;
                    scaleDetector.onTouchEvent(event);

                    if (event.getPointerCount() >= 2) {
                        float angle = (float) Math.toDegrees(
                            Math.atan2(event.getY(1) - event.getY(0),
                                       event.getX(1) - event.getX(0)));
                        if (event.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
                            lastRotate = angle;
                        } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                            float delta = angle - lastRotate;
                            textRotation += delta;
                            textMatrix.postRotate(delta,
                                                  textView.getWidth() / 2f, textView.getHeight() / 2f);
                            textView.setImageMatrix(textMatrix);
                            textView.invalidate();
                            lastRotate = angle;
                        }
                        return true;
                    }

                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            lastX = event.getX();
                            lastY = event.getY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            float dx = event.getX() - lastX;
                            float dy = event.getY() - lastY;
                            textMatrix.postTranslate(dx, dy);
                            textView.setImageMatrix(textMatrix);
                            textView.invalidate();
                            lastX = event.getX();
                            lastY = event.getY();
                            return true;
                    }
                    return false;
                }
            });
    }

    private void showExitDialog() {
        final float density = getResources().getDisplayMetrics().density;
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getRoundBg(ThemeManager.getPanelColor(this)));
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(10*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(LanguageManager.getString(this, R.string.text_abandon_title));
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(android.view.Gravity.CENTER);
        root.addView(tvTitle);

        TextView tvMsg = new TextView(this);
        tvMsg.setText(LanguageManager.getString(this, R.string.text_abandon_msg));
        tvMsg.setTextSize(13);
        tvMsg.setTextColor(ThemeManager.getTextColor(this));
        tvMsg.setGravity(android.view.Gravity.CENTER);
        tvMsg.setPadding(0, (int)(15*density), 0, (int)(15*density));
        root.addView(tvMsg);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, (int)(10*density), 0, 0);

        TextView btnCancel = new TextView(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setGravity(android.view.Gravity.CENTER);
        btnCancel.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnCancel.setBackground(getRoundBg(0xFF555555));
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp1.setMargins(0, 0, (int)(10*density), 0);
        btnCancel.setLayoutParams(lp1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dialog.dismiss(); }
            });
        btnRow.addView(btnCancel);

        TextView btnOk = new TextView(this);
        btnOk.setText(LanguageManager.getString(this, R.string.overlay_exit));
        btnOk.setTextSize(15);
        btnOk.setTextColor(Color.BLACK);
        btnOk.setGravity(android.view.Gravity.CENTER);
        btnOk.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnOk.setBackground(getRoundBg(0xFFFFB615));
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btnOk.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dialog.dismiss();
                    finish();
                }
            });
        btnRow.addView(btnOk);
        root.addView(btnRow);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dialog.setContentView(sv);

        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.8);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private GradientDrawable getRoundBg(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(8 * getResources().getDisplayMetrics().density);
        bg.setColor(color);
        return bg;
    }

    /** 选择字体文件并复制到用户的字体目录。 */
    private void pickFontFile() {
        try {
            android.content.Intent i = new android.content.Intent(
                    android.content.Intent.ACTION_GET_CONTENT);
            i.setType("*/*");     // 有些文件管理器不给 ttf 设 mime
            i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, 8103);
        } catch (Throwable t) {
            android.widget.Toast.makeText(this, "没有可用的文件选择器",
                    android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 8103 && resultCode == RESULT_OK && data != null) {
            importFontFile(data.getData());
        }
    }

    /** 把选中的字体文件复制进 Download/Weifp/fonts/ 并刷新列表。 */
    private void importFontFile(android.net.Uri uri) {
        if (uri == null) return;
        java.io.InputStream in = null;
        java.io.OutputStream out = null;
        try {
            String name = "font_" + System.currentTimeMillis() + ".ttf";
            // 尽量沿用原文件名，便于辨认
            try {
                android.database.Cursor c = getContentResolver().query(uri, null, null, null, null);
                if (c != null) {
                    int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0 && c.moveToFirst()) {
                        String dn = c.getString(idx);
                        if (dn != null && dn.length() > 0) name = dn;
                    }
                    c.close();
                }
            } catch (Throwable ignored) {}
            String lower = name.toLowerCase();
            if (!lower.endsWith(".ttf") && !lower.endsWith(".otf")) name = name + ".ttf";

            java.io.File dir = FontManager.userFontDir();
            if (dir == null) {
                android.widget.Toast.makeText(this, "无法创建字体目录",
                        android.widget.Toast.LENGTH_SHORT).show();
                return;
            }
            java.io.File dest = new java.io.File(dir, name);
            in = getContentResolver().openInputStream(uri);
            if (in == null) return;
            out = new java.io.FileOutputStream(dest);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.flush();

            FontManager.invalidate();   // 重新扫描
            android.widget.Toast.makeText(this,
                    "已添加字体：" + name + "\n下次打开文字工具即可选用",
                    android.widget.Toast.LENGTH_LONG).show();
            // 立刻把新字体加进当前列表
            currentFont = name.replaceAll("\\.(ttf|otf|TTF|OTF)$", "");
            if (applyInput != null) applyInput.run();
        } catch (Throwable t) {
            android.widget.Toast.makeText(this, "添加失败：" + t,
                    android.widget.Toast.LENGTH_LONG).show();
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
            try { if (out != null) out.close(); } catch (Throwable ignored) {}
        }
    }

    /** 重建字体选择胶囊（用户放新字体后会重新扫描）。 */
    private void rebuildFontChips(LinearLayout fontRow) {
        fontRow.removeAllViews();
        // ★ 重建时必须把「+ 添加字体」按钮补回来，
        //   否则选过一次字体后入口就消失了。
        TextView addBtn = makeChip("+ 添加字体");
        addBtn.setTextColor(0xFFFFB615);
        addBtn.setBackground(UiSpec.pressable(this, 0xFF2C2C2E, UiSpec.RADIUS_M));
        addBtn.setOnClickListener(new android.view.View.OnClickListener() {
                @Override public void onClick(android.view.View v) { pickFontFile(); }
            });
        fontRow.addView(addBtn);
        java.util.List<FontManager.FontItem> fonts;
        try {
            fonts = FontManager.all(this);
        } catch (Throwable t) {
            fonts = new java.util.ArrayList<FontManager.FontItem>();
        }
        for (final FontManager.FontItem it : fonts) {
            TextView chip = makeChip(it.name);
            // 用字体自身的字形显示名字，一眼看出效果
            try { chip.setTypeface(it.face); } catch (Throwable ignored) {}
            if (it.name.equals(currentFont)) {
                chip.setBackground(UiSpec.pressable(this, 0xFFFFB615, UiSpec.RADIUS_M));
                chip.setTextColor(Color.BLACK);
            }
            chip.setOnClickListener(new android.view.View.OnClickListener() {
                    @Override public void onClick(android.view.View v) {
                        currentFont = it.name;
                        LinearLayout parent = (LinearLayout) v.getParent();
                        rebuildFontChips(parent);
                        if (applyInput != null) applyInput.run();
                    }
                });
            fontRow.addView(chip);
        }
    }

    /** 小标题（灰字，HTMLGo 风格）。 */
    private TextView makeSectionLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(11.5f);
        tv.setTextColor(0xFF9E9E9E);
        tv.setPadding(UiSpec.dpi(this, 4), UiSpec.dpi(this, 12),
                UiSpec.dpi(this, 4), UiSpec.dpi(this, 6));
        return tv;
    }

    /** 圆角胶囊按钮（HTMLGo 风格）。 */
    private TextView makeChip(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setTextColor(Color.WHITE);
        tv.setGravity(android.view.Gravity.CENTER);
        int ph = UiSpec.dpi(this, 16), pv = UiSpec.dpi(this, 10);
        tv.setPadding(ph, pv, ph, pv);
        tv.setBackground(UiSpec.pressable(this, 0xFF2C2C2E, UiSpec.RADIUS_M));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, UiSpec.dpi(this, 8), 0);
        tv.setLayoutParams(lp);
        return tv;
    }

    /** 当前选中的字体名。 */
    private String currentFont = "默认";
    /** 重新生成文字预览（由输入框/字号/字体/颜色共用）。 */
    private Runnable applyInput = null;

    private void fixSeekBarColor(SeekBar sb) {
        if (sb == null) return;
        try {
            sb.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#FFB615")));
            sb.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#FFB615")));
        } catch (Throwable ignored) {}
    }

    private void refreshTextBitmap() {
        Paint p = new Paint();
        p.setColor(currentTextColor);
        p.setTextSize(currentTextSize);
        p.setAntiAlias(true);

        float textWidth = p.measureText(currentText);
        Paint.FontMetrics fm = p.getFontMetrics();
        int w = (int) Math.ceil(textWidth) + 20;
        int h = (int) Math.ceil(fm.bottom - fm.top) + 20;
        if (w <= 0) w = 100;
        if (h <= 0) h = 100;

        if (textBitmap != null && !textBitmap.isRecycled() && textBitmap != scaledText) {
            textBitmap.recycle();
        }
        if (scaledText != null && !scaledText.isRecycled() && scaledText != textBitmap) {
            scaledText.recycle();
        }

        // 应用选定字体后再测量一次（字体不同，行高会变）
        try {
            Typeface tf = FontManager.find(this, currentFont);
            if (tf != null) p.setTypeface(tf);
            fm = p.getFontMetrics();
        } catch (Throwable ignored) {}
        textBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(textBitmap);
        c.drawText(currentText, 10, 10 - fm.top, p);

        textScale = 1.0f;
        scaledText = textBitmap;
        textView.setImageBitmap(scaledText);
        textView.setScaleType(ImageView.ScaleType.MATRIX);
        textView.post(new Runnable() {
                @Override public void run() { centerText(); }
            });
    }

    private void centerText() {
        if (scaledText == null) return;
        textMatrix.reset();
        float cx = (textView.getWidth() - scaledText.getWidth()) / 2f;
        float cy = (textView.getHeight() - scaledText.getHeight()) / 2f;
        textMatrix.postTranslate(cx, cy);
        textView.setImageMatrix(textMatrix);
    }

    private void applyCustomColor() {
        currentTextColor = Color.rgb(drawR, drawG, drawB);
        if (colorPreview != null) {
            colorPreview.setBackground(getRoundBg(currentTextColor));
        }
        if (etHexRef != null) {
            etHexRef.setText(String.format("%02X%02X%02X", drawR, drawG, drawB));
        }
        refreshTextBitmap();
    }

    interface OnSeekBarChangeListener {
        void onProgressChanged(int value);
    }

    private void addRgbRow(LinearLayout parent, final String label, int defaultValue,
                           final OnSeekBarChangeListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(10, 0, 10, 0);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label + "：");
        tvLabel.setTextColor(Color.WHITE);
        row.addView(tvLabel);

        final SeekBar sb = new SeekBar(this);
        LinearLayout.LayoutParams seekLp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        sb.setLayoutParams(seekLp);
        sb.setMax(255);
        sb.setProgress(defaultValue);

        fixSeekBarColor(sb);
        row.addView(sb);

        final EditText et = new EditText(this);
        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(120,
                                                                       LinearLayout.LayoutParams.WRAP_CONTENT);
        et.setLayoutParams(etLp);
        et.setText(String.valueOf(defaultValue));
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setTextColor(Color.WHITE);
        et.setBackground(getRoundBg(0xFF3A3A3A));
        row.addView(et);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (fromUser) {
                        et.setText(String.valueOf(progress));
                        listener.onProgressChanged(progress);
                    }
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });

        et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        try {
                            int value = Integer.parseInt(et.getText().toString());
                            if (value < 0) value = 0;
                            if (value > 255) value = 255;
                            sb.setProgress(value);
                            et.setText(String.valueOf(value));
                            listener.onProgressChanged(value);
                        } catch (Throwable e) {
                            et.setText("0");
                            sb.setProgress(0);
                            listener.onProgressChanged(0);
                        }
                    }
                }
            });

        parent.addView(row);
    }

    private void resetX() {
        if (scaledText == null) return;
        float[] v = new float[9];
        textMatrix.getValues(v);
        float ty = v[Matrix.MTRANS_Y];
        textMatrix.reset();
        float cx = (textView.getWidth() - scaledText.getWidth()) / 2f;
        textMatrix.postTranslate(cx, ty);
        textView.setImageMatrix(textMatrix);
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_x_toast), Toast.LENGTH_SHORT).show();
    }

    private void resetY() {
        if (scaledText == null) return;
        float[] v = new float[9];
        textMatrix.getValues(v);
        float tx = v[Matrix.MTRANS_X];
        textMatrix.reset();
        float cy = (textView.getHeight() - scaledText.getHeight()) / 2f;
        textMatrix.postTranslate(tx, cy);
        textView.setImageMatrix(textMatrix);
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_y_toast), Toast.LENGTH_SHORT).show();
    }

    private void resetRotation() {
        textRotation = 0f;
        if (scaledText == null) return;
        float[] v = new float[9];
        textMatrix.getValues(v);
        float tx = v[Matrix.MTRANS_X];
        float ty = v[Matrix.MTRANS_Y];
        textMatrix.reset();
        textMatrix.postTranslate(tx, ty);
        textView.setImageMatrix(textMatrix);
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_rot_toast), Toast.LENGTH_SHORT).show();
    }

    private void resetScale() {
        textScale = 1.0f;
        if (textBitmap != null) {
            scaledText = textBitmap;
            textView.setImageBitmap(scaledText);
        }
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_scale_toast), Toast.LENGTH_SHORT).show();
    }

    private void finishAndReturn() {
        if (baseBitmap == null) {
            setResult(RESULT_CANCELED);
            finish();
            return;
        }

        Bitmap result = Bitmap.createBitmap(baseBitmap.getWidth(), baseBitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);

        if (scaledText != null) {
            Matrix inverseBaseMatrix = new Matrix();
            baseView.getImageMatrix().invert(inverseBaseMatrix);

            Matrix drawMatrix = new Matrix(textMatrix);
            drawMatrix.postConcat(inverseBaseMatrix);

            canvas.drawBitmap(scaledText, drawMatrix, null);
        }

        try {
            java.io.File cacheFile = new java.io.File(getCacheDir(), "text_result.png");
            java.io.FileOutputStream fos = new java.io.FileOutputStream(cacheFile);
            result.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();

            Intent resultIntent = new Intent();
            resultIntent.setData(Uri.fromFile(cacheFile));
            setResult(RESULT_OK, resultIntent);
            finish();
        } catch (Throwable e) {
            Toast.makeText(this, LanguageManager.getString(this, R.string.text_compose_fail), Toast.LENGTH_SHORT).show();
            setResult(RESULT_CANCELED);
            finish();
        }
    }
}
