package com.sertrt.weifp;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;

/**
 * 极简 ContentProvider：把下载目录里的 APK 共享给系统安装器。
 *
 * 为什么不用 support 库的 FileProvider：
 * 本项目没有引入 support/androidx 依赖，自己实现一个更轻。
 *
 * authority: com.sertrt.weifp.fileprovider
 */
public class ApkFileProvider extends ContentProvider {

    public static final String AUTHORITY = "com.sertrt.weifp.fileprovider";

    /** 构造一个可给安装器用的 content:// Uri。 */
    public static Uri uriFor(File file) {
        return Uri.parse("content://" + AUTHORITY + "/" + Uri.encode(file.getName()));
    }

    private File resolve(String name) {
        try {
            String n = Uri.decode(name);
            if (n.contains("/") || n.contains("..")) return null;   // 防目录穿越
            // 在两个可能的下载位置里找
            File dir1;
            if (android.os.Build.VERSION.SDK_INT >= 29 && getContext() != null) {
                dir1 = new File(getContext().getExternalFilesDir(null), "update");
            } else {
                dir1 = new File(android.os.Environment.getExternalStoragePublicDirectory(
                        android.os.Environment.DIRECTORY_DOWNLOADS), "Weifp");
            }
            File f = new File(dir1, n);
            if (f.exists()) return f;
            File dir2 = new File(android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_DOWNLOADS), "Weifp");
            File f2 = new File(dir2, n);
            return f2.exists() ? f2 : null;
        } catch (Throwable t) {
            return null;
        }
    }

    @Override public boolean onCreate() {
        return true;
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode)
            throws java.io.FileNotFoundException {
        File f = resolve(uri.getLastPathSegment());
        if (f == null) throw new java.io.FileNotFoundException(String.valueOf(uri));
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection,
                                  String[] selectionArgs, String sortOrder) {
        File f = resolve(uri.getLastPathSegment());
        if (f == null) return null;
        String[] cols = {OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor c = new MatrixCursor(cols, 1);
        c.addRow(new Object[]{f.getName(), f.length()});
        return c;
    }

    @Override public String getType(Uri uri) {
        return "application/vnd.android.package-archive";
    }

    @Override public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override public int update(Uri uri, ContentValues values, String selection,
                                String[] selectionArgs) {
        return 0;
    }
}
