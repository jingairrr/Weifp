package com.sertrt.weifp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

public class RealRawDecoder {

    static {
        try {
            // 必须和反编译代码里的一致，加载底层 so 库
            System.loadLibrary("androidraw");
        } catch (Throwable e) {
            Log.e("RealRaw", "加载 libandroidraw.so 失败");
        }
    }

    private long mNativeContext;

    public RealRawDecoder() {
        mNativeContext = init(1); // 1 代表常规模式
    }

    // 对应底层的 JNI 方法
    public native long init(int flags);
    public native int open(String path);
    public native void setQuality(int quality);
    public native void setHalfSize(boolean halfSize);
    public native int dcrawProcess();
    public native Bitmap getMutableBitmap(Bitmap.Config config);
    public native void recycle();

    /**
     * 核心解码方法
     */
    public Bitmap decodeRaw(String filePath) {
        Bitmap result = null;
        try {
            // 1. 打开文件
            int ret = open(filePath);
            if (ret != 0) {
                Log.e("RealRaw", "Open failed: " + ret);
                return null;
            }

            // 2. 设置参数
            setQuality(3); // 高质量
            setHalfSize(true); // 设为 true 可以半尺寸解码，速度更快，防 OOM

            // 3. 开始处理 RAW 数据（这一步会非常耗时，会真正读取传感器的 14-bit 数据）
            ret = dcrawProcess();
            if (ret != 0) {
                Log.e("RealRaw", "Process failed: " + ret);
                return null;
            }

            // 4. 生成 Bitmap
            result = getMutableBitmap(Bitmap.Config.ARGB_8888);

        } catch (Throwable e) {
            e.printStackTrace();
        } finally {
            try {
                recycle(); // 释放底层内存，防止 OOM
            } catch (Throwable ignored) {}
        }
        return result;
    }
}
