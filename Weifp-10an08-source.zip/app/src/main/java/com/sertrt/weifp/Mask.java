package com.sertrt.weifp;

/**
 * 局部蒙版（Mask）：只对图片的某个区域做调整。
 *
 * 支持三种区域：
 *  1. RADIAL  —— 径向（椭圆，可旋转、可羽化），对应 Lightroom 的径向渐变
 *  2. BRUSH   —— 画笔涂抹，画过的地方生效
 *  3. COLOR   —— 按颜色选择（吸取一个颜色，相近的像素生效），复用色度抠图的思路
 *
 * 每种蒙版都带一组调整参数（曝光/对比度/饱和度/色温/清晰度），
 * 并且可以反相（作用在区域内或区域外）。
 *
 * 纯 Java，不依赖 Android，便于离线验证。
 */
public final class Mask {

    /** 区域类型。 */
    public static final int TYPE_RADIAL = 0;
    public static final int TYPE_BRUSH = 1;
    public static final int TYPE_COLOR = 2;
    /** 线性渐变（对应 Lightroom 的渐变滤镜）。 */
    public static final int TYPE_LINEAR = 3;

    /** 单个蒙版。 */
    public static class MaskItem {
        public int type = TYPE_RADIAL;
        public boolean enabled = true;
        /** 反相：true = 作用在区域外。 */
        public boolean invert = false;

        // ---- 径向 ----
        /** 中心点（0~1 相对坐标）。 */
        public float cx = 0.5f, cy = 0.5f;
        /** 半径（相对短边，0~1）。 */
        public float rx = 0.35f, ry = 0.35f;
        /** 旋转角度（度）。 */
        public float rotation = 0f;
        /** 羽化 0~100：0=硬边，100=完全柔和。 */
        public int feather = 50;
        /** 发散值 0~100：光的柔和程度（对权重做高斯模糊）。 */
        public int spread = 30;

        // ---- 画笔 ----
        /** 画笔蒙版数据：与图片同尺寸的 alpha 数组（0=不生效，255=完全生效）。 */
        public byte[] brushAlpha = null;
        /** brushAlpha 的原始宽高（图片尺寸变了也能按相对坐标采样）。 */
        public int brushW = 0, brushH = 0;
        /** 画笔强度。 */
        public int brushStrength = 100;

        // ---- 颜色 ----
        /** 目标颜色。 */
        public int keyColor = 0xFF808080;
        /** 颜色容差 0~100。 */
        public int colorTolerance = 30;

        // ---- 调整参数 ----
        /** 曝光 -100~100。 */
        public float exposure = 25f;
        /** 对比度 -100~100。 */
        public float contrast = 0f;
        /** 饱和度 -100~100。 */
        public float saturation = 0f;
        /** 色温 -100~100。 */
        public float temperature = 0f;
        /** 清晰度 -100~100（数值越大边缘越锐）。 */
        public float clarity = 0f;

        public MaskItem copy() {
            MaskItem m = new MaskItem();
            m.type = type; m.enabled = enabled; m.invert = invert;
            m.cx = cx; m.cy = cy; m.rx = rx; m.ry = ry;
            m.rotation = rotation; m.feather = feather; m.spread = spread;
            m.brushAlpha = brushAlpha == null ? null : brushAlpha.clone();
            m.brushW = brushW; m.brushH = brushH;
            m.brushStrength = brushStrength;
            m.keyColor = keyColor; m.colorTolerance = colorTolerance;
            m.exposure = exposure; m.contrast = contrast; m.saturation = saturation;
            m.temperature = temperature; m.clarity = clarity;
            return m;
        }

        /** 是否做了任何调整（没调的话不必参与渲染）。 */
        public boolean hasAdjustment() {
            return exposure != 0 || contrast != 0 || saturation != 0
                    || temperature != 0 || clarity != 0;
        }
    }

    private Mask() {
    }

    // ==================== 蒙版权重计算 ====================

    /**
     * 计算像素 (x,y) 处该蒙版的权重。
     *
     * @param m      蒙版
     * @param x      x 坐标（像素）
     * @param y      y 坐标
     * @param w      图片宽
     * @param h      图片高
     * @param pixel  该像素颜色（仅 COLOR 类型用），传 0 表示不取色
     * @return 0~255 的权重
     */
    public static int weightAt(MaskItem m, int x, int y, int w, int h, int pixel) {
        if (m == null || !m.enabled) return 0;
        int a;
        switch (m.type) {
            case TYPE_BRUSH:
                a = brushWeight(m, x, y, w, h);
                break;
            case TYPE_COLOR:
                a = colorWeight(m, pixel);
                break;
            case TYPE_RADIAL:
                a = radialWeight(m, x, y, w, h);
                break;
            case TYPE_LINEAR:
                a = linearWeight(m, x, y, w, h);
                break;
            default:
                a = radialWeight(m, x, y, w, h);
                break;
        }
        return m.invert ? (255 - a) : a;
    }

    /**
     * 径向（Lightroom 模型）：
     *
     *   内椭圆（rx,ry）以内  = 255（完全生效）
     *   内椭圆到外椭圆之间   = 从 255 平滑衰减到 0（这就是"光发散"的范围）
     *   外椭圆以外           = 0
     *
     * 外椭圆 = 内椭圆 × (1 + feather/100 * maxSpread)
     * 所以 feather 越大，发散越远；feather=0 时外椭圆=内椭圆，是硬边。
     */
    static int radialWeight(MaskItem m, int x, int y, int w, int h) {
        if (w <= 0 || h <= 0) return 0;
        float aspect = (float) w / h;
        float px = ((float) x / w - m.cx) * aspect;
        float py = (float) y / h - m.cy;
        double rad = Math.toRadians(m.rotation);
        double cos = Math.cos(rad), sin = Math.sin(rad);
        float rx2 = (float) (px * cos - py * sin);
        float ry2 = (float) (px * sin + py * cos);

        float arx = Math.max(1e-4f, m.rx * aspect);
        float ary = Math.max(1e-4f, m.ry);
        // 归一化半径：内椭圆上 = 1.0
        double d = Math.sqrt((rx2 / arx) * (rx2 / arx) + (ry2 / ary) * (ry2 / ary));

        if (d <= 1.0) return 255;              // 内椭圆内：满强度

        // 外椭圆边界：feather 100 时扩展到内椭圆的 2.5 倍
        double spread = 1.0 + (m.feather / 100.0) * 1.5;
        if (d >= spread) return 0;             // 外椭圆外：不生效

        // 内外之间：用平滑曲线（smoothstep）避免线性过渡的生硬感
        double t = (d - 1.0) / (spread - 1.0);  // 0..1
        double smooth = t * t * (3 - 2 * t);     // smoothstep
        return (int) Math.round(255 * (1.0 - smooth));
    }

    /**
     * 线性渐变（对应 Lightroom 的渐变滤镜）。
     *
     * 参数复用：
     *   cx, cy     渐变起点（权重满 255 的那一侧）
     *   rotation   渐变方向（度，0 = 从上往下）
     *   feather    渐变带长度，占图像对角线的百分比
     *   rx         固定为 1（未使用）
     *   invert     反向（从下往上）
     *
     * 语义：
     *   起点之前      = 255（完全生效）
     *   起点到终点之间 = 从 255 线性平滑过渡到 0
     *   终点之后      = 0（完全不生效）
     */
    static int linearWeight(MaskItem m, int x, int y, int w, int h) {
        if (w <= 0 || h <= 0) return 0;
        // 渐变带长度：按对角线长度 × feather 比例，保证不同尺寸观感一致
        double diag = Math.sqrt((double) w * w + (double) h * h);
        float band = (float) (diag * Math.max(0.01f, m.feather / 100.0));
        if (band <= 0.5f) band = 0.5f;

        // 方向向量（rotation=0 时沿 +y 向下）
        double rad = Math.toRadians(m.rotation);
        float dirX = (float) Math.sin(rad);
        float dirY = (float) Math.cos(rad);

        // 当前像素相对起点的投影距离
        float dx = x - m.cx * w;
        float dy = y - m.cy * h;
        float proj = dx * dirX + dy * dirY;

        if (proj <= 0) return 255;            // 起点之前：满强度
        if (proj >= band) return 0;           // 终点之后：不生效

        // smoothstep 过渡，避免生硬的线性边
        double t = proj / band;
        double smooth = t * t * (3 - 2 * t);
        return (int) Math.round(255 * (1.0 - smooth));
    }

    /** 画笔：直接取存储的 alpha。 */
    static int brushWeight(MaskItem m, int x, int y, int w, int h) {
        if (m.brushAlpha == null || w <= 0 || h <= 0) return 0;
        if (x < 0 || y < 0 || x >= w || y >= h) return 0;

        // 尺寸一致：直接下标
        if (m.brushAlpha.length == w * h) {
            int a = m.brushAlpha[y * w + x] & 0xFF;
            return (int) (a * (m.brushStrength / 100.0));
        }

        // 尺寸变了（裁剪/缩放/超分）：按相对坐标双线性采样，
        // 工作量再大也比"整个蒙版突然失效"好。
        int aw = m.brushW, ah = m.brushH;
        if (aw <= 0 || ah <= 0) return 0;
        float fx = (float) x / w * aw;
        float fy = (float) y / h * ah;
        int x0 = (int) fx, y0 = (int) fy;
        int x1 = Math.min(aw - 1, x0 + 1), y1 = Math.min(ah - 1, y0 + 1);
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x0 >= aw) x0 = aw - 1;
        if (y0 >= ah) y0 = ah - 1;
        float tx = fx - x0, ty = fy - y0;
        int a00 = m.brushAlpha[y0 * aw + x0] & 0xFF;
        int a10 = m.brushAlpha[y0 * aw + x1] & 0xFF;
        int a01 = m.brushAlpha[y1 * aw + x0] & 0xFF;
        int a11 = m.brushAlpha[y1 * aw + x1] & 0xFF;
        float top = a00 + (a10 - a00) * tx;
        float bot = a01 + (a11 - a01) * tx;
        int a = Math.round(top + (bot - top) * ty);
        return (int) (a * (m.brushStrength / 100.0));
    }

    /** 颜色：与目标色的 HSV 距离判定。 */
    static int colorWeight(MaskItem m, int pixel) {
        if (pixel == 0) return 0;
        double[] key = ChromaKey.toHsv(m.keyColor);
        double[] cur = ChromaKey.toHsv(pixel);
        double dh = ChromaKey.hueDelta(cur[0], key[0]);
        double ds = Math.abs(cur[1] - key[1]);
        double dv = Math.abs(cur[2] - key[2]);
        // 容差 0~100 -> 色相 2~45 度
        double hueTol = 2.0 + (m.colorTolerance / 100.0) * 43.0;
        if (dh > hueTol) return 0;
        // 边缘软化
        double t = 1.0 - (dh / hueTol);
        // 饱和度、亮度太远则减弱
        double sv = 1.0 - Math.min(1.0, (ds * 0.5 + dv * 0.5) * 2.0);
        int a = (int) Math.round(255 * t * Math.max(0, sv));
        return Math.max(0, Math.min(255, a));
    }

    // ==================== 应用调整 ====================

    /**
     * 把蒙版调整应用到像素数组。就地修改。
     *
     * @param px 像素（ARGB_8888）
     * @param w  宽
     * @param h  高
     * @param m  蒙版
     */
    public static void apply(int[] px, int w, int h, MaskItem m) {
        apply(px, w, h, m, null);
    }

    /**
     * 并行版本：按行切分权重计算和像素应用。
     *
     * @param ctx 用来读「高性能/省电」模式；null 则单线程
     */
    public static void apply(final int[] px, final int w, final int h,
                             final MaskItem m, android.content.Context ctx) {
        if (px == null || m == null || !m.enabled || !m.hasAdjustment()) return;
        if (w <= 0 || h <= 0) return;

        // 曝光：乘法（可逆）
        float expScale = 1f;
        if (m.exposure > 0) {
            expScale = 1f + (m.exposure / 100f) * 1.0f;    // 最高 2 倍
        } else if (m.exposure < 0) {
            expScale = 1f + (m.exposure / 100f) * 0.75f;   // 最低 0.25 倍
        }
        // 对比度：围绕 128 缩放
        float cScale = 1f + (m.contrast / 100f) * 0.6f;    // 0.4 ~ 1.6
        float cOff = 128f * (1f - cScale);
        // 饱和度
        float sat = 1f + (m.saturation / 100f);            // 0 ~ 2
        // 色温（红蓝增益）
        float tAmt = m.temperature / 100f;
        float rGain = 1f + tAmt * 0.25f;
        float bGain = 1f - tAmt * 0.25f;

        // 不再复制整个像素数组：每次迭代只读一次原像素、写一次结果，
        // 大图上这份拷贝是几十 MB，多蒙版叠加时会直接 OOM。
        // 发散值：先算出整张权重图，再做高斯模糊，光就会"散"开而不是硬边界
        final int[] weights = new int[w * h];
        final int threads = Parallel.threadCount(ctx, (long) w * h);
        try {
            Parallel.runRows(h, threads, new Parallel.RowTask() {
                    @Override public void run(int y0, int y1, int ti) {
                        for (int y = y0; y < y1; y++) {
                            int row = y * w;
                            for (int x = 0; x < w; x++) {
                                weights[row + x] = weightAt(m, x, y, w, h, px[row + x]);
                            }
                        }
                    }
                });
        } catch (Throwable ignored) {
        }
        if (m.spread > 0) {
            int r = Math.max(1, (int) Math.round(m.spread / 100.0 * Math.min(w, h) * 0.06));
            boxBlurWeight(weights, w, h, r);
            boxBlurWeight(weights, w, h, r);   // 两遍近似高斯
        }

        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int i = row + x;
                int c = px[i];
                int wt = weights[i];
                if (wt <= 0) continue;

                int a = (c >>> 24) & 0xFF;
                float r = (c >> 16) & 0xFF;
                float g = (c >> 8) & 0xFF;
                float b = c & 0xFF;

                // 1) 曝光（乘法）
                r *= expScale; g *= expScale; b *= expScale;
                // 2) 对比度
                r = r * cScale + cOff;
                g = g * cScale + cOff;
                b = b * cScale + cOff;
                // 3) 色温
                r *= rGain; b *= bGain;
                // 4) 饱和度
                if (sat != 1f) {
                    float luma = 0.299f * r + 0.587f * g + 0.114f * b;
                    r = luma + (r - luma) * sat;
                    g = luma + (g - luma) * sat;
                    b = luma + (b - luma) * sat;
                }
                // 5) 清晰度：局部对比（简化版，用亮度反差）
                if (m.clarity != 0) {
                    float k = m.clarity / 100f;
                    float luma = 0.299f * r + 0.587f * g + 0.114f * b;
                    float d = luma - 128f;
                    float boost = d * k * 0.35f;
                    r += boost; g += boost; b += boost;
                }

                int nr = clamp255(Math.round(r));
                int ng = clamp255(Math.round(g));
                int nb = clamp255(Math.round(b));

                // 按权重与原像素混合
                float t = wt / 255f;
                int fr = clamp255(Math.round(((c >> 16) & 0xFF) * (1 - t) + nr * t));
                int fg = clamp255(Math.round(((c >> 8) & 0xFF) * (1 - t) + ng * t));
                int fb = clamp255(Math.round((c & 0xFF) * (1 - t) + nb * t));
                px[i] = (a << 24) | (fr << 16) | (fg << 8) | fb;
            }
        }
    }

    // ==================== 画笔辅助 ====================

    /** 在画笔蒙版上画一个圆点（用于手指拖动时累积）。 */
    public static void brushStamp(MaskItem m, int w, int h, float sx, float sy, float radius,
                                  int strength, boolean erase) {
        if (m == null || w <= 0 || h <= 0) return;
        if (m.brushAlpha == null || m.brushAlpha.length != w * h) {
            m.brushAlpha = new byte[w * h];
            m.brushW = w;
            m.brushH = h;
        }
        int cx = Math.round(sx), cy = Math.round(sy);
        int r = Math.max(1, Math.round(radius));
        int r2 = r * r;
        for (int y = cy - r; y <= cy + r; y++) {
            if (y < 0 || y >= h) continue;
            for (int x = cx - r; x <= cx + r; x++) {
                if (x < 0 || x >= w) continue;
                int dx = x - cx, dy = y - cy;
                int d2 = dx * dx + dy * dy;
                if (d2 > r2) continue;
                // 高斯衰减：中心 1.0，边缘平滑降到 0，避免线性衰减的硬边
                // gauss = exp(-3 * (d/r)^2)，d=0 时 1，d=r 时约 0.05
                double dist2 = (double) d2 / r2;   // 0..1
                double falloff = Math.exp(-3.0 * dist2);
                // 边缘再补一刀，保证在 r 处归零，不留硬边
                if (falloff < 0.06) falloff = 0;
                int add = (int) Math.round(strength * falloff);
                int idx = y * w + x;
                int cur = m.brushAlpha[idx] & 0xFF;
                int nv = erase ? Math.max(0, cur - add) : Math.min(255, cur + add);
                m.brushAlpha[idx] = (byte) nv;
            }
        }
    }

    /** 在两点之间连续盖章，避免快速拖动出现断点。 */
    public static void brushLine(MaskItem m, int w, int h, float x0, float y0,
                                 float x1, float y1, float radius, int strength, boolean erase) {
        float dx = x1 - x0, dy = y1 - y0;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        float stepLen = Math.max(1f, radius * 0.4f);
        int steps = (int) Math.ceil(len / stepLen);
        if (steps <= 0) {
            brushStamp(m, w, h, x1, y1, radius, strength, erase);
            return;
        }
        for (int i = 0; i <= steps; i++) {
            float t = (float) i / steps;
            brushStamp(m, w, h, x0 + dx * t, y0 + dy * t, radius, strength, erase);
        }
    }

    // ==================== 序列化（存进 WPB / SharedPreferences） ====================

    /** 兼容旧调用：不落盘，画笔数据用 base64（仅用于小图/临时场景）。 */
    public static String serialize(java.util.List<MaskItem> list) {
        return serialize(list, null);
    }

    /**
     * 把蒙版列表序列化成文本。
     *
     * 画笔蒙版的数据量 = 图片像素数，大图上 base64 会有十几 MB，
     * 绝不能塞进 SharedPreferences（XML 解析会卡死）。所以 dir 不为空时
     * 写到独立 PNG 文件，序列化里只存文件名。
     */
    public static String serialize(java.util.List<MaskItem> list, java.io.File dir) {
        if (list == null || list.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (MaskItem m : list) {
            if (m == null) continue;
            sb.append("MASK|")
              .append(m.type).append("|")
              .append(m.enabled ? 1 : 0).append("|")
              .append(m.invert ? 1 : 0).append("|")
              .append(m.cx).append("|").append(m.cy).append("|")
              .append(m.rx).append("|").append(m.ry).append("|")
              .append(m.rotation).append("|").append(m.feather).append("|")
              .append(m.brushStrength).append("|")
              .append(m.keyColor).append("|").append(m.colorTolerance).append("|")
              .append(m.exposure).append("|").append(m.contrast).append("|")
              .append(m.saturation).append("|").append(m.temperature).append("|")
              .append(m.clarity).append("|")
              .append(m.brushW).append("|").append(m.brushH).append("|")
              .append(m.spread).append("|");
            if (m.brushAlpha != null && m.brushAlpha.length > 0) {
                // 文件名按蒙版序号固定，重复保存时覆盖同一个文件，
                // 否则每拖一下滑轨就多一个几 MB 的 PNG，磁盘会被塞满。
                String fileName = saveBrushToFile(m.brushAlpha, dir,
                        "mask_brush_" + list.indexOf(m) + ".png");
                if (fileName != null) {
                    sb.append("FILE:").append(fileName);
                } else {
                    // 没有可用目录时才退回 base64（小图可接受）
                    sb.append(android.util.Base64.encodeToString(m.brushAlpha,
                            android.util.Base64.NO_WRAP));
                }
            } else {
                sb.append("-");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    /** 兼容旧调用。 */
    public static java.util.List<MaskItem> deserialize(String text) {
        return deserialize(text, null);
    }

    /** 反序列化。任何解析失败都跳过该条，不影响其他蒙版。 */
    public static java.util.List<MaskItem> deserialize(String text, java.io.File dir) {
        java.util.List<MaskItem> list = new java.util.ArrayList<MaskItem>();
        if (text == null || text.length() == 0) return list;
        String[] lines = text.split("\n");
        for (String line : lines) {
            if (line == null || !line.startsWith("MASK|")) continue;
            try {
                String[] f = line.split("\\|", -1);
                if (f.length < 19) continue;
                MaskItem m = new MaskItem();
                m.type = Integer.parseInt(f[1]);
                m.enabled = "1".equals(f[2]);
                m.invert = "1".equals(f[3]);
                m.cx = Float.parseFloat(f[4]);
                m.cy = Float.parseFloat(f[5]);
                m.rx = Float.parseFloat(f[6]);
                m.ry = Float.parseFloat(f[7]);
                m.rotation = Float.parseFloat(f[8]);
                m.feather = Integer.parseInt(f[9]);
                m.brushStrength = Integer.parseInt(f[10]);
                m.keyColor = Integer.parseInt(f[11]);
                m.colorTolerance = Integer.parseInt(f[12]);
                m.exposure = Float.parseFloat(f[13]);
                m.contrast = Float.parseFloat(f[14]);
                m.saturation = Float.parseFloat(f[15]);
                m.temperature = Float.parseFloat(f[16]);
                try { m.clarity = Float.parseFloat(f[17]); } catch (Throwable ignored) {}

                // ★ 字段顺序必须和 serialize 完全一致：
                //   ..., clarity(17), brushW(18), brushH(19), spread(20), brushAlpha(21)
                //   旧格式只有 brushAlpha(18)。
                if (f.length > 21) {
                    try { m.brushW = Integer.parseInt(f[18].trim()); } catch (Throwable ignored) {}
                    try { m.brushH = Integer.parseInt(f[19].trim()); } catch (Throwable ignored) {}
                    try { m.spread = Integer.parseInt(f[20].trim()); } catch (Throwable ignored) {}
                    m.brushAlpha = decodeBrushField(f[21], dir);
                } else if (f.length > 18) {
                    // 旧格式：f[18] 就是画笔数据
                    m.brushAlpha = decodeBrushField(f[18], dir);
                }

                // 老数据没存尺寸：从长度反推一个接近方形的尺寸
                if (m.brushAlpha != null && (m.brushW <= 0 || m.brushH <= 0)) {
                    int total = m.brushAlpha.length;
                    int ww = 1, hh = total;
                    for (int t = (int) Math.sqrt(total); t >= 2; t--) {
                        if (total % t == 0) { ww = t; hh = total / t; break; }
                    }
                    m.brushW = ww; m.brushH = hh;
                }
                list.add(m);
            } catch (Throwable ignored) {
            }
        }
        return list;
    }

    // ---- 画笔蒙版的落盘/读回（用灰度 PNG 存 alpha） ----

    private static String saveBrushToFile(byte[] alpha, java.io.File dir, String name) {
        if (dir == null || alpha == null || alpha.length == 0) return null;
        java.io.FileOutputStream fos = null;
        try {
            if (!dir.exists()) dir.mkdirs();
            // 关键：只存 alpha，尺寸信息从长度反推不方便，所以存 1/4 分辨率的灰度图
            int total = alpha.length;
            int w = 1, h = total;
            // 尽量接近方形：能找到整数因子就拆分，否则按长条存
            for (int t = (int) Math.sqrt(total); t >= 2; t--) {
                if (total % t == 0) { w = t; h = total / t; break; }
            }
            if (w == 1) { w = total; h = 1; }
            int[] px = new int[total];
            for (int i = 0; i < total; i++) {
                int a = alpha[i] & 0xFF;
                px[i] = (0xFF << 24) | (a << 16) | (a << 8) | a;
            }
            android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(
                    w, h, android.graphics.Bitmap.Config.ARGB_8888);
            bmp.setPixels(px, 0, w, 0, 0, w, h);
            java.io.File f = new java.io.File(dir, name);
            fos = new java.io.FileOutputStream(f);
            bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            bmp.recycle();
            return name;
        } catch (Throwable t) {
            return null;
        } finally {
            try { if (fos != null) fos.close(); } catch (Throwable ignored) {}
        }
    }

    /** 解析画笔字段：支持 FILE: 引用、-、base64。任何异常都返回 null，不往外抛。 */
    private static byte[] decodeBrushField(String v, java.io.File dir) {
        if (v == null) return null;
        v = v.trim();
        if (v.length() == 0 || "-".equals(v)) return null;
        try {
            if (v.startsWith("FILE:")) {
                return loadBrushFromFile(dir, v.substring(5));
            }
            return android.util.Base64.decode(v, android.util.Base64.NO_WRAP);
        } catch (Throwable t) {
            return null;
        }
    }

    private static byte[] loadBrushFromFile(java.io.File dir, String name) {
        if (dir == null || name == null) return null;
        try {
            java.io.File f = new java.io.File(dir, name);
            if (!f.exists() || f.length() <= 0) return null;
            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeFile(
                    f.getAbsolutePath());
            if (bmp == null) return null;
            int w = bmp.getWidth(), h = bmp.getHeight();
            int[] px = new int[w * h];
            bmp.getPixels(px, 0, w, 0, 0, w, h);
            bmp.recycle();
            byte[] alpha = new byte[w * h];
            for (int i = 0; i < px.length; i++) {
                alpha[i] = (byte) (px[i] & 0xFF);
            }
            return alpha;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 对权重图做盒式模糊（可分离，O(n)），两遍近似高斯。 */
    static void boxBlurWeight(int[] wts, int w, int h, int radius) {
        if (radius <= 0 || w <= 0 || h <= 0) return;
        int[] tmp = new int[Math.max(w, h)];
        // 横向
        for (int y = 0; y < h; y++) {
            int base = y * w;
            int sum = 0, count = 0;
            for (int x = -radius; x <= radius; x++) {
                if (x >= 0 && x < w) { sum += wts[base + x]; count++; }
            }
            for (int x = 0; x < w; x++) {
                tmp[x] = sum / count;
                int addIdx = x + radius + 1, subIdx = x - radius;
                if (addIdx < w) sum += wts[base + addIdx];
                if (subIdx >= 0) sum -= wts[base + subIdx];
                int lo = Math.max(0, x - radius), hi = Math.min(w - 1, x + radius + 1);
                count = hi - lo;
                if (count < 1) count = 1;
            }
            System.arraycopy(tmp, 0, wts, base, w);
        }
        // 纵向
        for (int x = 0; x < w; x++) {
            int sum = 0, count = 0;
            for (int y = -radius; y <= radius; y++) {
                if (y >= 0 && y < h) { sum += wts[y * w + x]; count++; }
            }
            for (int y = 0; y < h; y++) {
                tmp[y] = sum / count;
                int addIdx = y + radius + 1, subIdx = y - radius;
                if (addIdx < h) sum += wts[addIdx * w + x];
                if (subIdx >= 0) sum -= wts[subIdx * w + x];
                int lo = Math.max(0, y - radius), hi = Math.min(h - 1, y + radius + 1);
                count = hi - lo;
                if (count < 1) count = 1;
            }
            for (int y = 0; y < h; y++) wts[y * w + x] = tmp[y];
        }
    }

    private static int clamp255(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }
}
