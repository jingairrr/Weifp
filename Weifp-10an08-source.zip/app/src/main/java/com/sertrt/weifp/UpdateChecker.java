package com.sertrt.weifp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * 版本更新检查（GitHub Releases）。
 *
 * 流程：
 *  1. 请求 https://api.github.com/repos/<owner>/<repo>/releases/latest
 *  2. 解析 tag_name 里的版本号，与本地 AppVersion.VERSION_CODE 比较
 *  3. 有新版则回调给 UI 弹窗
 *  4. 用户确认后下载 APK 到公共目录，交给系统安装器
 *
 * 注意：GitHub 在国内可能不稳定，所有网络异常都静默失败（不影响正常使用）。
 */
public final class UpdateChecker {

    /** 填成你自己的仓库，例如 "sertrt/Weifp"。 */
    public static final String REPO_OWNER = "jingairrr";
    public static final String REPO_NAME = "Weifp";
    private static final String API_URL =
            "https://api.github.com/repos/" + REPO_OWNER + "/" + REPO_NAME + "/releases/latest";

    /** 检查结果。 */
    public interface Callback {
        /** 有新版。 */
        void onUpdateAvailable(String versionName, int versionCode, String downloadUrl,
                               String releaseNotes);
        /** 已是最新（可静默忽略）。 */
        void onUpToDate();
        /** 检查失败（网络等）。 */
        void onError(String reason);
    }

    private UpdateChecker() {
    }

    /** 上次检查的时间戳 key（同一天只提示一次）。 */
    private static final String PREF = "weifp_update";
    private static final String KEY_LAST_CHECK = "last_check";

    /** 是否应该自动检查（一天一次）。 */
    public static boolean shouldAutoCheck(Context ctx) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            long last = sp.getLong(KEY_LAST_CHECK, 0);
            return System.currentTimeMillis() - last > 24L * 3600 * 1000;
        } catch (Throwable t) {
            return false;
        }
    }

    public static void markChecked(Context ctx) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .edit().putLong(KEY_LAST_CHECK, System.currentTimeMillis()).commit();
        } catch (Throwable ignored) {
        }
    }

    /** 在后台线程检查更新。 */
    public static void check(final Callback cb) {
        new Thread(new Runnable() {
                @Override public void run() {
                    HttpURLConnection conn = null;
                    try {
                        URL url = new URL(API_URL);
                        conn = (HttpURLConnection) url.openConnection();
                        conn.setConnectTimeout(8000);
                        conn.setReadTimeout(8000);
                        conn.setRequestProperty("Accept", "application/vnd.github+json");
                        conn.setRequestProperty("User-Agent", "Weifp-Updater");
                        int code = conn.getResponseCode();
                        if (code != 200) {
                            cb.onError("HTTP " + code);
                            return;
                        }
                        String body = readAll(conn.getInputStream());

                        String tag = jsonString(body, "tag_name");
                        String htmlUrl = jsonString(body, "html_url");
                        String notes = jsonString(body, "body");
                        if (tag == null) {
                            cb.onError("no tag");
                            return;
                        }
                        int remoteCode = parseVersionCode(tag);
                        String remoteName = tag.startsWith("v") || tag.startsWith("V")
                                ? tag.substring(1) : tag;

                        if (remoteCode <= AppVersion.VERSION_CODE) {
                            cb.onUpToDate();
                            return;
                        }
                        // 优先找 .apk 资产
                        String apkUrl = findApkAsset(body);
                        cb.onUpdateAvailable(remoteName, remoteCode,
                                apkUrl != null ? apkUrl : htmlUrl, notes);
                    } catch (Throwable t) {
                        cb.onError(t.getClass().getSimpleName());
                    } finally {
                        try { if (conn != null) conn.disconnect(); } catch (Throwable ignored) {}
                    }
                }
            }).start();
    }

    /** 从 tag 解析版本号：支持 "10an05"、"v10an05"、"1.2.3" 形式。 */
    public static int parseVersionCode(String tag) {
        if (tag == null) return -1;
        try {
            // 10an05 -> 1005
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(\\d+)\\s*an\\s*(\\d+)", java.util.regex.Pattern.CASE_INSENSITIVE)
                    .matcher(tag);
            if (m.find()) {
                int major = Integer.parseInt(m.group(1));
                int minor = Integer.parseInt(m.group(2));
                return major * 100 + minor;
            }
            // 1.2.3 -> 10203
            m = java.util.regex.Pattern.compile("(\\d+)\\.(\\d+)(?:\\.(\\d+))?").matcher(tag);
            if (m.find()) {
                int a = Integer.parseInt(m.group(1));
                int b = Integer.parseInt(m.group(2));
                int c = m.group(3) != null ? Integer.parseInt(m.group(3)) : 0;
                return a * 10000 + b * 100 + c;
            }
            m = java.util.regex.Pattern.compile("(\\d+)").matcher(tag);
            if (m.find()) return Integer.parseInt(m.group(1));
        } catch (Throwable ignored) {
        }
        return -1;
    }

    // ---------- 简易 JSON 取值（只处理字符串字段，够用） ----------

    static String jsonString(String json, String key) {
        try {
            String pat = "\"" + key + "\"\\s*:\\s*\"";
            int i = json.indexOf("\"" + key + "\"");
            if (i < 0) return null;
            int colon = json.indexOf(':', i);
            if (colon < 0) return null;
            int q1 = json.indexOf('"', colon);
            if (q1 < 0) return null;
            StringBuilder sb = new StringBuilder();
            for (int k = q1 + 1; k < json.length(); k++) {
                char c = json.charAt(k);
                if (c == '\\' && k + 1 < json.length()) {
                    char n = json.charAt(k + 1);
                    if (n == 'n') { sb.append('\n'); k++; }
                    else if (n == 't') { sb.append('\t'); k++; }
                    else if (n == '"') { sb.append('"'); k++; }
                    else if (n == '\\') { sb.append('\\'); k++; }
                    else if (n == 'u' && k + 5 < json.length()) {
                        try {
                            sb.append((char) Integer.parseInt(json.substring(k + 2, k + 6), 16));
                            k += 5;
                        } catch (Throwable ignored) {}
                    } else sb.append(n);
                } else if (c == '"') {
                    return sb.toString();
                } else {
                    sb.append(c);
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** 在 assets 数组里找 .apk 的 download url。 */
    static String findApkAsset(String json) {
        try {
            int idx = 0;
            while (true) {
                int p = json.indexOf("browser_download_url", idx);
                if (p < 0) break;
                int q1 = json.indexOf('"', json.indexOf(':', p) + 1);
                int q2 = json.indexOf('"', q1 + 1);
                if (q1 < 0 || q2 < 0) break;
                String u = json.substring(q1 + 1, q2);
                if (u.toLowerCase().endsWith(".apk")) return u;
                idx = q2 + 1;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static String readAll(InputStream is) throws Exception {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        return bos.toString("UTF-8");
    }

    // ---------- 下载 ----------

    /**
     * 下载 APK 到公共下载目录。回调在主线程。
     */
    public static void download(final Context ctx, final String url,
                                final Progress cb) {
        new Thread(new Runnable() {
                @Override public void run() {
                    HttpURLConnection conn = null;
                    FileOutputStream fos = null;
                    try {
                        conn = (HttpURLConnection) new URL(url).openConnection();
                        conn.setConnectTimeout(15000);
                        conn.setReadTimeout(30000);
                        conn.setInstanceFollowRedirects(true);
                        conn.setRequestProperty("User-Agent", "Weifp-Updater");
                        int total = conn.getContentLength();
                        // Android 10+ 分区存储：直接写公共 Download 会被拒。
                        // 用应用自己的外部目录（无需任何权限，卸载时自动清理）。
                        File dir;
                        if (Build.VERSION.SDK_INT >= 29) {
                            dir = new File(ctx.getExternalFilesDir(null), "update");
                        } else {
                            dir = new File(Environment.getExternalStoragePublicDirectory(
                                    Environment.DIRECTORY_DOWNLOADS), "Weifp");
                        }
                        if (!dir.exists() && !dir.mkdirs()) {
                            cb.onFail("mkdir");
                            return;
                        }
                        File out = new File(dir, "Weifp_update_" + System.currentTimeMillis() + ".apk");
                        fos = new FileOutputStream(out);
                        InputStream is = conn.getInputStream();
                        byte[] buf = new byte[16384];
                        long got = 0;
                        int n;
                        int lastPct = -1;
                        while ((n = is.read(buf)) > 0) {
                            fos.write(buf, 0, n);
                            got += n;
                            if (total > 0) {
                                int pct = (int) (got * 100 / total);
                                if (pct != lastPct && pct % 2 == 0) {
                                    lastPct = pct;
                                    cb.onProgress(pct);
                                }
                            }
                        }
                        is.close();
                        fos.flush();
                        fos.close();
                        fos = null;
                        cb.onDone(out.getAbsolutePath());
                    } catch (Throwable t) {
                        cb.onFail(t.getClass().getSimpleName());
                    } finally {
                        try { if (fos != null) fos.close(); } catch (Throwable ignored) {}
                        try { if (conn != null) conn.disconnect(); } catch (Throwable ignored) {}
                    }
                }
            }).start();
    }

    /** 下载进度回调（都在主线程）。 */
    public interface Progress {
        void onProgress(int percent);
        void onDone(String apkPath);
        void onFail(String reason);
    }
}
