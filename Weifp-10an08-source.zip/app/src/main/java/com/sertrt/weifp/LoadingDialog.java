package com.sertrt.weifp;

import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class LoadingDialog extends Dialog {

    public LoadingDialog(Context context, String msg) {
        super(context);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            // 去掉弹窗外围暗色和阴影
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

            WindowManager.LayoutParams params = window.getAttributes();
            params.width = WindowManager.LayoutParams.WRAP_CONTENT;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.gravity = Gravity.CENTER;
            window.setAttributes(params);
        }

        float density = context.getResources().getDisplayMetrics().density;

        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);

        // ★ 设置最小宽度，强制把正方形拉成长方形
        root.setMinimumWidth((int)(200 * density));
        root.setPadding((int)(20 * density), (int)(25 * density), (int)(20 * density), (int)(25 * density));

        // 灰色圆角背景
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF333333); // 深灰底
        bg.setCornerRadius(UiSpec.dp(context, UiSpec.RADIUS_L));
        root.setBackground(bg);

        // 橘色加载圈
        ProgressBar pb = new ProgressBar(context);
        try {
            pb.setIndeterminateTintList(ColorStateList.valueOf(0xFFFFB615));
        } catch (Throwable ignored) {}
        LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams((int)(36 * density), (int)(36 * density));
        pb.setLayoutParams(pLp);
        root.addView(pb);

        // 文字说明
        TextView tv = new TextView(context);
        tv.setText(msg);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(14);
        tv.setGravity(Gravity.CENTER);

        // ★ 支持多行，防止文字长时显示不全
        tv.setMaxLines(4);
        tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tvLp.topMargin = (int)(15 * density);
        tv.setLayoutParams(tvLp);

        root.addView(tv);

        setContentView(root);
        setCancelable(false);
    }
}
