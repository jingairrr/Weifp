package com.sertrt.weifp;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 色度抠图面板（Chroma Key）。
 *
 * 交互：
 *  1. 吸管：点「吸管」后到画布上点一下，取该点颜色作为要抠掉的颜色；
 *  2. 灵敏度 / 羽化 / 溢出抑制 三个滑轨，实时预览；
 *  3. 应用后写入当前图层（可撤销），取消则还原。
 *
 * 只作用于**当前图层**；如果当前在底图层，会自动复制成新图层再抠，不破坏底图。
 *
 * 本类是纯新增，沿用项目现有 UI 风格（Dialog + 圆角 + 主题色）。
 */
public final class ChromaKeyPanel {

    /** 预览用的复用像素缓冲（避免每次拖动都分配几十 MB）。 */
    private static int[] previewBuf = null;
    /**
     * 预览位图：双缓冲。
     *
     * ★ 必须是两张轮流用：setChromaPreview() 会回收传进去的旧位图，
     *   如果复用同一张，第二次就会把自己回收掉（崩溃或画面空白）。
     */
    private static Bitmap previewBitmapA = null;
    private static Bitmap previewBitmapB = null;
    private static boolean previewUseA = true;

    /** 回调。 */
    public interface Callback {
        /** 用户应用了抠图（已可撤销）。 */
        void onApplied();
    }

    private ChromaKeyPanel() {
    }

    /** 打开抠图面板。 */
    public static void show(final Activity act, final ZoomImageView zoom, final Callback cb) {
        if (act == null || act.isFinishing()) return;

        final float d = act.getResources().getDisplayMetrics().density;
        final int textColor = ThemeManager.getTextColor(act);
        final int panelColor = ThemeManager.getPanelColor(act);
        final int buttonColor = ThemeManager.getButtonColor(act);

        // 源图（只读派生，不改图层）
        final Bitmap target = zoom.prepareChromaTarget();
        if (target == null) {
            Toast.makeText(act, LanguageManager.getString(act, R.string.chroma_no_layer),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        final int tw = target.getWidth();
        final int th = target.getHeight();
        if (tw <= 0 || th <= 0) {
            Toast.makeText(act, LanguageManager.getString(act, R.string.chroma_no_layer),
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // 原始像素（用于每次重新计算，保证参数调整不累积）
        final int[] originalPx = new int[tw * th];
        target.getPixels(originalPx, 0, tw, 0, 0, tw, th);

        final ChromaKey.Settings settings = new ChromaKey.Settings();
        // 默认目标色：如果画布上能拿到，就不预设；等用户吸管
        final boolean[] hasKey = {false};

        final Dialog dialog = new Dialog(act);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(roundBg(panelColor, 12 * d));
        int pad = (int) (18 * d);
        root.setPadding(pad, pad, pad, (int) (10 * d));

        TextView title = new TextView(act);
        title.setText(LanguageManager.getString(act, R.string.chroma_title));
        title.setTextSize(16);
        title.setTextColor(textColor);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, (int) (10 * d));
        root.addView(title);

        // ---- 取色区 ----
        final View[] swatch = new View[1];
        LinearLayout colorRow = new LinearLayout(act);
        colorRow.setOrientation(LinearLayout.HORIZONTAL);

        swatch[0] = new View(act);
        swatch[0].setBackground(roundBg(0xFF888888, 6 * d));
        LinearLayout.LayoutParams swLp = new LinearLayout.LayoutParams((int) (34 * d), (int) (34 * d));
        swLp.setMargins(0, 0, (int) (10 * d), 0);
        swatch[0].setLayoutParams(swLp);
        colorRow.addView(swatch[0]);

        final Button btnPick = makeBtn(act, LanguageManager.getString(act, R.string.chroma_pick),
                buttonColor, textColor, d);
        btnPick.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        colorRow.addView(btnPick);

        root.addView(colorRow);

        final TextView tvPicked = new TextView(act);
        tvPicked.setText(LanguageManager.getString(act, R.string.chroma_not_picked));
        tvPicked.setTextSize(12);
        tvPicked.setTextColor(0xFF9E9E9E);
        tvPicked.setPadding(0, (int) (6 * d), 0, (int) (8 * d));
        root.addView(tvPicked);

        // ---- 三个滑轨 ----
        final SeekBar sbSens = makeSeek(act, 40);
        final SeekBar sbFeather = makeSeek(act, 20);
        final SeekBar sbSpill = makeSeek(act, 30);

        final TextView tvSens = addSliderRow(act, root, LanguageManager.getString(act, R.string.chroma_sensitivity),
                sbSens, d, textColor, 40);
        final TextView tvFeather = addSliderRow(act, root,
                LanguageManager.getString(act, R.string.chroma_feather), sbFeather, d, textColor, 20);
        final TextView tvSpill = addSliderRow(act, root,
                LanguageManager.getString(act, R.string.chroma_spill), sbSpill, d, textColor, 30);

        // ---- 预览开关 ----
        final boolean[] previewOn = {true};
        final Button btnPreview = makeBtn(act,
                LanguageManager.getString(act, R.string.chroma_preview_on),
                buttonColor, textColor, d);
        btnPreview.setTextSize(12);
        LinearLayout.LayoutParams pvLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        pvLp.gravity = Gravity.CENTER_HORIZONTAL;
        pvLp.setMargins(0, (int) (4 * d), 0, (int) (8 * d));
        btnPreview.setLayoutParams(pvLp);
        root.addView(btnPreview);

        // ---- 应用/取消 ----
        LinearLayout btnRow = new LinearLayout(act);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        final Button btnCancel = makeBtn(act, LanguageManager.getString(act, R.string.cancel),
                0xFFB61515, Color.WHITE, d);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        clp.setMargins(0, 0, (int) (5 * d), 0);
        btnCancel.setLayoutParams(clp);
        btnRow.addView(btnCancel);

        final Button btnApply = makeBtn(act, LanguageManager.getString(act, R.string.chroma_apply),
                0xFFFFB615, Color.BLACK, d);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f);
        alp.setMargins((int) (5 * d), 0, 0, 0);
        btnApply.setLayoutParams(alp);
        btnRow.addView(btnApply);

        root.addView(btnRow);

        // ============ 逻辑 ============

        // 预览改成后台线程 + 防抖：
        //   原来在主线程跑全图抠图，拖灵敏度滑轨时界面直接卡住。
        final java.util.concurrent.atomic.AtomicBoolean previewRunning =
                new java.util.concurrent.atomic.AtomicBoolean(false);
        final java.util.concurrent.atomic.AtomicBoolean previewPending =
                new java.util.concurrent.atomic.AtomicBoolean(false);

        final Runnable[] applyPreview = new Runnable[1];
        applyPreview[0] = new Runnable() {
            @Override
            public void run() {
                if (!hasKey[0]) return;
                // 已有任务在跑：标记一下，等它结束再补一次（合并中间状态）
                if (previewRunning.get()) {
                    previewPending.set(true);
                    return;
                }
                previewRunning.set(true);
                new Thread(new Runnable() {
                        @Override public void run() {
                            Bitmap out = null;
                            double ratio = 0;
                            try {
                                // ★ 不再 clone() 整个数组：
                                //   4000x3000 = 48MB，每拖一下都拷一遍，比算法本身慢得多。
                                //   复用同一块缓冲，每次从 originalPx 拷回来即可。
                                if (previewBuf == null || previewBuf.length != originalPx.length) {
                                    previewBuf = new int[originalPx.length];
                                }
                                System.arraycopy(originalPx, 0, previewBuf, 0, originalPx.length);
                                ChromaKey.Result r = ChromaKey.apply(previewBuf, tw, th, settings, act);
                                // 双缓冲轮流用：上一次的位图正被视图显示，不能覆盖
                                Bitmap target = previewUseA ? previewBitmapB : previewBitmapA;
                                if (target == null || target.isRecycled()
                                        || target.getWidth() != tw || target.getHeight() != th) {
                                    target = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
                                }
                                target.setPixels(previewBuf, 0, tw, 0, 0, tw, th);
                                if (previewUseA) previewBitmapB = target;
                                else previewBitmapA = target;
                                previewUseA = !previewUseA;
                                out = target;
                                ratio = r.removedRatio();
                            } catch (Throwable ignored) {
                            }
                            final Bitmap fOut = out;
                            final double fRatio = ratio;
                            act.runOnUiThread(new Runnable() {
                                    @Override public void run() {
                                        try {
                                            if (fOut != null) zoom.setChromaPreview(fOut);
                                            tvPicked.setText(String.format("%s  %.1f%%",
                                                    LanguageManager.getString(act,
                                                        R.string.chroma_removed),
                                                    fRatio * 100));
                                        } catch (Throwable ignored) {
                                        }
                                        previewRunning.set(false);
                                        if (previewPending.getAndSet(false)) {
                                            applyPreview[0].run();
                                        }
                                    }
                                });
                        }
                    }).start();
            }
        };

        final Runnable clearPreview = new Runnable() {
            @Override
            public void run() {
                zoom.setChromaPreview(null);
            }
        };

        btnPick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // ★ 用 hide 而不是 dismiss：面板和所有参数都保留
                    dialog.hide();
                    startEyedropper(act, zoom, new EyedropperCallback() {
                            @Override
                            public void onPicked(int color) {
                                settings.keyColor = color;
                                hasKey[0] = true;
                                swatch[0].setBackground(roundBg(
                                        0xFF000000 | (color & 0xFFFFFF), 6 * d));
                                try { dialog.show(); } catch (Throwable ignored) {}
                                applyPreview[0].run();
                            }

                            @Override
                            public void onCancel() {
                                // 没取到色也要有明确反馈，不能像"点了没反应"
                                try { dialog.show(); } catch (Throwable ignored) {}
                                Toast.makeText(act,
                                        LanguageManager.getString(act, R.string.chroma_pick_fail),
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                }
            });

        SeekBar.OnSeekBarChangeListener lst = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                settings.sensitivity = sbSens.getProgress();
                settings.feather = sbFeather.getProgress();
                settings.spillSuppress = sbSpill.getProgress();
                tvSens.setText(String.valueOf(settings.sensitivity));
                tvFeather.setText(String.valueOf(settings.feather));
                tvSpill.setText(String.valueOf(settings.spillSuppress));
                if (previewOn[0]) applyPreview[0].run();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        };
        sbSens.setOnSeekBarChangeListener(lst);
        sbFeather.setOnSeekBarChangeListener(lst);
        sbSpill.setOnSeekBarChangeListener(lst);

        btnPreview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    previewOn[0] = !previewOn[0];
                    btnPreview.setText(LanguageManager.getString(act, previewOn[0]
                            ? R.string.chroma_preview_on : R.string.chroma_preview_off));
                    if (previewOn[0]) {
                        applyPreview[0].run();
                    } else {
                        clearPreview.run();
                    }
                }
            });

        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clearPreview.run();
                    dialog.dismiss();
                }
            });

        btnApply.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!hasKey[0]) {
                        Toast.makeText(act, LanguageManager.getString(act, R.string.chroma_need_pick),
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int[] px = originalPx.clone();
                    ChromaKey.Result res = ChromaKey.apply(px, tw, th, settings, act);
                    // 保护：抠掉绝大部分说明取色点选错了（比如取了主体色），
                    // 静默接受会让用户以为"整张图都没了"。
                    if (res.removedRatio() > 0.95) {
                        Toast.makeText(act,
                                LanguageManager.getString(act, R.string.chroma_all_removed),
                                Toast.LENGTH_LONG).show();
                    }
                    clearPreview.run();
                    boolean ok = false;
                    try {
                        ok = zoom.applyChromaPixels(px, tw, th);
                    } catch (Throwable e) {
                        try { CrashLogger.log("抠图-应用失败", e); } catch (Throwable ignored) {}
                    }
                    if (!ok) {
                        Toast.makeText(act, LanguageManager.getString(act,
                                R.string.chroma_no_layer), Toast.LENGTH_SHORT).show();
                        return;
                    }
                    dialog.dismiss();
                    Toast.makeText(act, LanguageManager.getString(act, R.string.chroma_done),
                            Toast.LENGTH_SHORT).show();
                    if (cb != null) cb.onApplied();
                }
            });

        dialog.setContentView(root);
        Window win = dialog.getWindow();
        if (win != null) {
            WindowManager.LayoutParams params = win.getAttributes();
            params.width = (int) (act.getResources().getDisplayMetrics().widthPixels * 0.9);
            win.setAttributes(params);
        }
        dialog.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                @Override public void onDismiss(android.content.DialogInterface di) {
                    zoom.setChromaPreview(null);
                }
            });
        dialog.show();

        // 已有取色：直接出预览
        if (hasKey[0]) {
            applyPreview[0].run();
        }
    }

    // ============ 吸管 ============

    interface EyedropperCallback {
        void onPicked(int color);

        void onCancel();
    }

    /**
     * 启动吸管：进入取色模式，用户点画布取色。
     * 取色期间在屏幕上显示提示条，点取消退出。
     */
    static void startEyedropper(final Activity act, final ZoomImageView zoom,
                                final EyedropperCallback cb) {
        // 用一个透明覆盖层处理点击
        final ChromaEyedropperLayer[] ref = new ChromaEyedropperLayer[1];
        final ChromaEyedropperLayer layer = new ChromaEyedropperLayer(act, zoom,
                new ChromaEyedropperLayer.Listener() {
                    @Override public void onPicked(float sx, float sy) {
                        int color = zoom.pickColorAtScreen(sx, sy, 2);
                        try { if (ref[0] != null) ref[0].dismiss(); } catch (Throwable ignored) {}
                        if (color == 0) {
                            cb.onCancel();
                        } else {
                            cb.onPicked(color);
                        }
                    }

                    @Override public void onCancel() {
                        try { if (ref[0] != null) ref[0].dismiss(); } catch (Throwable ignored) {}
                        cb.onCancel();
                    }

                    @Override public void onReady(ChromaEyedropperLayer l) {
                    }
                });
        ref[0] = layer;
        try {
            layer.show();
        } catch (Throwable t) {
            cb.onCancel();
        }
    }

    // ============ UI 工具 ============

    private static Button makeBtn(Activity act, String text, int bg, int fg, float d) {
        Button b = new Button(act);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setBackground(roundBg(bg, 8 * d));
        b.setTextColor(fg);
        b.setPadding((int) (10 * d), (int) (6 * d), (int) (10 * d), (int) (6 * d));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        return b;
    }

    private static SeekBar makeSeek(Activity act, int init) {
        SeekBar sb = new SeekBar(act);
        sb.setMax(100);
        sb.setProgress(init);
        try {
            sb.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFFFB615));
            sb.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFFFB615));
        } catch (Throwable ignored) {
        }
        return sb;
    }

    private static TextView addSliderRow(Activity act, LinearLayout root, String label,
                                         SeekBar sb, float d, int textColor, int init) {
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView tv = new TextView(act);
        tv.setText(label);
        tv.setTextSize(13);
        tv.setTextColor(textColor);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams((int) (76 * d),
                LinearLayout.LayoutParams.WRAP_CONTENT);
        tv.setLayoutParams(tlp);
        row.addView(tv);

        sb.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(sb);

        TextView val = new TextView(act);
        val.setText(String.valueOf(init));
        val.setTextSize(13);
        val.setTextColor(0xFFFFB615);
        val.setGravity(Gravity.CENTER);
        val.setLayoutParams(new LinearLayout.LayoutParams((int) (44 * d),
                LinearLayout.LayoutParams.WRAP_CONTENT));
        row.addView(val);

        root.addView(row);
        return val;
    }

    private static GradientDrawable roundBg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }
}
