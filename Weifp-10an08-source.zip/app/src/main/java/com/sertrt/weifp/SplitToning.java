package com.sertrt.weifp;

public class SplitToning {

    public float shadowHue = 0f;       // 0~360
    public float shadowSat = 0f;       // 0~100
    public float highlightHue = 0f;    // 0~360
    public float highlightSat = 0f;    // 0~100
    public int balance = 0;            // -100~100

    public boolean isEmpty() {
        return shadowSat <= 0.01f && highlightSat <= 0.01f;
    }

    public void reset() {
        shadowHue = 0f;
        shadowSat = 0f;
        highlightHue = 0f;
        highlightSat = 0f;
        balance = 0;
    }

    public int applyPixel(int r8, int g8, int b8) {
        if (isEmpty()) return (r8 << 16) | (g8 << 8) | b8;

        float rf = r8 / 255f, gf = g8 / 255f, bf = b8 / 255f;
        float lum = 0.299f * rf + 0.587f * gf + 0.114f * bf;

        float midpoint = 0.5f + (balance / 100f) * 0.3f;
        if (midpoint < 0.15f) midpoint = 0.15f;
        if (midpoint > 0.85f) midpoint = 0.85f;

        float shadowW = 0f, highlightW = 0f;
        if (lum < midpoint) {
            shadowW = (midpoint - lum) / midpoint;
        } else {
            highlightW = (lum - midpoint) / (1f - midpoint);
        }

        // RGB -> HSL
        float max = Math.max(rf, Math.max(gf, bf));
        float min = Math.min(rf, Math.min(gf, bf));
        float h = 0f, s = 0f, l = (max + min) / 2f;
        float d = max - min;
        if (d > 0.00001f) {
            if (l > 0.5f) s = d / (2f - max - min);
            else s = d / (max + min);
            if (max == rf) h = (gf - bf) / d + (gf < bf ? 6f : 0f);
            else if (max == gf) h = (bf - rf) / d + 2f;
            else h = (rf - gf) / d + 4f;
            h *= 60f;
        }

        // 阴影着色
        if (shadowW > 0.001f && shadowSat > 0.01f) {
            float mixAmt = shadowW * 0.7f;
            float hueDiff = shadowHue - h;
            while (hueDiff > 180f) hueDiff -= 360f;
            while (hueDiff < -180f) hueDiff += 360f;
            h = h + hueDiff * mixAmt;
            float targetS = shadowSat / 100f;
            s = s + (targetS - s) * mixAmt;
            if (h < 0) h += 360f;
            if (h >= 360f) h -= 360f;
        }

        // 高光着色
        if (highlightW > 0.001f && highlightSat > 0.01f) {
            float mixAmt = highlightW * 0.7f;
            float hueDiff = highlightHue - h;
            while (hueDiff > 180f) hueDiff -= 360f;
            while (hueDiff < -180f) hueDiff += 360f;
            h = h + hueDiff * mixAmt;
            float targetS = highlightSat / 100f;
            s = s + (targetS - s) * mixAmt;
            if (h < 0) h += 360f;
            if (h >= 360f) h -= 360f;
        }

        if (s < 0f) s = 0f;
        if (s > 1f) s = 1f;

        // HSL -> RGB
        float c = (1f - Math.abs(2f * l - 1f)) * s;
        float x = c * (1f - Math.abs((h / 60f) % 2f - 1f));
        float m = l - c / 2f;
        float rr = 0, gg = 0, bb = 0;
        if (h < 60f) { rr = c; gg = x; bb = 0; }
        else if (h < 120f) { rr = x; gg = c; bb = 0; }
        else if (h < 180f) { rr = 0; gg = c; bb = x; }
        else if (h < 240f) { rr = 0; gg = x; bb = c; }
        else if (h < 300f) { rr = x; gg = 0; bb = c; }
        else { rr = c; gg = 0; bb = x; }

        int nr = (int)((rr + m) * 255f);
        int ng = (int)((gg + m) * 255f);
        int nb = (int)((bb + m) * 255f);
        if (nr < 0) nr = 0; if (nr > 255) nr = 255;
        if (ng < 0) ng = 0; if (ng > 255) ng = 255;
        if (nb < 0) nb = 0; if (nb > 255) nb = 255;

        return (nr << 16) | (ng << 8) | nb;
    }
}
