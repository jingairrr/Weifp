package com.sertrt.weifp;

import java.util.ArrayList;
import java.util.List;

/**
 * 指令词典：定义 Weifp 支持的「命令」及其参数。
 *
 * 设计目标：让外部（人或 AI）用一句话就能操作软件，例如
 *   {"cmd":"brightness","value":50}
 *   {"cmd":"rotate","value":90}
 *   {"cmd":"upscale","value":2}
 *
 * 一个指令包含：
 *   - key      英文标识（JSON 里用）
 *   - aliases  中文/英文别名，用户怎么写都能认
 *   - min/max  数值范围（-1 表示不限）
 *   - desc     说明
 */
public final class CommandDict {

    /** 指令定义。 */
    public static class Def {
        public final String key;
        public final String[] aliases;
        public final float min;
        public final float max;
        public final String desc;

        Def(String key, String[] aliases, float min, float max, String desc) {
            this.key = key;
            this.aliases = aliases;
            this.min = min;
            this.max = max;
            this.desc = desc;
        }

        public boolean hasRange() {
            return min < max;
        }
    }

    private static final List<Def> DEFS = new ArrayList<Def>();

    private static void add(String key, float min, float max, String desc, String... aliases) {
        DEFS.add(new Def(key, aliases, min, max, desc));
    }

    static {
        // ==================== 基础：几何 ====================
        add("rotate", -1, -1, "旋转，单位度（90/180/270）", "旋转", "转", "rotate");
        add("flip_h", -1, -1, "水平翻转", "水平翻转", "镜像", "左右翻转", "flip_h");
        add("flip_v", -1, -1, "垂直翻转", "垂直翻转", "上下翻转", "flip_v");
        add("resize", -1, -1, "调整尺寸，值=目标宽或高（像素）", "调整尺寸", "缩放尺寸", "resize");
        add("crop", -1, -1, "裁剪（需配合 x/y/w/h 参数）", "裁剪", "剪切画面", "crop");

        // ==================== 基础：调整 ====================
        add("brightness", -100, 100, "亮度 -100~100", "亮度", "brightness", "明暗", "曝光");
        add("contrast", -100, 100, "对比度 -100~100", "对比度", "contrast");
        add("saturation", -100, 100, "饱和度 -100~100", "饱和度", "saturation", "鲜艳度");
        add("shadows", -100, 100, "阴影 -100~100", "阴影", "shadows", "暗部");
        add("highlights", -100, 100, "高光 -100~100", "高光", "highlights", "亮部");
        add("temperature", -100, 100, "色温 -100~100（负=冷，正=暖）", "色温", "temperature", "冷暖");
        add("tint", -100, 100, "色调 -100~100（负=绿，正=品红）", "色调", "tint", "品红");
        add("sharpness", -100, 100, "清晰度 -100~100", "清晰度", "锐化", "sharpness");
        add("vibrance", -100, 100, "自然饱和度 -100~100", "自然饱和度", "vibrance");

        // ==================== 高级：HSL ====================
        add("hsl_hue", -100, 100, "HSL 色相偏移", "色相偏移", "hsl_hue");
        add("hsl_sat", -100, 100, "HSL 饱和度", "hsl饱和", "hsl_sat");
        add("hsl_lum", -100, 100, "HSL 明度", "hsl明度", "hsl_lum");

        // ==================== 高级：色阶 / 曲线 ====================
        add("levels", -1, -1, "色阶（需配合 black/gamma/white）", "色阶", "levels");
        add("curve", -1, -1, "曲线（需配合 points 参数）", "曲线", "curve");

        // ==================== 高级：特殊效果 ====================
        add("split_shadow_hue", -1, -1, "分色调-阴影色相", "阴影色相");
        add("split_shadow_sat", -100, 100, "分色调-阴影饱和度", "阴影饱和");
        add("split_highlight_hue", -1, -1, "分色调-高光色相", "高光色相");
        add("split_highlight_sat", -100, 100, "分色调-高光饱和度", "高光饱和");
        add("noise_color", -1, -1, "彩色噪点强度", "彩色噪点", "噪点");
        add("noise_luma", -1, -1, "亮度噪点强度", "亮度噪点");
        add("denoise", -1, -1, "一键降噪", "降噪", "denoise");

        // ==================== 高级：AI / 智能 ====================
        add("upscale", -1, -1, "超分辨率放大，值=倍数（2/4）", "超分", "放大", "upscale", "超分辨率");
        add("chroma_key", -1, -1, "色度抠图（需配合 key_color）", "抠图", "去背景", "抠背景", "chroma_key");
        add("mask_radial", -1, -1, "加径向蒙版", "径向蒙版", "圆形蒙版");
        add("mask_brush", -1, -1, "加画笔蒙版", "画笔蒙版");
        add("mask_color", -1, -1, "加颜色蒙版", "颜色蒙版");

        // ==================== 全局操作 ====================
        add("reset", -1, -1, "重置全部调整", "重置", "还原", "reset", "清空调整");
        add("preset_apply", -1, -1, "应用预设（需配合 name）", "应用预设", "preset_apply");
        add("preset_save", -1, -1, "保存当前预设（需配合 name）", "保存预设", "preset_save");
        add("save", -1, -1, "保存到历史", "保存", "save", "存");
        add("export", -1, -1, "导出到相册", "导出", "export", "输出");
        add("undo", -1, -1, "撤销", "撤销", "回退", "undo");
        add("redo", -1, -1, "重做", "重做", "redo");
    }

    private CommandDict() {
    }

    public static List<Def> all() {
        return DEFS;
    }

    /** 按 key 或别名查指令；找不到返回 null。 */
    public static Def find(String word) {
        if (word == null) return null;
        String w = word.trim().toLowerCase();
        if (w.length() == 0) return null;
        for (Def d : DEFS) {
            if (d.key.equalsIgnoreCase(w)) return d;
            for (String a : d.aliases) {
                String al = a.toLowerCase();
                if (al.equals(w)) return d;
                // 允许「把亮度调到」「调亮度」这类前缀/后缀
                if (w.length() >= 2 && (w.contains(al) || al.contains(w))) return d;
            }
        }
        return null;
    }

    /** 生成给 AI 看的指令说明（一行一条）。 */
    public static String describeAll() {
        StringBuilder sb = new StringBuilder();
        for (Def d : DEFS) {
            sb.append(d.key);
            if (d.hasRange()) {
                sb.append(" (").append((int) d.min).append("~").append((int) d.max).append(")");
            }
            sb.append("  —  ").append(d.desc).append('\n');
        }
        return sb.toString();
    }
}
