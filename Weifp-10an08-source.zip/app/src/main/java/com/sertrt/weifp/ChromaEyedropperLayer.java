package com.sertrt.weifp;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 吸管取色用的全屏覆盖层。
 *
 * 覆盖在画布上方，用户点哪里就取哪里的颜色。
 * 自己管理生命周期：关闭时自动移除，不残留（对应"抠图页面切工具去不掉"那类问题的预防）。
 */
class ChromaEyedropperLayer extends Dialog {

    interface Listener {
        void onPicked(float screenX, float screenY);

        void onCancel();

        void onReady(ChromaEyedropperLayer layer);
    }

    private final Activity act;
    private final ZoomImageView zoom;

    ChromaEyedropperLayer(final Activity act, final ZoomImageView zoom, final Listener l) {
        super(act, android.R.style.Theme_Translucent_NoTitleBar_Fullscreen);
        this.act = act;
        this.zoom = zoom;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window w = getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT);
            w.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        }
        setCancelable(true);
        setOnDismissListener(new OnDismissListener() {
                @Override public void onDismiss(android.content.DialogInterface d) {
                    // 确保不遮挡后续操作
                    try {
                        if (zoom != null) {
                            zoom.setEnabled(true);
                            zoom.invalidate();
                        }
                    } catch (Throwable ignored) {
                    }
                }
            });

        float density = act.getResources().getDisplayMetrics().density;

        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);

        // 顶部提示条
        LinearLayout bar = new LinearLayout(act);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding((int) (14 * density), (int) (10 * density),
                (int) (14 * density), (int) (10 * density));
        bar.setBackgroundColor(0xDD222222);

        TextView tv = new TextView(act);
        tv.setText(LanguageManager.getString(act, R.string.chroma_eyedropper_hint));
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(13);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(tv);

        Button btnCancel = new Button(act);
        btnCancel.setText(LanguageManager.getString(act, R.string.cancel));
        btnCancel.setTextSize(13);
        btnCancel.setAllCaps(false);
        btnCancel.setBackgroundColor(0xFFB61515);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setMinHeight(0);
        btnCancel.setMinimumHeight(0);
        btnCancel.setPadding((int) (12 * density), (int) (2 * density),
                (int) (12 * density), (int) (2 * density));
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    l.onCancel();
                }
            });
        bar.addView(btnCancel);

        root.addView(bar);

        // 透明捕获层
        View catcher = new View(act);
        catcher.setBackgroundColor(0x00000000);
        catcher.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        catcher.setOnTouchListener(new View.OnTouchListener() {
                @Override public boolean onTouch(View v, MotionEvent e) {
                    if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                        // 屏幕坐标 -> 当前窗口坐标（全屏透明层，基本一致）
                        int[] loc = new int[2];
                        v.getLocationOnScreen(loc);
                        float sx = e.getRawX() - loc[0];
                        float sy = e.getRawY() - loc[1];
                        // 转成 zoom 视图内的坐标
                        int[] zloc = new int[2];
                        zoom.getLocationOnScreen(zloc);
                        float zx = e.getRawX() - zloc[0];
                        float zy = e.getRawY() - zloc[1];
                        l.onPicked(zx, zy);
                        return true;
                    }
                    return true;
                }
            });
        root.addView(catcher);

        setContentView(root);
        l.onReady(this);
    }
}
