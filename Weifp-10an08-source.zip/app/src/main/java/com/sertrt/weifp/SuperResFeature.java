package com.sertrt.weifp;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 超分放大功能（Lightroom Super Resolution 式的一次性动作，不是默认开关）。
 *
 * 交互：用户点「超分放大」→ 选 2× / 4× → 确认 → 后台处理 → 整篇文档替换为高清图。
 * 语义：会先把当前所有编辑（滤镜 + 图层）合并成一张图，再放大。
 *       所以图层会被合并、参数被固化；因此弹窗里必须明确提示，且默认不勾选任何选项。
 *
 * 本类是纯新增，不改动任何现有渲染/图层逻辑；唯一依赖是 ZoomImageView 新增的
 * {@link ZoomImageView#replaceDocument(Bitmap)}。
 */
public final class SuperResFeature {

    /** 替换完成回调（用于刷新界面、标记未保存）。 */
    public interface Callback {
        void onApplied(Bitmap result, double scale);
    }

    /**
     * 尺寸变化后处理历史存档。
     *
     * 分三种情况（对应 WPB 开关状态）：
     *  - WPB 关、每步存档关：什么都不做
     *  - WPB 关、每步存档开：旧步骤图是旧尺寸，清空以免错误恢复
     *  - WPB 开：清空旧步骤（旧尺寸），并把"超分后的尺寸"写进存档状态，
     *            这样恢复时不会把旧尺寸的图套到新尺寸上
     */
    public interface HistoryHandler {
        /** @param oldW/oldH 超分前尺寸；newW/newH 超分后尺寸 */
        void onDocumentResized(int oldW, int oldH, int newW, int newH);
    }

    private SuperResFeature() {
    }

    /** 打开超分弹窗。 */
    public static void show(final Activity act, final ZoomImageView zoom, final Callback cb) {
        show(act, zoom, cb, null, null);
    }

    /**
     * @param rawUri 原始 RAW 文件 Uri（非 RAW 传 null）。传入时超分会优先按全尺寸重新解码。
     */
    public static void show(final Activity act, final ZoomImageView zoom, final Callback cb,
                            final Uri rawUri) {
        show(act, zoom, cb, rawUri, null);
    }

    public static void show(final Activity act, final ZoomImageView zoom, final Callback cb,
                            final Uri rawUri, final HistoryHandler historyHandler) {
        if (act == null || act.isFinishing()) {
            return;
        }
        final float density = act.getResources().getDisplayMetrics().density;
        final int textColor = ThemeManager.getTextColor(act);
        final int panelColor = ThemeManager.getPanelColor(act);
        final int buttonColor = ThemeManager.getButtonColor(act);
        final int radiusPx = (int) (8 * density);

        // 用"实际会被超分的那张图"的尺寸，不能用 drawable 的显示尺寸
        int curW = 0, curH = 0;
        Bitmap probe = null;
        try {
            probe = zoom.getBaseForSuperRes();
            if (probe != null) {
                curW = probe.getWidth();
                curH = probe.getHeight();
            }
        } catch (Throwable ignored) {
        } finally {
            if (probe != null && !probe.isRecycled()) {
                probe.recycle();
                probe = null;
            }
        }
        if (curW <= 0 && zoom.getDrawable() != null) {
            curW = zoom.getDrawable().getIntrinsicWidth();
            curH = zoom.getDrawable().getIntrinsicHeight();
        }
        if (curW <= 0 || curH <= 0) {
            Toast.makeText(act, LanguageManager.getString(act, R.string.super_res_no_image),
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // RAW 全尺寸通常正好是半尺寸的 2 倍；弹窗不能真的解码全尺寸（太吃内存），
        // 所以按 2 倍预估，并把风险写在提示里。
        final boolean rawFullSize = rawUri != null
                && RawFullSizeDecoder.isRawUri(act, rawUri);
        final int srcW = rawFullSize ? curW * 2 : curW;
        final int srcH = rawFullSize ? curH * 2 : curH;

        final Dialog dialog = new Dialog(act);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(
                    new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        }

        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(roundBg(panelColor, 12 * density));
        int pad = (int) (20 * density);
        root.setPadding(pad, pad, pad, (int) (12 * density));

        TextView tvTitle = new TextView(act);
        tvTitle.setText(LanguageManager.getString(act, R.string.super_res_title));
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(textColor);
        tvTitle.setGravity(Gravity.CENTER);
        tvTitle.setPadding(0, 0, 0, (int) (10 * density));
        root.addView(tvTitle);

        TextView tvSize = new TextView(act);
        Runtime rt0 = Runtime.getRuntime();
        long usedMB = (rt0.totalMemory() - rt0.freeMemory()) >> 20;
        long maxMB = rt0.maxMemory() >> 20;
        tvSize.setText(LanguageManager.getString(act, R.string.super_res_current_size)
                + " " + srcW + " × " + srcH
                + (rawFullSize ? "  RAW" : "")
                + "\n" + LanguageManager.getString(act, R.string.super_res_memory)
                + " " + usedMB + " / " + maxMB + " MB");
        tvSize.setTextSize(13);
        tvSize.setTextColor(0xFF9E9E9E);
        tvSize.setGravity(Gravity.CENTER);
        tvSize.setTextColor(0xFF757575);
        tvSize.setPadding(0, 0, 0, (int) (14 * density));
        root.addView(tvSize);

        // ---- 倍率选择 ----
        final double[] scales = {2.0, 4.0};
        final int[] scaleLabels = {R.string.super_res_scale_2x, R.string.super_res_scale_4x};
        final boolean[] scaleAllowed = new boolean[scales.length];
        final boolean[] scaleCompact = new boolean[scales.length];
        final TextView[] scaleViews = new TextView[scales.length];
        final int[] selected = {0}; // 0 = 2x, 1 = 4x
        final boolean[] useCompact = {false};

        for (int i = 0; i < scales.length; i++) {
            final int idx = i;
            // 两级判断：标准模式(8888) 不行就看省内存模式(565)
            // 单边超过 8192 的位图在很多设备上会直接崩（内存够也一样），必须拦住
            boolean sideOk = !SuperResolution.sideExceeded(srcW, srcH, scales[i]);
            scaleAllowed[i] = sideOk
                    && MemoryProbe.canUpscale(act, srcW, srcH, scales[i], false);
            scaleCompact[i] = sideOk && !scaleAllowed[i]
                    && MemoryProbe.canUpscale(act, srcW, srcH, scales[i], true);

            TextView tv = new TextView(act);
            String label = LanguageManager.getString(act, scaleLabels[i]);
            long outPx = Math.round(srcW * scales[i]) * Math.round(srcH * scales[i]);
            label += "   " + Math.round(srcW * scales[i]) + " × " + Math.round(srcH * scales[i])
                    + "  (" + (outPx / 1000000) + "MP / " + (outPx * 4 / (1024 * 1024)) + "MB)";
            if (!scaleAllowed[i] && !scaleCompact[i]
                    && SuperResolution.sideExceeded(srcW, srcH, scales[i])) {
                label += "  ✕ " + LanguageManager.getString(act, R.string.super_res_side_limit)
                        + " " + SuperResolution.MAX_SIDE;
            } else if (!scaleAllowed[i]) {
                if (scaleCompact[i]) {
                    label += "  " + LanguageManager.getString(act, R.string.super_res_compact_hint);
                } else {
                    label += "  ✕ " + LanguageManager.getString(act, R.string.super_res_too_large);
                }
            }

            tv.setText(label);
            tv.setTextSize(15);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, (int) (14 * density), 0, (int) (14 * density));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, (int) (8 * density));
            tv.setLayoutParams(lp);
            scaleViews[i] = tv;

            tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!scaleAllowed[idx] && !scaleCompact[idx]) {
                            Toast.makeText(act,
                                    LanguageManager.getString(act, R.string.super_res_too_large_tip),
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        selected[0] = idx;
                        useCompact[0] = !scaleAllowed[idx];
                        for (int k = 0; k < scaleViews.length; k++) {
                            styleOptionEx(scaleViews[k], k == idx, scaleAllowed[k],
                                    scaleCompact[k], buttonColor, radiusPx);
                        }
                    }
                });
            root.addView(tv);
        }
        for (int k = 0; k < scaleViews.length; k++) {
            styleOptionEx(scaleViews[k], k == selected[0], scaleAllowed[k],
                    scaleCompact[k], buttonColor, radiusPx);
        }

        // ---- 细节锐化 ----
        final boolean[] sharpen = {true};
        final TextView tvSharpen = new TextView(act);
        tvSharpen.setTextSize(14);
        tvSharpen.setGravity(Gravity.CENTER);
        tvSharpen.setPadding(0, (int) (12 * density), 0, (int) (12 * density));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.setMargins(0, (int) (6 * density), 0, (int) (6 * density));
        tvSharpen.setLayoutParams(slp);
        updateSharpenView(tvSharpen, sharpen[0], act, buttonColor, textColor, radiusPx);
        tvSharpen.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sharpen[0] = !sharpen[0];
                    updateSharpenView(tvSharpen, sharpen[0], act, buttonColor, textColor, radiusPx);
                }
            });
        root.addView(tvSharpen);

        // ---- 提示 ----
        TextView tvNote = new TextView(act);
        tvNote.setText(LanguageManager.getString(act, R.string.super_res_note));
        tvNote.setTextSize(12);
        tvNote.setTextColor(0xFF9E9E9E);
        tvNote.setPadding(0, (int) (10 * density), 0, (int) (14 * density));
        root.addView(tvNote);

        // ---- 按钮 ----
        LinearLayout btnRow = new LinearLayout(act);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnCancel = new TextView(act);
        btnCancel.setText(LanguageManager.getString(act, R.string.cancel));
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setPadding(0, (int) (14 * density), 0, (int) (14 * density));
        btnCancel.setBackground(roundBg(0xFFB61515, 8 * density));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        clp.setMargins(0, 0, (int) (5 * density), 0);
        btnCancel.setLayoutParams(clp);
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        btnRow.addView(btnCancel);

        TextView btnStart = new TextView(act);
        btnStart.setText(LanguageManager.getString(act, R.string.super_res_start));
        btnStart.setTextSize(15);
        btnStart.setTextColor(Color.BLACK);
        btnStart.setGravity(Gravity.CENTER);
        btnStart.setPadding(0, (int) (14 * density), 0, (int) (14 * density));
        btnStart.setBackground(roundBg(0xFFFFB615, 8 * density));
        LinearLayout.LayoutParams slp2 = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f);
        slp2.setMargins((int) (5 * density), 0, 0, 0);
        btnStart.setLayoutParams(slp2);
        btnStart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!scaleAllowed[selected[0]] && !scaleCompact[selected[0]]) {
                        Toast.makeText(act,
                                LanguageManager.getString(act, R.string.super_res_too_large_tip),
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    dialog.dismiss();
                    run(act, zoom, cb, scales[selected[0]], sharpen[0], rawUri, historyHandler,
                            !scaleAllowed[selected[0]]);
                }
            });
        btnRow.addView(btnStart);
        root.addView(btnRow);

        dialog.setContentView(root);
        Window win = dialog.getWindow();
        if (win != null) {
            WindowManager.LayoutParams params = win.getAttributes();
            params.width = (int) (act.getResources().getDisplayMetrics().widthPixels * 0.85);
            win.setAttributes(params);
        }
        dialog.show();
    }

    private static void styleOption(TextView tv, boolean selected, boolean allowed,
                                    int buttonColor, int radiusPx) {
        if (!allowed) {
            tv.setBackground(roundBg(0xFF3A3A3A, radiusPx));
            tv.setAlpha(0.5f);
            tv.setTextColor(0xFFBDBDBD);
            return;
        }
        if (selected) {
            tv.setBackground(roundBg(0xFFFFB615, radiusPx));
            tv.setTextColor(Color.BLACK);
        } else {
            tv.setBackground(roundBg(buttonColor, radiusPx));
            tv.setTextColor(ThemeManager.getTextColor(tv.getContext()));
        }
    }

    /** 三种状态：可选 / 仅省内存模式可用 / 不可用。 */
    private static void styleOptionEx(TextView tv, boolean selected, boolean allowed,
                                      boolean compact, int buttonColor, int radiusPx) {
        if (!allowed && !compact) {
            tv.setBackground(roundBg(0xFF3A3A3A, radiusPx));
            tv.setAlpha(0.5f);
            tv.setTextColor(0xFFBDBDBD);
            return;
        }
        tv.setAlpha(1f);
        if (selected) {
            tv.setBackground(roundBg(0xFFFFB615, radiusPx));
            tv.setTextColor(Color.BLACK);
        } else if (!allowed && compact) {
            // 只有省内存模式能用：用蓝色区分
            tv.setBackground(roundBg(0xFF2F6FA8, radiusPx));
            tv.setTextColor(Color.WHITE);
        } else {
            tv.setBackground(roundBg(buttonColor, radiusPx));
            tv.setTextColor(ThemeManager.getTextColor(tv.getContext()));
        }
    }

    private static void updateSharpenView(TextView tv, boolean on, Activity act,
                                          int buttonColor, int textColor, int radiusPx) {
        tv.setText(LanguageManager.getString(act, R.string.super_res_sharpen)
                + (on ? "  ✔" : "  ✘"));
        tv.setTextColor(on ? Color.BLACK : textColor);
        tv.setBackground(roundBg(on ? 0xFFFFB615 : buttonColor, radiusPx));
    }

    private static GradientDrawable roundBg(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    /**
     * 全尺寸 RAW 解码前先看内存：解码本身就要一张全尺寸图，
     * 余量不够就直接放弃（回退到半尺寸底图），避免还没超分就先崩。
     */
    /**
     * 全尺寸 RAW 解码前判断内存是否够用。
     *
     * 注意：libraw 是 native 解码，中间会额外吃一大块堆外内存（对数百万像素的 RAW
     * 往往是 100~300MB），Java 堆看不到这部分。所以这里要求留足余量：
     * 至少一半堆且不低于 300MB 空闲，否则退回半尺寸底图，宁可糊一点也不能崩。
     */
    private static boolean rawFullSizeSafe(int rawW, int rawH) {
        Runtime rt = Runtime.getRuntime();
        long max = rt.maxMemory();
        long free = max - (rt.totalMemory() - rt.freeMemory());
        long decodedBytes = (long) Math.max(rawW, 1) * Math.max(rawH, 1) * 4L;
        // Java 侧：成品图 + 解码图 + 分块缓冲(约30MB)
        long javaNeed = decodedBytes * 4L + decodedBytes + 30L * 1024 * 1024;
        // native 侧：保守按解码图的 3 倍估（libraw 内部缓冲）
        long nativeNeed = decodedBytes * 3L;
        long require = Math.max(javaNeed, nativeNeed);
        return free > require && free > max * 0.55;
    }

    private static void run(final Activity act, final ZoomImageView zoom, final Callback cb,
                            final double scale, final boolean sharpen, final Uri rawUri,
                            final HistoryHandler historyHandler, final boolean compact) {
        final LoadingDialog pd = new LoadingDialog(act,
                LanguageManager.getString(act, R.string.super_res_running));
        try {
            pd.show();
        } catch (Throwable ignored) {
        }

        new Thread(new Runnable() {
                @Override
                public void run() {
                    Bitmap result = null;
                    String error = null;
                    try {
                        // 第 1 步：取源图。RAW 优先按全尺寸重新解码（编辑页里是半尺寸的）；
                        // 失败则回退到当前底图。滤镜参数在后续步骤保留，不受影响。
                        Bitmap flat = null;
                        boolean alreadyUpscaled = zoom.wasSuperResApplied();
                        // 先拿到当前（半尺寸）底图尺寸，用来估算全尺寸 RAW 的体量
                        int probeW = 0, probeH = 0;
                        try {
                            if (zoom.getDrawable() != null) {
                                probeW = zoom.getDrawable().getIntrinsicWidth() * 2;
                                probeH = zoom.getDrawable().getIntrinsicHeight() * 2;
                            }
                        } catch (Throwable ignored) {
                        }
                        if (!alreadyUpscaled && rawUri != null
                                && RawFullSizeDecoder.isRawUri(act, rawUri)
                                && rawFullSizeSafe(probeW, probeH)) {
                            try {
                                flat = RawFullSizeDecoder.decodeFullSize(act, rawUri);
                            } catch (Throwable ignored) {
                                flat = null;
                            }
                        }
                        if (flat == null) {
                            flat = zoom.getBaseForSuperRes();
                        }
                        if (flat == null) {
                            throw new IllegalStateException("empty image");
                        }

                        // 第 2 步：再拷成一张"干净"的紧凑图，然后立刻丢掉原图，
                        // 保证超分期间只有这一张源图占内存（关键：否则和输出图叠加会爆）
                        int fw = flat.getWidth(), fh = flat.getHeight();
                        int[] srcPx = new int[fw * fh];
                        flat.getPixels(srcPx, 0, fw, 0, 0, fw, fh);
                        if (flat != null && !flat.isRecycled()) {
                            flat.recycle();
                        }
                        flat = null;
                        System.gc();

                        // 第 3 步：按真实剩余堆再确认一次，不够就早退（不让它崩）
                        SuperResolution.Options o = new SuperResolution.Options(scale);
                        o.usm = sharpen;
                        o.usmRadius = 1.0;
                        o.usmAmount = 0.5;
                        o.lowMemory = compact;   // 省内存模式：成品用 RGB_565

                        long outPixels = (long) Math.round(fw * scale)
                                * Math.round(fh * scale);
                        // ★ 用真实内存（含 native 堆）再确认一次
                        if (!MemoryProbe.canUpscale(act, fw, fh, scale, compact)) {
                            throw new IllegalArgumentException("too-large");
                        }
                        int dw = (int) Math.round(fw * scale);
                        int dh = (int) Math.round(fh * scale);

                        // 第 4 步：直接写进 Bitmap（不建整张 int[]）
                        if (dw > SuperResolution.MAX_SIDE || dh > SuperResolution.MAX_SIDE) {
                            throw new IllegalArgumentException("side-limit");
                        }
                        result = Bitmap.createBitmap(dw, dh, o.targetConfig());
                        boolean ok = SuperResolution.upscaleIntoBitmap(srcPx, fw, fh, o,
                                result, null);
                        srcPx = null;
                        if (!ok) {
                            if (result != null && !result.isRecycled()) result.recycle();
                            result = null;
                            throw new OutOfMemoryError("bitmap upscale failed");
                        }
                        System.gc();
                    } catch (OutOfMemoryError e) {
                        error = "oom";
                        try { CrashLogger.log("超分-内存不足", e); } catch (Throwable ignored) {}
                    } catch (IllegalArgumentException e) {
                        error = "too-large";
                    } catch (Error e) {
                        // LinkageError / OutOfMemoryError 之外的原生错误
                        error = "fatal:" + e.getClass().getSimpleName();
                    } catch (Throwable t) {
                        error = t.toString();
                        try { CrashLogger.log("超分-失败", t); } catch (Throwable ignored) {}
                    }

                    final Bitmap fResult = result;
                    final String fError = error;
                    act.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    pd.dismiss();
                                } catch (Throwable ignored) {
                                }
                                if (act.isFinishing()) {
                                    return;
                                }
                                if (fResult == null) {
                                    String msg;
                                    if ("oom".equals(fError)) {
                                        msg = LanguageManager.getString(act,
                                                R.string.super_res_fail_oom);
                                    } else if ("too-large".equals(fError)) {
                                        msg = LanguageManager.getString(act,
                                                R.string.super_res_too_large_tip);
                                    } else if (fError != null && fError.startsWith("fatal:")) {
                                        msg = LanguageManager.getString(act, R.string.super_res_fail)
                                                + " " + fError;
                                    } else {
                                        msg = LanguageManager.getString(act,
                                                R.string.super_res_fail) + " " + fError;
                                    }
                                    Toast.makeText(act, msg, Toast.LENGTH_LONG).show();
                                    return;
                                }
                                int oldW = 0, oldH = 0;
                                if (zoom.getDrawable() != null) {
                                    oldW = zoom.getDrawable().getIntrinsicWidth();
                                    oldH = zoom.getDrawable().getIntrinsicHeight();
                                }
                                try {
                                    zoom.applySuperResToBase(fResult);
                                } catch (Throwable t) {
                                    Toast.makeText(act,
                                            LanguageManager.getString(act,
                                                    R.string.super_res_fail) + " " + t,
                                            Toast.LENGTH_LONG).show();
                                    return;
                                }
                                // 尺寸变了：按 WPB 开关状态处理历史存档
                                if (historyHandler != null) {
                                    try {
                                        historyHandler.onDocumentResized(oldW, oldH,
                                                fResult.getWidth(), fResult.getHeight());
                                    } catch (Throwable ignored) {
                                    }
                                }
                                Toast.makeText(act,
                                        LanguageManager.getString(act, R.string.super_res_done)
                                        + " " + fResult.getWidth() + " × " + fResult.getHeight(),
                                        Toast.LENGTH_LONG).show();
                                if (cb != null) {
                                    cb.onApplied(fResult, scale);
                                }
                            }
                        });
                }
            }, "super-res").start();
    }
}
