package com.sertrt.weifp;

import java.io.File;

public class Preset {

    public String name;
    public File file;

    public float brightness = 0f;
    public float contrast = 1f;
    public float saturation = 1f;
    public float shadows = 0f;
    public float highlights = 0f;
    public float temperature = 0f;
    public float tint = 0f;
    public float sharpness = 0f;

    public String lutM;
    public String lutR;
    public String lutG;
    public String lutB;

    public String ptsM;
    public String ptsR;
    public String ptsG;
    public String ptsB;

    public String cubePath;
    public float cubeStrength = 1.0f;

    public float[] cropRatio;

    public float[] hslHue = new float[8];
    public float[] hslSat = new float[8];
    public float[] hslLum = new float[8];

    public float[] cbShadow = new float[3];
    public float[] cbMid = new float[3];
    public float[] cbHigh = new float[3];

    // ★ 色阶 4 通道 × 黑/灰/白
    public int[] lvBlack = {0, 0, 0, 0};
    public int[] lvGray = {128, 128, 128, 128};
    public int[] lvWhite = {255, 255, 255, 255};

    public Preset(String name, File file) {
        this.name = name;
        this.file = file;
    }
}
