package com.sertrt.weifp;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;

public class overlayActivity extends Activity {

    private ImageView baseView;
    private ImageView overlayView;
    private FrameLayout previewArea;

    private Bitmap baseBitmap;
    private Bitmap overlayBitmap;
    private Bitmap scaledOverlay;

    private Matrix overlayMatrix = new Matrix();
    private ScaleGestureDetector scaleDetector;

    private float lastX, lastY;
    private float overlayScale = 1.0f;
    private float overlayRotation = 0f;

    private static final int PICK_OVERLAY_REQUEST = 300;
    private float density;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF1E1E1E);

        previewArea = new FrameLayout(this);
        previewArea.setLayoutParams(new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        previewArea.setPadding(0, (int)(50 * density), 0, 0);

        baseView = new ImageView(this);
        baseView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        previewArea.addView(baseView);

        overlayView = new ImageView(this);
        overlayView.setScaleType(ImageView.ScaleType.MATRIX);
        previewArea.addView(overlayView);

        root.addView(previewArea);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setBackgroundColor(0xFF2A2A2A);
        btnRow.setPadding((int)(10*density), (int)(10*density), (int)(10*density), (int)(10*density));

        Button btnPick = new Button(this);
        btnPick.setText(LanguageManager.getString(this, R.string.overlay_pick));
        btnPick.setBackground(getRoundBg(0xFF3A3A3A));
        btnPick.setTextColor(0xFFFFFFFF);
        fixButtonStyle(btnPick);
        btnPick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent pick = new Intent(Intent.ACTION_PICK,
                                             android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pick, PICK_OVERLAY_REQUEST);
                }
            });
        btnRow.addView(btnPick, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button btnDone = new Button(this);
        btnDone.setText(LanguageManager.getString(this, R.string.overlay_done));
        btnDone.setBackground(getRoundBg(0xFFFFB615));
        btnDone.setTextColor(0xFF000000);
        fixButtonStyle(btnDone);
        btnDone.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { finishAndReturn(); }
            });
        btnRow.addView(btnDone, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(btnRow);

        LinearLayout resetRow = new LinearLayout(this);
        resetRow.setOrientation(LinearLayout.HORIZONTAL);
        resetRow.setBackgroundColor(0xFF1E1E1E);
        resetRow.setPadding((int)(5*density), (int)(10*density), (int)(5*density), (int)(10*density));

        Button btnResetX = new Button(this);
        btnResetX.setText(LanguageManager.getString(this, R.string.overlay_reset_x));
        btnResetX.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetX.setTextColor(0xFFFFFFFF);
        fixButtonStyle(btnResetX);
        btnResetX.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetX(); }
            });
        resetRow.addView(btnResetX, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button btnResetY = new Button(this);
        btnResetY.setText(LanguageManager.getString(this, R.string.overlay_reset_y));
        btnResetY.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetY.setTextColor(0xFFFFFFFF);
        fixButtonStyle(btnResetY);
        btnResetY.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetY(); }
            });
        resetRow.addView(btnResetY, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button btnResetRot = new Button(this);
        btnResetRot.setText(LanguageManager.getString(this, R.string.overlay_reset_rot));
        btnResetRot.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetRot.setTextColor(0xFFFFFFFF);
        fixButtonStyle(btnResetRot);
        btnResetRot.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetRotation(); }
            });
        resetRow.addView(btnResetRot, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button btnResetScale = new Button(this);
        btnResetScale.setText(LanguageManager.getString(this, R.string.overlay_reset_scale));
        btnResetScale.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetScale.setTextColor(0xFFFFFFFF);
        fixButtonStyle(btnResetScale);
        btnResetScale.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetScale(); }
            });
        resetRow.addView(btnResetScale, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button btnResetAll = new Button(this);
        btnResetAll.setText(LanguageManager.getString(this, R.string.overlay_reset_all));
        btnResetAll.setBackground(getRoundBg(0xFFB61515));
        btnResetAll.setTextColor(0xFFFFFFFF);
        fixButtonStyle(btnResetAll);
        btnResetAll.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetAll(); }
            });
        resetRow.addView(btnResetAll, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(resetRow);

        setContentView(root);

        BackButtonHelper.addBackButton(this, new BackButtonHelper.OnBackListener() {
                @Override public void onBack() {
                    showExitDialog();
                }
            });

        Uri baseUri = getIntent().getData();
        if (baseUri != null) {
            try {
                InputStream is = getContentResolver().openInputStream(baseUri);
                baseBitmap = BitmapFactory.decodeStream(is);
                if (is != null) is.close();
                baseView.setImageBitmap(baseBitmap);
            } catch (Throwable e) {
                Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_base_fail), Toast.LENGTH_SHORT).show();
            }
        }

        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector detector) {
                    if (overlayBitmap == null) return false;
                    float factor = detector.getScaleFactor();
                    overlayScale *= factor;
                    if (overlayScale < 0.2f) overlayScale = 0.2f;
                    if (overlayScale > 5.0f) overlayScale = 5.0f;

                    int newW = (int) (overlayBitmap.getWidth() * overlayScale);
                    int newH = (int) (overlayBitmap.getHeight() * overlayScale);
                    if (newW > 0 && newH > 0) {
                        scaledOverlay = Bitmap.createScaledBitmap(overlayBitmap, newW, newH, true);
                        overlayView.setImageBitmap(scaledOverlay);
                    }
                    return true;
                }
            });

        overlayView.setOnTouchListener(new View.OnTouchListener() {
                private float lastRotate = 0f;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if (overlayBitmap == null) return false;
                    scaleDetector.onTouchEvent(event);

                    if (event.getPointerCount() >= 2) {
                        float angle = (float) Math.toDegrees(
                            Math.atan2(event.getY(1) - event.getY(0),
                                       event.getX(1) - event.getX(0)));
                        if (event.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
                            lastRotate = angle;
                        } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                            float delta = angle - lastRotate;
                            overlayRotation += delta;
                            overlayMatrix.postRotate(delta,
                                                     overlayView.getWidth() / 2f, overlayView.getHeight() / 2f);
                            overlayView.setImageMatrix(overlayMatrix);
                            overlayView.invalidate();
                            lastRotate = angle;
                        }
                        return true;
                    }

                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            lastX = event.getX();
                            lastY = event.getY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            float dx = event.getX() - lastX;
                            float dy = event.getY() - lastY;
                            overlayMatrix.postTranslate(dx, dy);
                            overlayView.setImageMatrix(overlayMatrix);
                            overlayView.invalidate();
                            lastX = event.getX();
                            lastY = event.getY();
                            return true;
                    }
                    return false;
                }
            });
    }

    private void fixButtonStyle(Button b) {
        if (b == null) return;
        b.setAllCaps(false);
        b.setStateListAnimator(null);
    }

    private GradientDrawable getRoundBg(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(8 * density);
        bg.setColor(color);
        return bg;
    }

    private void showExitDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getRoundBg(ThemeManager.getPanelColor(this)));
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(10*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(LanguageManager.getString(this, R.string.overlay_abandon_title));
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        TextView tvMsg = new TextView(this);
        tvMsg.setText(LanguageManager.getString(this, R.string.overlay_abandon_msg));
        tvMsg.setTextSize(13);
        tvMsg.setTextColor(ThemeManager.getTextColor(this));
        tvMsg.setGravity(Gravity.CENTER);
        tvMsg.setPadding(0, (int)(15*density), 0, (int)(15*density));
        root.addView(tvMsg);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, (int)(10*density), 0, 0);

        TextView btnCancel = new TextView(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnCancel.setBackground(getRoundBg(0xFF555555));
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp1.setMargins(0, 0, (int)(10*density), 0);
        btnCancel.setLayoutParams(lp1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dialog.dismiss(); }
            });
        btnRow.addView(btnCancel);

        TextView btnOk = new TextView(this);
        btnOk.setText(LanguageManager.getString(this, R.string.overlay_exit));
        btnOk.setTextSize(15);
        btnOk.setTextColor(Color.BLACK);
        btnOk.setGravity(Gravity.CENTER);
        btnOk.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnOk.setBackground(getRoundBg(0xFFFFB615));
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btnOk.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dialog.dismiss();
                    finish();
                }
            });
        btnRow.addView(btnOk);
        root.addView(btnRow);

        ScrollView sv = new ScrollView(this); sv.addView(root);
        dialog.setContentView(sv);

        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.8);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void resetX() {
        if (scaledOverlay == null) return;
        float[] v = new float[9];
        overlayMatrix.getValues(v);
        float ty = v[Matrix.MTRANS_Y];
        overlayMatrix.reset();
        float cx = (overlayView.getWidth() - scaledOverlay.getWidth()) / 2f;
        overlayMatrix.postTranslate(cx, ty);
        overlayView.setImageMatrix(overlayMatrix);
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_x_toast), Toast.LENGTH_SHORT).show();
    }

    private void resetY() {
        if (scaledOverlay == null) return;
        float[] v = new float[9];
        overlayMatrix.getValues(v);
        float tx = v[Matrix.MTRANS_X];
        overlayMatrix.reset();
        float cy = (overlayView.getHeight() - scaledOverlay.getHeight()) / 2f;
        overlayMatrix.postTranslate(tx, cy);
        overlayView.setImageMatrix(overlayMatrix);
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_y_toast), Toast.LENGTH_SHORT).show();
    }

    private void resetRotation() {
        overlayRotation = 0f;
        if (scaledOverlay == null) return;
        float[] v = new float[9];
        overlayMatrix.getValues(v);
        float tx = v[Matrix.MTRANS_X];
        float ty = v[Matrix.MTRANS_Y];
        overlayMatrix.reset();
        overlayMatrix.postTranslate(tx, ty);
        overlayView.setImageMatrix(overlayMatrix);
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_rot_toast), Toast.LENGTH_SHORT).show();
    }

    private void resetScale() {
        overlayScale = 0.5f;
        if (overlayBitmap != null) {
            int w = (int) (overlayBitmap.getWidth() * overlayScale);
            int h = (int) (overlayBitmap.getHeight() * overlayScale);
            scaledOverlay = Bitmap.createScaledBitmap(overlayBitmap, w, h, true);
            overlayView.setImageBitmap(scaledOverlay);
        }
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_scale_toast), Toast.LENGTH_SHORT).show();
    }

    private void resetAll() {
        if (scaledOverlay == null) return;
        overlayMatrix.reset();
        float cx = (overlayView.getWidth() - scaledOverlay.getWidth()) / 2f;
        float cy = (overlayView.getHeight() - scaledOverlay.getHeight()) / 2f;
        overlayMatrix.postTranslate(cx, cy);
        overlayView.setImageMatrix(overlayMatrix);
        overlayRotation = 0f;
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_all_toast), Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_OVERLAY_REQUEST && resultCode == RESULT_OK && data != null) {
            try {
                InputStream is = getContentResolver().openInputStream(data.getData());
                overlayBitmap = BitmapFactory.decodeStream(is);
                if (is != null) is.close();

                if (overlayBitmap != null && baseBitmap != null) {
                    overlayScale = 0.5f;
                    int w = (int) (overlayBitmap.getWidth() * overlayScale);
                    int h = (int) (overlayBitmap.getHeight() * overlayScale);
                    scaledOverlay = Bitmap.createScaledBitmap(overlayBitmap, w, h, true);
                    overlayView.setImageBitmap(scaledOverlay);

                    overlayMatrix.reset();
                    overlayView.setImageMatrix(overlayMatrix);
                    overlayView.post(new Runnable() {
                            @Override
                            public void run() {
                                float cx = (overlayView.getWidth() - scaledOverlay.getWidth()) / 2f;
                                float cy = (overlayView.getHeight() - scaledOverlay.getHeight()) / 2f;
                                overlayMatrix.postTranslate(cx, cy);
                                overlayView.setImageMatrix(overlayMatrix);
                            }
                        });
                }
            } catch (Throwable e) {
                Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_overlay_fail), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void finishAndReturn() {
        if (baseBitmap == null) {
            setResult(RESULT_CANCELED);
            finish();
            return;
        }

        Bitmap result = Bitmap.createBitmap(baseBitmap.getWidth(), baseBitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);

        if (scaledOverlay != null) {
            Matrix inverseBaseMatrix = new Matrix();
            baseView.getImageMatrix().invert(inverseBaseMatrix);

            Matrix drawMatrix = new Matrix(overlayMatrix);
            drawMatrix.postConcat(inverseBaseMatrix);

            canvas.drawBitmap(scaledOverlay, drawMatrix, null);
        }

        try {
            java.io.File cacheFile = new java.io.File(getCacheDir(), "overlay_result.png");
            java.io.FileOutputStream fos = new java.io.FileOutputStream(cacheFile);
            result.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();

            Intent resultIntent = new Intent();
            resultIntent.setData(Uri.fromFile(cacheFile));
            setResult(RESULT_OK, resultIntent);
            finish();
        } catch (Throwable e) {
            Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_compose_fail), Toast.LENGTH_SHORT).show();
            setResult(RESULT_CANCELED);
            finish();
        }
    }
}
