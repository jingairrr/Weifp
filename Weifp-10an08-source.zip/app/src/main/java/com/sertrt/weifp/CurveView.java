package com.sertrt.weifp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CurveView extends View {

    public interface OnCurveChangedListener {
        void onCurveChanged(int[] master, int[] r, int[] g, int[] b, String[] pts);
        void onCurveFinished(int[] master, int[] r, int[] g, int[] b, String[] pts);
    }

    private OnCurveChangedListener listener;
    private Paint gridPaint, linePaint, pointPaint, bgPaint;
    private List<Point>[] channelPoints = new List[4];
    private int activeChannel = 0; 
    private int activePointIndex = -1;

    public CurveView(Context context) {
        super(context);
        init();
    }

    public void setOnCurveChangedListener(OnCurveChangedListener listener) {
        this.listener = listener;
    }

    private void init() {
        bgPaint = new Paint(); bgPaint.setColor(0xFF1E1E1E);
        gridPaint = new Paint(); gridPaint.setColor(0xFF444444); gridPaint.setStrokeWidth(1f); gridPaint.setStyle(Paint.Style.STROKE);

        linePaint = new Paint(); linePaint.setStrokeWidth(4f); linePaint.setStyle(Paint.Style.STROKE); linePaint.setAntiAlias(true);
        pointPaint = new Paint(); pointPaint.setColor(0xFFFFB615); pointPaint.setStyle(Paint.Style.FILL); pointPaint.setAntiAlias(true);

        for (int i = 0; i < 4; i++) {
            channelPoints[i] = new ArrayList<>();
            channelPoints[i].add(new Point(0, 0));
            channelPoints[i].add(new Point(255, 255));
        }
        updateLineColor();
    }

    public void setActiveChannel(int channel) {
        if (channel < 0 || channel > 3 || this.activeChannel == channel) return;
        this.activeChannel = channel;
        updateLineColor();
        invalidate();
    }

    public String getChannelPointsString(int channel) {
        StringBuilder sb = new StringBuilder();
        for (Point p : channelPoints[channel]) {
            sb.append(p.x).append(",").append(p.y).append(";");
        }
        return sb.toString();
    }

    public void setChannelPointsFromString(int channel, String str) {
        if (str == null || str.isEmpty()) return;
        List<Point> pts = new ArrayList<>();
        String[] arr = str.split(";");
        for (String s : arr) {
            if (s.isEmpty()) continue;
            String[] xy = s.split(",");
            if (xy.length == 2) {
                try {
                    pts.add(new Point(Integer.parseInt(xy[0]), Integer.parseInt(xy[1])));
                } catch (Exception ignored) {}
            }
        }
        if (pts.size() >= 2) {
            channelPoints[channel] = pts;
            if (channel == activeChannel) invalidate();
        }
    }

    public void setChannelLUT(int channel, int[] lut) {
        if (lut == null || lut.length < 256) return;
        List<Point> pts = new ArrayList<>();
        pts.add(new Point(0, lut[0]));
        for (int i = 1; i <= 5; i++) {
            int x = (i * 255) / 6;
            pts.add(new Point(x, lut[x]));
        }
        pts.add(new Point(255, lut[255]));
        channelPoints[channel] = pts;
        if (channel == activeChannel) invalidate();
    }

    public void resetAll() {
        for (int i = 0; i < 4; i++) {
            channelPoints[i].clear();
            channelPoints[i].add(new Point(0, 0));
            channelPoints[i].add(new Point(255, 255));
        }
        invalidate();
        if (listener != null) notifyListener(true);
    }

    private void updateLineColor() {
        if (activeChannel == 0) linePaint.setColor(Color.WHITE);
        else if (activeChannel == 1) linePaint.setColor(Color.RED);
        else if (activeChannel == 2) linePaint.setColor(Color.GREEN);
        else linePaint.setColor(Color.BLUE);
    }

    public int[] getLUT(int channel) {
        int[] lut = new int[256];
        List<Point> points = channelPoints[channel];
        for (int i = 0; i < 256; i++) {
            lut[i] = getYValueAt(i, points);
        }
        return lut;
    }

    private void notifyListener(boolean finished) {
        if (listener != null) {
            int[] m = getLUT(0);
            int[] r = getLUT(1);
            int[] g = getLUT(2);
            int[] b = getLUT(3);
            String[] pts = new String[]{
                getChannelPointsString(0),
                getChannelPointsString(1),
                getChannelPointsString(2),
                getChannelPointsString(3)
            };
            if (finished) listener.onCurveFinished(m, r, g, b, pts);
            else listener.onCurveChanged(m, r, g, b, pts);
        }
    }

    // ★ 纯数学平滑曲线（单调三次插值）
    /** 是否存在重复的 x（重复会导致插值除零）。 */
    private static boolean hasDuplicateX(List<Point> pts) {
        for (int i = 1; i < pts.size(); i++) {
            if (pts.get(i).x == pts.get(i - 1).x) return true;
        }
        return false;
    }

    private int getYValueAt(int x, List<Point> points) {
        if (points.isEmpty()) return x;

        // ★ 先去掉重复 x 的点。
        //   两个点 x 相同的话，下面 dx[i] = 0，slope = dy/0 = Infinity/NaN，
        //   一路传染到最终结果，Math.round(NaN) 变成 0 —— 整张图直接变黑。
        //   曲线控件只有 240px 宽，同一列点两下就会重合，很容易触发。
        List<Point> pts = points;
        if (hasDuplicateX(points)) {
            pts = new java.util.ArrayList<Point>();
            int lastX = Integer.MIN_VALUE;
            for (Point p : points) {
                if (p.x == lastX) {
                    pts.remove(pts.size() - 1);   // 同 x 用后加的那个
                }
                pts.add(p);
                lastX = p.x;
            }
        }

        if (pts.size() < 2) {
            if (pts.isEmpty()) return x;
            // 只剩一个点：当作恒定值
            return pts.get(0).y;
        }

        if (pts.size() == 2) {
            Point p1 = pts.get(0);
            Point p2 = pts.get(1);
            if (p1.x == p2.x) return p1.y;
            float t = (float)(x - p1.x) / (p2.x - p1.x);
            return (int) (p1.y + t * (p2.y - p1.y));
        }

        if (x <= pts.get(0).x) return pts.get(0).y;
        if (x >= pts.get(pts.size() - 1).x) return pts.get(pts.size() - 1).y;

        int n = pts.size();
        points = pts;
        float[] dx = new float[n - 1];
        float[] dy = new float[n - 1];
        float[] slope = new float[n - 1];

        for (int i = 0; i < n - 1; i++) {
            dx[i] = points.get(i + 1).x - points.get(i).x;
            dy[i] = points.get(i + 1).y - points.get(i).y;
            // 兜底：dx 为 0 时不能除，否则产生 Infinity/NaN
            slope[i] = dx[i] != 0 ? dy[i] / dx[i] : 0f;
        }

        float[] m = new float[n];
        m[0] = slope[0];
        m[n - 1] = slope[n - 2];
        for (int i = 1; i < n - 1; i++) {
            m[i] = (slope[i - 1] + slope[i]) / 2.0f;
        }

        for (int i = 0; i < n - 1; i++) {
            if (slope[i] == 0) {
                m[i] = 0;
                m[i + 1] = 0;
            } else {
                float alpha = m[i] / slope[i];
                float beta = m[i + 1] / slope[i];
                if (alpha * alpha + beta * beta > 9) {
                    float tau = 3.0f / (float) Math.sqrt(alpha * alpha + beta * beta);
                    m[i] = tau * alpha * slope[i];
                    m[i + 1] = tau * beta * slope[i];
                }
            }
        }

        int i = 0;
        while (i < n - 2 && x > points.get(i + 1).x) {
            i++;
        }

        float t = (x - points.get(i).x) / dx[i];
        float t2 = t * t;
        float t3 = t2 * t;

        float h00 = 2 * t3 - 3 * t2 + 1;
        float h10 = t3 - 2 * t2 + t;
        float h01 = -2 * t3 + 3 * t2;
        float h11 = t3 - t2;

        float y = h00 * points.get(i).y + h10 * dx[i] * m[i] + h01 * points.get(i + 1).y + h11 * dx[i] * m[i + 1];
        return Math.max(0, Math.min(255, Math.round(y)));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();

        canvas.drawRect(0, 0, w, h, bgPaint);

        for (int i = 1; i < 4; i++) {
            canvas.drawLine(w * i / 4f, 0, w * i / 4f, h, gridPaint);
            canvas.drawLine(0, h * i / 4f, w, h * i / 4f, gridPaint);
        }
        canvas.drawRect(0, 0, w, h, gridPaint);

        List<Point> points = channelPoints[activeChannel];
        if (points.isEmpty()) return;

        Path path = new Path();
        for (int x = 0; x <= 255; x++) {
            int y = getYValueAt(x, points);
            float px = (x / 255f) * w;
            float py = h - (y / 255f) * h;
            if (x == 0) path.moveTo(px, py);
            else path.lineTo(px, py);
        }
        canvas.drawPath(path, linePaint);

        for (Point p : points) {
            float px = (p.x / 255f) * w;
            float py = h - (p.y / 255f) * h;
            canvas.drawCircle(px, py, 12f, pointPaint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int w = getWidth();
        int h = getHeight();
        float x = event.getX();
        float y = event.getY();
        List<Point> points = channelPoints[activeChannel];

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                activePointIndex = -1;
                for (int i = 0; i < points.size(); i++) {
                    Point p = points.get(i);
                    float px = (p.x / 255f) * w;
                    float py = h - (p.y / 255f) * h;
                    if (Math.hypot(x - px, y - py) < 60) { 
                        activePointIndex = i;
                        break;
                    }
                }

                if (activePointIndex == -1 && x > 20 && x < w - 20) {
                    int newX = (int) ((x / w) * 255);
                    int newY = (int) ((1 - y / h) * 255);
                    // ★ 同一列已经有点了就不再添加：
                    //   重复 x 会让插值除零，整张图变黑。
                    boolean dup = false;
                    for (Point ep : points) {
                        if (Math.abs(ep.x - newX) <= 1) { dup = true; break; }
                    }
                    if (dup) { invalidate(); return true; }
                    points.add(new Point(newX, newY));
                    Collections.sort(points, new Comparator<Point>() {
                            @Override public int compare(Point p1, Point p2) { return Integer.compare(p1.x, p2.x); }
                        });
                    for (int i = 0; i < points.size(); i++) {
                        if (points.get(i).x == newX) { activePointIndex = i; break; }
                    }
                }
                invalidate();
                if (activePointIndex != -1) notifyListener(false);
                return true;

            case MotionEvent.ACTION_MOVE:
                if (activePointIndex != -1) {
                    Point p = points.get(activePointIndex);
                    int newX = (int) ((x / w) * 255);
                    int newY = (int) ((1 - y / h) * 255);

                    if (newY < 0) newY = 0;
                    if (newY > 255) newY = 255;

                    if (activePointIndex == 0) {
                        p.x = 0;
                    } else if (activePointIndex == points.size() - 1) {
                        p.x = 255;
                    } else {
                        int minX = points.get(activePointIndex - 1).x + 1;
                        int maxX = points.get(activePointIndex + 1).x - 1;
                        if (newX < minX) newX = minX;
                        if (newX > maxX) newX = maxX;
                        p.x = newX;
                    }

                    p.y = newY;
                    invalidate();

                    notifyListener(false);
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                getParent().requestDisallowInterceptTouchEvent(false);
                if (activePointIndex != -1) notifyListener(true);
                activePointIndex = -1;
                return true;
        }
        return super.onTouchEvent(event);
    }

    public static class Point {
        public int x, y;
        public Point(int x, int y) { this.x = x; this.y = y; }
    }
}
