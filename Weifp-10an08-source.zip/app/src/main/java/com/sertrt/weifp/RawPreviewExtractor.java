package com.sertrt.weifp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class RawPreviewExtractor {

    public static Bitmap extractPreview(String filePath) {
        return null;
    }

    // ★ 改为接收 byte[]，完美绕过 Android 的各种 Uri 权限和路径问题
    public static Bitmap extractPreview(byte[] data) {
        if (data == null || data.length < 1024) return null;

        int bestStart = -1;
        int bestLength = 0;

        // 暴力扫描全文件，寻找 JPEG 的起始标志 (0xFFD8) 和结束标志 (0xFFD9)
        for (int i = 0; i < data.length - 1; i++) {
            if ((data[i] & 0xFF) == 0xFF && (data[i + 1] & 0xFF) == 0xD8) {
                // 找到了开头，现在去找结尾
                int end = -1;
                for (int j = i + 2; j < data.length - 1; j++) {
                    if ((data[j] & 0xFF) == 0xFF && (data[j + 1] & 0xFF) == 0xD9) {
                        end = j + 1; // 包含 D9
                        break;
                    }
                }
                
                // 如果找到了成对的 JPEG 头尾，且比之前找到的都大，就记录下来
                if (end != -1) {
                    int length = end - i + 1;
                    if (length > bestLength) {
                        bestLength = length;
                        bestStart = i;
                    }
                }
            }
        }

        if (bestStart != -1 && bestLength > 0) {
            try {
                // 为了防 OOM，用 Options 限制一下最大分辨率，如果原图超大，系统会自动降采样
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, bestStart, bestLength, opts);
                
                // 尼康的某些全尺寸预览图可能达到 6000x4000，直接解容易 OOM
                // 如果长边超过 4000，设置采样率降下来
                if (opts.outWidth > 4000 || opts.outHeight > 4000) {
                    opts.inSampleSize = 2;
                }
                
                opts.inJustDecodeBounds = false;
                opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                Bitmap bmp = BitmapFactory.decodeByteArray(data, bestStart, bestLength, opts);
                if (bmp != null) return bmp;
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
