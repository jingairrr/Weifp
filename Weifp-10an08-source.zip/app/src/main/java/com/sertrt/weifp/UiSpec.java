package com.sertrt.weifp;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;

/**
 * UI 设计规范（间距 / 圆角 / 描边 / 透明度）。
 *
 * 目的：把零散的 dp 数值收敛到统一的 4dp 网格，让界面显得整齐、专业。
 *
 * 原则：
 *  - **纯新增**，不改动任何现有布局行为；现有代码不改也能跑。
 *  - 新写的界面一律用这里的常量；老界面可以逐步替换。
 *  - 圆角按元素层级分档，不再 8/10/12 混用。
 *
 * 尺寸单位统一为 dp，内部按 density 换算成像素。
 */
public final class UiSpec {

    private UiSpec() {
    }

    // ==================== 间距（4dp 网格） ====================

    /** 4dp：元素内部最小间距。 */
    public static final int SPACE_XS = 4;
    /** 8dp：相关元素之间。 */
    public static final int SPACE_S = 8;
    /** 12dp：控件之间。 */
    public static final int SPACE_M = 12;
    /** 16dp：分组之间。 */
    public static final int SPACE_L = 16;
    /** 24dp：大分区之间。 */
    public static final int SPACE_XL = 24;
    /** 32dp：页面级留白。 */
    public static final int SPACE_XXL = 32;

    // ==================== 圆角（按层级分档） ====================

    /** 4dp：小控件（色块、标签）。 */
    public static final int RADIUS_XS = 4;
    /** 8dp：按钮。 */
    public static final int RADIUS_S = 8;
    /** 12dp：卡片、面板。 */
    public static final int RADIUS_M = 12;
    /** 16dp：对话框。 */
    public static final int RADIUS_L = 16;
    /** 999dp：完全圆角（胶囊）。 */
    public static final int RADIUS_PILL = 999;

    // ==================== 层级透明度 ====================

    /** 面板背景：略透，能感觉到浮在画布上。 */
    public static final int ALPHA_PANEL = 0xF2;   // 242/255
    /** 遮罩层。 */
    public static final int ALPHA_SCRIM = 0x99;   // 153/255
    /** 次要文字。 */
    public static final int ALPHA_TEXT_SECONDARY = 0xB3;  // 179/255
    /** 禁用态。 */
    public static final int ALPHA_DISABLED = 0x66;        // 102/255
    /** 按钮按下反馈。 */
    public static final float PRESS_SCALE = 0.96f;

    // ==================== 描边 ====================

    /** 描边宽度 1dp。 */
    public static final int STROKE_WIDTH = 1;
    /** 亮色主题下的描边色。 */
    public static final int STROKE_LIGHT = 0x1A000000;   // 10% 黑
    /** 暗色主题下的描边色。 */
    public static final int STROKE_DARK = 0x1AFFFFFF;    // 10% 白

    // ==================== 换算 ====================

    /** dp -> px。 */
    public static float dp(Context ctx, float dp) {
        if (ctx == null) return dp;
        return dp * ctx.getResources().getDisplayMetrics().density;
    }

    /** dp -> px（取整）。 */
    public static int dpi(Context ctx, float dp) {
        if (ctx == null) return Math.round(dp);
        return Math.round(dp * ctx.getResources().getDisplayMetrics().density);
    }

    /** dp -> px（用 Resources）。 */
    public static int dpi(Resources res, float dp) {
        if (res == null) return Math.round(dp);
        return Math.round(dp * res.getDisplayMetrics().density);
    }

    // ==================== 便捷构造 ====================

    /**
     * 生成层级的背景 drawable。
     *
     * @param ctx    上下文（用于 dp 换算）
     * @param fill   填充色（含 alpha）
     * @param radius 圆角 dp（用 RADIUS_* 常量）
     * @param stroke 是否加细描边
     * @param dark   是否暗色主题（决定描边颜色）
     */
    public static GradientDrawable panel(Context ctx, int fill, int radius,
                                         boolean stroke, boolean dark) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(fill);
        g.setCornerRadius(dp(ctx, radius));
        if (stroke) {
            g.setStroke(dpi(ctx, STROKE_WIDTH), dark ? STROKE_DARK : STROKE_LIGHT);
        }
        return g;
    }

    /** 给颜色叠加一个 alpha（色值不带 alpha 时用）。 */
    public static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    /** 按亮度判断是否用于暗色主题。 */
    public static boolean isDarkColor(int color) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        return (0.299 * r + 0.587 * g + 0.114 * b) < 100;
    }

    /** 主题主色（橙色），与项目现有视觉一致。 */
    public static final int ACCENT = 0xFFFFB615;

    /** 主色的浅色版本（用于选中背景）。 */
    public static int accentSoft() {
        return withAlpha(ACCENT, 0x33);
    }

    /**
     * 颜色色块（圆形，选中时外圈描边）。
     *
     * 参考 HMCLgo 的 swatch：内圆 + 外环，比方形色块精致得多。
     *
     * @param ctx      上下文
     * @param color    色块颜色
     * @param sizeDp   直径（dp）
     * @param selected 是否选中（选中时加外环）
     */
    public static android.widget.FrameLayout swatch(Context ctx, int color, int sizeDp,
                                                    boolean selected, boolean dark) {
        android.widget.FrameLayout f = new android.widget.FrameLayout(ctx);
        int size = dpi(ctx, sizeDp);
        f.setLayoutParams(new android.widget.LinearLayout.LayoutParams(size, size));

        android.view.View inner = new android.view.View(ctx);
        int inset = dpi(ctx, 3);
        android.widget.FrameLayout.LayoutParams ilp =
                new android.widget.FrameLayout.LayoutParams(size - inset * 2, size - inset * 2);
        ilp.gravity = android.view.Gravity.CENTER;
        inner.setLayoutParams(ilp);
        // 内圆：给浅色块加一圈细边界，避免白块在白底上看不见
        int ringColor = isDarkColor(color) ? 0x22000000 : 0x44000000;
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(color);
        circle.setStroke(1, ringColor);
        inner.setBackground(circle);
        f.addView(inner);

        if (selected) {
            GradientDrawable ring = new GradientDrawable();
            ring.setShape(GradientDrawable.OVAL);
            ring.setColor(Color.TRANSPARENT);
            ring.setStroke(dpi(ctx, 2), ACCENT);
            f.setBackground(ring);
        }
        return f;
    }

    /** 方形按钮背景（无圆角，用于"连在一起"的一排主按钮），带按下反馈。 */
    public static android.graphics.drawable.StateListDrawable pressableSquare(int color) {
        android.graphics.drawable.StateListDrawable s =
                new android.graphics.drawable.StateListDrawable();
        android.graphics.drawable.GradientDrawable pressed = new android.graphics.drawable.GradientDrawable();
        pressed.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        pressed.setColor(darkened(color, 0.10f));
        android.graphics.drawable.GradientDrawable normal = new android.graphics.drawable.GradientDrawable();
        normal.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        normal.setColor(color);
        s.addState(new int[]{android.R.attr.state_pressed}, pressed);
        s.addState(new int[]{}, normal);
        return s;
    }

    /** 胶囊 chip 背景（未选中）。 */
    public static GradientDrawable chip(Context ctx, boolean selected, int accent,
                                        boolean dark) {
        if (selected) {
            return panel(ctx, accent, RADIUS_PILL, false, dark);
        }
        int base = dark ? 0xFF2B2B2B : 0xFFF0F0F2;
        return panel(ctx, base, RADIUS_PILL, true, dark);
    }

    /** 危险色（删除/取消）。 */
    public static final int DANGER = 0xFFB61515;

    // ==================== 颜色工具（参考 HMCLgo 的风格） ====================

    /** 加深颜色（用于按下反馈），factor 0.12 表示加深 12%。 */
    public static int darkened(int color, float factor) {
        int a = (color >>> 24) & 0xFF;
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        r = Math.max(0, (int) (r * (1 - factor)));
        g = Math.max(0, (int) (g * (1 - factor)));
        b = Math.max(0, (int) (b * (1 - factor)));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** 两色线性混合，t=0 取 c1，t=1 取 c2。 */
    public static int mix(int c1, int c2, float t) {
        int a1 = (c1 >>> 24) & 0xFF, r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
        int a2 = (c2 >>> 24) & 0xFF, r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
        int a = (int) (a1 + (a2 - a1) * t);
        int r = (int) (r1 + (r2 - r1) * t);
        int g = (int) (g1 + (g2 - g1) * t);
        int b = (int) (b1 + (b2 - b1) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /**
     * 生成"按下有反馈"的背景：常态 + 按下变暗。
     * 这是 HMCLgo 里最提质感的一处，用完整个 App 的手感都会变。
     */
    public static android.graphics.drawable.StateListDrawable pressable(
            Context ctx, int color, int radiusDp) {
        android.graphics.drawable.StateListDrawable s =
                new android.graphics.drawable.StateListDrawable();
        android.graphics.drawable.GradientDrawable pressed =
                panel(ctx, darkened(color, 0.14f), radiusDp,
                        isRefined(), isDarkColor(color));
        android.graphics.drawable.GradientDrawable normal =
                panel(ctx, color, radiusDp, isRefined(), isDarkColor(color));
        s.addState(new int[]{android.R.attr.state_pressed}, pressed);
        s.addState(new int[]{}, normal);
        return s;
    }

    /**
     * 精致模式总开关：控制细描边等"观感增强"。
     * 关掉后界面回到原来的纯色块，不影响任何功能。
     */
    private static volatile boolean sRefined = true;

    public static boolean isRefined() {
        return sRefined;
    }

    public static void setRefined(boolean on) {
        sRefined = on;
    }
}
