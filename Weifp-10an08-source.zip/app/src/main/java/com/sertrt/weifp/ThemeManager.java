package com.sertrt.weifp;

import android.content.Context;
import android.content.SharedPreferences;

public class ThemeManager {

    // ==================== AI 指令执行模式 ====================
    public static final int AI_EXEC_OFF = 0;
    public static final int AI_EXEC_ASK = 1;
    public static final int AI_EXEC_AUTO = 2;

    /** AI 指令集总开关（默认关）。 */
    public static boolean isAiEnabled(Context context) {
        try {
            return context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE)
                    .getBoolean("ai_enabled", false);
        } catch (Throwable t) {
            return false;
        }
    }

    public static void setAiEnabled(Context context, boolean on) {
        try {
            context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE)
                    .edit().putBoolean("ai_enabled", on).commit();
        } catch (Throwable ignored) {}
    }

    // ==================== 界面字体（中英文可分开）====================
    public static String getFontCjk(Context ctx) {
        try {
            return ctx.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE)
                    .getString("font_cjk", "默认");
        } catch (Throwable t) { return "默认"; }
    }

    public static void setFontCjk(Context ctx, String v) {
        try {
            ctx.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE)
                    .edit().putString("font_cjk", v).commit();
        } catch (Throwable ignored) {}
    }

    /** 字体设置版本：改了默认字体就 +1，老用户的旧值会被重置。 */
    private static final int FONT_VER = 2;

    public static String getFontLatin(Context ctx) {
        try {
            android.content.SharedPreferences sp =
                    ctx.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
            // 老版本存过 "Roboto"/"默认"，升级后清掉让新默认生效
            int ver = sp.getInt("font_ver", 1);
            if (ver < FONT_VER) {
                sp.edit().putInt("font_ver", FONT_VER)
                  .remove("font_latin").remove("font_cjk").commit();
                return "IBM Plex";
            }
            return sp.getString("font_latin", "IBM Plex");
        } catch (Throwable t) { return "IBM Plex"; }
    }

    public static void setFontLatin(Context ctx, String v) {
        try {
            ctx.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE)
                    .edit().putString("font_latin", v).commit();
        } catch (Throwable ignored) {}
    }

    /** 取当前界面字体（中英组合）。 */
    public static android.graphics.Typeface getUiTypeface(Context ctx) {
        try {
            return FontManager.combine(ctx, getFontCjk(ctx), getFontLatin(ctx));
        } catch (Throwable t) {
            return android.graphics.Typeface.DEFAULT;
        }
    }

    public static int getAiExecMode(Context context) {
        try {
            return context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE)
                    .getInt("ai_exec_mode", AI_EXEC_ASK);
        } catch (Throwable t) {
            return AI_EXEC_ASK;
        }
    }

    public static void setAiExecMode(Context context, int mode) {
        try {
            context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE)
                    .edit().putInt("ai_exec_mode", mode).commit();
        } catch (Throwable ignored) {}
    }

    public static final int THEME_DARK = 0;
    public static final int THEME_LIGHT = 1;
    public static final int THEME_AUTO = 2;

    public static void setThemeMode(Context context, int mode) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        sp.edit().putInt("theme_mode", mode).apply();
    }

    public static int getThemeModeSetting(Context context) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        return sp.getInt("theme_mode", THEME_DARK);
    }

    public static int getThemeMode(Context context) {
        int mode = getThemeModeSetting(context);
        if (mode == THEME_AUTO) {
            int hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
            return (hour >= 18 || hour < 6) ? THEME_DARK : THEME_LIGHT;
        }
        return mode;
    }

    public static boolean isDark(Context context) {
        return getThemeMode(context) == THEME_DARK;
    }

    public static int getBgColor(Context context) {
        return isDark(context) ? 0xFF1E1E1E : 0xFFF5F5F5;
    }

    public static int getPanelColor(Context context) {
        return isDark(context) ? 0xFF2A2A2A : 0xFFFFFFFF;
    }

    public static int getTextColor(Context context) {
        return isDark(context) ? 0xFFFFFFFF : 0xFF333333;
    }

    public static int getButtonColor(Context context) {
        return isDark(context) ? 0xFF3A3A3A : 0xFFE0E0E0; 
    }

    // ==================== 三层灰阶（参考 HMCLgo 的层级体系） ====================
    // bg（最底） < surface（面板） < card（卡片/按钮）
    // 让面板、卡片、按钮在视觉上有明确层级，而不是同一个灰。

    /** 中间层：面板/工具栏。暗色比 bg 亮一档，亮色为纯白。 */
    public static int getSurfaceColor(Context context) {
        return isDark(context) ? 0xFF262626 : 0xFFFFFFFF;
    }

    /** 最上层：卡片、列表项。 */
    public static int getCardColor(Context context) {
        return isDark(context) ? 0xFF303030 : 0xFFF0F0F2;
    }

    /** 卡片按下时的底色。 */
    public static int getCardPressedColor(Context context) {
        return isDark(context) ? 0xFF3A3A3A : 0xFFE4E4E7;
    }

    /** 次要文字（说明、提示）。 */
    public static int getTextSecondaryColor(Context context) {
        return isDark(context) ? 0xFFA8A8A8 : 0xFF6C6C70;
    }

    /** 分隔线。 */
    public static int getDividerColor(Context context) {
        return isDark(context) ? 0xFF303030 : 0xFFE3E3E6;
    }

    // 直方图开关
    public static void setHistogramEnabled(Context context, boolean enabled) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        sp.edit().putBoolean("histogram_enabled", enabled).apply();
    }

    public static boolean isHistogramEnabled(Context context) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        return sp.getBoolean("histogram_enabled", false);
    }

    // ★ WPC 保存频率：true=每步保存，false=退出时保存
    public static void setStepPerActionEnabled(Context context, boolean enabled) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        sp.edit().putBoolean("step_per_action", enabled).apply();
    }

    public static boolean isStepPerActionEnabled(Context context) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        return sp.getBoolean("step_per_action", true);
    }

    // ★ 启用 WPB
    public static void setWpbEnabled(Context context, boolean enabled) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        sp.edit().putBoolean("wpb_enabled", enabled).apply();
    }

    public static boolean isWpbEnabled(Context context) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        return sp.getBoolean("wpb_enabled", false);
    }

    // ★ 性能提示是否已弹过
    public static void setPerfWarned(Context context, boolean warned) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        sp.edit().putBoolean("perf_warned", warned).apply();
    }

    public static boolean isPerfWarned(Context context) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        return sp.getBoolean("perf_warned", false);
    }
}
