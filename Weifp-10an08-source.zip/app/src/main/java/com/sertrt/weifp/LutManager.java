package com.sertrt.weifp;

import android.content.Context;
import android.net.Uri;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class LutManager {

    public static File getLutDir(Context context) {
        File dir = new File(context.getExternalFilesDir(null), "LUTs");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    // 列出所有 .cube
    public static List<File> getAllLuts(Context context) {
        File dir = getLutDir(context);
        List<File> list = new ArrayList<File>();
        File[] files = dir.listFiles();
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                File f = files[i];
                if (f.getName().toLowerCase().endsWith(".cube")) {
                    list.add(f);
                }
            }
        }
        return list;
    }

    // 加载 .cube 文件
    public static CubeLut loadLut(File file) {
        try {
            FileInputStream fis = new FileInputStream(file);
            CubeLut lut = CubeLut.parse(fis);
            fis.close();
            if (lut != null) {
                String name = file.getName();
                if (name.toLowerCase().endsWith(".cube")) {
                    name = name.substring(0, name.length() - 5);
                }
                lut.title = name;
            }
            return lut;
        } catch (Throwable e) {
            return null;
        }
    }

    // 导入 .cube 到 LUTs 目录
    public static File importLut(Context context, Uri uri, String fileName) {
        try {
            if (fileName == null) fileName = "未命名.cube";
            if (!fileName.toLowerCase().endsWith(".cube")) fileName = fileName + ".cube";

            String baseName = fileName;
            if (baseName.toLowerCase().endsWith(".cube")) {
                baseName = baseName.substring(0, baseName.length() - 5);
            }

            File destFile = new File(getLutDir(context), fileName);
            int count = 1;
            while (destFile.exists()) {
                destFile = new File(getLutDir(context), baseName + " (" + count + ").cube");
                count++;
            }

            InputStream is = context.getContentResolver().openInputStream(uri);
            if (is == null) return null;
            FileOutputStream fos = new FileOutputStream(destFile);
            byte[] buf = new byte[8192];
            int len;
            while ((len = is.read(buf)) > 0) {
                fos.write(buf, 0, len);
            }
            fos.close();
            is.close();
            return destFile;
        } catch (Throwable e) {
            return null;
        }
    }

    public static boolean deleteLut(File file) {
        if (file == null || !file.exists()) return false;
        return file.delete();
    }
}
