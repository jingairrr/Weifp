package com.sertrt.weifp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.File;

/**
 * 指令执行器：把一条指令应用到一张图片上，输出结果文件。
 *
 * 这是给外部（人或 AI）用的接口，流程：
 *   输入图 + 指令 JSON  →  加载图片  →  逐条应用  →  保存输出
 *
 * 只处理「基础」和「高级」里的调整类功能，
 * 不涉及交互式操作（涂鸦、套索、裁剪框）。
 */
public final class CommandExecutor {

    /** 执行结果。 */
    public static class Result {
        public boolean ok;
        public String message;
        public String outputPath;
        /** 本次用了哪些调整参数（key -> value），供写入滤镜状态用。 */
        public final java.util.LinkedHashMap<String, Float> adjustments =
                new java.util.LinkedHashMap<String, Float>();
    }

    private CommandExecutor() {
    }

    /**
     * 对一张图应用一组指令。
     *
     * @param inputPath  输入图片路径
     * @param outputPath 输出路径（null 则自动生成）
     * @param cmds       指令列表
     */
    public static Result run(String inputPath, String outputPath, java.util.List<Cmd> cmds) {
        return run(inputPath, outputPath, cmds, null);
    }

    /**
     * @param ctx 用于输出失败时回退到应用私有目录；可为 null
     */
    public static Result run(String inputPath, String outputPath,
                             java.util.List<Cmd> cmds, android.content.Context ctx) {
        Result r = new Result();
        Bitmap src = null;
        // 记录调整类参数，方便把编辑状态一并写回，打开图片时滑轨能对上
        if (cmds != null) {
            for (Cmd c : cmds) {
                if (c != null && c.key != null && isAdjustKey(c.key)) {
                    r.adjustments.put(c.key, c.value);
                }
            }
        }
        try {
            File in = new File(inputPath);
            if (!in.exists() || in.length() <= 0) {
                r.message = "输入文件不存在: " + inputPath;
                return r;
            }
            src = BitmapFactory.decodeFile(inputPath);
            if (src == null) {
                r.message = "无法解码图片: " + inputPath;
                return r;
            }
            // 需要可变位图才能原地改
            if (!src.isMutable()) {
                Bitmap mut = src.copy(Bitmap.Config.ARGB_8888, true);
                if (mut != null) {
                    src.recycle();
                    src = mut;
                }
            }

            // 逐条执行
            for (Cmd c : cmds) {
                Bitmap after = applyOne(src, c);
                if (after != null && after != src) {
                    if (!src.isRecycled()) src.recycle();
                    src = after;
                }
            }

            String out = outputPath;
            if (out == null || out.length() == 0) {
                out = inputPath.replace(".", "_out.");
                if (out.equals(inputPath)) out = inputPath + "_out.png";
            }
            File outFile = new File(out);
            File parent = outFile.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();

            // 先尝试写用户指定位置；失败（Android 10+ 分区存储常拒绝公共目录写入）
            // 再回退到应用私有目录，保证功能能用。
            boolean saved = tryWrite(src, outFile, out);
            if (!saved && ctx != null) {
                try {
                    File fallbackDir = new File(ctx.getExternalFilesDir(null), "out");
                    if (!fallbackDir.exists()) fallbackDir.mkdirs();
                    String name = outFile.getName();
                    File fb = new File(fallbackDir, name);
                    if (tryWrite(src, fb, out)) {
                        r.ok = true;
                        r.outputPath = fb.getAbsolutePath();
                        r.message = "完成（已写入应用目录，公共目录无写权限）";
                        return r;
                    }
                } catch (Throwable ignored) {}
            }
            if (!saved) {
                r.message = "无法写入输出文件: " + out
                        + "（公共目录无写权限，可把 output 指到应用目录）";
                return r;
            }

            r.ok = true;
            r.outputPath = outFile.getAbsolutePath();
            r.message = "完成";
            return r;
        } catch (Throwable t) {
            r.message = "执行出错: " + t;
            return r;
        } finally {
            if (src != null && !src.isRecycled()) src.recycle();
        }
    }

    /** 这个指令是不是"调整类"（会写进滤镜状态）。 */
    static boolean isAdjustKey(String key) {
        if (key == null) return false;
        switch (key) {
            case "brightness": case "contrast": case "saturation":
            case "shadows": case "highlights": case "temperature":
            case "tint": case "vibrance":
                return true;
            default:
                return false;
        }
    }

    /** 尝试把位图写到指定文件；成功返回 true。 */
    private static boolean tryWrite(Bitmap src, File outFile, String out) {
        java.io.FileOutputStream fos = null;
        try {
            fos = new java.io.FileOutputStream(outFile);
            String lower = out.toLowerCase();
            if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) {
                src.compress(Bitmap.CompressFormat.JPEG, 95, fos);
            } else {
                src.compress(Bitmap.CompressFormat.PNG, 100, fos);
            }
            fos.flush();
            return outFile.exists() && outFile.length() > 0;
        } catch (Throwable t) {
            try { outFile.delete(); } catch (Throwable ignored) {}
            return false;
        } finally {
            try { if (fos != null) fos.close(); } catch (Throwable ignored) {}
        }
    }

    /** 一条指令。 */
    public static class Cmd {
        public String key;        // 指令名，如 brightness
        public float value;       // 数值参数
        public String text;       // 文本参数（预设名等）
        public float x, y, w, h;  // 裁剪用
        public int color;         // 颜色参数（抠图）
    }

    /**
     * 应用单条指令。返回新的位图，或 null 表示无变化。
     */
    private static Bitmap applyOne(Bitmap src, Cmd c) {
        if (src == null || c == null || c.key == null) return null;
        try {
            switch (c.key) {
                case "rotate": {
                    int deg = (int) c.value;
                    if (deg == 0) deg = 90;
                    android.graphics.Matrix m = new android.graphics.Matrix();
                    m.postRotate(deg);
                    return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
                }
                case "flip_h": {
                    android.graphics.Matrix m = new android.graphics.Matrix();
                    m.postScale(-1, 1);
                    return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
                }
                case "flip_v": {
                    android.graphics.Matrix m = new android.graphics.Matrix();
                    m.postScale(1, -1);
                    return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
                }
                case "resize": {
                    int target = (int) c.value;
                    if (target <= 0) return null;
                    int w = src.getWidth(), h = src.getHeight();
                    float scale = (float) target / Math.max(w, h);
                    int nw = Math.max(1, Math.round(w * scale));
                    int nh = Math.max(1, Math.round(h * scale));
                    return Bitmap.createScaledBitmap(src, nw, nh, true);
                }
                case "crop": {
                    int l = Math.max(0, (int) c.x);
                    int t = Math.max(0, (int) c.y);
                    int cw = Math.min(src.getWidth() - l, (int) c.w);
                    int ch = Math.min(src.getHeight() - t, (int) c.h);
                    if (cw <= 0 || ch <= 0) return null;
                    return Bitmap.createBitmap(src, l, t, cw, ch);
                }
                case "upscale": {
                    int times = (int) c.value;
                    if (times < 2) times = 2;
                    SuperResolution.Options op = new SuperResolution.Options();
                    op.scale = times;
                    op.usm = true;
                    op.usmAmount = 0.5;
                    return SuperResolution.upscale(src, op);
                }
                case "chroma_key": {
                    int[] px = new int[src.getWidth() * src.getHeight()];
                    src.getPixels(px, 0, src.getWidth(), 0, 0, src.getWidth(), src.getHeight());
                    ChromaKey.Settings st = new ChromaKey.Settings();
                    st.keyColor = c.color != 0 ? c.color : px[px.length / 2];
                    st.sensitivity = c.value > 0 ? (int) c.value : 50;
                    st.feather = 30;
                    st.spillSuppress = 50;
                    st.sampleRadius = 3;
                    ChromaKey.apply(px, src.getWidth(), src.getHeight(), st, null);
                    Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(),
                            Bitmap.Config.ARGB_8888);
                    out.setPixels(px, 0, src.getWidth(), 0, 0, src.getWidth(), src.getHeight());
                    return out;
                }
                default:
                    // 调整类参数：用 ColorMatrix 批量处理
                    return applyAdjust(src, c);
            }
        } catch (Throwable t) {
            try { CrashLogger.log("指令执行失败: " + c.key, t); } catch (Throwable ignored) {}
            return null;
        }
    }

    /** 调整类指令（亮度/对比度/色温等）：一次 ColorMatrix 搞定。 */
    private static Bitmap applyAdjust(Bitmap src, Cmd c) {
        android.graphics.ColorMatrix cm = buildMatrix(c.key, c.value);
        if (cm == null) return null;
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(),
                Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas = new android.graphics.Canvas(out);
        android.graphics.Paint p = new android.graphics.Paint();
        p.setColorFilter(new android.graphics.ColorMatrixColorFilter(cm));
        canvas.drawBitmap(src, 0, 0, p);
        return out;
    }

    /**
     * 按指令构造色彩矩阵。和 ZoomImageView 里的算法保持一致（可逆）。
     */
    static android.graphics.ColorMatrix buildMatrix(String key, float v) {
        android.graphics.ColorMatrix cm = new android.graphics.ColorMatrix();
        switch (key) {
            case "brightness": {
                float s = v >= 0 ? 1f + v / 100f : 1f + v / 100f * 0.75f;
                cm.set(new float[]{s,0,0,0,0, 0,s,0,0,0, 0,0,s,0,0, 0,0,0,1,0});
                return cm;
            }
            case "contrast": {
                float s = 1f + v / 100f * 0.6f;
                float o = 128f * (1f - s);
                cm.set(new float[]{s,0,0,0,o, 0,s,0,0,o, 0,0,s,0,o, 0,0,0,1,0});
                return cm;
            }
            case "saturation": {
                float s = 1f + v / 100f;
                float sr = (1 - s) * 0.3086f, sg = (1 - s) * 0.6094f, sb = (1 - s) * 0.0820f;
                cm.set(new float[]{
                        sr+s, sg, sb, 0, 0,
                        sr, sg+s, sb, 0, 0,
                        sr, sg, sb+s, 0, 0,
                        0, 0, 0, 1, 0});
                return cm;
            }
            case "vibrance": {
                // 近似：减弱版饱和度
                float s = 1f + v / 200f;
                float sr = (1 - s) * 0.3086f, sg = (1 - s) * 0.6094f, sb = (1 - s) * 0.0820f;
                cm.set(new float[]{
                        sr+s, sg, sb, 0, 0,
                        sr, sg+s, sb, 0, 0,
                        sr, sg, sb+s, 0, 0,
                        0, 0, 0, 1, 0});
                return cm;
            }
            case "temperature": {
                float t = v / 100f;
                float rg = 1f + t * 0.25f, bg = 1f - t * 0.25f;
                cm.set(new float[]{rg,0,0,0,0, 0,1,0,0,0, 0,0,bg,0,0, 0,0,0,1,0});
                return cm;
            }
            case "tint": {
                float t = v / 100f;
                float rg = 1f + t * 0.15f, gg = 1f - t * 0.18f, bg = 1f + t * 0.15f;
                cm.set(new float[]{rg,0,0,0,0, 0,gg,0,0,0, 0,0,bg,0,0, 0,0,0,1,0});
                return cm;
            }
            case "shadows": {
                float s = 1f + v / 100f * 0.22f;
                float o = 255f * (1f - s) * 0.18f;
                cm.set(new float[]{s,0,0,0,o, 0,s,0,0,o, 0,0,s,0,o, 0,0,0,1,0});
                return cm;
            }
            case "highlights": {
                float s = 1f + v / 100f * 0.18f;
                float o = 255f * (1f - s) * 0.18f;
                cm.set(new float[]{s,0,0,0,o, 0,s,0,0,o, 0,0,s,0,o, 0,0,0,1,0});
                return cm;
            }
            default:
                return null;
        }
    }
}
