package com.sertrt.weifp;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Environment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 字体管理：提供文字工具可选的字体列表。
 *
 * 三类来源：
 *  1. 内置字体族（sans / serif / monospace 及其粗体、斜体变体）
 *  2. 系统字体目录里的 .ttf / .otf（/system/fonts）
 *  3. 用户放在 Download/Weifp/fonts/ 里的自定义字体
 *
 * 图形字体的体积通常几 MB，不适合全部打包进 APK，
 * 所以这里走"读系统已有字体 + 允许用户自己丢字体文件"的方式。
 */
public final class FontManager {

    /** 一个可选字体。 */
    public static class FontItem {
        public final String name;      // 显示名
        public final Typeface face;    // 实际字体对象
        public final String file;      // 来源文件路径（内置的为空）

        FontItem(String name, Typeface face, String file) {
            this.name = name;
            this.face = face;
            this.file = file;
        }
    }

    private static List<FontItem> cached = null;

    private FontManager() {
    }

    /** 用户自定义字体目录。 */
    public static File userFontDir() {
        try {
            File d = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), "Weifp/fonts");
            if (!d.exists()) d.mkdirs();
            return d;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 取全部可用字体（第一次调用会扫描，之后缓存）。 */
    public static List<FontItem> all(Context ctx) {
        if (cached != null) return cached;
        List<FontItem> list = new ArrayList<FontItem>();

        // ---- 1. 内置字体族 ----
        list.add(new FontItem("默认", Typeface.DEFAULT, null));
        try {
            list.add(new FontItem("无衬线", Typeface.SANS_SERIF, null));
            list.add(new FontItem("衬线", Typeface.SERIF, null));
            list.add(new FontItem("等宽", Typeface.MONOSPACE, null));
            list.add(new FontItem("无衬线粗体",
                    Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD), null));
            list.add(new FontItem("衬线粗体",
                    Typeface.create(Typeface.SERIF, Typeface.BOLD), null));
            list.add(new FontItem("斜体",
                    Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC), null));
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                list.add(new FontItem("细体",
                        Typeface.create(Typeface.SANS_SERIF, 300, false), null));
                list.add(new FontItem("特粗",
                        Typeface.create(Typeface.SANS_SERIF, 900, false), null));
            }
        } catch (Throwable ignored) {}

        // ---- 2. 内置字体（打包在 assets/fonts，体积小、开箱可用）----
        //   这些字体原本来自系统 /system/fonts，都是可自由分发的开源字体。
        String[][] bundled = {
            // IBM Plex Sans：默认界面字体，SIL OFL 授权，可自由分发
            {"IBMPlexSans", "IBM Plex", "fonts/IBMPlexSans-Regular.ttf"},
            {"IBMPlexSansBold", "IBM Plex 粗体", "fonts/IBMPlexSans-Bold.ttf"},
            {"CarroisGothicSC", "卡洛里斯", "fonts/CarroisGothicSC-Regular.ttf"},
            {"ComingSoon",      "楷体手写", "fonts/ComingSoon.ttf"},
            {"CutiveMono",      "打字机",   "fonts/CutiveMono.ttf"},
            {"DancingScript",   "手写体",   "fonts/DancingScript-Regular.ttf"},
            {"DancingScriptB",  "手写粗体", "fonts/DancingScript-Bold.ttf"}
        };
        if (ctx != null) {
            for (String[] b : bundled) {
                try {
                    Typeface tf = Typeface.createFromAsset(ctx.getAssets(), b[2]);
                    if (tf != null) {
                        list.add(new FontItem(b[1], tf, b[2]));
                        CrashLogger.logInfo("字体", "内置字体加载成功: " + b[1]);
                    }
                } catch (Throwable e) {
                    CrashLogger.logInfo("字体", "内置字体加载失败: " + b[1] + " " + e);
                }
            }
        }

        // ---- 3. 用户自定义字体（优先，用户自己放的最常用）----
        try {
            File dir = userFontDir();
            File[] files = dir == null ? null : dir.listFiles();
            if (files != null) {
                for (File f : files) {
                    String n = f.getName().toLowerCase();
                    if (!n.endsWith(".ttf") && !n.endsWith(".otf")) continue;
                    try {
                        Typeface tf = Typeface.createFromFile(f);
                        if (tf != null) {
                            list.add(new FontItem(stripExt(f.getName()), tf,
                                    f.getAbsolutePath()));
                        }
                    } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {}

        // ---- Roboto：安卓原生科技感无衬线，英文界面的默认选择 ----
        try {
            java.io.File roboto = new java.io.File("/system/fonts/Roboto-Regular.ttf");
            if (roboto.exists()) {
                Typeface tf = Typeface.createFromFile(roboto);
                if (tf != null) list.add(new FontItem("Roboto", tf, roboto.getAbsolutePath()));
            }
            java.io.File robotoBold = new java.io.File("/system/fonts/Roboto-Bold.ttf");
            if (robotoBold.exists()) {
                Typeface tf = Typeface.createFromFile(robotoBold);
                if (tf != null) list.add(new FontItem("Roboto Bold", tf, robotoBold.getAbsolutePath()));
            }
        } catch (Throwable ignored) {}

        // ---- 4. 系统字体目录 ----
        try {
            File[] files = new File("/system/fonts").listFiles();
            if (files != null) {
                int added = 0;
                for (File f : files) {
                    if (added >= 30) break;      // 上限，避免列表过长
                    String n = f.getName().toLowerCase();
                    if (!n.endsWith(".ttf") && !n.endsWith(".otf")) continue;
                    // 跳过中文/复杂语言的超大字体，加载慢
                    if (n.contains("cjk") || n.contains("hans") || n.contains("hant")
                            || n.contains("arabic") || n.contains("devanagari")) continue;
                    try {
                        Typeface tf = Typeface.createFromFile(f);
                        if (tf != null) {
                            list.add(new FontItem(stripExt(f.getName()), tf,
                                    f.getAbsolutePath()));
                            added++;
                        }
                    } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {}

        cached = list;
        return list;
    }

    /**
     * 取字体对应的"真实文件路径"。
     *
     * 内置字体（assets）返回 null —— assets 不是文件系统路径，
     * 没法交给 FontFamily.Builder 用。这种情况直接用它自己的 Typeface。
     */
    public static String fileOf(Context ctx, String name) {
        if (name == null || ctx == null) return null;
        for (FontItem it : all(ctx)) {
            if (!it.name.equals(name)) continue;
            String f = it.file;
            if (f == null) return null;
            if (!f.startsWith("/")) return null;   // assets 相对路径，不是真文件
            if (!new java.io.File(f).exists()) return null;
            return f;
        }
        return null;
    }

    /** 用户自定义字体目录里的文件路径（用于内置族）。 */
    public static String bundledFile(Context ctx, String assetName) {
        return null;
    }

    /** 按名字找字体。 */
    public static Typeface find(Context ctx, String name) {
        if (name == null) return Typeface.DEFAULT;
        for (FontItem it : all(ctx)) {
            if (it.name.equals(name)) return it.face;
        }
        return Typeface.DEFAULT;
    }

    /** 清缓存（用户新放了字体后调用）。 */
    public static void invalidate() {
        cached = null;
        combinedCache = null;
    }

    // ==================== 中英文分别设置 ====================
    private static Typeface combinedCache = null;
    private static String combinedKey = "";

    /**
     * 组合两个字体：中文用 cjk，其它字符用 latin。
     *
     * API 26+ 用 FontFamily 让系统按字符自动回退；
     * 更低版本只能返回中文字体（英文会用它自带的西文字形）。
     */
    public static Typeface combine(Context ctx, String cjkName, String latinName) {
        String key = cjkName + "|" + latinName;
        if (key.equals(combinedKey) && combinedCache != null) return combinedCache;
        combinedKey = key;

        Typeface cjk = find(ctx, cjkName);
        Typeface latin = find(ctx, latinName);
        Typeface result;
        String cjkFile = fileOf(ctx, cjkName);
        String latinFile = fileOf(ctx, latinName);
        if (cjkFile == null && latinFile == null) {
            // 没有可用的字体文件（都是系统内置族），退回单一 Typeface
            result = cjk != null ? cjk : (latin != null ? latin : Typeface.DEFAULT);
        } else if (android.os.Build.VERSION.SDK_INT >= 26) {
            try {
                android.graphics.fonts.FontFamily.Builder builder = null;
                // 顺序很重要：先中文，缺字时回退到英文
                if (cjkFile != null) {
                    builder = new android.graphics.fonts.FontFamily.Builder(
                            new android.graphics.fonts.Font.Builder(new java.io.File(cjkFile)).build());
                }
                if (latinFile != null) {
                    android.graphics.fonts.Font lf =
                            new android.graphics.fonts.Font.Builder(new java.io.File(latinFile)).build();
                    if (builder == null) {
                        builder = new android.graphics.fonts.FontFamily.Builder(lf);
                    } else {
                        builder = builder.addFont(lf);
                    }
                }
                result = builder != null
                        ? new Typeface.CustomFallbackBuilder(builder.build()).build()
                        : Typeface.DEFAULT;
            } catch (Throwable t) {
                result = cjk != null ? cjk : (latin != null ? latin : Typeface.DEFAULT);
            }
        } else {
            // 低版本：只能用一个，优先中文（覆盖字符更全）
            result = cjk != null ? cjk : (latin != null ? latin : Typeface.DEFAULT);
        }
        combinedCache = result;
        return result;
    }

    private static String stripExt(String s) {
        int i = s.lastIndexOf('.');
        return i > 0 ? s.substring(0, i) : s;
    }
}
