package com.sertrt.weifp;

import android.app.Activity;
import android.content.ContentValues;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileDescriptor;
import java.io.OutputStream;

public class ExportActivity extends Activity {

    private ZoomImageView zoomImage;
    private Bitmap currentBitmap;
    private int quality = 100;
    private String format = "JPG";

    private SeekBar seekQuality;
    private TextView tvQuality;
    private float density;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getBaseContext().getResources().updateConfiguration(
            LanguageManager.wrap(this).getResources().getConfiguration(),
            getBaseContext().getResources().getDisplayMetrics()
        );

        density = getResources().getDisplayMetrics().density;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF1E1E1E);
        root.setPadding(0, (int)(50 * density), 0, 0);

        zoomImage = new ZoomImageView(this);
        zoomImage.setLayoutParams(new LinearLayout.LayoutParams(
                                      LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        zoomImage.setBackgroundColor(0xFF333333);
        zoomImage.setZoomEnabled(true);
        root.addView(zoomImage);

        Uri imageUri = getIntent().getData();
        if (imageUri != null) {
            try {
                ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(imageUri, "r");
                if (pfd != null) {
                    FileDescriptor fd = pfd.getFileDescriptor();
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inSampleSize = 1;
                    options.inScaled = false;
                    options.inDensity = 0;
                    options.inTargetDensity = 0;
                    options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                    currentBitmap = BitmapFactory.decodeFileDescriptor(fd, null, options);
                    pfd.close();
                    zoomImage.setImageBitmap(currentBitmap);
                }
            } catch (Throwable e) {
                Toast.makeText(this, "图片加载失败啦 (｡•́︿•̀｡)", Toast.LENGTH_SHORT).show();
            }
        }

        LinearLayout toolBar = new LinearLayout(this);
        toolBar.setOrientation(LinearLayout.VERTICAL);
        toolBar.setBackgroundColor(0xFF2A2A2A);
        toolBar.setPadding(20, 20, 20, 20);

        TextView tvFormat = new TextView(this);
        tvFormat.setText(LanguageManager.getString(this, R.string.export_format));
        tvFormat.setTextColor(0xFFFFFFFF);
        toolBar.addView(tvFormat);

        RadioGroup formatGroup = new RadioGroup(this);
        formatGroup.setOrientation(RadioGroup.HORIZONTAL);

        // ★ 统一橘色
        ColorStateList orangeTint = ColorStateList.valueOf(0xFFFFB615);

        RadioButton rbJpg = new RadioButton(this);
        rbJpg.setText("JPG");
        rbJpg.setTextColor(0xFFFFFFFF);
        rbJpg.setId(2);
        rbJpg.setChecked(true);
        try { rbJpg.setButtonTintList(orangeTint); } catch (Throwable ignored) {}
        formatGroup.addView(rbJpg);

        RadioButton rbPng = new RadioButton(this);
        rbPng.setText("PNG");
        rbPng.setTextColor(0xFFFFFFFF);
        rbPng.setId(1);
        try { rbPng.setButtonTintList(orangeTint); } catch (Throwable ignored) {}
        formatGroup.addView(rbPng);

        RadioButton rbWebp = new RadioButton(this);
        rbWebp.setText("WEBP");
        rbWebp.setTextColor(0xFFFFFFFF);
        rbWebp.setId(3);
        try { rbWebp.setButtonTintList(orangeTint); } catch (Throwable ignored) {}
        formatGroup.addView(rbWebp);

        tvQuality = new TextView(this);
        tvQuality.setText(LanguageManager.getString(this, R.string.quality) + "100");
        tvQuality.setTextColor(0xFFFFFFFF);
        toolBar.addView(tvQuality);

        seekQuality = new SeekBar(this);
        seekQuality.setMax(100);
        seekQuality.setProgress(100);
        seekQuality.setEnabled(true);
        seekQuality.setAlpha(1.0f);

        // ★ 强制染成橘色，告别牙膏蓝
        try {
            seekQuality.setProgressTintList(orangeTint);
            seekQuality.setThumbTintList(orangeTint);
        } catch (Throwable ignored) {}

        seekQuality.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    quality = progress;
                    tvQuality.setText(LanguageManager.getString(ExportActivity.this, R.string.quality) + progress);
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        toolBar.addView(seekQuality);

        formatGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    if (checkedId == 1) {
                        format = "PNG";
                        seekQuality.setEnabled(false);
                        seekQuality.setAlpha(0.3f);
                        tvQuality.setTextColor(0xFF666666);
                        tvQuality.setText(LanguageManager.getString(ExportActivity.this, R.string.png_no_quality));
                    } else if (checkedId == 2) {
                        format = "JPG";
                        seekQuality.setEnabled(true);
                        seekQuality.setAlpha(1.0f);
                        tvQuality.setTextColor(0xFFFFFFFF);
                        tvQuality.setText(LanguageManager.getString(ExportActivity.this, R.string.quality) + quality);
                    } else if (checkedId == 3) {
                        format = "WEBP";
                        seekQuality.setEnabled(true);
                        seekQuality.setAlpha(1.0f);
                        tvQuality.setTextColor(0xFFFFFFFF);
                        tvQuality.setText(LanguageManager.getString(ExportActivity.this, R.string.quality) + quality);
                    }
                }
            });
        toolBar.addView(formatGroup);

        Button btnSave = new Button(this);
        btnSave.setText(LanguageManager.getString(this, R.string.save_return));
        btnSave.setBackground(getRoundBg(0xFFFFB615));
        btnSave.setTextColor(0xFF000000);
        btnSave.setStateListAnimator(null);
        btnSave.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { saveAndReturn(); }
            });
        toolBar.addView(btnSave);

        root.addView(toolBar);
        setContentView(root);

        BackButtonHelper.addBackButton(this, null);
    }

    private GradientDrawable getRoundBg(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(UiSpec.dp(this, UiSpec.RADIUS_S));
        bg.setColor(color);
        return bg;
    }

    private void saveAndReturn() {
        if (currentBitmap == null) {
            Toast.makeText(this, "还没有图片呀 ( ´▽｀)", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Bitmap.CompressFormat compressFormat;
            String mimeType;
            String ext;

            switch (format) {
                case "JPG":
                    compressFormat = Bitmap.CompressFormat.JPEG;
                    mimeType = "image/jpeg";
                    ext = ".jpg";
                    break;
                case "WEBP":
                    compressFormat = Bitmap.CompressFormat.WEBP;
                    mimeType = "image/webp";
                    ext = ".webp";
                    break;
                default:
                    compressFormat = Bitmap.CompressFormat.PNG;
                    mimeType = "image/png";
                    ext = ".png";
                    break;
            }

            String fileName = "Weifp_" + System.currentTimeMillis() + ext;

            ContentValues values = new ContentValues();
            values.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, fileName);
            values.put(android.provider.MediaStore.Images.Media.MIME_TYPE, mimeType);

            if (Build.VERSION.SDK_INT >= 29) {
                values.put("relative_path", android.os.Environment.DIRECTORY_PICTURES + "/Weifp");
            } else {
                java.io.File dir = new java.io.File(
                    android.os.Environment.getExternalStoragePublicDirectory(
                        android.os.Environment.DIRECTORY_PICTURES), "Weifp");
                if (!dir.exists()) dir.mkdirs();
                values.put(android.provider.MediaStore.Images.Media.DATA,
                           new java.io.File(dir, fileName).getAbsolutePath());
            }

            Uri uri = getContentResolver().insert(
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

            if (uri != null) {
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) {
                    Toast.makeText(this, "保存失败啦 (｡•́︿•̀｡)", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                currentBitmap.compress(compressFormat, quality, os);
                os.flush();
                os.close();
                Toast.makeText(this, "已保存到相册！", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "保存失败啦 (｡•́︿•̀｡)", Toast.LENGTH_SHORT).show();
            }
            finish();

        } catch (Throwable e) {
            Toast.makeText(this, "保存失败: " + e.toString(), Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}
