package com.sertrt.weifp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CubeLut {

    public String title = "";
    public int size = 0;            // 内部实际尺寸（大图会降采样到 33）
    public int originalSize = 0;    // 文件原始尺寸（显示用）
    public boolean is1D = false;    // 是否由 1D LUT 转换而来

    // DOMAIN 范围（默认 0~1）
    public float domainMinR = 0f, domainMinG = 0f, domainMinB = 0f;
    public float domainMaxR = 1f, domainMaxG = 1f, domainMaxB = 1f;

    // 数据按 (b, g, r) 嵌套，每条 3 个 float（r,g,b）
    public float[] data = null;

    public static CubeLut parse(InputStream is) {
        try {
            CubeLut lut = new CubeLut();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            String line;
            java.util.ArrayList<float[]> rows = new java.util.ArrayList<float[]>();
            int lut1DSize = 0;
            int lut3DSize = 0;

            while ((line = reader.readLine()) != null) {
                // ★ 加固4：清掉 CRLF 的 \r
                line = line.replace("\r", "").trim();
                if (line.length() == 0) continue;
                if (line.startsWith("#")) continue;

                if (line.startsWith("TITLE")) {
                    int q1 = line.indexOf('"');
                    int q2 = line.lastIndexOf('"');
                    if (q1 >= 0 && q2 > q1) lut.title = line.substring(q1 + 1, q2);
                } else if (line.startsWith("LUT_1D_SIZE")) {
                    // ★ 加固1：支持 1D LUT
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 2) {
                        try { lut1DSize = Integer.parseInt(parts[1]); } catch (Throwable ignored) {}
                        lut.is1D = true;
                    }
                } else if (line.startsWith("LUT_3D_SIZE")) {
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 2) {
                        try { lut3DSize = Integer.parseInt(parts[1]); } catch (Throwable ignored) {}
                    }
                } else if (line.startsWith("DOMAIN_MIN")) {
                    // ★ 加固3：DOMAIN 支持
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 4) {
                        try {
                            lut.domainMinR = Float.parseFloat(parts[1]);
                            lut.domainMinG = Float.parseFloat(parts[2]);
                            lut.domainMinB = Float.parseFloat(parts[3]);
                        } catch (Throwable ignored) {}
                    }
                } else if (line.startsWith("DOMAIN_MAX")) {
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 4) {
                        try {
                            lut.domainMaxR = Float.parseFloat(parts[1]);
                            lut.domainMaxG = Float.parseFloat(parts[2]);
                            lut.domainMaxB = Float.parseFloat(parts[3]);
                        } catch (Throwable ignored) {}
                    }
                } else if (lut1DSize > 0 || lut3DSize > 0) {
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 3) {
                        try {
                            float r = Float.parseFloat(parts[0]);
                            float g = Float.parseFloat(parts[1]);
                            float b = Float.parseFloat(parts[2]);
                            rows.add(new float[]{r, g, b});
                        } catch (Throwable ignored) {}
                    }
                }
            }
            reader.close();

            if (lut3DSize > 0) {
                return buildFrom3D(lut, rows, lut3DSize);
            } else if (lut1DSize > 0) {
                return buildFrom1D(lut, rows, lut1DSize);
            }
            return null;
        } catch (Throwable e) {
            return null;
        }
    }

    // 3D 处理：大尺寸降采样到 33
    private static CubeLut buildFrom3D(CubeLut lut, java.util.ArrayList<float[]> rows, int size) {
        if (size < 2) return null;
        int expected = size * size * size;
        if (rows.size() < expected) return null;

        lut.originalSize = size;
        lut.is1D = false;

        int targetSize = size;
        boolean downsample = false;
        if (size > 33) {
            // ★ 加固2：大尺寸降到 33
            targetSize = 33;
            downsample = true;
        }
        lut.size = targetSize;

        if (downsample) {
            lut.data = new float[targetSize * targetSize * targetSize * 3];
            for (int b = 0; b < targetSize; b++) {
                int origB = b * (size - 1) / (targetSize - 1);
                for (int g = 0; g < targetSize; g++) {
                    int origG = g * (size - 1) / (targetSize - 1);
                    for (int r = 0; r < targetSize; r++) {
                        int origR = r * (size - 1) / (targetSize - 1);
                        int origIdx = ((origB * size + origG) * size + origR);
                        int newIdx = ((b * targetSize + g) * targetSize + r) * 3;
                        if (origIdx >= 0 && origIdx < rows.size()) {
                            float[] v = rows.get(origIdx);
                            lut.data[newIdx] = v[0];
                            lut.data[newIdx + 1] = v[1];
                            lut.data[newIdx + 2] = v[2];
                        }
                    }
                }
            }
        } else {
            lut.data = new float[expected * 3];
            int n = Math.min(expected, rows.size());
            for (int i = 0; i < n; i++) {
                float[] v = rows.get(i);
                lut.data[i * 3] = v[0];
                lut.data[i * 3 + 1] = v[1];
                lut.data[i * 3 + 2] = v[2];
            }
        }
        return lut;
    }

    // 1D 转 33³ 3D
    private static CubeLut buildFrom1D(CubeLut lut, java.util.ArrayList<float[]> rows, int size) {
        if (size < 2) return null;
        if (rows.size() < size) return null;

        lut.originalSize = size;
        lut.is1D = true;

        int targetSize = 33;
        lut.size = targetSize;
        lut.data = new float[targetSize * targetSize * targetSize * 3];

        for (int b = 0; b < targetSize; b++) {
            float fb = (float) b / (targetSize - 1);
            int bi = (int)(fb * (size - 1) + 0.5f);
            if (bi >= size) bi = size - 1;
            float outB = rows.get(bi)[2];

            for (int g = 0; g < targetSize; g++) {
                float fg = (float) g / (targetSize - 1);
                int gi = (int)(fg * (size - 1) + 0.5f);
                if (gi >= size) gi = size - 1;
                float outG = rows.get(gi)[1];

                for (int r = 0; r < targetSize; r++) {
                    float fr = (float) r / (targetSize - 1);
                    int ri = (int)(fr * (size - 1) + 0.5f);
                    if (ri >= size) ri = size - 1;
                    float outR = rows.get(ri)[0];

                    int idx = ((b * targetSize + g) * targetSize + r) * 3;
                    lut.data[idx] = outR;
                    lut.data[idx + 1] = outG;
                    lut.data[idx + 2] = outB;
                }
            }
        }
        return lut;
    }

    // 应用单像素：DOMAIN 归一化 + 三线性插值 + 强度混合
    public int applyPixel(int r, int g, int b, float strength) {
        if (size <= 0 || data == null) return (r << 16) | (g << 8) | b;
        if (strength <= 0f) return (r << 16) | (g << 8) | b;

        // ★ 加固3：DOMAIN 归一化
        float fr = (r / 255f - domainMinR) / Math.max(0.0001f, domainMaxR - domainMinR);
        float fg = (g / 255f - domainMinG) / Math.max(0.0001f, domainMaxG - domainMinG);
        float fb = (b / 255f - domainMinB) / Math.max(0.0001f, domainMaxB - domainMinB);
        if (fr < 0) fr = 0; if (fr > 1) fr = 1;
        if (fg < 0) fg = 0; if (fg > 1) fg = 1;
        if (fb < 0) fb = 0; if (fb > 1) fb = 1;

        fr *= (size - 1);
        fg *= (size - 1);
        fb *= (size - 1);

        int r0 = (int) fr; if (r0 >= size - 1) r0 = size - 2;
        int g0 = (int) fg; if (g0 >= size - 1) g0 = size - 2;
        int b0 = (int) fb; if (b0 >= size - 1) b0 = size - 2;

        float dr = fr - r0;
        float dg = fg - g0;
        float db = fb - b0;

        float outR = sample(r0, g0, b0, dr, dg, db, 0);
        float outG = sample(r0, g0, b0, dr, dg, db, 1);
        float outB = sample(r0, g0, b0, dr, dg, db, 2);

        int nr = (int)(r * (1 - strength) + outR * 255f * strength);
        int ng = (int)(g * (1 - strength) + outG * 255f * strength);
        int nb = (int)(b * (1 - strength) + outB * 255f * strength);

        if (nr < 0) nr = 0; if (nr > 255) nr = 255;
        if (ng < 0) ng = 0; if (ng > 255) ng = 255;
        if (nb < 0) nb = 0; if (nb > 255) nb = 255;

        return (nr << 16) | (ng << 8) | nb;
    }

    // 三线性插值采样
    private float sample(int r0, int g0, int b0, float dr, float dg, float db, int ch) {
        float c000 = get(r0, g0, b0, ch);
        float c100 = get(r0 + 1, g0, b0, ch);
        float c010 = get(r0, g0 + 1, b0, ch);
        float c110 = get(r0 + 1, g0 + 1, b0, ch);
        float c001 = get(r0, g0, b0 + 1, ch);
        float c101 = get(r0 + 1, g0, b0 + 1, ch);
        float c011 = get(r0, g0 + 1, b0 + 1, ch);
        float c111 = get(r0 + 1, g0 + 1, b0 + 1, ch);
        float c00 = c000 + (c100 - c000) * dr;
        float c10 = c010 + (c110 - c010) * dr;
        float c01 = c001 + (c101 - c001) * dr;
        float c11 = c011 + (c111 - c011) * dr;
        float c0 = c00 + (c10 - c00) * dg;
        float c1 = c01 + (c11 - c01) * dg;
        return c0 + (c1 - c0) * db;
    }

    private float get(int r, int g, int b, int ch) {
        int idx = ((b * size + g) * size + r) * 3 + ch;
        if (idx < 0 || idx >= data.length) return 0;
        return data[idx];
    }
}
