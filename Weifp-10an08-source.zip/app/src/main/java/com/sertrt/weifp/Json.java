package com.sertrt.weifp;

/**
 * 极简 JSON 取值工具（只处理「对象里取字段」这一种场景）。
 *
 * 不引入第三方库：只需要读 "key": value 这种简单结构，
 * 完整 JSON 解析器会多出几百 KB，不划算。
 */
final class Json {

    private Json() {
    }

    /** 取字符串字段；没有或格式不对返回 null。 */
    static String str(String json, String key) {
        if (json == null || key == null) return null;
        try {
            int k = json.indexOf("\"" + key + "\"");
            if (k < 0) return null;
            int colon = json.indexOf(':', k);
            if (colon < 0) return null;
            int q1 = json.indexOf('"', colon);
            if (q1 < 0) return null;
            StringBuilder sb = new StringBuilder();
            for (int i = q1 + 1; i < json.length(); i++) {
                char c = json.charAt(i);
                if (c == '\\' && i + 1 < json.length()) {
                    char n = json.charAt(i + 1);
                    if (n == 'n') { sb.append('\n'); i++; }
                    else if (n == 't') { sb.append('\t'); i++; }
                    else if (n == 'r') { sb.append('\r'); i++; }
                    else if (n == '"') { sb.append('"'); i++; }
                    else if (n == '\\') { sb.append('\\'); i++; }
                    else if (n == 'u' && i + 5 < json.length()) {
                        try {
                            sb.append((char) Integer.parseInt(
                                    json.substring(i + 2, i + 6), 16));
                            i += 5;
                        } catch (Throwable ignored) {}
                    } else {
                        sb.append(n);
                        i++;
                    }
                } else if (c == '"') {
                    return sb.toString();
                } else {
                    sb.append(c);
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** 取数值字段。 */
    static double num(String json, String key, double def) {
        if (json == null || key == null) return def;
        try {
            int k = json.indexOf("\"" + key + "\"");
            if (k < 0) return def;
            int colon = json.indexOf(':', k);
            if (colon < 0) return def;
            int i = colon + 1;
            while (i < json.length() && Character.isWhitespace(json.charAt(i))) i++;
            int start = i;
            while (i < json.length()) {
                char c = json.charAt(i);
                if (Character.isDigit(c) || c == '-' || c == '+' || c == '.'
                        || c == 'e' || c == 'E') {
                    i++;
                } else {
                    break;
                }
            }
            if (i <= start) return def;
            return Double.parseDouble(json.substring(start, i));
        } catch (Throwable t) {
            return def;
        }
    }

    /** 解析 #RRGGBB / #AARRGGBB 颜色。 */
    static int parseColor(String s) {
        if (s == null) return 0;
        try {
            String t = s.trim();
            if (t.startsWith("#")) t = t.substring(1);
            if (t.length() == 6) {
                return (int) (0xFF000000L | Long.parseLong(t, 16));
            }
            if (t.length() == 8) {
                return (int) Long.parseLong(t, 16);
            }
        } catch (Throwable ignored) {
        }
        return 0;
    }
}
