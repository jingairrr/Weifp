package com.sertrt.weifp;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SplashActivity extends Activity {

    private static final long SPLASH_DELAY = 1500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
       

        SharedPreferences sp = getSharedPreferences("weifp_theme", MODE_PRIVATE);
        String lastShown = sp.getString("last_shown_version", "");

        if (AppVersion.VERSION_NAME.equals(lastShown)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        sp.edit().putString("last_shown_version", AppVersion.VERSION_NAME).apply();

        float density = getResources().getDisplayMetrics().density;
        getWindow().setBackgroundDrawable(new ColorDrawable(ThemeManager.getBgColor(this)));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(ThemeManager.getBgColor(this));

        ImageView logo = new ImageView(this);
        int logoSize = (int)(120 * density);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(logoSize, logoSize);
        logo.setLayoutParams(logoLp);
        logo.setImageResource(R.drawable.ic_launcher);
        root.addView(logo);

        TextView tvName = new TextView(this);
        tvName.setText("Weifp");
        tvName.setTextSize(28);
        tvName.setTextColor(ThemeManager.getTextColor(this));
        tvName.setTypeface(null, android.graphics.Typeface.BOLD);
        tvName.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        nameLp.topMargin = (int)(20 * density);
        tvName.setLayoutParams(nameLp);
        root.addView(tvName);

        TextView tvVersion = new TextView(this);
        tvVersion.setText(AppVersion.VERSION_NAME);
        tvVersion.setTextSize(14);
        tvVersion.setTextColor(0xFFFFB615);
        tvVersion.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams verLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        verLp.topMargin = (int)(8 * density);
        tvVersion.setLayoutParams(verLp);
        root.addView(tvVersion);

        setContentView(root);

        new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(SplashActivity.this, MainActivity.class));
                    finish();
                }
            }, SPLASH_DELAY);
    }
}
