package com.sertrt.weifp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import java.util.Locale;

public class LanguageManager {
    public static final int LANG_SIMPLIFIED = 0; // 简体
    public static final int LANG_TRADITIONAL = 1; // 繁体
    public static final int LANG_ENGLISH = 2; // 英语
    public static final int LANG_CLASSICAL = 99; // 文言文（彩蛋）

    public static void setLanguage(Context context, int langCode) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        sp.edit().putInt("app_language", langCode).commit();
    }

    public static int getLanguage(Context context) {
        SharedPreferences sp = context.getSharedPreferences("weifp_theme", Context.MODE_PRIVATE);
        return sp.getInt("app_language", LANG_SIMPLIFIED);
    }

    public static Context wrap(Context context) {
        int langCode = getLanguage(context);
        Locale locale;
        if (langCode == LANG_TRADITIONAL) {
            locale = Locale.TRADITIONAL_CHINESE;
        } else if (langCode == LANG_ENGLISH) {
            locale = Locale.US;
        } else if (langCode == LANG_CLASSICAL) {
            locale = new Locale("zh", "HK");
        } else {
            locale = Locale.SIMPLIFIED_CHINESE;
        }
        Locale.setDefault(locale);
        Configuration config = new Configuration(context.getResources().getConfiguration());
        config.setLocale(locale);
        return context.createConfigurationContext(config);
    }

    public static String getCurrentLangName(Context context) {
        int lang = getLanguage(context);
        if (lang == LANG_TRADITIONAL) return "繁體中文";
        if (lang == LANG_ENGLISH) return "English (US)";
        if (lang == LANG_CLASSICAL) return "文言文（彩蛋）";
        return "简体中文";
    }

    public static String getString(Context context, int resId) {
        // ★ 只有 99 才去字典里找，找完直接返回
        if (getLanguage(context) == LANG_CLASSICAL) {
            String classical = ClassicalDict.get(resId);
            if (classical != null) return classical;
        }
        return context.getString(resId);
    }

    public static String getString(Context context, int resId, Object... formatArgs) {
        if (getLanguage(context) == LANG_CLASSICAL) {
            String classical = ClassicalDict.get(resId);
            if (classical != null) {
                return String.format(classical, formatArgs);
            }
        }
        return context.getString(resId, formatArgs);
    }
}
