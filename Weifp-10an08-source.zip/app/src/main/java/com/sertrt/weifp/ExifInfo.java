package com.sertrt.weifp;

import android.content.Context;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * EXIF 信息处理：从图片读取元数据并保存到步骤目录的 info.txt。
 *
 * 字段分组参考 Lightroom 的「相机信息」面板：
 *   [相机] 厂商 / 型号 / 镜头
 *   [拍摄] 光圈 / 快门 / ISO / 焦距 / 等效焦距 / 曝光补偿 / 测光 / 闪光 / 白平衡 / 光源
 *   [时间] 时间 / 拍摄时间 / 数字化时间
 *   [图像] 尺寸 / 朝向 / 色彩空间 / 分辨率
 *   [位置] 经纬度 / 海拔（有 GPS 才写）
 *   [软件] 软件 / 作者 / 版权
 *
 * 读取端见 MainActivity.showImageInfoDialog()。
 */
public final class ExifInfo {

    private ExifInfo() {
    }

    /**
     * 读取照片 EXIF 并写入 {@code stepsDir/info.txt}。
     *
     * @param ctx      上下文
     * @param uri      图片 uri
     * @param stepsDir 该图片的步骤目录（不存在会自动创建）
     */
    public static void save(Context ctx, Uri uri, File stepsDir) {
        if (ctx == null || uri == null || stepsDir == null) return;
        InputStream is = null;
        try {
            is = ctx.getContentResolver().openInputStream(uri);
            if (is == null) return;

            android.media.ExifInterface exif = new android.media.ExifInterface(is);
            String unk = LanguageManager.getString(ctx, R.string.str_unknown);

            StringBuilder sb = new StringBuilder();

            // ---- 相机 ----
            sb.append("[相机]\n");
            append(sb, "make", exif, android.media.ExifInterface.TAG_MAKE, unk);
            append(sb, "model", exif, android.media.ExifInterface.TAG_MODEL, unk);
            append(sb, "lens", exif, "LensModel", unk);

            // ---- 拍摄参数 ----
            sb.append("[拍摄]\n");
            // 光圈：优先 FNumber，老文件只有 Aperture
            String ap = attr(exif, "FNumber");
            if (ap == null || ap.trim().length() == 0) {
                ap = attr(exif, android.media.ExifInterface.TAG_APERTURE);
            }
            sb.append("aperture=").append(ap != null && ap.trim().length() > 0
                    ? ap.trim() : unk).append('\n');
            append(sb, "exposure", exif, android.media.ExifInterface.TAG_EXPOSURE_TIME, unk);
            append(sb, "iso", exif, android.media.ExifInterface.TAG_ISO_SPEED_RATINGS, unk);
            append(sb, "focal", exif, android.media.ExifInterface.TAG_FOCAL_LENGTH, unk);
            append(sb, "focal35", exif, "FocalLengthIn35mmFilm", unk);
            append(sb, "exposure_bias", exif,
                    android.media.ExifInterface.TAG_EXPOSURE_BIAS_VALUE, unk);
            append(sb, "metering", exif, android.media.ExifInterface.TAG_METERING_MODE, unk);
            append(sb, "flash", exif, android.media.ExifInterface.TAG_FLASH, unk);
            append(sb, "white_balance", exif, android.media.ExifInterface.TAG_WHITE_BALANCE, unk);
            append(sb, "light_source", exif, android.media.ExifInterface.TAG_LIGHT_SOURCE, unk);

            // ---- 时间 ----
            sb.append("[时间]\n");
            append(sb, "datetime", exif, android.media.ExifInterface.TAG_DATETIME, unk);
            append(sb, "datetime_original", exif,
                    android.media.ExifInterface.TAG_DATETIME_ORIGINAL, unk);
            append(sb, "datetime_digitized", exif,
                    android.media.ExifInterface.TAG_DATETIME_DIGITIZED, unk);

            // ---- 图像 ----
            sb.append("[图像]\n");
            append(sb, "width", exif, android.media.ExifInterface.TAG_IMAGE_WIDTH, "0");
            append(sb, "height", exif, android.media.ExifInterface.TAG_IMAGE_LENGTH, "0");
            append(sb, "orientation", exif, android.media.ExifInterface.TAG_ORIENTATION, unk);
            append(sb, "color_space", exif, android.media.ExifInterface.TAG_COLOR_SPACE, unk);
            append(sb, "x_resolution", exif, android.media.ExifInterface.TAG_X_RESOLUTION, unk);
            append(sb, "y_resolution", exif, android.media.ExifInterface.TAG_Y_RESOLUTION, unk);

            // ---- 位置（有才写）----
            float[] latLong = new float[2];
            if (exif.getLatLong(latLong)) {
                sb.append("[位置]\n");
                sb.append("latitude=").append(latLong[0]).append('\n');
                sb.append("longitude=").append(latLong[1]).append('\n');
                String alt = attr(exif, android.media.ExifInterface.TAG_GPS_ALTITUDE);
                if (alt != null) sb.append("altitude=").append(alt).append('\n');
            }

            // ---- 软件信息 ----
            sb.append("[软件]\n");
            append(sb, "software", exif, android.media.ExifInterface.TAG_SOFTWARE, unk);
            append(sb, "artist", exif, android.media.ExifInterface.TAG_ARTIST, "");
            append(sb, "copyright", exif, android.media.ExifInterface.TAG_COPYRIGHT, "");

            if (!stepsDir.exists()) stepsDir.mkdirs();
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(new File(stepsDir, "info.txt"));
                fos.write(sb.toString().getBytes("UTF-8"));
                fos.flush();
            } finally {
                try { if (fos != null) fos.close(); } catch (Throwable ignored) {}
            }

        } catch (Throwable e) {
            try { CrashLogger.log("EXIF 读取失败", e); } catch (Throwable ignored) {}
        } finally {
            try { if (is != null) is.close(); } catch (Throwable ignored) {}
        }
    }

    private static String attr(android.media.ExifInterface exif, String tag) {
        try {
            return exif.getAttribute(tag);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 追加一条字段；取不到就写 fallback（fallback 为空则跳过）。 */
    private static void append(StringBuilder sb, String key,
                               android.media.ExifInterface exif,
                               String tag, String fallback) {
        String v = attr(exif, tag);
        if (v == null || v.trim().length() == 0) {
            if (fallback == null || fallback.length() == 0) return;
            v = fallback;
        }
        sb.append(key).append('=').append(v.trim()).append('\n');
    }
}
