package com.sertrt.weifp;

import android.content.Context;
import android.os.Build;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 崩溃与异常记录器。
 *
 * 作用：把未捕获异常、以及功能内部捕获到的错误写到本地文件，
 * 出问题时可以直接用文件管理器打开查看，不用连电脑抓 logcat。
 *
 * 位置：Android/data/<包名>/files/crash/weifp_crash.log
 *
 * 设计原则：
 *  - 纯新增，不改动任何现有逻辑。
 *  - 任何写入失败都静默忽略，绝不能因为它自己再崩一次。
 *  - 单文件滚动，超过 512KB 就归档一份，避免无限增大。
 */
public final class CrashLogger {

    private static final String DIR = "crash";
    private static final String FILE = "weifp_crash.log";
    private static final long MAX_BYTES = 512 * 1024;

    private static Context sAppCtx;
    private static volatile boolean sInstalled = false;

    private CrashLogger() {
    }

    /** 在 Application/主 Activity 启动时调用一次即可。 */
    public static void install(Context ctx) {
        if (ctx == null || sInstalled) return;
        sInstalled = true;
        try {
            sAppCtx = ctx.getApplicationContext();
        } catch (Throwable ignored) {
            sAppCtx = ctx;
        }
        try {
            final Thread.UncaughtExceptionHandler prev =
                    Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                @Override public void uncaughtException(Thread t, Throwable e) {
                    try {
                        log("未捕获异常 @线程 " + t.getName(), e);
                    } catch (Throwable ignored) {
                    }
                    if (prev != null) {
                        prev.uncaughtException(t, e);
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    /** 记录一条异常（功能内部捕获到的错误也建议记一下）。 */
    public static void log(String tag, Throwable e) {
        StringBuilder sb = new StringBuilder();
        sb.append("==== ").append(now()).append(" ====\n");
        sb.append("标签: ").append(tag).append('\n');
        sb.append("设备: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
          .append(" / Android ").append(Build.VERSION.RELEASE)
          .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("版本: ").append(AppVersion.VERSION_NAME)
          .append(" (").append(AppVersion.VERSION_CODE).append(")\n");
        if (e != null) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            sb.append(sw.toString()).append('\n');
        }
        sb.append('\n');
        write(sb.toString());
    }

    /** 记录一条普通信息（不带异常）。 */
    public static void logInfo(String tag, String msg) {
        StringBuilder sb = new StringBuilder();
        sb.append("==== ").append(now()).append(" ====\n");
        sb.append("标签: ").append(tag).append('\n');
        sb.append("版本: ").append(AppVersion.VERSION_NAME).append('\n');
        sb.append(msg).append("\n\n");
        write(sb.toString());
    }

    /** 日志文件路径（给"关于/设置"里展示用）。 */
    public static String logPath() {
        try {
            File f = file();
            return f != null ? f.getAbsolutePath() : "";
        } catch (Throwable t) {
            return "";
        }
    }

    /** 清空日志。 */
    public static void clear() {
        try {
            File f = file();
            if (f != null && f.exists()) f.delete();
        } catch (Throwable ignored) {
        }
    }

    // ==================== 内部 ====================

    private static File dir() {
        if (sAppCtx == null) return null;
        try {
            File d = new File(sAppCtx.getExternalFilesDir(null), DIR);
            if (!d.exists() && !d.mkdirs()) return null;
            return d;
        } catch (Throwable t) {
            return null;
        }
    }

    private static File file() {
        File d = dir();
        return d == null ? null : new File(d, FILE);
    }

    private static synchronized void write(String text) {
        try {
            File f = file();
            if (f == null) return;
            // 超过上限就归档，保留上一份
            if (f.exists() && f.length() > MAX_BYTES) {
                File old = new File(f.getParentFile(), FILE + ".old");
                if (old.exists()) old.delete();
                f.renameTo(old);
            }
            FileOutputStream fos = new FileOutputStream(f, true);
            fos.write(text.getBytes("UTF-8"));
            fos.close();
        } catch (Throwable ignored) {
        }
    }

    private static String now() {
        try {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                    .format(new Date());
        } catch (Throwable t) {
            return String.valueOf(System.currentTimeMillis());
        }
    }
}
