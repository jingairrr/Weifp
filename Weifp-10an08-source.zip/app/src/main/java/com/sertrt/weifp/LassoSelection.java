package com.sertrt.weifp;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.List;

/**
 * 套索选区工具（仿 Photoshop 的套索）。
 *
 * 工作流：
 *   1. 手指在画布上画一条闭合路径
 *   2. 路径转换成选区（内部用 Path 做包含判定）
 *   3. 对选区执行：清除 / 填充 / 剪切 / 粘贴
 *
 * 实现要点：
 *  - 用 {@link Path} 的边界 + 逐像素判定，简单可靠（不做扫描线优化，图大了慢一点）
 *  - 选区只记录 Path，操作时才去碰像素，内存开销小
 */
public final class LassoSelection {

    /** 选区路径（画布坐标）。 */
    public final Path path = new Path();
    /** 选区包围盒（画布坐标，整数）。 */
    public final Rect bounds = new Rect();

    private final List<Float> xs = new ArrayList<Float>();
    private final List<Float> ys = new ArrayList<Float>();

    public void reset() {
        path.reset();
        bounds.setEmpty();
        xs.clear();
        ys.clear();
        lastX = Float.NaN;
        lastY = Float.NaN;
    }

    public boolean isEmpty() {
        return xs.size() < 3;
    }

    /** 两点至少隔这么远才记录（画布坐标），避免拖动时产生几千个点。 */
    private static final float MIN_DIST = 2.0f;
    /** 上次记录的点，用于距离判断。 */
    private float lastX = Float.NaN, lastY = Float.NaN;

    /**
     * 加一个点（画布坐标）。
     *
     * 距离太近的会跳过：手指快速拖动时每秒能产生上百个事件，
     * 全记下来的话路径重建和内部判定都会变慢。
     */
    public void addPoint(float x, float y) {
        if (!Float.isNaN(lastX)) {
            float dx = x - lastX, dy = y - lastY;
            if (dx * dx + dy * dy < MIN_DIST * MIN_DIST) return;
        }
        lastX = x;
        lastY = y;
        xs.add(x);
        ys.add(y);
        rebuildPath();
    }

    /**
     * 首尾自动闭合吸附。
     *
     * 用户画圈时很难精确回到起点，抬手时如果终点离起点足够近，
     * 就把终点直接吸到起点上，形成一个干净的闭合形状。
     *
     * @param maxDist 吸附半径（画布坐标）
     * @return true 表示发生了吸附
     */
    public boolean snapClose(float maxDist) {
        int n = xs.size();
        if (n < 4) return false;
        float dx = xs.get(n - 1) - xs.get(0);
        float dy = ys.get(n - 1) - ys.get(0);
        float d2 = dx * dx + dy * dy;
        if (d2 > maxDist * maxDist) return false;
        // 去掉尾部几个点，让路径直接回到起点，避免出现小尾巴和自交
        while (xs.size() > 3) {
            int last = xs.size() - 1;
            float lx = xs.get(last) - xs.get(0);
            float ly = ys.get(last) - ys.get(0);
            if (lx * lx + ly * ly <= maxDist * maxDist) {
                xs.remove(last);
                ys.remove(last);
            } else {
                break;
            }
        }
        rebuildPath();
        return true;
    }

    /** 用已有点重建路径与包围盒。 */
    public void rebuildPath() {
        path.reset();
        if (xs.isEmpty()) {
            bounds.setEmpty();
            return;
        }
        path.moveTo(xs.get(0), ys.get(0));
        for (int i = 1; i < xs.size(); i++) {
            path.lineTo(xs.get(i), ys.get(i));
        }
        path.close();
        buildBounds();
    }

    /** 用已有 Path 设置选区（例如从历史恢复）。 */
    public void setPath(Path p) {
        path.reset();
        if (p != null) path.set(p);
        path.close();
        buildBounds();
    }

    private void buildBounds() {
        RectF rf = new RectF();
        path.computeBounds(rf, true);
        bounds.set((int) Math.floor(rf.left), (int) Math.floor(rf.top),
                (int) Math.ceil(rf.right), (int) Math.ceil(rf.bottom));
        // 裁到合法范围由调用方再处理
    }

    /**
     * 生成抗锯齿遮罩：用 Canvas.drawPath 渲染选区，
     * 边缘会得到 0~255 的平滑 alpha，而不是"在/不在"的硬边。
     *
     * 扫描线栅格化虽然快，但边缘是锯齿状的（每个像素非黑即白），
     * 剪切/清除后边界会有明显台阶。用 Canvas 渲染一遍就平滑了。
     *
     * @return 遮罩位图（ALPHA_8，只有透明度），失败返回 null
     */
    private android.graphics.Bitmap buildAAMask(int l, int t, int r, int b, float scale) {
        int rw = r - l, rh = b - t;
        if (rw <= 0 || rh <= 0) return null;
        try {
            android.graphics.Bitmap mask = android.graphics.Bitmap.createBitmap(
                    rw, rh, android.graphics.Bitmap.Config.ALPHA_8);
            Canvas mc = new Canvas(mask);
            mc.drawColor(android.graphics.Color.TRANSPARENT);
            // 把多边形平移到区域左上角并缩放到位图坐标
            Path sp = new Path(path);
            Matrix m = new Matrix();
            m.postScale(scale, scale);
            m.postTranslate(-l, -t);
            sp.transform(m);
            Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
            pp.setStyle(Paint.Style.FILL);
            pp.setColor(0xFFFFFFFF);
            mc.drawPath(sp, pp);
            return mask;
        } catch (Throwable t2) {
            return null;
        }
    }

    /**
     * 把多边形一次性栅格化成布尔掩码（扫描线填充）。
     *
     * 之前是逐个像素调 contains()，每个像素都要遍历全部顶点，
     * 4000x3000 的图配上几百个点的选区就是几十亿次运算 —— 界面直接卡死。
     * 扫描线只对每一行求交点，复杂度从 O(W*H*P) 降到 O(H*P + 面���像素)。
     *
     * @param l,t,r,b  区域在位图坐标系里的范围
     * @return 选区掩码；失败返回 null。
     *   用 BitSet 而不是 boolean[]：4000x3000 的选区，
     *   boolean[] 要 12MB，BitSet 只要 1.5MB。
     */
    private java.util.BitSet rasterize(int l, int t, int r, int b, float scale) {
        int rw = r - l, rh = b - t;
        if (rw <= 0 || rh <= 0) return null;
        int n = xs.size();
        if (n < 3) return null;

        java.util.BitSet mask = new java.util.BitSet(rw * rh);

        // 顶点先换算到位图坐标
        float[] px = new float[n];
        float[] py = new float[n];
        for (int i = 0; i < n; i++) {
            px[i] = xs.get(i) * scale;
            py[i] = ys.get(i) * scale;
        }

        float[] cross = new float[n];
        for (int y = 0; y < rh; y++) {
            float sy = t + y + 0.5f;          // 取像素中心
            int cnt = 0;
            for (int i = 0, j = n - 1; i < n; j = i++) {
                float yi = py[i], yj = py[j];
                if ((yi > sy) != (yj > sy)) {
                    float xi = px[i], xj = px[j];
                    cross[cnt++] = (xj - xi) * (sy - yi) / (yj - yi) + xi;
                }
            }
            if (cnt < 2) continue;
            java.util.Arrays.sort(cross, 0, cnt);

            int rowOff = y * rw;
            for (int k = 0; k + 1 < cnt; k += 2) {
                int x0 = (int) Math.ceil(cross[k] - 0.5f) - l;
                int x1 = (int) Math.floor(cross[k + 1] - 0.5f) - l;
                if (x0 < 0) x0 = 0;
                if (x1 >= rw) x1 = rw - 1;
                if (x1 >= x0) mask.set(rowOff + x0, rowOff + x1 + 1);
            }
        }
        return mask;
    }

    /**
     * 点是否在选择区内。
     *
     * 自己用「射线法」判断，因为 Path.contains(x,y) 要 API 26+，
     * 本项目 minSdk 19，不能用。
     */
    public boolean contains(float x, float y) {
        if (xs.size() < 3) return false;
        // 先用包围盒快速排除
        if (!bounds.isEmpty()) {
            if (x < bounds.left || x > bounds.right || y < bounds.top || y > bounds.bottom) {
                return false;
            }
        }
        return pointInPolygon(x, y);
    }

    /** 射线法：从点向右发射水平线，数穿过多边形边的次数，奇数在内。 */
    private boolean pointInPolygon(float px, float py) {
        boolean inside = false;
        int n = xs.size();
        for (int i = 0, j = n - 1; i < n; j = i++) {
            float xi = xs.get(i), yi = ys.get(i);
            float xj = xs.get(j), yj = ys.get(j);
            // 边是否跨越 py
            if ((yi > py) != (yj > py)) {
                // 计算交点 x
                float xCross = (xj - xi) * (py - yi) / (yj - yi) + xi;
                if (px < xCross) inside = !inside;
            }
        }
        return inside;
    }

    /**
     * 把选区内的像素清成透明（等同 PS 的 Delete）。
     *
     * @param bmp   目标位图（会被直接修改，需 mutable）
     * @param scale 位图相对画布的缩放（位图尺寸 / 画布尺寸）
     * @return 是否有像素被清除
     */
    public boolean eraseRegion(Bitmap bmp, float scale) {
        if (bmp == null || bmp.isRecycled() || isEmpty()) return false;
        if (!bmp.isMutable()) return false;
        int w = bmp.getWidth(), h = bmp.getHeight();
        int l = Math.max(0, (int) (bounds.left * scale));
        int t = Math.max(0, (int) (bounds.top * scale));
        int r = Math.min(w, (int) Math.ceil(bounds.right * scale));
        int b = Math.min(h, (int) Math.ceil(bounds.bottom * scale));
        if (r <= l || b <= t) return false;

        int rw = r - l, rh = b - t;
        int[] px = new int[rw * rh];
        bmp.getPixels(px, 0, rw, l, t, rw, rh);

        // 用抗锯齿遮罩，得到 0~255 的边缘 alpha 而不是硬边
        android.graphics.Bitmap am = buildAAMask(l, t, r, b, scale);
        if (am == null) return false;
        byte[] aBytes = null;
        try {
            aBytes = new byte[rw * rh];
            am.copyPixelsToBuffer(java.nio.ByteBuffer.wrap(aBytes));
        } catch (Throwable t3) {
            aBytes = null;
        }
        boolean changed = false;
        for (int i = 0; i < px.length; i++) {
            int a8 = aBytes != null ? (aBytes[i] & 0xFF) : 255;
            if (a8 <= 0) continue;
            int c = px[i];
            if (a8 >= 255) {
                px[i] = 0;
            } else {
                // 边缘像素：按遮罩强度部分擦除
                int srcA = (c >>> 24) & 0xFF;
                int newA = srcA * (255 - a8) / 255;
                px[i] = (newA << 24) | (c & 0x00FFFFFF);
            }
            changed = true;
        }
        if (!am.isRecycled()) am.recycle();
        if (changed) bmp.setPixels(px, 0, rw, l, t, rw, rh);
        return changed;
    }

    /**
     * 把选区内像素填成指定颜色（等同 PS 的 Alt+Delete）。
     */
    public boolean fillRegion(Bitmap bmp, float scale, int color) {
        if (bmp == null || bmp.isRecycled() || isEmpty()) return false;
        if (!bmp.isMutable()) return false;
        int w = bmp.getWidth(), h = bmp.getHeight();
        int l = Math.max(0, (int) (bounds.left * scale));
        int t = Math.max(0, (int) (bounds.top * scale));
        int r = Math.min(w, (int) Math.ceil(bounds.right * scale));
        int b = Math.min(h, (int) Math.ceil(bounds.bottom * scale));
        if (r <= l || b <= t) return false;

        int rw = r - l, rh = b - t;
        int[] px = new int[rw * rh];
        bmp.getPixels(px, 0, rw, l, t, rw, rh);

        // 填充也用抗锯齿遮罩，边缘才不会有台阶
        android.graphics.Bitmap am = buildAAMask(l, t, r, b, scale);
        if (am == null) return false;
        byte[] aBytes = null;
        try {
            aBytes = new byte[rw * rh];
            am.copyPixelsToBuffer(java.nio.ByteBuffer.wrap(aBytes));
        } catch (Throwable t3) {
            aBytes = null;
        }
        boolean changed = false;
        int ca = (color >>> 24) & 0xFF;
        int cr = (color >> 16) & 0xFF, cg = (color >> 8) & 0xFF, cb = color & 0xFF;
        for (int i = 0; i < px.length; i++) {
            int a8 = aBytes != null ? (aBytes[i] & 0xFF) : 255;
            if (a8 <= 0) continue;
            if (a8 >= 255) {
                px[i] = color;
            } else {
                // 边缘：和原像素按遮罩强度混合
                int c0 = px[i];
                int r0 = (c0 >> 16) & 0xFF, g0 = (c0 >> 8) & 0xFF, b0 = c0 & 0xFF;
                int nr = (cr * a8 + r0 * (255 - a8)) / 255;
                int ng = (cg * a8 + g0 * (255 - a8)) / 255;
                int nb = (cb * a8 + b0 * (255 - a8)) / 255;
                px[i] = (0xFF << 24) | (nr << 16) | (ng << 8) | nb;
            }
            changed = true;
        }
        if (!am.isRecycled()) am.recycle();
        if (changed) bmp.setPixels(px, 0, rw, l, t, rw, rh);
        return changed;
    }

    /**
     * 把选区内的像素剪切出来（透明 + 返回一张只含选区的位图）。
     *
     * @return 剪出的位图（尺寸 = 包围盒）；失败返回 null
     */
    public Bitmap cutRegion(Bitmap bmp, float scale) {
        if (bmp == null || bmp.isRecycled() || isEmpty()) return null;
        if (!bmp.isMutable()) return null;
        int w = bmp.getWidth(), h = bmp.getHeight();
        int l = Math.max(0, (int) (bounds.left * scale));
        int t = Math.max(0, (int) (bounds.top * scale));
        int r = Math.min(w, (int) Math.ceil(bounds.right * scale));
        int b = Math.min(h, (int) Math.ceil(bounds.bottom * scale));
        if (r <= l || b <= t) return null;

        int rw = r - l, rh = b - t;
        int[] px = new int[rw * rh];
        bmp.getPixels(px, 0, rw, l, t, rw, rh);

        android.graphics.Bitmap am = buildAAMask(l, t, r, b, scale);
        if (am == null) return null;
        // ★ 直接读遮罩的原始字节（ALPHA_8 每像素 1 字节），
        //   不转成 int[]：4000x3000 转成 int[] 就是 48MB，
        //   加上 px[] 和 outPx[] 一共 144MB，大图上直接 OOM。
        java.nio.ByteBuffer abuf = java.nio.ByteBuffer.allocateDirect(0);
        byte[] aBytes = null;
        try {
            aBytes = new byte[rw * rh];
            am.copyPixelsToBuffer(java.nio.ByteBuffer.wrap(aBytes));
        } catch (Throwable t3) {
            aBytes = null;
        }
        int[] outPx = new int[rw * rh];
        boolean any = false;
        for (int i = 0; i < px.length; i++) {
            int a8 = aBytes != null ? (aBytes[i] & 0xFF) : 255;
            if (a8 <= 0) continue;
            int c = px[i];
            int srcA = (c >>> 24) & 0xFF;
            if (a8 >= 255) {
                outPx[i] = c;
                px[i] = 0;
            } else {
                // 边缘：按比例分配 alpha，剪切和原图都能平滑过渡
                int cutA = srcA * a8 / 255;
                int keepA = srcA - cutA;
                outPx[i] = (cutA << 24) | (c & 0x00FFFFFF);
                px[i] = (keepA << 24) | (c & 0x00FFFFFF);
            }
            any = true;
        }
        if (!am.isRecycled()) am.recycle();
        if (!any) return null;
        bmp.setPixels(px, 0, rw, l, t, rw, rh);
        Bitmap out = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
        out.setPixels(outPx, 0, rw, 0, 0, rw, rh);
        return out;
    }

    /** 把剪切出来的内容贴到新位置（覆盖）。 */
    public static boolean pasteAt(Bitmap bmp, Bitmap content, int destX, int destY) {
        if (bmp == null || content == null || bmp.isRecycled() || content.isRecycled()) return false;
        if (!bmp.isMutable()) return false;
        try {
            Canvas c = new Canvas(bmp);
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
            c.drawBitmap(content, destX, destY, p);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 画出选区边界（PS 的蚂蚁线，这里用虚线代替）。 */
    public void drawOutline(Canvas canvas, Paint paint) {
        if (isEmpty()) return;
        canvas.drawPath(path, paint);
    }
}
