package com.sertrt.weifp;

public class AppVersion {
    // ★ 内部版本号，每次发版递增，用户看不见
    // 1000 = 10an00，以后 1001 = 10an01，1100 = 11an00
    public static final int VERSION_CODE = 1007;

    // ★ 用户可见版本号，显示在设置/关于/启动页
    public static final String VERSION_NAME = "10an07";
}
