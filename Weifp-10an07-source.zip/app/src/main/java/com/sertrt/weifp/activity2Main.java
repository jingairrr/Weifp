package com.sertrt.weifp;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Map;

public class activity2Main extends Activity implements ZoomImageView.OnStepListener, ZoomImageView.OnLayerLockedListener {

    @Override
    public void onStepFinished() {
        hasUnsavedChanges = true;
        updateHistogram();
        saveStepImage();
    }

    @Override
    public void onLayerLocked(final int layerIndex) {
        runOnUiThread(new Runnable() {
                @Override public void run() {
                    showLayerLockedDialog(layerIndex);
                }
            });
    }

    private ZoomImageView zoomImage;
    private LinearLayout toolContent;
    private boolean gridSettingOn = false;

    /** 本次编辑是否已经成功保存过一次（用于退出时的判断）。 */
    private boolean isSavedOnce = false;

    // 顶部工具栏按钮（改为字段，供统一初始化与主题刷新使用）
    private android.widget.ImageView btnSaveExit;
    private android.widget.ImageView btnShare;
    private android.widget.ImageView btnRedo;
    private android.widget.ImageView btnUndo;
    private View bottomToolbar;
    private View rootView;
    private HistogramView histogramView;

    private static final int CANVAS_SIZE = 1024;
    private static final int OVERLAY_PAGE_REQUEST = 300;
    private static final int TEXT_OVERLAY_PAGE_REQUEST = 400;
    private static final int CROP_REQUEST = 500;
    private static final int LAYER_IMAGE_PICK_REQUEST = 600;
    private static final int CUBE_LUT_PICK_REQUEST = 700;

    private Button btnBasic, btnAdvanced, btnDraw, btnExport;
    private android.widget.ImageView btnLayers;

    private int drawR = 255, drawG = 0, drawB = 0;
    private View colorPreview;
    private TextView colorInfo;
    private SeekBar seekR, seekG, seekB;
    private EditText etR, etG, etB, etHex;
    private boolean isUpdatingColor = false;

    private boolean hasUnsavedChanges = false;
    private String editFilePath = null;
    private File currentStepsDir;
    private float density;

    private boolean isCurrentImageRaw = false;
    private Uri sourceImageUri = null;

    private String currentLutPath = null;
    private String currentLutName = null;

    private int hslSelectedHue = 0;
    private int cbSelectedArea = 0;
    private int levelsSelectedChannel = 0;

    private Button btnChannelW, btnChannelR, btnChannelG, btnChannelB;

    private String currentTool = "basic";

    // 底部工具栏动画相关
    private TextView btnToggleToolbar;
    private boolean isToolbarExpanded = true;

    private String sep() {
        int lang = LanguageManager.getLanguage(this);
        if (lang == LanguageManager.LANG_ENGLISH) return ": ";
        return "：";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 对齐网格设置
        try {
            boolean gridOn = getSharedPreferences("weifp_theme", MODE_PRIVATE)
                    .getBoolean("grid_on", false);
            // zoomImage 还没创建，稍后在 onCreate 末尾应用
            gridSettingOn = gridOn;
        } catch (Throwable ignored) {}
        // 安装崩溃记录器（写本地文件，方便自查）
        try { CrashLogger.install(this); } catch (Throwable ignored) {}
        // 同步"精致界面"开关
        try {
            UiSpec.setRefined(getSharedPreferences("weifp_theme", MODE_PRIVATE)
                    .getBoolean("ui_refined", true));
        } catch (Throwable ignored) {
        }

        getBaseContext().getResources().updateConfiguration(
            LanguageManager.wrap(this).getResources().getConfiguration(),
            getBaseContext().getResources().getDisplayMetrics()
        );

        setContentView(R.layout.activity2);

        density = getResources().getDisplayMetrics().density;
        rootView = findViewById(android.R.id.content);
        zoomImage = (ZoomImageView) findViewById(R.id.zoom_image);
        toolContent = (LinearLayout) findViewById(R.id.tool_content);
        bottomToolbar = findViewById(R.id.bottom_toolbar);

        bottomToolbar.post(new Runnable() {
            @Override
            public void run() {
                ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) zoomImage.getLayoutParams();
                lp.bottomMargin = bottomToolbar.getHeight(); 
                zoomImage.setLayoutParams(lp);
                zoomImage.post(new Runnable() {
                    @Override
                    public void run() {
                        zoomImage.resetToCenter();
                    }
                });
            }
        });

        btnToggleToolbar = (TextView) findViewById(R.id.btn_toggle_toolbar);
        if (btnToggleToolbar != null) {
            GradientDrawable arrowBg = new GradientDrawable();
            arrowBg.setColor(0xFFFFB615);
            arrowBg.setCornerRadius(8 * density);
            btnToggleToolbar.setBackground(arrowBg);
            
            btnToggleToolbar.post(new Runnable() {
                @Override public void run() {
                    if (bottomToolbar != null && btnToggleToolbar != null) {
                        btnToggleToolbar.setTranslationY(-bottomToolbar.getHeight());
                    }
                }
            });
            
            btnToggleToolbar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    toggleToolbar();
                }
            });
        }

        zoomImage.setOnStepListener(this);
        try { zoomImage.setGridOn(gridSettingOn); } catch (Throwable ignored) {}
        zoomImage.setOnLayerLockedListener(this);

        histogramView = new HistogramView(this);
        FrameLayout.LayoutParams histLp = new FrameLayout.LayoutParams(
            (int)(180 * density), (int)(90 * density));
        histLp.gravity = Gravity.TOP | Gravity.START;
        histLp.setMargins((int)(16 * density), (int)(58 * density), 0, 0);
        histogramView.setLayoutParams(histLp);
        histogramView.setVisibility(View.VISIBLE);
        if (rootView != null) ((ViewGroup) rootView).addView(histogramView);

        Intent intent = getIntent();
        boolean isBlank = intent.getBooleanExtra("is_blank", false);
        isCurrentImageRaw = intent.getBooleanExtra("is_raw", false);

        Uri imageUri = intent.getData();
        editFilePath = intent.getStringExtra("edit_file_path");

        if (editFilePath != null && !editFilePath.isEmpty()) {
            try { MaskPanel.setOwnerPath(editFilePath); } catch (Throwable ignored) {}
            currentStepsDir = HistoryManager.getStepsDir(this, new File(editFilePath).getName());
            SharedPreferences sp = getSharedPreferences("weifp_filters", MODE_PRIVATE);
            isCurrentImageRaw = sp.getBoolean(editFilePath + "_is_raw", isCurrentImageRaw);
        } else {
            currentStepsDir = HistoryManager.getTempStepsDir(this);
        }

        btnBasic = (Button) findViewById(R.id.btn_basic);
        btnAdvanced = (Button) findViewById(R.id.btn_advanced);
        btnDraw = (Button) findViewById(R.id.btn_draw);
        btnExport = (Button) findViewById(R.id.btn_export);

        fixButtonStyle(btnBasic);
        fixButtonStyle(btnAdvanced);
        fixButtonStyle(btnDraw);
        fixButtonStyle(btnExport);

        btnBasic.setBackgroundColor(ThemeManager.getButtonColor(this));
        btnAdvanced.setBackgroundColor(ThemeManager.getButtonColor(this));
        btnDraw.setBackgroundColor(ThemeManager.getButtonColor(this));
        btnExport.setBackgroundColor(ThemeManager.getButtonColor(this));

        btnBasic.setText(LanguageManager.getString(this, R.string.basic));
        btnAdvanced.setText(LanguageManager.getString(this, R.string.advanced));
        btnDraw.setText(LanguageManager.getString(this, R.string.draw));
        btnExport.setText(LanguageManager.getString(this, R.string.export));

        checkRawAndDisableDraw();

        btnBasic.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showBasicTools(); } });
        btnAdvanced.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showAdvancedTools(); } });
        btnDraw.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showDrawTools(); } });
        // 点「导出」标签直接进入导出，不再需要二次点击
        btnExport.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { doExportNow(); } });

        LinearLayout topRightBar = new LinearLayout(this);
        topRightBar.setOrientation(LinearLayout.HORIZONTAL);
        topRightBar.setGravity(Gravity.CENTER_VERTICAL);
        int btnSize = (int) (42 * density);
        int margin = (int) (4 * density);

        // ★ 五个顶部按钮全部由同一个工厂创建，属性完全一致，杜绝高度错位。
        btnLayers = makeTopButton(R.drawable.ic_layers, btnSize, margin);
        btnLayers.setContentDescription(LanguageManager.getString(this, R.string.layer));
        btnLayers.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { showLayersTools(); }
            });
        topRightBar.addView(btnLayers);

        btnSaveExit = makeTopButton(R.drawable.ic_save, btnSize, margin);
        btnSaveExit.setContentDescription(LanguageManager.getString(this, R.string.save));
        btnSaveExit.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { saveAndExit(); }
            });
        topRightBar.addView(btnSaveExit);

        btnShare = makeTopButton(R.drawable.ic_share, btnSize, margin);
        btnShare.setContentDescription(LanguageManager.getString(this, R.string.share));
        btnShare.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { shareCurrent(); }
            });
        topRightBar.addView(btnShare);

        btnRedo = makeTopButton(R.drawable.ic_redo, btnSize, margin);
        btnRedo.setContentDescription(LanguageManager.getString(this, R.string.redo));
        btnRedo.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (zoomImage.redo()) { hasUnsavedChanges = true; updateHistogram(); }
                }
            });
        topRightBar.addView(btnRedo);

        btnUndo = makeTopButton(R.drawable.ic_undo, btnSize, margin);
        btnUndo.setContentDescription(LanguageManager.getString(this, R.string.undo));
        btnUndo.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (zoomImage.undo()) { hasUnsavedChanges = true; updateHistogram(); }
                }
            });
        topRightBar.addView(btnUndo);

        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        barLp.gravity = Gravity.TOP | Gravity.END; barLp.setMargins(0, (int) (8 * density), (int) (8 * density), 0);
        topRightBar.setLayoutParams(barLp);
        if (rootView != null) ((ViewGroup) rootView).addView(topRightBar);

        applyThemeColors();
        showBasicTools();

        loadImage(imageUri, isBlank);

        BackButtonHelper.addBackButton(this, new BackButtonHelper.OnBackListener() {
                @Override public void onBack() { handleBack(); }
            });
    }

    private void toggleToolbar() {
        if (bottomToolbar == null) return;
        float targetY = isToolbarExpanded ? bottomToolbar.getHeight() : 0;
        float arrowTargetY = isToolbarExpanded ? 0 : -bottomToolbar.getHeight();
        
        ObjectAnimator anim = ObjectAnimator.ofFloat(bottomToolbar, "translationY", bottomToolbar.getTranslationY(), targetY);
        anim.setDuration(300); anim.setInterpolator(new LinearInterpolator()); anim.start();
        ObjectAnimator arrowAnim = ObjectAnimator.ofFloat(btnToggleToolbar, "translationY", btnToggleToolbar.getTranslationY(), arrowTargetY);
        arrowAnim.setDuration(300); arrowAnim.setInterpolator(new LinearInterpolator()); arrowAnim.start();
        ObjectAnimator rotateAnim = ObjectAnimator.ofFloat(btnToggleToolbar, "rotation", isToolbarExpanded ? 0f : 180f, isToolbarExpanded ? 180f : 360f);
        rotateAnim.setDuration(300); rotateAnim.setInterpolator(new LinearInterpolator()); rotateAnim.start();

        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) zoomImage.getLayoutParams();
        lp.bottomMargin = isToolbarExpanded ? 0 : bottomToolbar.getHeight();
        zoomImage.setLayoutParams(lp);
        zoomImage.post(new Runnable() { @Override public void run() { zoomImage.resetToCenter(); } });
        isToolbarExpanded = !isToolbarExpanded;
    }

    private void ensureToolbarExpanded() {
        if (!isToolbarExpanded && bottomToolbar != null) {
            ObjectAnimator anim = ObjectAnimator.ofFloat(bottomToolbar, "translationY", bottomToolbar.getTranslationY(), 0f);
            anim.setDuration(300); anim.setInterpolator(new LinearInterpolator()); anim.start();
            ObjectAnimator arrowAnim = ObjectAnimator.ofFloat(btnToggleToolbar, "translationY", btnToggleToolbar.getTranslationY(), -bottomToolbar.getHeight());
            arrowAnim.setDuration(300); arrowAnim.setInterpolator(new LinearInterpolator()); arrowAnim.start();
            ObjectAnimator rotateAnim = ObjectAnimator.ofFloat(btnToggleToolbar, "rotation", 180f, 360f);
            rotateAnim.setDuration(300); rotateAnim.setInterpolator(new LinearInterpolator()); rotateAnim.start();

            ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) zoomImage.getLayoutParams();
            lp.bottomMargin = bottomToolbar.getHeight();
            zoomImage.setLayoutParams(lp);
            zoomImage.post(new Runnable() { @Override public void run() { zoomImage.resetToCenter(); } });
            isToolbarExpanded = true;
        }
    }

    private void fixButtonStyle(Button b) {
        if (b == null) return;
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        // 按钮加粗：参考 HMCLgo，字重是"专业感"最容易被感知的一处
        if (UiSpec.isRefined()) {
            try {
                b.setTypeface(b.getTypeface(), android.graphics.Typeface.BOLD);
            } catch (Throwable ignored) {
            }
        }
    }

    private void fixSeekBarColor(final SeekBar sb) {
        if (sb == null) return;
        try {
            sb.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#FFB615")));
            sb.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#FFB615")));
        } catch (Throwable ignored) {}
        sb.post(new Runnable() {
                @Override public void run() {
                    android.view.ViewGroup.LayoutParams lp = sb.getLayoutParams();
                    if (lp instanceof LinearLayout.LayoutParams) {
                        LinearLayout.LayoutParams llp = (LinearLayout.LayoutParams) lp;
                        int pad = (int)(20 * density);
                        llp.leftMargin = pad;
                        llp.rightMargin = pad;
                        sb.setLayoutParams(llp);
                    }
                }
            });
    }

    /**
     * 对话框/面板的层级背景：surface 层 + 细描边。
     * 与按钮的 button 层形成层次，不再糊成一片。
     */
    private GradientDrawable getPanelLayerBg() {
        int color = ThemeManager.getSurfaceColor(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setColor(color);
        bg.setCornerRadius(UiSpec.dp(this, UiSpec.RADIUS_L));
        if (UiSpec.isRefined()) {
            boolean dark = ThemeManager.isDark(this);
            bg.setStroke(UiSpec.dpi(this, UiSpec.STROKE_WIDTH),
                    dark ? 0x1FFFFFFF : 0x0F000000);
        }
        return bg;
    }

    private GradientDrawable getRoundBg(int color) {
        return getRoundBgCorners(color, 1, 1, 1, 1);
    }

    private GradientDrawable getRoundBgCorners(int color, float tl, float tr, float br, float bl) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setColor(color);
        float r = UiSpec.dp(this, UiSpec.RADIUS_S);
        bg.setCornerRadii(new float[]{
                              tl * r, tl * r,
                              tr * r, tr * r,
                              br * r, br * r,
                              bl * r, bl * r
                          });
        // 细描边：给控件一层清晰边界，视觉上更精致（暗色主题用白色低透明，亮色用黑色低透明）
        if (UiSpec.isRefined()) {
            try {
                boolean dark = ThemeManager.isDark(this);
                int strokeColor = dark ? 0x14FFFFFF : 0x14000000;
                bg.setStroke(UiSpec.dpi(this, UiSpec.STROKE_WIDTH), strokeColor);
            } catch (Throwable ignored) {
            }
        }
        return bg;
    }

    private void showLayerLockedDialog(final int layerIndex) {
        final float d = getResources().getDisplayMetrics().density;
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getPanelLayerBg());
        root.setPadding((int)(20*d), (int)(20*d), (int)(20*d), (int)(10*d));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(LanguageManager.getString(this, R.string.layer_invisible_title));
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        TextView tvMsg = new TextView(this);
        tvMsg.setText(LanguageManager.getString(this, R.string.layer_invisible_msg));
        tvMsg.setTextSize(13);
        tvMsg.setTextColor(ThemeManager.getTextColor(this));
        tvMsg.setGravity(Gravity.CENTER);
        tvMsg.setPadding(0, (int)(15*d), 0, (int)(15*d));
        root.addView(tvMsg);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, (int)(10*d), 0, 0);

        TextView btnCancel = new TextView(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setPadding(0, (int)(12*d), 0, (int)(12*d));
        btnCancel.setBackground(getRoundBg(0xFF555555));
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp1.setMargins(0, 0, (int)(10*d), 0);
        btnCancel.setLayoutParams(lp1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dialog.dismiss(); }
            });
        btnRow.addView(btnCancel);

        TextView btnOk = new TextView(this);
        btnOk.setText(LanguageManager.getString(this, R.string.layer_invisible_fix));
        btnOk.setTextSize(13);
        btnOk.setTextColor(Color.BLACK);
        btnOk.setGravity(Gravity.CENTER);
        btnOk.setPadding(0, (int)(12*d), 0, (int)(12*d));
        btnOk.setBackground(getRoundBg(0xFFFFB615));
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f));
        btnOk.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    LayerManager lm = zoomImage.getLayerManager();
                    if (layerIndex >= 0 && layerIndex < lm.size()) {
                        lm.get(layerIndex).alpha = 255;
                        zoomImage.invalidate();
                        hasUnsavedChanges = true;
                        if (editFilePath != null && !editFilePath.isEmpty()) {
                            SharedPreferences sp = getSharedPreferences("weifp_filters", MODE_PRIVATE);
                            SharedPreferences.Editor ed = sp.edit();
                            String ld = lm.getSerializedString();
                            if (ld != null && ld.length() > 0) ed.putString(editFilePath + "_layer_data", ld);
                            ed.apply();
                        }
                        toast(R.string.opacity_restored);
                    }
                    dialog.dismiss();
                }
            });
        btnRow.addView(btnOk);
        root.addView(btnRow);

        dialog.setContentView(root);
        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.85);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void showCustomDialog(String title, String[] items, final DialogInterface.OnClickListener listener) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getPanelLayerBg());
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(10*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(Gravity.CENTER);
        tvTitle.setPadding(0, 0, 0, (int)(20*density));
        root.addView(tvTitle);

        if (items != null) {
            for (int i = 0; i < items.length; i++) {
                final int index = i;
                TextView tvItem = new TextView(this);
                tvItem.setText(items[i]);
                tvItem.setTextSize(15);
                tvItem.setTextColor(ThemeManager.getTextColor(this));
                tvItem.setGravity(Gravity.CENTER);
                tvItem.setPadding(0, (int)(15*density), 0, (int)(15*density));
                tvItem.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 0, 0, (int)(10*density));
                tvItem.setLayoutParams(lp);
                tvItem.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            if (listener != null) listener.onClick(dialog, index);
                            dialog.dismiss();
                        }
                    });
                root.addView(tvItem);
            }
        }

        TextView btnCancel = new TextView(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setPadding(0, (int)(15*density), 0, (int)(15*density));
        btnCancel.setBackground(getRoundBg(0xFFB61515));
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dialog.dismiss(); }
            });
        root.addView(btnCancel);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dialog.setContentView(sv);

        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.8);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void showCustomPrompt(String title, String msg, View inputView, final DialogInterface.OnClickListener listener) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getPanelLayerBg());
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(10*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        if (msg != null) {
            TextView tvMsg = new TextView(this);
            tvMsg.setText(msg);
            tvMsg.setTextSize(13);
            tvMsg.setTextColor(ThemeManager.getTextColor(this));
            tvMsg.setGravity(Gravity.CENTER);
            tvMsg.setPadding(0, (int)(10*density), 0, (int)(10*density));
            root.addView(tvMsg);
        }
        if (inputView != null) root.addView(inputView);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, (int)(20*density), 0, 0);

        TextView btnCancel = new TextView(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnCancel.setBackground(getRoundBg(0xFF555555));
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp1.setMargins(0, 0, (int)(10*density), 0);
        btnCancel.setLayoutParams(lp1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dialog.dismiss(); }
            });
        btnRow.addView(btnCancel);

        TextView btnOk = new TextView(this);
        btnOk.setText(LanguageManager.getString(this, R.string.confirm));
        btnOk.setTextSize(15);
        btnOk.setTextColor(Color.BLACK);
        btnOk.setGravity(Gravity.CENTER);
        btnOk.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnOk.setBackground(getRoundBg(0xFFFFB615));
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btnOk.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (listener != null) listener.onClick(dialog, 0);
                    dialog.dismiss();
                }
            });
        btnRow.addView(btnOk);

        root.addView(btnRow);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dialog.setContentView(sv);

        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.8);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void checkRawAndDisableDraw() {
        if (btnDraw != null) {
            if (isCurrentImageRaw) {
                btnDraw.setEnabled(false);
                btnDraw.setAlpha(0.4f);
                btnDraw.setText(LanguageManager.getString(this, R.string.draw) + "(RAW)");
            } else {
                btnDraw.setEnabled(true);
                btnDraw.setAlpha(1.0f);
                btnDraw.setText(LanguageManager.getString(this, R.string.draw));
            }
        }
    }

    private Handler saveHandler = new Handler();
    private Runnable saveRunnable = new Runnable() {
        @Override
        public void run() {
            doSaveStepImage();
        }
    };

    /** 步骤图用的压缩格式：API 14+ 用 WEBP 无损，更省时省空间。 */
    /** 步骤图扩展名，与 stepFormat() 对应。 */
    private static String stepExt() {
        return android.os.Build.VERSION.SDK_INT >= 14 ? ".webp" : ".png";
    }

    private static android.graphics.Bitmap.CompressFormat stepFormat() {
        if (android.os.Build.VERSION.SDK_INT >= 14) {
            return android.graphics.Bitmap.CompressFormat.WEBP;
        }
        return android.graphics.Bitmap.CompressFormat.PNG;
    }

    private void saveStepImage() {
        if (!ThemeManager.isStepPerActionEnabled(this)) return;
        saveHandler.removeCallbacks(saveRunnable);
        saveHandler.postDelayed(saveRunnable, 800);
    }

    private void doSaveStepImage() {
        new Thread(new Runnable() {
                @Override
                public void run() {
                    Bitmap bmp = null;
                    try {
                        boolean applyFilter = !ThemeManager.isWpbEnabled(activity2Main.this);
                        bmp = zoomImage.getStepBitmapFromHistory(applyFilter);
                        if (bmp == null) return;

                        if (!currentStepsDir.exists()) currentStepsDir.mkdirs();
                        String name = "step_" + System.currentTimeMillis() + stepExt();
                        // 步骤图只用于撤销预览和列表缩略：超过 1600px 先缩小，
                        // 否则每编辑一次都要压缩一张壁纸级的 PNG，卡在保存上。
                        Bitmap toSave = bmp;
                        final int STEP_MAX = 1080;
                        if (bmp.getWidth() > STEP_MAX || bmp.getHeight() > STEP_MAX) {
                            float f = Math.min((float) STEP_MAX / Math.max(1, bmp.getWidth()),
                                    (float) STEP_MAX / Math.max(1, bmp.getHeight()));
                            int sw = Math.max(1, Math.round(bmp.getWidth() * f));
                            int sh = Math.max(1, Math.round(bmp.getHeight() * f));
                            Bitmap small = Bitmap.createScaledBitmap(bmp, sw, sh, true);
                            if (small != null) toSave = small;
                        }
                        FileOutputStream fos = null;
                        try {
                            fos = new FileOutputStream(new File(currentStepsDir, name));
                            // 步骤图用 WEBP 无损：比 PNG 小且压缩快，同时保留透明
                            toSave.compress(stepFormat(), 100, fos);
                            fos.flush();
                        } finally {
                            // 必须 finally 关闭：compress 抛异常时否则文件句柄泄漏
                            try { if (fos != null) fos.close(); } catch (Throwable ignored) {}
                        }
                        if (toSave != bmp && !toSave.isRecycled()) toSave.recycle();

                        saveStepWpbFor(name);
                        HistoryManager.trimOldSteps(currentStepsDir);
                    } catch (Throwable e) {
                    } finally {
                        if (bmp != null && !bmp.isRecycled()) bmp.recycle();
                    }
                }
            }).start();
    }

    private void saveStepWpbFor(String stepPngName) {
        try {
            String[] pts = zoomImage.getCurvePointStrs();
            zoomImage.getLayerManager().saveLayerBitmaps(currentStepsDir);
            zoomImage.getLayerManager().saveLayerBitmaps(currentStepsDir, stripStepExtLocal(stepPngName));
            String layerData = zoomImage.getLayerManager().getSerializedString();
            HslAdjust hh = zoomImage.getHslAdjust();
            StringBuilder hslSb = new StringBuilder();
            for (int i = 0; i < 8; i++) {
                hslSb.append("hsl_hue_").append(i).append("=").append(hh.hue[i]).append("\n");
                hslSb.append("hsl_sat_").append(i).append("=").append(hh.sat[i]).append("\n");
                hslSb.append("hsl_lum_").append(i).append("=").append(hh.lum[i]).append("\n");
            }
            String hslData = hslSb.toString();

            HistoryManager.saveStepWpb(this, currentStepsDir, stepPngName,
                                       zoomImage.getBrightness(), zoomImage.getContrast(), zoomImage.getSaturation(),
                                       zoomImage.getShadows(), zoomImage.getHighlights(), zoomImage.getTemperature(),
                                       zoomImage.getTint(), zoomImage.getSharpness(),
                                       lutToString(zoomImage.getMasterLUT()), lutToString(zoomImage.getRLUT()),
                                       lutToString(zoomImage.getGLUT()), lutToString(zoomImage.getBLUT()),
                                       pts != null ? pts[0] : null, pts != null ? pts[1] : null,
                                       pts != null ? pts[2] : null, pts != null ? pts[3] : null,
                                       zoomImage.getCropRatio(), isCurrentImageRaw, layerData, hslData);
        } catch (Throwable e) {
            // WPB 写失败会导致下次打开时滤镜参数丢失，必须留痕
            try { CrashLogger.log("WPB保存失败", e); } catch (Throwable ignored) {}
        }
    }

    /** 直方图重算的防抖句柄（62 处调用，拖动时每帧都算会卡）。 */
    private Runnable histRunnable;
    private android.os.Handler histHandler;

    // ==================== 简化工具 ====================

    /** 短 Toast（简写，替代一长串 Toast.makeText(...).show()）。 */
    private void toast(int resId) {
        try {
            Toast.makeText(this, LanguageManager.getString(this, resId),
                    Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {}
    }

    /** 长 Toast（错误提示用，停留更久）。 */
    private void toastLong(int resId) {
        try {
            Toast.makeText(this, LanguageManager.getString(this, resId),
                    Toast.LENGTH_LONG).show();
        } catch (Throwable ignored) {}
    }

    /** 带附加文本的 Toast（如「保存成功：xxx」）。 */
    private void toast(int resId, String extra) {
        try {
            Toast.makeText(this, LanguageManager.getString(this, resId) + extra,
                    Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {}
    }

    private void toastLong(int resId, String extra) {
        try {
            Toast.makeText(this, LanguageManager.getString(this, resId) + extra,
                    Toast.LENGTH_LONG).show();
        } catch (Throwable ignored) {}
    }

    /** 取字符串（简写）。 */
    private String str(int resId) {
        try {
            return LanguageManager.getString(this, resId);
        } catch (Throwable t) {
            return "";
        }
    }

    /** 直方图是否正在后台计算（避免拖滑轨时堆线程）。 */
    private final java.util.concurrent.atomic.AtomicBoolean histBusy =
            new java.util.concurrent.atomic.AtomicBoolean(false);
    /** 计算期间是否又有新变化，等算完要补一次。 */
    private final java.util.concurrent.atomic.AtomicBoolean histPending =
            new java.util.concurrent.atomic.AtomicBoolean(false);

    /** 直方图最小刷新间隔：节流用，不是防抖。 */
    private static final long HIST_MIN_INTERVAL_MS = 80L;
    /** 上次真正开始计算的时间。 */
    private long histLastRun = 0L;

    /**
     * 刷新直方图。
     *
     * 这里必须用「节流」而不是「防抖」：
     *   防抖会在每次事件时取消上一个定时器，拖动滑轨时事件每 16ms 来一次，
     *   定时器就永远轮不到执行，表现为"松手才更新一次"。
     * 节流则是第一个事件立刻算，之后最多每 80ms 算一次，最后一次一定补上。
     */
    private void updateHistogram() {
        if (histogramView == null) return;
        if (histHandler == null) {
            histHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        }
        long now = System.currentTimeMillis();
        long elapsed = now - histLastRun;
        if (elapsed >= HIST_MIN_INTERVAL_MS) {
            histLastRun = now;
            startHistogramWork();
        } else {
            if (histRunnable != null) histHandler.removeCallbacks(histRunnable);
            final long wait = HIST_MIN_INTERVAL_MS - elapsed;
            histRunnable = new Runnable() {
                @Override public void run() {
                    histLastRun = System.currentTimeMillis();
                    startHistogramWork();
                }
            };
            histHandler.postDelayed(histRunnable, wait);
        }
    }

    /** 真正启动一次后台计算。 */
    private void startHistogramWork() {
        if (!histBusy.compareAndSet(false, true)) {
            // 正在算：记一笔，算完补一次，保证最后一次改动不会被丢掉
            histPending.set(true);
            return;
        }
        new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        final Bitmap thumb = zoomImage.getFilteredThumbnail();
                        if (thumb == null) return;
                        if (histogramView == null) return;
                        final int[] data = HistogramView.computeHistogram(thumb);
                        if (data == null) return;
                        if (histHandler == null) return;
                        histHandler.post(new Runnable() {
                                @Override public void run() {
                                    try {
                                        if (histogramView != null) {
                                            histogramView.applyHistogram(data);
                                        }
                                    } catch (Throwable ignored) {}
                                }
                            });
                    } catch (Throwable ignored) {
                    } finally {
                        histBusy.set(false);
                        if (histPending.compareAndSet(true, false)) {
                            if (histHandler != null) {
                                histHandler.post(new Runnable() {
                                        @Override public void run() {
                                            histLastRun = System.currentTimeMillis();
                                            startHistogramWork();
                                        }
                                    });
                            }
                        }
                    }
                }
            }).start();
    }


    @Override protected void onResume() {
        super.onResume();
        if (zoomImage != null) {
            zoomImage.setZoomEnabled(true); // ★ 彻底放开缩放
        }
        applyThemeColors();
        if (histogramView != null) histogramView.setVisibility(ThemeManager.isHistogramEnabled(this) ? View.VISIBLE : View.GONE);
        // 从设置页回来时同步对齐网格开关
        try {
            boolean g = getSharedPreferences("weifp_theme", MODE_PRIVATE)
                    .getBoolean("grid_on", false);
            if (zoomImage != null) zoomImage.setGridOn(g);
        } catch (Throwable ignored) {}
        checkRawAndDisableDraw();
    }

    private void applyThemeColors() {
        int bgColor = ThemeManager.getBgColor(this);
        getWindow().setBackgroundDrawable(new ColorDrawable(bgColor));
        if(rootView != null) rootView.setBackgroundColor(bgColor);
        if(bottomToolbar != null) {
            if (UiSpec.isRefined()) {
                bottomToolbar.setBackgroundColor(ThemeManager.getSurfaceColor(this));
            } else {
                bottomToolbar.setBackgroundColor(ThemeManager.getPanelColor(this));
            }
        }
        if (ThemeManager.isDark(this)) zoomImage.setBackgroundColor(0xFF333333);
        else zoomImage.setBackgroundColor(0xFFBBBBBB);
        updateButtonHighlight(null);
    }

    private Bitmap loadFullResBitmap() {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 1;
        options.inScaled = false;
        options.inDensity = 0;
        options.inTargetDensity = 0;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        options.inMutable = true;

        // ★ 关键：如果底图被像素级改过（抠图/超分），必须用内存里的版本。
        //   以前这里总是从原文件重新解码，导致抠图的透明在保存时全部丢失。
        try {
            if (zoomImage != null && zoomImage.isBasePixelModified()) {
                Bitmap cur = zoomImage.getOriginalBitmapCopy();
                if (cur != null) return cur;
            }
        } catch (Throwable ignored) {
        }

        if (sourceImageUri != null) {
            try {
                ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(sourceImageUri, "r");
                if (pfd != null) {
                    Bitmap b = BitmapFactory.decodeFileDescriptor(pfd.getFileDescriptor(), null, options);
                    pfd.close();
                    if (b != null) return b;
                }
            } catch (Throwable e) {}
            try {
                InputStream is = getContentResolver().openInputStream(sourceImageUri);
                if (is != null) {
                    Bitmap b = BitmapFactory.decodeStream(is, null, options);
                    is.close();
                    if (b != null) return b;
                }
            } catch (Throwable e) {}
        }

        if (editFilePath != null && !editFilePath.isEmpty()) {
            File editFile = new File(editFilePath);
            if (editFile.exists()) {
                Bitmap b = BitmapFactory.decodeFile(editFilePath, options);
                if (b != null) return b;
            }
            File histFile = new File(HistoryManager.getHistoryDir(this), new File(editFilePath).getName());
            if (histFile.exists()) {
                Bitmap b = BitmapFactory.decodeFile(histFile.getAbsolutePath(), options);
                if (b != null) return b;
            }
        }

        try {
            Bitmap fallback = zoomImage.getOriginalBitmapCopy();
            if (fallback != null) return fallback;
        } catch (Throwable e) {}
        return null;
    }

    private void saveAndExit() {
        final LoadingDialog pd = new LoadingDialog(this, LanguageManager.getString(this, R.string.loading_saving));
        pd.show();

        new Thread(new Runnable() {
                @Override public void run() {
                    // ★ 保存基准：底图 + 历史里的几何操作 + 当前图层尺寸。
                    //   不再从原文件重新解码，避免"旋转/裁剪/涂鸦"与基准不符。
                    Bitmap fullBitmap = zoomImage.getSaveBaseBitmap();
                    if (fullBitmap == null) {
                        fullBitmap = loadFullResBitmap();
                    }
                    if (fullBitmap == null) {
                        runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    pd.dismiss();
                                    toastLong(R.string.raw_load_fail);
                                }
                            });
                        return;
                    }

                    final Bitmap mainBmp = zoomImage.renderFullSize(fullBitmap, false, true);
                    // ★ 封面直接从 mainBmp 缩小生成，不再单独走一遍 renderFullSize。
                    //   原来封面要重新 replay + 合并图层 + 应用滤镜，等于把最重的工作做两遍，
                    //   而封面最终只有 ~720px，完全没必要。
                    Bitmap finalCover = null;
                    try {
                        if (mainBmp != null) {
                            int cwB = mainBmp.getWidth(), chB = mainBmp.getHeight();
                            final int COVER_MAX = 720;
                            if (cwB > COVER_MAX || chB > COVER_MAX) {
                                float f = Math.min((float) COVER_MAX / Math.max(1, cwB),
                                        (float) COVER_MAX / Math.max(1, chB));
                                int sw = Math.max(1, Math.round(cwB * f));
                                int sh = Math.max(1, Math.round(chB * f));
                                Bitmap small = Bitmap.createScaledBitmap(mainBmp, sw, sh, true);
                                // 小图再套滤镜：缩放后像素少，滤镜快得多
                                if (small != null) {
                                    finalCover = zoomImage.applyMergedFilters(small);
                                    if (finalCover != small && !small.isRecycled()) small.recycle();
                                }
                            } else {
                                Bitmap cp = mainBmp.copy(Bitmap.Config.ARGB_8888, false);
                                if (cp != null) finalCover = zoomImage.applyMergedFilters(cp);
                                if (finalCover != cp && cp != null && !cp.isRecycled()) cp.recycle();
                            }
                        }
                    } catch (Throwable ignored) {
                    }
                    if (finalCover == null) {
                        finalCover = zoomImage.renderFullSize(fullBitmap, true, true);
                    }

                    if (mainBmp == null) {
                        if (fullBitmap != null && !fullBitmap.isRecycled()) fullBitmap.recycle();
                        runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    pd.dismiss();
                                    toastLong(R.string.render_oom_fail);
                                }
                            });
                        return;
                    }

                    final String newPath = HistoryManager.saveToHistory(activity2Main.this, mainBmp, editFilePath);
                    if (newPath == null) {
                        if (!mainBmp.isRecycled()) mainBmp.recycle();
                        if (fullBitmap != null && !fullBitmap.isRecycled()) fullBitmap.recycle();
                        runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    pd.dismiss();
                                    toast(R.string.save_fail);
                                }
                            });
                        return;
                    }

                    File savedFile = new File(newPath);
                    try {
                        CrashLogger.logInfo("保存诊断",
                            "目标路径: " + newPath
                            + "\n文件存在: " + savedFile.exists()
                            + "\n文件大小: " + savedFile.length()
                            + "\n修改时间: " + savedFile.lastModified()
                            + "\n位图尺寸: " + mainBmp.getWidth() + "x" + mainBmp.getHeight()
                            + "\n原editFilePath: " + editFilePath);
                    } catch (Throwable ignored) {}
                    if (!savedFile.exists() || savedFile.length() < 1024) {
                        savedFile.delete();
                        if (!mainBmp.isRecycled()) mainBmp.recycle();
                        if (fullBitmap != null && !fullBitmap.isRecycled()) fullBitmap.recycle();
                        runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    pd.dismiss();
                                    toastLong(R.string.save_empty_fail);
                                }
                            });
                        return;
                    }

                    if (fullBitmap != null && !fullBitmap.isRecycled()) fullBitmap.recycle();

                    editFilePath = newPath;
                    try { MaskPanel.setOwnerPath(editFilePath); } catch (Throwable ignored) {}
                    // 通知主页刷新（保存不再退出编辑页，主页收不到回调）
                    try { HistoryManager.markNeedsRefresh(); } catch (Throwable ignored) {}

                    if (finalCover != null && !finalCover.isRecycled()) {
                        HistoryManager.saveCoverBitmap(activity2Main.this, newPath, finalCover);
                    }
                    if (finalCover != null && finalCover != mainBmp && !finalCover.isRecycled()) {
                        finalCover.recycle();
                    }

                    final String finalStepName = "step_" + System.currentTimeMillis()
                            + "_final" + stepExt();
                    try {
                        if (!currentStepsDir.exists()) currentStepsDir.mkdirs();
                        FileOutputStream fos = null;
                        try {
                            fos = new FileOutputStream(new File(currentStepsDir, finalStepName));
                            // 和步骤目录其它文件一致用 WEBP，比 PNG 快 2~4 倍
                            mainBmp.compress(stepFormat(), 100, fos);
                            fos.flush();
                        } finally {
                            try { if (fos != null) fos.close(); } catch (Throwable ignored) {}
                        }
                        saveStepWpbFor(finalStepName);
                    } catch (Throwable e) {}

                    // 上面已经写了 finalStepName 这一步，不再重复调 doSaveStepImage()
                    // （那边会重新渲染整图再压一次，等于白做一遍）

                    saveFilterParams();
                    // ★ 兜底：再按"文件名无关"的固定 key 存一份，
                    //   避免路径变化后回读不到（文件名可能被重命名）
                    try {
                        saveFilterParamsToKey("__last_edit__");
                    } catch (Throwable ignored) {}
                    HistoryManager.renameTempSteps(activity2Main.this, currentStepsDir, newPath);
                    // ★ renameTempSteps 会删除临时目录，这里必须把指针切到新位置，
                    //   否则后续保存都会写进一个已不存在的目录，封面/步骤丢失。
                    try {
                        currentStepsDir = HistoryManager.getStepsDir(activity2Main.this,
                                new File(newPath).getName());
                        if (!currentStepsDir.exists()) currentStepsDir.mkdirs();
                    } catch (Throwable ignored) {}

                    try {
                        File legacyBase = new File(getExternalFilesDir(null), "WeifpBase/" + savedFile.getName());
                        if (legacyBase.exists()) legacyBase.delete();
                    } catch (Throwable e) {}

                    if (!mainBmp.isRecycled()) mainBmp.recycle();

                    runOnUiThread(new Runnable() {
                            @Override public void run() {
                                pd.dismiss();
                                hasUnsavedChanges = false;
                                isSavedOnce = true;
                                if (finishBySavePending) {
                                    // 来自"保存并退出"：保存成功后关闭页面
                                    finishBySavePending = false;
                                    finish();
                                    return;
                                }
                                Toast.makeText(activity2Main.this,
                                        LanguageManager.getString(activity2Main.this,
                                                R.string.save_done_stay),
                                        Toast.LENGTH_SHORT).show();
                                // 普通保存：不退出，留在编辑页继续编辑
                            }
                        });
                }
            }).start();
    }

    private void shareCurrent() {
        final LoadingDialog pd = new LoadingDialog(this, LanguageManager.getString(this, R.string.loading_saving));
        pd.show();

        new Thread(new Runnable() {
                @Override public void run() {
                    Bitmap fullBitmap = loadFullResBitmap();
                    if (fullBitmap == null) {
                        runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    pd.dismiss();
                                    toastLong(R.string.share_load_fail);
                                }
                            });
                        return;
                    }

                    Bitmap baked = zoomImage.renderFullSize(fullBitmap, true);
                    if (fullBitmap != null && !fullBitmap.isRecycled()) fullBitmap.recycle();

                    if (baked == null) {
                        runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    pd.dismiss();
                                    toastLong(R.string.share_render_fail);
                                }
                            });
                        return;
                    }

                    final Uri shareUri = saveToGalleryForShare(baked);
                    if (!baked.isRecycled()) baked.recycle();

                    runOnUiThread(new Runnable() {
                            @Override public void run() {
                                pd.dismiss();
                                if (shareUri == null) {
                                    toastLong(R.string.share_save_fail);
                                    return;
                                }
                                try {
                                    Intent share = new Intent(Intent.ACTION_SEND);
                                    share.setType("image/jpeg");
                                    share.putExtra(Intent.EXTRA_STREAM, shareUri);
                                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    startActivity(Intent.createChooser(share, "Share"));
                                } catch (Throwable e) {
                                    toastLong(R.string.share_fail_prefix, e.toString());
                                }
                            }
                        });
                }
            }).start();
    }

    private Uri saveToGalleryForShare(Bitmap bmp) {
        try {
            // ★ 用 PNG 分享：JPEG 不支持透明通道，抠图结果会变白
            String fileName = "Weifp_Share_" + System.currentTimeMillis() + ".png";
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, fileName);
            values.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                values.put("relative_path", android.os.Environment.DIRECTORY_PICTURES + "/Weifp");
            }
            Uri uri = getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;
            java.io.OutputStream os = getContentResolver().openOutputStream(uri);
            if (os == null) return null;
            bmp.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.flush();
            os.close();
            return uri;
        } catch (Throwable e) { return null; }
    }

    /**
     * 返回键 / 退出键处理。
     *
     * 逻辑：保存已经独立成"只保存不退出"，所以这里只在
     *  - 有未保存改动时提示；
     *  - 已保存过且没有新改动时直接退出。
     */
    /** 系统内存紧张：释放所有可重建的缓存。 */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_RUNNING_LOW) {
            try { zoomImage.releaseOptionalCaches(); } catch (Throwable ignored) {}
        }
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        try { zoomImage.releaseOptionalCaches(); } catch (Throwable ignored) {}
    }

    @Override
    protected void onPause() {
        super.onPause();
        // ★ 退出/切后台时把参数（含蒙版）落盘。
        //   没有这个回调，用户不点"保存"就退出，蒙版会全部丢失。
        try {
            if (editFilePath != null && !editFilePath.isEmpty()) {
                saveFilterParams();
            }
        } catch (Throwable ignored) {
        }
    }

    private void handleBack() {
        boolean dirty = hasUnsavedChanges;
        if (!dirty) {
            finish();
            return;
        }
        // 有改动：给两个选项——保存并退出 / 直接丢弃
        showCustomDialog(LanguageManager.getString(this, R.string.unsaved_title),
            new String[]{
                LanguageManager.getString(this, R.string.unsaved_save_exit),
                LanguageManager.getString(this, R.string.unsaved_discard)
            },
            new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if (which == 0) {
                        finishBySavePending = true;   // 必须在保存开始前设置
                        saveAndExit();
                    } else if (which == 1) {
                        finish();
                    }
                }
            });
    }

    /** 标记：这次保存是为了退出，保存完成后要关闭页面。 */
    private boolean finishBySavePending = false;

    @Override public void onBackPressed() { handleBack(); }
    @Override public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (keyCode == android.view.KeyEvent.KEYCODE_BACK) { handleBack(); return true; }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * 图标按钮：矢量图标 + 可选小字，比纯文字按钮省空间、更清晰。
     *
     * @param iconRes 图标资源（VectorDrawable）
     * @param label   小字（传 null 则只有图标）
     */
    /**
     * 顶部工具栏按钮工厂：尺寸、内边距、背景、最小尺寸全部固定，
     * 五个按钮走同一段代码，保证高度与对齐完全一致。
     */
    /**
     * 顶部工具栏按钮：用 ImageView 而非 Button。
     *
     * 之前用 Button + compoundDrawable 放图标，即使 setText("") 也仍占一行文字高度，
     * 图标被挤到上方——这是"所有图标偏上"的真正原因。
     * ImageView 完全没有文字行高问题，图标天然居中。
     */
    private android.widget.ImageView makeTopButton(int iconRes, int sizePx, int marginRight) {
        android.widget.ImageView iv = new android.widget.ImageView(this);
        iv.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
        iv.setPadding(0, 0, 0, 0);
        iv.setBackground(getRoundBg(0xCCFFB615));
        iv.setPadding(0, 0, 0, 0);   // 背景会套回自己的 padding，设完再清一次
        try {
            iv.setImageResource(iconRes);
            try { iv.setColorFilter(Color.BLACK); } catch (Throwable ignored) {}
        } catch (Throwable ignored) {
        }
        iv.setClickable(true);
        iv.setFocusable(true);
        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(sizePx, sizePx);
        lp.setMargins(0, 0, marginRight, 0);
        iv.setLayoutParams(lp);
        return iv;
    }

    /** 顶部工具栏按钮：只显示居中图标（无文字），悬停/无障碍仍能读出名称。 */
    private void applyTopIcon(Button b, int iconRes) {
        if (b == null) return;
        b.setText("");
        try {
            android.graphics.drawable.Drawable d = getResources().getDrawable(iconRes);
            if (d != null) {
                int sz = UiSpec.dpi(this, 20);
                d.setBounds(0, 0, sz, sz);
                try { d.setTint(Color.BLACK); } catch (Throwable ignored) {}
                b.setCompoundDrawables(null, d, null, null);
            }
        } catch (Throwable ignored) {
        }
        // Android 的 Button 默认带 minWidth/minHeight 和左右 padding，
        // 换成图标后这些默认值会让内容偏向一侧，必须全部归零才能居中。
        b.setPadding(0, 0, 0, 0);
        b.setGravity(android.view.Gravity.CENTER);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setIncludeFontPadding(false);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 17) {
                b.setTextAlignment(android.view.View.TEXT_ALIGNMENT_CENTER);
            }
        } catch (Throwable ignored) {
        }
    }

    /**
     * 图标按钮（图标在上，小字在下）。
     *
     * 用 TextView 而非 Button：Button 自带背景内边距和最小高度，
     * 会让图标+文字整体偏上；TextView 的属性完全由这里控制。
     */
    private android.widget.TextView createIconButton(int iconRes, String label) {
        android.widget.TextView tv = new android.widget.TextView(this);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        tv.setIncludeFontPadding(false);
        tv.setTextSize(10);
        tv.setTextColor(ThemeManager.getTextColor(this));
        tv.setMinHeight(0);
        tv.setMinimumHeight(0);
        tv.setMinWidth(0);
        tv.setMinimumWidth(0);
        tv.setSingleLine(false);
        // 图标：上下左右都居中，尺寸 20dp
        try {
            android.graphics.drawable.Drawable d = getResources().getDrawable(iconRes);
            if (d != null) {
                d.setBounds(0, 0, UiSpec.dpi(this, 20), UiSpec.dpi(this, 20));
                try { d.setTint(ThemeManager.getTextColor(this)); } catch (Throwable ignored) {}
                tv.setCompoundDrawables(null, d, null, null);
                tv.setCompoundDrawablePadding(UiSpec.dpi(this, 3));
            }
        } catch (Throwable ignored) {
        }
        if (label != null && label.length() > 0) {
            tv.setText(label);
        } else {
            tv.setText(null);   // null 而不是 ""：空串仍占一行高度
        }
        // 背景最后设，设完再补 padding（背景会覆盖内边距）
        tv.setBackground(UiSpec.pressable(this, ThemeManager.getButtonColor(this),
                UiSpec.RADIUS_S));
        int ph = UiSpec.dpi(this, 2);
        int pv = UiSpec.dpi(this, 8);
        tv.setPadding(ph, pv, ph, pv);
        tv.setClickable(true);
        return tv;
    }

    /** 预设色块视图与其颜色（用于按当前画笔颜色高亮） */
    private final java.util.List<android.widget.FrameLayout> swatchViews =
            new java.util.ArrayList<android.widget.FrameLayout>();
    private final java.util.List<Integer> swatchColors = new java.util.ArrayList<Integer>();

    /**
     * 按当前画笔颜色的 16 进制值刷新预设色块选中态。
     * 用户自选的、不在预设里的颜色 -> 所有预设都不高亮。
     */
    private void updateSwatchSelection() {
        int cur = Color.rgb(drawR, drawG, drawB) | 0xFF000000;
        for (int i = 0; i < swatchViews.size() && i < swatchColors.size(); i++) {
            android.widget.FrameLayout v = swatchViews.get(i);
            int c = swatchColors.get(i) | 0xFF000000;
            v.setBackground((c == cur) ? ringDrawable() : null);
        }
    }

    /** 色块选中的橙色外环。 */
    private GradientDrawable ringDrawable() {
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(Color.TRANSPARENT);
        ring.setStroke(UiSpec.dpi(this, 2), UiSpec.ACCENT);
        return ring;
    }

    private Button createToolButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        // 按下变暗的反馈（参考 HMCLgo 的做法）：所有工具按钮统一手感
        b.setBackground(UiSpec.pressable(this, ThemeManager.getButtonColor(this),
                UiSpec.RADIUS_S));
        b.setTextColor(ThemeManager.getTextColor(this));
        fixButtonStyle(b);
        return b;
    }

    private void updateButtonHighlight(Button selected) {
        int orange = UiSpec.ACCENT;
        int normalText = ThemeManager.getTextColor(this);
        boolean dark = ThemeManager.isDark(this);
        Button[] allButtons = {btnBasic, btnAdvanced, btnDraw, btnExport};
        for (Button b : allButtons) {
            if (b == null) continue;
            boolean on = (b == selected);
            // 四大金刚键保持"方形 + 连在一起"：不加圆角、不加胶囊。
            // 选中用实心橙，未选中用按钮底色；按下时变暗一点算反馈。
            int base = on ? orange : ThemeManager.getButtonColor(this);
            if (UiSpec.isRefined()) {
                b.setBackground(UiSpec.pressableSquare(base));
            } else {
                b.setBackgroundColor(base);
            }
            b.setTextColor(on ? Color.BLACK : normalText);
        }
    }


    private void showBasicTools() {
        // 离开蒙版面板：无条件收尾（此时 currentTool 还可能是 "mask"，不能拿它判断）
        try {
            zoomImage.setMaskIndicatorLocked(false);
            zoomImage.setMaskIndicatorVisible(false, -1);
            zoomImage.hideMaskIndicator();
            zoomImage.setMaskBrushMode(false, -1, 0, 0, false);
            zoomImage.setMaskDragMode(false, -1);
            zoomImage.setMaskInteracting(false);
            zoomImage.setMaskIndicatorHideTemporarily(false);
            MaskPanel.commitSession(zoomImage);
        } catch (Throwable ignored) {}
        currentTool = "basic";
        ensureToolbarExpanded();
        updateButtonHighlight(btnBasic);
        zoomImage.setZoomEnabled(true);
        zoomImage.setDrawMode(false);
        toolContent.removeAllViews();
        scrollToolsToTop();

        int gap = (int)(4 * density);
        int rowGap = (int)(6 * density);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(0, (int)(8*density), 0, (int)(8*density));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setLayoutParams(new LinearLayout.LayoutParams(
                                 LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        android.widget.TextView btnRotate = createIconButton(R.drawable.ic_rotate90,
                LanguageManager.getString(this, R.string.rotate_90));
        
        btnRotate.setLayoutParams(makeWeightLp(gap, rowGap));
        btnRotate.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { zoomImage.rotate90(); hasUnsavedChanges = true; updateHistogram(); saveStepImage(); } });
        row1.addView(btnRotate);

        android.widget.TextView btnFlipH = createIconButton(R.drawable.ic_flip_h,
                LanguageManager.getString(this, R.string.flip_horizontal));
        
        btnFlipH.setLayoutParams(makeWeightLp(gap, rowGap));
        btnFlipH.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { zoomImage.flipHorizontal(); hasUnsavedChanges = true; updateHistogram(); saveStepImage(); } });
        row1.addView(btnFlipH);

        android.widget.TextView btnFlipV = createIconButton(R.drawable.ic_flip_v,
                LanguageManager.getString(this, R.string.flip_vertical));
        
        btnFlipV.setLayoutParams(makeWeightLp(gap, rowGap));
        btnFlipV.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { zoomImage.flipVertical(); hasUnsavedChanges = true; updateHistogram(); saveStepImage(); } });
        row1.addView(btnFlipV);

        android.widget.TextView btnResize = createIconButton(R.drawable.ic_resize,
                LanguageManager.getString(this, R.string.adjust_size));
        
        btnResize.setLayoutParams(makeWeightLp(gap, rowGap));
        btnResize.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showResizeDialog(); } });
        row1.addView(btnResize);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setLayoutParams(new LinearLayout.LayoutParams(
                                 LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        android.widget.TextView btnCrop = createIconButton(R.drawable.ic_crop,
                LanguageManager.getString(this, R.string.crop));
        
        btnCrop.setLayoutParams(makeWeightLp(gap, rowGap));
        btnCrop.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Bitmap current = zoomImage.getFinalBitmapFromHistory(false);
                    if (current == null) {
                        toast(R.string.crop_no_image);
                        return;
                    }
                    try {
                        java.io.File cacheFile = new java.io.File(getCacheDir(), "crop_base.png");
                        java.io.FileOutputStream fos = new java.io.FileOutputStream(cacheFile);
                        current.compress(stepFormat(), 100, fos); fos.close();
                        Intent intent = new Intent(activity2Main.this, CropActivity.class);
                        intent.setData(Uri.fromFile(cacheFile));
                        startActivityForResult(intent, CROP_REQUEST);
                    } catch (Throwable e) {
                        toastLong(R.string.crop_start_fail, e.toString());
                    }
                }
            });
        row2.addView(btnCrop);

        android.widget.TextView btnOverlay = createIconButton(R.drawable.ic_overlay_image,
                LanguageManager.getString(this, R.string.overlay_image));
        
        btnOverlay.setLayoutParams(makeWeightLp(gap, rowGap));
        btnOverlay.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Bitmap current = zoomImage.getFinalBitmapFromHistory(true); if (current == null) return;
                    try {
                        java.io.File cacheFile = new java.io.File(getCacheDir(), "base_temp.png");
                        java.io.FileOutputStream fos = new java.io.FileOutputStream(cacheFile);
                        current.compress(stepFormat(), 100, fos); fos.close();
                        Intent intent = new Intent(activity2Main.this, overlayActivity.class);
                        intent.setData(Uri.fromFile(cacheFile)); startActivityForResult(intent, OVERLAY_PAGE_REQUEST);
                    } catch (Throwable e) {}
                }
            });
        row2.addView(btnOverlay);

        android.widget.TextView btnText = createIconButton(R.drawable.ic_overlay_text,
                LanguageManager.getString(this, R.string.overlay_text));
        
        btnText.setLayoutParams(makeWeightLp(gap, rowGap));
        btnText.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Bitmap current = zoomImage.getFinalBitmapFromHistory(true); if (current == null) return;
                    try {
                        java.io.File cacheFile = new java.io.File(getCacheDir(), "base_temp.png");
                        java.io.FileOutputStream fos = new java.io.FileOutputStream(cacheFile);
                        current.compress(stepFormat(), 100, fos); fos.close();
                        Intent intent = new Intent(activity2Main.this, textOverlayActivity.class);
                        intent.setData(Uri.fromFile(cacheFile)); startActivityForResult(intent, TEXT_OVERLAY_PAGE_REQUEST);
                    } catch (Throwable e) {}
                }
            });
        row2.addView(btnText);

        android.widget.TextView btnResetView = createIconButton(R.drawable.ic_reset_view,
                LanguageManager.getString(this, R.string.reset_view));
        
        btnResetView.setLayoutParams(makeWeightLp(gap, rowGap));
        btnResetView.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { zoomImage.resetToCenter(); } });
        row2.addView(btnResetView);

        android.widget.TextView btnSuperRes = createIconButton(R.drawable.ic_superres,
                LanguageManager.getString(this, R.string.super_res_title));
        btnSuperRes.setTextSize(11);
        btnSuperRes.setLayoutParams(makeWeightLp(gap, rowGap));
        btnSuperRes.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openSuperRes(); }
            });
        row2.addView(btnSuperRes);

        container.addView(row1);
        container.addView(row2);
        toolContent.addView(container);
    }

    /**
     * 把工具栏滚回顶部。
     *
     * toolContent 外面套着一个 220dp 的 ScrollView，切换工具只清空内容
     * 不会重置滚动位置，用户会看到"面板跑到下面去了"。
     */
    private void scrollToolsToTop() {
        try {
            if (toolContent == null) return;
            final View parent = (View) toolContent.getParent();
            if (!(parent instanceof ScrollView)) return;
            final ScrollView sv = (ScrollView) parent;
            sv.scrollTo(0, 0);
            // 新内容布局完成后滚动范围才确定，这时再滚一次。
            // 不用 fullScroll()：它会让子视图抢焦点，页面会"往里缩一点"，
            // 表现为切换工具后整体下移。直接 scrollTo(0,0) 没有这个副作用。
            parent.post(new Runnable() {
                    @Override public void run() {
                        try { sv.scrollTo(0, 0); } catch (Throwable ignored) {}
                    }
                });
        } catch (Throwable ignored) {}
    }

    /** 打开局部蒙版面板。 */
    private void openMaskPanel() {
        zoomImage.setDrawMode(false);
        updateButtonHighlight(btnAdvanced);
        toolContent.removeAllViews();
        scrollToolsToTop();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        if (currentTool != null && "mask".equals(currentTool)) {
            // 已经在蒙版面板
        }
        currentTool = "mask";
        MaskPanel.resetSelection();
        MaskPanel.setOwnerPath(editFilePath);
        MaskPanel.build(this, zoomImage, box, new MaskPanel.Callback() {
                @Override public void onMaskChanged() {
                    hasUnsavedChanges = true;
                    updateHistogram();
                }
            });
        toolContent.addView(box);
    }

    /** 色度抠图：一次性动作，作用在当前图层，可撤销。 */
    private void openChromaKey() {
        // 关键：退出绘制模式，否则吸管点画布会被画笔拦截
        zoomImage.setDrawMode(false);
        zoomImage.setZoomEnabled(false);
        ChromaKeyPanel.show(this, zoomImage, new ChromaKeyPanel.Callback() {
                @Override public void onApplied() {
                    hasUnsavedChanges = true;
                    updateHistogram();
                    saveStepImage();
                    zoomImage.setZoomEnabled(true);
                    showDrawTools();
                }
            });
        zoomImage.postDelayed(new Runnable() {
            @Override public void run() { zoomImage.setZoomEnabled(true); }
        }, 300);
    }

    /** 超分放大：一次性动作，用户点了才执行，默认不开启。 */
    private void openSuperRes() {
        SuperResFeature.show(this, zoomImage, new SuperResFeature.Callback() {
                @Override public void onApplied(Bitmap result, double scale) {
                    hasUnsavedChanges = true;
                    updateHistogram();
                    saveStepImage();
                    showBasicTools();
                }
            }, isCurrentImageRaw ? sourceImageUri : null, new SuperResFeature.HistoryHandler() {
                @Override public void onDocumentResized(int oldW, int oldH, int newW, int newH) {
                    handleResizeForHistory(oldW, oldH, newW, newH);
                }
            });
    }

    /**
     * 超分改变尺寸后，按 WPB 开关状态处理历史存档。
     *
     *  · 每步存档关闭 —— 本来就不存步骤，什么都不做；
     *  · WPB 开启 —— 旧步骤 PNG 是不含滤镜的原始像素，靠 WPB 参数还原。
     *    尺寸变了以后旧 PNG 对不上新画布，所以**归档到子目录**（不删除，可找回），
     *    再为新尺寸打一个基准步骤，并记下新旧尺寸。
     *  · WPB 关闭 —— 旧步骤 PNG 是烘焙好的像素，同样尺寸对不上，归档处理。
     *
     * 原则：只归档、不删除；不碰图层文件。
     */
    private void handleResizeForHistory(int oldW, int oldH, int newW, int newH) {
        if (!ThemeManager.isStepPerActionEnabled(this)) {
            return;
        }
        boolean wpbOn = ThemeManager.isWpbEnabled(this);
        try {
            if (currentStepsDir != null && currentStepsDir.exists()) {
                File archive = new File(currentStepsDir,
                        "pre_superres_" + oldW + "x" + oldH);
                if (!archive.exists()) archive.mkdirs();
                File[] files = currentStepsDir.listFiles();
                if (files != null) {
                    for (File f : files) {
                        if (f.isDirectory()) continue;
                        String n = f.getName();
                        boolean isStep = n.startsWith("step_");
                        boolean isWpb = n.endsWith(".wpb");
                        if (!isStep && !isWpb) continue;
                        // 图层文件（layer_*.png）保持不动
                        if (n.contains("_layer_") || n.startsWith("layer_")) continue;
                        File dest = new File(archive, n);
                        if (dest.exists()) dest.delete();
                        f.renameTo(dest);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        if (wpbOn && editFilePath != null && !editFilePath.isEmpty()) {
            try {
                SharedPreferences sp = getSharedPreferences("weifp_filters", MODE_PRIVATE);
                sp.edit()
                    .putInt(editFilePath + "_doc_w", newW)
                    .putInt(editFilePath + "_doc_h", newH)
                    .putInt(editFilePath + "_doc_w_before_sr", oldW)
                    .putInt(editFilePath + "_doc_h_before_sr", oldH)
                    .commit();
            } catch (Throwable ignored) {
            }
        }
        try {
            doSaveStepImage();
        } catch (Throwable ignored) {
        }
    }

    private LinearLayout.LayoutParams makeWeightLp(int hGap, int vGap) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(hGap, 0, hGap, vGap);
        return lp;
    }

    private void showResizeDialog() {
        int curW = CANVAS_SIZE, curH = CANVAS_SIZE;
        if (zoomImage.getDrawable() != null) {
            int iw = zoomImage.getDrawable().getIntrinsicWidth();
            int ih = zoomImage.getDrawable().getIntrinsicHeight();
            if (iw > 0) curW = iw;
            if (ih > 0) curH = ih;
        }

        int textColor = ThemeManager.getTextColor(this);

        final EditText inputW = new EditText(this);
        inputW.setHint("W");
        inputW.setInputType(InputType.TYPE_CLASS_NUMBER);
        inputW.setText(String.valueOf(curW));
        inputW.setTextColor(textColor);

        final EditText inputH = new EditText(this);
        inputH.setHint("H");
        inputH.setInputType(InputType.TYPE_CLASS_NUMBER);
        inputH.setText(String.valueOf(curH));
        inputH.setTextColor(textColor);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(inputW);
        layout.addView(inputH);

        showCustomPrompt(LanguageManager.getString(this, R.string.adjust_size), null, layout, new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    try {
                        int w = Integer.parseInt(inputW.getText().toString().trim());
                        int h = Integer.parseInt(inputH.getText().toString().trim());
                        if (w <= 0 || h <= 0) {
                            toast(R.string.resize_invalid);
                            return;
                        }
                        int cw = CANVAS_SIZE, ch = CANVAS_SIZE;
                        if (zoomImage.getDrawable() != null) {
                            int iw = zoomImage.getDrawable().getIntrinsicWidth();
                            int ih = zoomImage.getDrawable().getIntrinsicHeight();
                            if (iw > 0) cw = iw;
                            if (ih > 0) ch = ih;
                        }
                        if (w == cw && h == ch) return;

                        zoomImage.resizeBitmap(w, h);
                        hasUnsavedChanges = true;
                        updateHistogram();
                        saveStepImage();
                    } catch (Throwable e) {
                        toast(R.string.resize_invalid_number);
                    }
                }
            });
    }

    private void showAdvancedTools() {
        // 离开蒙版面板：无条件收尾（此时 currentTool 还可能是 "mask"，不能拿它判断）
        try {
            zoomImage.setMaskIndicatorLocked(false);
            zoomImage.setMaskIndicatorVisible(false, -1);
            zoomImage.hideMaskIndicator();
            zoomImage.setMaskBrushMode(false, -1, 0, 0, false);
            zoomImage.setMaskDragMode(false, -1);
            zoomImage.setMaskInteracting(false);
            zoomImage.setMaskIndicatorHideTemporarily(false);
            MaskPanel.commitSession(zoomImage);
        } catch (Throwable ignored) {}
        currentTool = "advanced";
        ensureToolbarExpanded();
        updateButtonHighlight(btnAdvanced); 
        zoomImage.setZoomEnabled(true); 
        zoomImage.setDrawMode(false); 
        zoomImage.resetToCenter(); 
        toolContent.removeAllViews();
        scrollToolsToTop();
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);

        addSeekBarRow(list, LanguageManager.getString(this, R.string.brightness), -100, 100, (int) zoomImage.getBrightness(), new OnSeekBarChangeListener() { @Override public void onProgressChanged(int value) { zoomImage.setBrightness(value); hasUnsavedChanges = true; updateHistogram(); } });
        addSeekBarRow(list, LanguageManager.getString(this, R.string.contrast), 0, 200, (int) (zoomImage.getContrast() * 100), new OnSeekBarChangeListener() { @Override public void onProgressChanged(int value) { zoomImage.setContrast(value / 100f); hasUnsavedChanges = true; updateHistogram(); } });
        addSeekBarRow(list, LanguageManager.getString(this, R.string.saturation), 0, 200, (int) (zoomImage.getSaturation() * 100), new OnSeekBarChangeListener() { @Override public void onProgressChanged(int value) { zoomImage.setSaturation(value / 100f); hasUnsavedChanges = true; updateHistogram(); } });
        addSeekBarRow(list, LanguageManager.getString(this, R.string.shadows), -100, 100, (int) zoomImage.getShadows(), new OnSeekBarChangeListener() { @Override public void onProgressChanged(int value) { zoomImage.setShadows(value); hasUnsavedChanges = true; updateHistogram(); } });
        addSeekBarRow(list, LanguageManager.getString(this, R.string.highlights), -100, 100, (int) zoomImage.getHighlights(), new OnSeekBarChangeListener() { @Override public void onProgressChanged(int value) { zoomImage.setHighlights(value); hasUnsavedChanges = true; updateHistogram(); } });
        addSeekBarRow(list, LanguageManager.getString(this, R.string.temperature), -100, 100, (int) zoomImage.getTemperature(), new OnSeekBarChangeListener() { @Override public void onProgressChanged(int value) { zoomImage.setTemperature(value); hasUnsavedChanges = true; updateHistogram(); } });
        addSeekBarRow(list, LanguageManager.getString(this, R.string.tint), -100, 100, (int) zoomImage.getTint(), new OnSeekBarChangeListener() { @Override public void onProgressChanged(int value) { zoomImage.setTint(value); hasUnsavedChanges = true; updateHistogram(); } });
        addSeekBarRow(list, LanguageManager.getString(this, R.string.sharpness), 0, 100, (int) (zoomImage.getSharpness() * 100), new OnSeekBarChangeListener() { @Override public void onProgressChanged(int value) { zoomImage.setSharpness(value / 100f); hasUnsavedChanges = true; updateHistogram(); } });

        Button btnMask = createToolButton(LanguageManager.getString(this, R.string.mask_title));
        btnMask.setBackground(getRoundBg(0xFFFFB615));
        btnMask.setTextColor(Color.BLACK);
        btnMask.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openMaskPanel(); }
            });
        list.addView(btnMask);

        Button btnOneKeyDenoise = createToolButton(LanguageManager.getString(this, R.string.denoise));
        btnOneKeyDenoise.setBackground(getRoundBg(0xFFFFB615)); 
        btnOneKeyDenoise.setTextColor(Color.BLACK);
        btnOneKeyDenoise.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final LoadingDialog pd = new LoadingDialog(activity2Main.this, LanguageManager.getString(activity2Main.this, R.string.denoise) + "...");
                pd.show();
                zoomImage.applyExtremeDenoise(new ZoomImageView.OnNoiseProgressListener() {
                    @Override public void onProgress(int percent) {}
                    @Override public void onFinished(Bitmap result) {
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                pd.dismiss();
                                updateHistogram();
                                Toast.makeText(activity2Main.this,
                                        LanguageManager.getString(activity2Main.this,
                                            R.string.str_done), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
            }
        });
        list.addView(btnOneKeyDenoise);

        final TextView tvColorNoise = new TextView(this);
        tvColorNoise.setText(LanguageManager.getString(this, R.string.noise_color_title) + sep() + (int) zoomImage.getColorNoise());
        tvColorNoise.setTextColor(ThemeManager.getTextColor(this));
        tvColorNoise.setPadding(0, 20, 0, 5);
        list.addView(tvColorNoise);
        SeekBar sbColorNoise = new SeekBar(this);
        sbColorNoise.setMax(100);
        sbColorNoise.setProgress((int) zoomImage.getColorNoise());
        fixSeekBarColor(sbColorNoise);
        sbColorNoise.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    zoomImage.setNoiseLivePreview(p, zoomImage.getLumaNoise());
                    tvColorNoise.setText(LanguageManager.getString(activity2Main.this, R.string.noise_color_title) + sep() + p);
                    hasUnsavedChanges = true;
                    updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) { zoomImage.setNoisePreviewStart(); }
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.setNoisePreviewEnd(); zoomImage.commitNoise(); updateHistogram(); saveStepImage(); }
            });
        list.addView(sbColorNoise);

        final TextView tvLumaNoise = new TextView(this);
        tvLumaNoise.setText(LanguageManager.getString(this, R.string.noise_luma_title) + sep() + (int) zoomImage.getLumaNoise());
        tvLumaNoise.setTextColor(ThemeManager.getTextColor(this));
        tvLumaNoise.setPadding(0, 20, 0, 5);
        list.addView(tvLumaNoise);
        SeekBar sbLumaNoise = new SeekBar(this);
        sbLumaNoise.setMax(100);
        sbLumaNoise.setProgress((int) zoomImage.getLumaNoise());
        fixSeekBarColor(sbLumaNoise);
        sbLumaNoise.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    zoomImage.setNoiseLivePreview(zoomImage.getColorNoise(), p);
                    tvLumaNoise.setText(LanguageManager.getString(activity2Main.this, R.string.noise_luma_title) + sep() + p);
                    hasUnsavedChanges = true;
                    updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) { zoomImage.setNoisePreviewStart(); }
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.setNoisePreviewEnd(); zoomImage.commitNoise(); updateHistogram(); saveStepImage(); }
            });
        list.addView(sbLumaNoise);

        TextView tvCurveTitle = new TextView(this);
        tvCurveTitle.setText(LanguageManager.getString(this, R.string.curve));
        tvCurveTitle.setTextColor(ThemeManager.getTextColor(this));
        tvCurveTitle.setPadding(0, 30, 0, 10);
        list.addView(tvCurveTitle);

        LinearLayout curveContainer = new LinearLayout(this);
        curveContainer.setOrientation(LinearLayout.HORIZONTAL);
        curveContainer.setGravity(Gravity.CENTER_VERTICAL);

        final CurveView curveView = new CurveView(this);
        LinearLayout.LayoutParams curveLp = new LinearLayout.LayoutParams(
            (int)(240 * density), (int)(240 * density));
        curveView.setLayoutParams(curveLp);

        String[] pStrs = zoomImage.getCurvePointStrs();
        if (pStrs != null && pStrs[0] != null) curveView.setChannelPointsFromString(0, pStrs[0]);
        else if (zoomImage.getMasterLUT() != null) curveView.setChannelLUT(0, zoomImage.getMasterLUT());
        if (pStrs != null && pStrs[1] != null) curveView.setChannelPointsFromString(1, pStrs[1]);
        else if (zoomImage.getRLUT() != null) curveView.setChannelLUT(1, zoomImage.getRLUT());
        if (pStrs != null && pStrs[2] != null) curveView.setChannelPointsFromString(2, pStrs[2]);
        else if (zoomImage.getGLUT() != null) curveView.setChannelLUT(2, zoomImage.getGLUT());
        if (pStrs != null && pStrs[3] != null) curveView.setChannelPointsFromString(3, pStrs[3]);
        else if (zoomImage.getBLUT() != null) curveView.setChannelLUT(3, zoomImage.getBLUT());

        LinearLayout btnLayout = new LinearLayout(this);
        btnLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams btnLayoutLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, (int)(240 * density));
        btnLayoutLp.setMargins((int)(8 * density), 0, 0, 0);
        btnLayout.setLayoutParams(btnLayoutLp);
        btnLayout.setGravity(Gravity.CENTER_VERTICAL);

        int btnW = (int)(64 * density);
        int btnH = (int)(42 * density);
        int btnMargin = (int)(6 * density);

        btnChannelW = new Button(this); btnChannelW.setText("RGB"); btnChannelW.setTextColor(Color.BLACK); btnChannelW.setBackground(getRoundBg(Color.WHITE));
        fixButtonStyle(btnChannelW);
        btnChannelW.setLayoutParams(new LinearLayout.LayoutParams(btnW, btnH));
        btnChannelW.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchChannel(0, curveView); } });
        btnLayout.addView(btnChannelW);

        btnChannelR = new Button(this); btnChannelR.setText("R"); btnChannelR.setTextColor(Color.BLACK); btnChannelR.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
        fixButtonStyle(btnChannelR);
        LinearLayout.LayoutParams lpR = new LinearLayout.LayoutParams(btnW, btnH); lpR.setMargins(0, btnMargin, 0, 0);
        btnChannelR.setLayoutParams(lpR);
        btnChannelR.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchChannel(1, curveView); } });
        btnLayout.addView(btnChannelR);

        btnChannelG = new Button(this); btnChannelG.setText("G"); btnChannelG.setTextColor(Color.BLACK); btnChannelG.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
        fixButtonStyle(btnChannelG);
        LinearLayout.LayoutParams lpG = new LinearLayout.LayoutParams(btnW, btnH); lpG.setMargins(0, btnMargin, 0, 0);
        btnChannelG.setLayoutParams(lpG);
        btnChannelG.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchChannel(2, curveView); } });
        btnLayout.addView(btnChannelG);

        btnChannelB = new Button(this); btnChannelB.setText("B"); btnChannelB.setTextColor(Color.BLACK); btnChannelB.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
        fixButtonStyle(btnChannelB);
        LinearLayout.LayoutParams lpB2 = new LinearLayout.LayoutParams(btnW, btnH); lpB2.setMargins(0, btnMargin, 0, 0);
        btnChannelB.setLayoutParams(lpB2);
        btnChannelB.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchChannel(3, curveView); } });
        btnLayout.addView(btnChannelB);

        Button btnResetCurve = new Button(this); btnResetCurve.setText(LanguageManager.getString(this, R.string.reset)); btnResetCurve.setTextColor(Color.WHITE); btnResetCurve.setBackground(getRoundBg(0xFF444444));
        fixButtonStyle(btnResetCurve);
        LinearLayout.LayoutParams lpReset = new LinearLayout.LayoutParams(btnW, btnH); lpReset.setMargins(0, btnMargin, 0, 0);
        btnResetCurve.setLayoutParams(lpReset);
        btnResetCurve.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    curveView.resetAll();
                    zoomImage.clearLUTs();
                    updateHistogram();
                    hasUnsavedChanges = true;
                }
            });
        btnLayout.addView(btnResetCurve);

        curveContainer.addView(curveView);
        curveContainer.addView(btnLayout);
        list.addView(curveContainer);

        curveView.setOnCurveChangedListener(new CurveView.OnCurveChangedListener() {
                @Override public void onCurveChanged(int[] m, int[] r, int[] g, int[] b, String[] pts) {
                    zoomImage.setPreviewLUTs(m, r, g, b, pts);
                    updateHistogram();
                    hasUnsavedChanges = true;
                }
                @Override public void onCurveFinished(int[] m, int[] r, int[] g, int[] b, String[] pts) {
                    zoomImage.setRGBLUTs(m, r, g, b, pts);
                    updateHistogram();
                    saveStepImage();
                }
            });

        addLevelsTools(list);

        final TextView tvVib = new TextView(this);
        tvVib.setText(LanguageManager.getString(this, R.string.vibrance) + sep() + (int) zoomImage.getVibrance());
        tvVib.setTextColor(ThemeManager.getTextColor(this));
        tvVib.setPadding(0, 30, 0, 5);
        list.addView(tvVib);
        SeekBar sbVib = new SeekBar(this);
        sbVib.setMax(200);
        sbVib.setProgress((int)(zoomImage.getVibrance() + 100));
        fixSeekBarColor(sbVib);
        sbVib.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    float v = p - 100;
                    zoomImage.setVibrance(v);
                    tvVib.setText(LanguageManager.getString(activity2Main.this, R.string.vibrance) + sep() + (int)v);
                    hasUnsavedChanges = true;
                    updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.commitFilter(); saveStepImage(); }
            });
        list.addView(sbVib);

        TextView tvCbTitle = new TextView(this);
        tvCbTitle.setText(LanguageManager.getString(this, R.string.wb_title));
        tvCbTitle.setTextColor(ThemeManager.getTextColor(this));
        tvCbTitle.setPadding(0, 30, 0, 10);
        list.addView(tvCbTitle);

        LinearLayout wbRow = new LinearLayout(this);
        wbRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] wbNames = {
            LanguageManager.getString(this, R.string.wb_daylight),
            LanguageManager.getString(this, R.string.wb_cloudy),
            LanguageManager.getString(this, R.string.wb_tungsten),
            LanguageManager.getString(this, R.string.wb_fluorescent)
        };
        final int[][] wbVals = {{0,0}, {20,5}, {-40,0}, {-15,20}};
        for (int i = 0; i < 4; i++) {
            Button btnWb = new Button(this);
            btnWb.setText(wbNames[i]);
            btnWb.setTextSize(11);
            btnWb.setTextColor(Color.BLACK);
            btnWb.setBackground(getRoundBg(0xFFDDDDDD));
            fixButtonStyle(btnWb);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int)(36*density), 1f);
            lp.setMargins(2, 0, 2, 10);
            btnWb.setLayoutParams(lp);
            final int idx = i;
            btnWb.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        zoomImage.setTemperature(wbVals[idx][0]);
                        zoomImage.setTint(wbVals[idx][1]);
                        zoomImage.commitFilter();
                        hasUnsavedChanges = true; updateHistogram(); showAdvancedTools();
                        toast(R.string.wb_preset_applied);
                    }
                });
            wbRow.addView(btnWb);
        }
        list.addView(wbRow);

        LinearLayout cbAreaRow = new LinearLayout(this);
        cbAreaRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] areaNames = {
            LanguageManager.getString(this, R.string.cb_shadows),
            LanguageManager.getString(this, R.string.cb_mids),
            LanguageManager.getString(this, R.string.cb_highlights)
        };
        for (int i = 0; i < 3; i++) {
            Button btnArea = new Button(this);
            btnArea.setText(areaNames[i]);
            btnArea.setTextSize(12);
            fixButtonStyle(btnArea);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int)(36*density), 1f);
            lp.setMargins(2, 0, 2, 10);
            btnArea.setLayoutParams(lp);
            if (i == cbSelectedArea) {
                btnArea.setBackground(getRoundBg(0xFFFFB615));
                btnArea.setTextColor(Color.BLACK);
            } else {
                btnArea.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
                btnArea.setTextColor(ThemeManager.getTextColor(this));
            }
            final int aIdx = i;
            btnArea.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { cbSelectedArea = aIdx; showAdvancedTools(); }
                });
            cbAreaRow.addView(btnArea);
        }
        list.addView(cbAreaRow);

        int curS = cbSelectedArea;
        float cr = 0, cg = 0, cb = 0;
        if (curS == 0) { cr = zoomImage.getCbShadowR(); cg = zoomImage.getCbShadowG(); cb = zoomImage.getCbShadowB(); }
        else if (curS == 1) { cr = zoomImage.getCbMidR(); cg = zoomImage.getCbMidG(); cb = zoomImage.getCbMidB(); }
        else if (curS == 2) { cr = zoomImage.getCbHighR(); cg = zoomImage.getCbHighG(); cb = zoomImage.getCbHighB(); }

        addCbSeekRow(list, LanguageManager.getString(this, R.string.cb_cyan_red), (int)cr, new OnSeekBarChangeListener() {
                @Override public void onProgressChanged(int value) { updateCbVal(0, value); hasUnsavedChanges = true; updateHistogram(); }
            });
        addCbSeekRow(list, LanguageManager.getString(this, R.string.cb_magenta_green), (int)cg, new OnSeekBarChangeListener() {
                @Override public void onProgressChanged(int value) { updateCbVal(1, value); hasUnsavedChanges = true; updateHistogram(); }
            });
        addCbSeekRow(list, LanguageManager.getString(this, R.string.cb_yellow_blue), (int)cb, new OnSeekBarChangeListener() {
                @Override public void onProgressChanged(int value) { updateCbVal(2, value); hasUnsavedChanges = true; updateHistogram(); }
            });

        TextView tvSplitTitle = new TextView(this);
        tvSplitTitle.setText(LanguageManager.getString(this, R.string.split_toning));
        tvSplitTitle.setTextColor(ThemeManager.getTextColor(this));
        tvSplitTitle.setPadding(0, 30, 0, 10);
        list.addView(tvSplitTitle);

        final SplitToning st = zoomImage.getSplitToning();

        final TextView tvStSHue = new TextView(this);
        tvStSHue.setText(LanguageManager.getString(this, R.string.split_shadow_hue) + sep() + (int)st.shadowHue);
        tvStSHue.setTextColor(ThemeManager.getTextColor(this));
        tvStSHue.setPadding(0, 8, 0, 5);
        list.addView(tvStSHue);
        SeekBar sbStSHue = new SeekBar(this);
        sbStSHue.setMax(360); sbStSHue.setProgress((int)st.shadowHue);
        fixSeekBarColor(sbStSHue);
        sbStSHue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    zoomImage.setSplitShadowHue(p);
                    tvStSHue.setText(LanguageManager.getString(activity2Main.this, R.string.split_shadow_hue) + sep() + p);
                    hasUnsavedChanges = true; updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.commitFilter(); saveStepImage(); }
            });
        list.addView(sbStSHue);

        final TextView tvStSSat = new TextView(this);
        tvStSSat.setText(LanguageManager.getString(this, R.string.split_shadow_sat) + sep() + (int)st.shadowSat);
        tvStSSat.setTextColor(ThemeManager.getTextColor(this));
        tvStSSat.setPadding(0, 8, 0, 5);
        list.addView(tvStSSat);
        SeekBar sbStSSat = new SeekBar(this);
        sbStSSat.setMax(100); sbStSSat.setProgress((int)st.shadowSat);
        fixSeekBarColor(sbStSSat);
        sbStSSat.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    zoomImage.setSplitShadowSat(p);
                    tvStSSat.setText(LanguageManager.getString(activity2Main.this, R.string.split_shadow_sat) + sep() + p);
                    hasUnsavedChanges = true; updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.commitFilter(); saveStepImage(); }
            });
        list.addView(sbStSSat);

        final TextView tvStHHue = new TextView(this);
        tvStHHue.setText(LanguageManager.getString(this, R.string.split_highlight_hue) + sep() + (int)st.highlightHue);
        tvStHHue.setTextColor(ThemeManager.getTextColor(this));
        tvStHHue.setPadding(0, 8, 0, 5);
        list.addView(tvStHHue);
        SeekBar sbStHHue = new SeekBar(this);
        sbStHHue.setMax(360); sbStHHue.setProgress((int)st.highlightHue);
        fixSeekBarColor(sbStHHue);
        sbStHHue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    zoomImage.setSplitHighlightHue(p);
                    tvStHHue.setText(LanguageManager.getString(activity2Main.this, R.string.split_highlight_hue) + sep() + p);
                    hasUnsavedChanges = true; updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.commitFilter(); saveStepImage(); }
            });
        list.addView(sbStHHue);

        final TextView tvStHSat = new TextView(this);
        tvStHSat.setText(LanguageManager.getString(this, R.string.split_highlight_sat) + sep() + (int)st.highlightSat);
        tvStHSat.setTextColor(ThemeManager.getTextColor(this));
        tvStHSat.setPadding(0, 8, 0, 5);
        list.addView(tvStHSat);
        SeekBar sbStHSat = new SeekBar(this);
        sbStHSat.setMax(100); sbStHSat.setProgress((int)st.highlightSat);
        fixSeekBarColor(sbStHSat);
        sbStHSat.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    zoomImage.setSplitHighlightSat(p);
                    tvStHSat.setText(LanguageManager.getString(activity2Main.this, R.string.split_highlight_sat) + sep() + p);
                    hasUnsavedChanges = true; updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.commitFilter(); saveStepImage(); }
            });
        list.addView(sbStHSat);

        final TextView tvStBal = new TextView(this);
        tvStBal.setText(LanguageManager.getString(this, R.string.split_balance) + sep() + st.balance);
        tvStBal.setTextColor(ThemeManager.getTextColor(this));
        tvStBal.setPadding(0, 8, 0, 5);
        list.addView(tvStBal);
        SeekBar sbStBal = new SeekBar(this);
        sbStBal.setMax(200); sbStBal.setProgress(st.balance + 100);
        fixSeekBarColor(sbStBal);
        sbStBal.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    int v = p - 100;
                    zoomImage.setSplitBalance(v);
                    tvStBal.setText(LanguageManager.getString(activity2Main.this, R.string.split_balance) + sep() + v);
                    hasUnsavedChanges = true; updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.commitFilter(); saveStepImage(); }
            });
        list.addView(sbStBal);

        Button btnResetSplit = createToolButton(LanguageManager.getString(this, R.string.reset));
        btnResetSplit.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    zoomImage.resetSplitToning();
                    updateHistogram(); hasUnsavedChanges = true; showAdvancedTools();
                }
            });
        list.addView(btnResetSplit);

        TextView tvHslTitle = new TextView(this);
        tvHslTitle.setText(LanguageManager.getString(this, R.string.hsl));
        tvHslTitle.setTextColor(ThemeManager.getTextColor(this));
        tvHslTitle.setPadding(0, 30, 0, 10);
        list.addView(tvHslTitle);

        final Button[] hslHueButtons = new Button[8];
        LinearLayout hslHueRow = new LinearLayout(this);
        hslHueRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int hi = 0; hi < 8; hi++) {
            final int hIdx = hi;
            Button hb = new Button(this);
            hb.setText(HslAdjust.HUE_NAMES[hi]);
            hb.setTextSize(11); hb.setPadding(0, 0, 0, 0);
            fixButtonStyle(hb);
            LinearLayout.LayoutParams hLp = new LinearLayout.LayoutParams(0, (int)(40 * density), 1f);
            hLp.setMargins(2, 0, 2, 0); hb.setLayoutParams(hLp);
            hb.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { hslSelectedHue = hIdx; showAdvancedTools(); }
                });
            hslHueButtons[hi] = hb;
            hslHueRow.addView(hb);
        }
        list.addView(hslHueRow);

        final HslAdjust ha = zoomImage.getHslAdjust();
        for (int hi = 0; hi < 8; hi++) {
            if (hi == hslSelectedHue) {
                hslHueButtons[hi].setBackground(getRoundBg(0xFFFFB615));
                hslHueButtons[hi].setTextColor(Color.BLACK);
            } else {
                hslHueButtons[hi].setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
                hslHueButtons[hi].setTextColor(ThemeManager.getTextColor(this));
            }
        }

        final int curHue = hslSelectedHue;
        final TextView tvHslHue = new TextView(this);
        tvHslHue.setText(LanguageManager.getString(this, R.string.hsl_hue_shift) + sep() + (int)ha.hue[curHue]);
        tvHslHue.setTextColor(ThemeManager.getTextColor(this));
        tvHslHue.setPadding(0, 12, 0, 5);
        list.addView(tvHslHue);
        SeekBar sbHslHue = new SeekBar(this);
        sbHslHue.setMax(360); sbHslHue.setProgress((int)(ha.hue[curHue] + 180));
        fixSeekBarColor(sbHslHue);
        sbHslHue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    float v = p - 180;
                    zoomImage.setHslLivePreview(curHue, v, 0);
                    tvHslHue.setText(LanguageManager.getString(activity2Main.this, R.string.hsl_hue_shift) + sep() + (int)v);
                    hasUnsavedChanges = true; updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) { zoomImage.setHslPreviewStart(); }
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.setHslPreviewEnd(); zoomImage.commitFilterAndRefresh(); updateHistogram(); saveStepImage(); }
            });
        list.addView(sbHslHue);

        final TextView tvHslSat = new TextView(this);
        tvHslSat.setText(LanguageManager.getString(this, R.string.hsl_sat_label) + sep() + (int)ha.sat[curHue]);
        tvHslSat.setTextColor(ThemeManager.getTextColor(this));
        tvHslSat.setPadding(0, 12, 0, 5);
        list.addView(tvHslSat);
        SeekBar sbHslSat = new SeekBar(this);
        sbHslSat.setMax(200); sbHslSat.setProgress((int)(ha.sat[curHue] + 100));
        fixSeekBarColor(sbHslSat);
        sbHslSat.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    float v = p - 100;
                    zoomImage.setHslLivePreview(curHue, v, 1);
                    tvHslSat.setText(LanguageManager.getString(activity2Main.this, R.string.hsl_sat_label) + sep() + (int)v);
                    hasUnsavedChanges = true; updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) { zoomImage.setHslPreviewStart(); }
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.setHslPreviewEnd(); zoomImage.commitFilterAndRefresh(); updateHistogram(); saveStepImage(); }
            });
        list.addView(sbHslSat);

        final TextView tvHslLum = new TextView(this);
        tvHslLum.setText(LanguageManager.getString(this, R.string.hsl_lum_label) + sep() + (int)ha.lum[curHue]);
        tvHslLum.setTextColor(ThemeManager.getTextColor(this));
        tvHslLum.setPadding(0, 12, 0, 5);
        list.addView(tvHslLum);
        SeekBar sbHslLum = new SeekBar(this);
        sbHslLum.setMax(200); sbHslLum.setProgress((int)(ha.lum[curHue] + 100));
        fixSeekBarColor(sbHslLum);
        sbHslLum.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    float v = p - 100;
                    zoomImage.setHslLivePreview(curHue, v, 2);
                    tvHslLum.setText(LanguageManager.getString(activity2Main.this, R.string.hsl_lum_label) + sep() + (int)v);
                    hasUnsavedChanges = true; updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) { zoomImage.setHslPreviewStart(); }
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.setHslPreviewEnd(); zoomImage.commitFilterAndRefresh(); updateHistogram(); saveStepImage(); }
            });
        list.addView(sbHslLum);

        Button btnResetHsl = createToolButton(LanguageManager.getString(this, R.string.reset_hsl_btn));
        btnResetHsl.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    zoomImage.resetHsl(); updateHistogram(); hasUnsavedChanges = true; showAdvancedTools();
                }
            });
        list.addView(btnResetHsl);

        TextView tvCubeTitle = new TextView(this);
        tvCubeTitle.setText(LanguageManager.getString(this, R.string.cube_lut));
        tvCubeTitle.setTextColor(ThemeManager.getTextColor(this));
        tvCubeTitle.setPadding(0, 30, 0, 10);
        list.addView(tvCubeTitle);

        LinearLayout cubeRow = new LinearLayout(this);
        cubeRow.setOrientation(LinearLayout.HORIZONTAL);
        cubeRow.setGravity(Gravity.CENTER_VERTICAL);

        Button btnImportCube = createToolButton(LanguageManager.getString(this, R.string.cube_import));
        btnImportCube.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("*/*");
                    startActivityForResult(intent, CUBE_LUT_PICK_REQUEST);
                }
            });
        cubeRow.addView(btnImportCube);

        TextView tvCubeName = new TextView(this);
        tvCubeName.setText(currentLutName != null ? currentLutName : "-");
        tvCubeName.setTextColor(ThemeManager.getTextColor(this));
        tvCubeName.setTextSize(12); tvCubeName.setSingleLine(true);
        tvCubeName.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams lpCubeName = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lpCubeName.setMargins(8, 0, 8, 0); tvCubeName.setLayoutParams(lpCubeName);
        cubeRow.addView(tvCubeName);

        Button btnClearCube = createToolButton("X");
        btnClearCube.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    zoomImage.clearCubeLut();
                    currentLutPath = null; currentLutName = null;
                    hasUnsavedChanges = true; updateHistogram(); showAdvancedTools();
                }
            });
        cubeRow.addView(btnClearCube);
        list.addView(cubeRow);

        final TextView tvCubeStr = new TextView(this);
        tvCubeStr.setText(LanguageManager.getString(this, R.string.cube_strength_label) + sep() + (int)(zoomImage.getCubeStrength() * 100) + "%");
        tvCubeStr.setTextColor(ThemeManager.getTextColor(this));
        tvCubeStr.setPadding(0, 12, 0, 5);
        list.addView(tvCubeStr);
        SeekBar cubeSeek = new SeekBar(this);
        cubeSeek.setMax(100); cubeSeek.setProgress((int)(zoomImage.getCubeStrength() * 100));
        fixSeekBarColor(cubeSeek);
        cubeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    zoomImage.setCubeStrength(progress / 100f);
                    tvCubeStr.setText(LanguageManager.getString(activity2Main.this, R.string.cube_strength_label) + sep() + progress + "%");
                    hasUnsavedChanges = true; updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) { zoomImage.commitFilter(); saveStepImage(); }
            });
        list.addView(cubeSeek);

        Button btnReset = createToolButton(LanguageManager.getString(this, R.string.reset));
        btnReset.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { zoomImage.resetFilters(); updateHistogram(); showAdvancedTools(); saveStepImage(); } });
        list.addView(btnReset);

        LinearLayout presetRow = new LinearLayout(this);
        presetRow.setOrientation(LinearLayout.HORIZONTAL);

        Button btnSavePreset = createToolButton(LanguageManager.getString(this, R.string.preset_save_btn));
        btnSavePreset.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showSavePresetDialog(); } });
        presetRow.addView(btnSavePreset);

        Button btnApplyPreset = createToolButton(LanguageManager.getString(this, R.string.preset_apply_btn));
        btnApplyPreset.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showApplyPresetDialog(); } });
        presetRow.addView(btnApplyPreset);

        list.addView(presetRow);

        toolContent.addView(list);
    }

    private void addLevelsTools(LinearLayout list) {
        TextView tvLevelsTitle = new TextView(this);
        tvLevelsTitle.setText(LanguageManager.getString(this, R.string.levels_title));
        tvLevelsTitle.setTextColor(ThemeManager.getTextColor(this));
        tvLevelsTitle.setPadding(0, 30, 0, 10);
        list.addView(tvLevelsTitle);

        LinearLayout levelsChRow = new LinearLayout(this);
        levelsChRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] lvChNames = {"RGB", "R", "G", "B"};
        int[] lvChColors = {Color.WHITE, Color.RED, Color.GREEN, Color.BLUE};
        for (int lci = 0; lci < 4; lci++) {
            final int chIdx = lci;
            Button chBtn = new Button(this);
            chBtn.setText(lvChNames[lci]);
            chBtn.setTextSize(12);
            fixButtonStyle(chBtn);
            LinearLayout.LayoutParams chLp = new LinearLayout.LayoutParams(0, (int)(40*density), 1f);
            chLp.setMargins(2, 0, 2, 10);
            chBtn.setLayoutParams(chLp);
            if (lci == levelsSelectedChannel) {
                chBtn.setBackground(getRoundBg(lvChColors[lci]));
                chBtn.setTextColor(lci == 3 ? Color.WHITE : Color.BLACK);
            } else {
                chBtn.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
                chBtn.setTextColor(ThemeManager.getTextColor(this));
            }
            chBtn.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { levelsSelectedChannel = chIdx; showAdvancedTools(); }
                });
            levelsChRow.addView(chBtn);
        }
        list.addView(levelsChRow);

        final int lvCh = levelsSelectedChannel;

        final TextView tvLvBlack = new TextView(this);
        tvLvBlack.setText(LanguageManager.getString(this, R.string.levels_black_label) + sep() + zoomImage.getLevelsBlack(lvCh));
        tvLvBlack.setTextColor(ThemeManager.getTextColor(this));
        tvLvBlack.setPadding(0, 8, 0, 5);
        list.addView(tvLvBlack);
        SeekBar sbLvBlack = new SeekBar(this);
        sbLvBlack.setMax(253);
        sbLvBlack.setProgress(zoomImage.getLevelsBlack(lvCh));
        fixSeekBarColor(sbLvBlack);
        sbLvBlack.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    int gr = zoomImage.getLevelsGray(lvCh);
                    int wh = zoomImage.getLevelsWhite(lvCh);
                    if (p >= wh - 2) p = wh - 2;
                    if (p >= gr) p = gr - 1;
                    if (p < 0) p = 0;
                    zoomImage.setLevels(lvCh, p, gr, wh);
                    tvLvBlack.setText(LanguageManager.getString(activity2Main.this, R.string.levels_black_label) + sep() + p);
                    hasUnsavedChanges = true;
                    updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.commitFilter(); saveStepImage(); }
            });
        list.addView(sbLvBlack);

        final TextView tvLvGray = new TextView(this);
        tvLvGray.setText(LanguageManager.getString(this, R.string.levels_gray_label) + sep() + zoomImage.getLevelsGray(lvCh));
        tvLvGray.setTextColor(ThemeManager.getTextColor(this));
        tvLvGray.setPadding(0, 8, 0, 5);
        list.addView(tvLvGray);
        SeekBar sbLvGray = new SeekBar(this);
        sbLvGray.setMax(253);
        sbLvGray.setProgress(zoomImage.getLevelsGray(lvCh) - 1);
        fixSeekBarColor(sbLvGray);
        sbLvGray.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    int gr = p + 1;
                    int bl = zoomImage.getLevelsBlack(lvCh);
                    int wh = zoomImage.getLevelsWhite(lvCh);
                    if (gr <= bl) gr = bl + 1;
                    if (gr >= wh) gr = wh - 1;
                    zoomImage.setLevels(lvCh, bl, gr, wh);
                    tvLvGray.setText(LanguageManager.getString(activity2Main.this, R.string.levels_gray_label) + sep() + gr);
                    hasUnsavedChanges = true;
                    updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.commitFilter(); saveStepImage(); }
            });
        list.addView(sbLvGray);

        final TextView tvLvWhite = new TextView(this);
        tvLvWhite.setText(LanguageManager.getString(this, R.string.levels_white_label) + sep() + zoomImage.getLevelsWhite(lvCh));
        tvLvWhite.setTextColor(ThemeManager.getTextColor(this));
        tvLvWhite.setPadding(0, 8, 0, 5);
        list.addView(tvLvWhite);
        SeekBar sbLvWhite = new SeekBar(this);
        sbLvWhite.setMax(253);
        sbLvWhite.setProgress(zoomImage.getLevelsWhite(lvCh) - 2);
        fixSeekBarColor(sbLvWhite);
        sbLvWhite.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    if (!fromUser) return;
                    int wh = p + 2;
                    int bl = zoomImage.getLevelsBlack(lvCh);
                    int gr = zoomImage.getLevelsGray(lvCh);
                    if (wh <= bl + 2) wh = bl + 2;
                    if (wh <= gr) wh = gr + 1;
                    if (wh > 255) wh = 255;
                    zoomImage.setLevels(lvCh, bl, gr, wh);
                    tvLvWhite.setText(LanguageManager.getString(activity2Main.this, R.string.levels_white_label) + sep() + wh);
                    hasUnsavedChanges = true;
                    updateHistogram();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) { zoomImage.commitFilter(); saveStepImage(); }
            });
        list.addView(sbLvWhite);

        Button btnResetLevels = createToolButton(LanguageManager.getString(this, R.string.levels_reset));
        btnResetLevels.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    zoomImage.resetLevels(lvCh);
                    updateHistogram();
                    hasUnsavedChanges = true;
                    showAdvancedTools();
                }
            });
        list.addView(btnResetLevels);
    }

    private void updateCbVal(int channel, int value) {
        float s = zoomImage.getCbShadowR(), sg = zoomImage.getCbShadowG(), sb = zoomImage.getCbShadowB();
        float m = zoomImage.getCbMidR(), mg = zoomImage.getCbMidG(), mb = zoomImage.getCbMidB();
        float h = zoomImage.getCbHighR(), hg = zoomImage.getCbHighG(), hb = zoomImage.getCbHighB();

        if (cbSelectedArea == 0) {
            if (channel == 0) s = value; else if (channel == 1) sg = value; else sb = value;
        } else if (cbSelectedArea == 1) {
            if (channel == 0) m = value; else if (channel == 1) mg = value; else mb = value;
        } else {
            if (channel == 0) h = value; else if (channel == 1) hg = value; else hb = value;
        }
        zoomImage.setColorBalance(s, sg, sb, m, mg, mb, h, hg, hb);
    }

    private void addCbSeekRow(LinearLayout parent, final String title, int defaultValue, final OnSeekBarChangeListener listener) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        final TextView tv = new TextView(this); tv.setText(title + sep() + defaultValue); tv.setTextColor(ThemeManager.getTextColor(this)); tv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)); row.addView(tv);
        final int[] lastCbShown = {defaultValue};
        SeekBar sb = new SeekBar(this); sb.setMax(200); sb.setProgress(defaultValue + 100);
        fixSeekBarColor(sb);
        sb.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    int val = progress - 100;
                    if (val != lastCbShown[0]) { lastCbShown[0] = val; tv.setText(title + sep() + val); }
                    if (fromUser) listener.onProgressChanged(val);
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) { zoomImage.commitFilter(); saveStepImage(); }
            });
        row.addView(sb);
        parent.addView(row);
    }

    private void showSavePresetDialog() {
        final EditText et = new EditText(this);
        et.setText(LanguageManager.getString(this, R.string.preset_default_prefix) + " " + new java.text.SimpleDateFormat("MMdd_HHmm").format(new java.util.Date()));

        showCustomPrompt(LanguageManager.getString(this, R.string.preset_save_title), LanguageManager.getString(this, R.string.preset_save_msg), et, new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int w) {
                    String name = et.getText().toString().trim();
                    if (name.length() == 0) name = LanguageManager.getString(activity2Main.this, R.string.preset_default_prefix);
                    try {
                        Preset p = new Preset(name, null);
                        p.brightness = zoomImage.getBrightness();
                        p.contrast = zoomImage.getContrast();
                        p.saturation = zoomImage.getSaturation();
                        p.shadows = zoomImage.getShadows();
                        p.highlights = zoomImage.getHighlights();
                        p.temperature = zoomImage.getTemperature();
                        p.tint = zoomImage.getTint();
                        p.sharpness = zoomImage.getSharpness();
                        p.lutM = lutToString(zoomImage.getMasterLUT());
                        p.lutR = lutToString(zoomImage.getRLUT());
                        p.lutG = lutToString(zoomImage.getGLUT());
                        p.lutB = lutToString(zoomImage.getBLUT());
                        String[] pts = zoomImage.getCurvePointStrs();
                        if (pts != null) {
                            p.ptsM = pts[0]; p.ptsR = pts[1]; p.ptsG = pts[2]; p.ptsB = pts[3];
                        }
                        if (currentLutPath != null) {
                            p.cubePath = currentLutPath;
                            p.cubeStrength = zoomImage.getCubeStrength();
                        }
                        p.cropRatio = zoomImage.getCropRatio();
                        HslAdjust hsave = zoomImage.getHslAdjust();
                        for (int i = 0; i < 8; i++) {
                            p.hslHue[i] = hsave.hue[i]; p.hslSat[i] = hsave.sat[i]; p.hslLum[i] = hsave.lum[i];
                        }
                        p.cbShadow[0] = zoomImage.getCbShadowR(); p.cbShadow[1] = zoomImage.getCbShadowG(); p.cbShadow[2] = zoomImage.getCbShadowB();
                        p.cbMid[0] = zoomImage.getCbMidR(); p.cbMid[1] = zoomImage.getCbMidG(); p.cbMid[2] = zoomImage.getCbMidB();
                        p.cbHigh[0] = zoomImage.getCbHighR(); p.cbHigh[1] = zoomImage.getCbHighG(); p.cbHigh[2] = zoomImage.getCbHighB();
                        for (int i = 0; i < 4; i++) {
                            p.lvBlack[i] = zoomImage.getLevelsBlack(i);
                            p.lvGray[i] = zoomImage.getLevelsGray(i);
                            p.lvWhite[i] = zoomImage.getLevelsWhite(i);
                        }

                        File f = PresetManager.generatePresetFile(activity2Main.this, name);
                        boolean ok = PresetManager.savePreset(f, p);
                        if (ok) toast(R.string.preset_saved_prefix, name);
                        else toast(R.string.preset_save_fail);
                    } catch (Throwable e) {
                        toast(R.string.preset_save_error, e.toString());
                    }
                }
            });
    }

    private void showApplyPresetDialog() {
        final java.util.List<Preset> presets = PresetManager.getAllPresets(this);
        if (presets.isEmpty()) {
            Toast.makeText(this, LanguageManager.getString(this, R.string.preset_none), Toast.LENGTH_SHORT).show();
            return;
        }
        final String[] items = new String[presets.size()];
        for (int i = 0; i < presets.size(); i++) items[i] = presets.get(i).name;

        showCustomDialog(LanguageManager.getString(this, R.string.preset_apply_title), items, new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int which) {
                    final Preset p = presets.get(which);
                    zoomImage.setAllFilters(p.brightness, p.contrast, p.saturation, p.shadows, p.highlights, p.temperature, p.tint, p.sharpness);
                    int[] m = stringToLut(p.lutM);
                    int[] r = stringToLut(p.lutR);
                    int[] g = stringToLut(p.lutG);
                    int[] b = stringToLut(p.lutB);
                    String[] pts = new String[]{p.ptsM, p.ptsR, p.ptsG, p.ptsB};
                    if (m != null || r != null || g != null || b != null || pts[0] != null) {
                        zoomImage.setRGBLUTs(m, r, g, b, pts);
                    }
                    if (p.cubePath != null) {
                        File lutFile = new File(p.cubePath);
                        if (lutFile.exists()) {
                            CubeLut lut = LutManager.loadLut(lutFile);
                            if (lut != null) {
                                zoomImage.setCubeLut(lut);
                                zoomImage.setCubeStrength(p.cubeStrength);
                                currentLutPath = p.cubePath; currentLutName = lut.title;
                            }
                        }
                    } else {
                        zoomImage.clearCubeLut();
                        currentLutPath = null; currentLutName = null;
                    }
                    if (p.hslHue != null && p.hslSat != null && p.hslLum != null) {
                        HslAdjust ha2 = new HslAdjust();
                        for (int i = 0; i < 8; i++) {
                            ha2.hue[i] = p.hslHue[i]; ha2.sat[i] = p.hslSat[i]; ha2.lum[i] = p.hslLum[i];
                        }
                        zoomImage.setHslAdjust(ha2);
                    }
                    if (p.cbShadow != null) zoomImage.setColorBalance(p.cbShadow[0], p.cbShadow[1], p.cbShadow[2], p.cbMid[0], p.cbMid[1], p.cbMid[2], p.cbHigh[0], p.cbHigh[1], p.cbHigh[2]);
                    if (p.lvBlack != null && p.lvGray != null && p.lvWhite != null) {
                        for (int i = 0; i < 4; i++) {
                            zoomImage.setLevels(i, p.lvBlack[i], p.lvGray[i], p.lvWhite[i]);
                        }
                    }

                    zoomImage.commitFilter();
                    hasUnsavedChanges = true; updateHistogram(); saveStepImage(); showAdvancedTools();
                    toast(R.string.preset_applied_prefix, p.name);
                }
            });
    }

    private void switchChannel(int channel, CurveView curveView) {
        curveView.setActiveChannel(channel);
        int normalBg = ThemeManager.getButtonColor(this);
        int normalText = ThemeManager.getTextColor(this);
        btnChannelW.setBackground(getRoundBg(channel == 0 ? Color.WHITE : normalBg));
        btnChannelW.setTextColor(channel == 0 ? Color.BLACK : normalText);
        btnChannelR.setBackground(getRoundBg(channel == 1 ? Color.RED : normalBg));
        btnChannelR.setTextColor(channel == 1 ? Color.BLACK : normalText);
        btnChannelG.setBackground(getRoundBg(channel == 2 ? Color.GREEN : normalBg));
        btnChannelG.setTextColor(channel == 2 ? Color.BLACK : normalText);
        btnChannelB.setBackground(getRoundBg(channel == 3 ? Color.BLUE : normalBg));
        btnChannelB.setTextColor(channel == 3 ? Color.WHITE : normalText);
    }

    interface OnSeekBarChangeListener { void onProgressChanged(int value); }

    private void addSeekBarRow(LinearLayout parent, final String title, final int min, int max, int defaultValue, final OnSeekBarChangeListener listener) {
        final TextView tv = new TextView(this); tv.setText(title + sep() + defaultValue); tv.setTextColor(ThemeManager.getTextColor(this)); tv.setPadding(0, 20, 0, 5); parent.addView(tv);
        final SeekBar sb = new SeekBar(this); sb.setMax(max - min); sb.setProgress(defaultValue - min);
        fixSeekBarColor(sb);
        final int[] lastShown = {Integer.MIN_VALUE};
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    int value = progress + min;
                    // 只有数值真的变了才重设文字，避免每帧触发文字测量/布局
                    if (value != lastShown[0]) {
                        lastShown[0] = value;
                        tv.setText(title + sep() + value);
                    }
                    if (fromUser) listener.onProgressChanged(value);
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) { zoomImage.commitFilter(); saveStepImage(); }
            });
        parent.addView(sb);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == LAYER_IMAGE_PICK_REQUEST) {
            if (resultCode == RESULT_OK && data != null) {
                try {
                    InputStream is = getContentResolver().openInputStream(data.getData());
                    Bitmap bmp = BitmapFactory.decodeStream(is);
                    if (is != null) is.close();
                    if (bmp != null) {
                        LayerManager lm = zoomImage.getLayerManager();
                        int w = CANVAS_SIZE, h = CANVAS_SIZE;
                        if (lm.size() > 0 && lm.get(0).bitmap != null && !lm.get(0).bitmap.isRecycled()) {
                            w = lm.get(0).bitmap.getWidth();
                            h = lm.get(0).bitmap.getHeight();
                        }
                        LayerManager.LayerItem l = lm.addImageLayer(bmp, w, h);
                        if (l != null) {
                            LayerManager.LayerItem snap = l.copyMeta();
                            if (l.bitmap != null && !l.bitmap.isRecycled()) {
                                snap.bitmap = l.bitmap.copy(Bitmap.Config.ARGB_8888, false);
                            }
                            zoomImage.getHistory().addAddLayer(snap);

                            zoomImage.setCurrentLayerIndex(lm.size() - 1);
                            zoomImage.onLayersChanged();
                            hasUnsavedChanges = true;
                            showLayersTools();
                        }
                    }
                } catch (Throwable e) {}
            }
            return;
        }

        if (requestCode == CUBE_LUT_PICK_REQUEST) {
            if (resultCode == RESULT_OK && data != null) {
                try {
                    String fileName = HistoryManager.getFileNameFromUri(this, data.getData());
                    File imported = LutManager.importLut(this, data.getData(), fileName);
                    if (imported != null) {
                        CubeLut lut = LutManager.loadLut(imported);
                        if (lut != null) {
                            zoomImage.setCubeLut(lut);
                            currentLutPath = imported.getAbsolutePath();
                            currentLutName = lut.title;
                            hasUnsavedChanges = true;
                            updateHistogram();
                            Toast.makeText(this, LanguageManager.getString(this, R.string.lut_loaded_prefix) + lut.title + " (" + lut.size + "³)", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, LanguageManager.getString(this, R.string.lut_parse_fail), Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Throwable e) {}
            }
            return;
        }

        if (requestCode == CROP_REQUEST) {
            if (resultCode == RESULT_OK && data != null) {
                float[] ratio = data.getFloatArrayExtra("crop_ratio");
                if (ratio != null && ratio.length == 4) {
                    zoomImage.applyCrop(ratio);
                    hasUnsavedChanges = true;
                    updateHistogram();
                    saveStepImage();
                }
            }
            return;
        }

        if ((requestCode == OVERLAY_PAGE_REQUEST || requestCode == TEXT_OVERLAY_PAGE_REQUEST)
            && resultCode == RESULT_OK && data != null) {
            Uri resultUri = data.getData();
            try {
                InputStream is = getContentResolver().openInputStream(resultUri);
                Bitmap resultBitmap = BitmapFactory.decodeStream(is);
                if (is != null) is.close();
                if (resultBitmap != null) {
                    LayerManager lm = zoomImage.getLayerManager();
                    int w = CANVAS_SIZE, h = CANVAS_SIZE;
                    if (lm.size() > 0 && lm.get(0).bitmap != null && !lm.get(0).bitmap.isRecycled()) {
                        w = lm.get(0).bitmap.getWidth();
                        h = lm.get(0).bitmap.getHeight();
                    }
                    if (resultBitmap.getWidth() != w || resultBitmap.getHeight() != h) {
                        Bitmap scaled = Bitmap.createScaledBitmap(resultBitmap, w, h, true);
                        if (scaled != resultBitmap && !resultBitmap.isRecycled()) resultBitmap.recycle();
                        resultBitmap = scaled;
                    }
                    LayerManager.LayerItem l = lm.addImageLayer(resultBitmap, w, h);
                    if (l != null) {
                        LayerManager.LayerItem snap = l.copyMeta();
                        if (l.bitmap != null && !l.bitmap.isRecycled()) {
                            snap.bitmap = l.bitmap.copy(Bitmap.Config.ARGB_8888, false);
                        }
                        zoomImage.getHistory().addAddLayer(snap);

                        zoomImage.setCurrentLayerIndex(lm.size() - 1);
                        zoomImage.onLayersChanged();
                        hasUnsavedChanges = true;
                        updateHistogram();
                    }
                }
            } catch (Throwable e) {}
        }
    }

    private void showLayersTools() {
        // 离开蒙版面板：无条件收尾（此时 currentTool 还可能是 "mask"，不能拿它判断）
        try {
            zoomImage.setMaskIndicatorLocked(false);
            zoomImage.setMaskIndicatorVisible(false, -1);
            zoomImage.hideMaskIndicator();
            zoomImage.setMaskBrushMode(false, -1, 0, 0, false);
            zoomImage.setMaskDragMode(false, -1);
            zoomImage.setMaskInteracting(false);
            zoomImage.setMaskIndicatorHideTemporarily(false);
            MaskPanel.commitSession(zoomImage);
        } catch (Throwable ignored) {}
        currentTool = "layers";
        ensureToolbarExpanded();
        if (!ThemeManager.isWpbEnabled(this)) {
            Toast.makeText(this, LanguageManager.getString(this, R.string.layer_need_wpb), Toast.LENGTH_SHORT).show();
            return;
        }

        updateButtonHighlight(null);
        zoomImage.setZoomEnabled(true); 
        zoomImage.setDrawMode(false);
        toolContent.removeAllViews();
        scrollToolsToTop();

        final LayerManager lm = zoomImage.getLayerManager();
        if (lm.size() == 0) lm.ensureBaseLayer(CANVAS_SIZE, CANVAS_SIZE);

        int ww = CANVAS_SIZE, hh = CANVAS_SIZE;
        if (lm.size() > 0 && lm.get(0).bitmap != null && !lm.get(0).bitmap.isRecycled()) {
            ww = lm.get(0).bitmap.getWidth();
            hh = lm.get(0).bitmap.getHeight();
        }
        final int canvasW = ww;
        final int canvasH = hh;

        lm.ensureDrawLayer(canvasW, canvasH);
        if (zoomImage.getCurrentLayerIndex() <= 0) {
            zoomImage.setCurrentLayerIndex(1);
        }

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);

        TextView tvHint0 = new TextView(this);
        {
            int cur = zoomImage.getCurrentLayerIndex();
            String name = (cur >= 0 && cur < lm.size() && lm.get(cur).name != null) ? lm.get(cur).name : (LanguageManager.getString(this, R.string.layer_default_name) + " " + cur);
            tvHint0.setText(LanguageManager.getString(this, R.string.layer_editing_prefix) + name);
        }
        tvHint0.setTextColor(0xFFFFB615); tvHint0.setTextSize(12); tvHint0.setPadding(8, 8, 8, 8);
        list.addView(tvHint0);

        int gap = (int)(4 * density);
        int rowGap = (int)(6 * density);
        LinearLayout addRow = new LinearLayout(this);
        addRow.setOrientation(LinearLayout.HORIZONTAL);

        android.widget.TextView btnAddBlank = createIconButton(R.drawable.ic_add_layer,
                LanguageManager.getString(this, R.string.layer_add_blank));
        btnAddBlank.setLayoutParams(makeWeightLp(gap, rowGap));
        btnAddBlank.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!lm.canAddLayer()) { toast(R.string.layer_max_reached); return; }
                    LayerManager.LayerItem l = lm.addBlankLayer(canvasW, canvasH);
                    if (l != null) {
                        LayerManager.LayerItem snap = l.copyMeta();
                        if (l.bitmap != null && !l.bitmap.isRecycled()) {
                            snap.bitmap = l.bitmap.copy(Bitmap.Config.ARGB_8888, false);
                        }
                        zoomImage.getHistory().addAddLayer(snap);

                        zoomImage.setCurrentLayerIndex(lm.size() - 1);
                        zoomImage.onLayersChanged();
                        hasUnsavedChanges = true;
                        showLayersTools();
                    }
                }
            });
        addRow.addView(btnAddBlank);

        android.widget.TextView btnAddImage = createIconButton(R.drawable.ic_add_image,
                LanguageManager.getString(this, R.string.layer_add_image));
        btnAddImage.setLayoutParams(makeWeightLp(gap, rowGap));
        btnAddImage.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!lm.canAddLayer()) { toast(R.string.layer_max_reached); return; }
                    Intent pick = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pick, LAYER_IMAGE_PICK_REQUEST);
                }
            });
        addRow.addView(btnAddImage);
        list.addView(addRow);

        TextView tvHint = new TextView(this);
        tvHint.setText(LanguageManager.getString(this, R.string.layer_list_hint));
        tvHint.setTextColor(ThemeManager.getTextColor(this));
        tvHint.setTextSize(12);
        tvHint.setPadding(0, 12, 0, 8);
        list.addView(tvHint);

        for (int i = lm.size() - 1; i >= 0; i--) {
            final int idx = i;
            final LayerManager.LayerItem layer = lm.get(i);
            final boolean isMain = (i == 0);
            final boolean isCur = (zoomImage.getCurrentLayerIndex() == i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(12, 8, 12, 8);
            row.setBackgroundColor(isCur ? 0xFF8A6D00 : ThemeManager.getButtonColor(this));

            ImageView thumb = new ImageView(this);
            int thumbPx = (int)(44 * density);
            LinearLayout.LayoutParams lpThumb = new LinearLayout.LayoutParams(thumbPx, thumbPx);
            lpThumb.setMargins(0, 0, 8, 0);
            thumb.setLayoutParams(lpThumb);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Bitmap tb = renderLayerThumb(layer, thumbPx);
            if (tb != null) thumb.setImageBitmap(tb);
            row.addView(thumb);

            TextView tvName = new TextView(this);
            String tn = (layer.name != null && layer.name.length() > 0) ? layer.name : (LanguageManager.getString(this, R.string.layer_default_name) + " " + i);
            String alphaStr = (layer.alpha < 255) ? (" [" + (layer.alpha * 100 / 255) + "%]") : "";
            String suffix = isMain ? LanguageManager.getString(this, R.string.layer_base_suffix) : ((layer.visible ? "" : LanguageManager.getString(this, R.string.layer_hidden_suffix)) + alphaStr + (isCur ? " ◀" : ""));
            tvName.setText((i + 1) + ". " + tn + suffix);
            tvName.setTextColor(isCur ? Color.WHITE : ThemeManager.getTextColor(this));
            tvName.setTextSize(13);
            LinearLayout.LayoutParams lpName = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tvName.setLayoutParams(lpName);
            row.addView(tvName);

            row.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (isMain) {
                            toast(R.string.layer_main_locked);
                            return;
                        }
                        zoomImage.setCurrentLayerIndex(idx); showLayersTools();
                    }
                });

            Button btnMore = new Button(this);
            btnMore.setText("⋯");
            btnMore.setTextSize(16);
            btnMore.setTextColor(Color.BLACK);
            btnMore.setBackground(getRoundBg(0xFFFFB615));
            btnMore.setPadding(0, 0, 0, 0);
            fixButtonStyle(btnMore);
            LinearLayout.LayoutParams lpMore = new LinearLayout.LayoutParams((int)(40*density), (int)(32*density));
            lpMore.setMargins(4, 0, 0, 0);
            btnMore.setLayoutParams(lpMore);
            if (isMain) {
                btnMore.setEnabled(false);
                btnMore.setAlpha(0.3f);
            } else {
                btnMore.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { showLayerMenu(idx); }
                    });
            }
            row.addView(btnMore);

            LinearLayout.LayoutParams lpRow = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lpRow.setMargins(0, 0, 0, 6);
            row.setLayoutParams(lpRow);
            list.addView(row);
        }

        toolContent.addView(list);
    }

    private void showLayerMenu(final int layerIdx) {
        final LayerManager lm = zoomImage.getLayerManager();
        if (layerIdx < 0 || layerIdx >= lm.size()) return;
        final LayerManager.LayerItem layer = lm.get(layerIdx);

        String[] items = {
            LanguageManager.getString(this, R.string.layer_menu_opacity),
            layer.visible ? LanguageManager.getString(this, R.string.layer_menu_hide) : LanguageManager.getString(this, R.string.layer_menu_show),
            layer.applyFilter ? LanguageManager.getString(this, R.string.layer_filter_off) : LanguageManager.getString(this, R.string.layer_filter_on),
            LanguageManager.getString(this, R.string.layer_menu_up),
            LanguageManager.getString(this, R.string.layer_menu_down),
            LanguageManager.getString(this, R.string.layer_menu_delete)
        };

        showCustomDialog(LanguageManager.getString(this, R.string.layer_menu_title), items, new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if (which == 0) {
                        showOpacityDialog(layerIdx);
                    } else if (which == 1) {
                        if (lm.toggleVisible(layerIdx)) {
                            zoomImage.onLayersChanged();
                            hasUnsavedChanges = true;
                            showLayersTools();
                        }
                    } else if (which == 2) {
                        layer.applyFilter = !layer.applyFilter;
                        zoomImage.invalidate();
                        hasUnsavedChanges = true;
                        showLayersTools();
                    } else if (which == 3) {
                        if (lm.moveUp(layerIdx)) {
                            int cur = zoomImage.getCurrentLayerIndex();
                            if (cur == layerIdx) zoomImage.setCurrentLayerIndex(layerIdx - 1);
                            else if (cur == layerIdx - 1) zoomImage.setCurrentLayerIndex(layerIdx);
                            zoomImage.onLayersChanged();
                            hasUnsavedChanges = true;
                            showLayersTools();
                        } else {
                            toast(R.string.layer_already_top);
                        }
                    } else if (which == 4) {
                        if (lm.moveDown(layerIdx)) {
                            int cur = zoomImage.getCurrentLayerIndex();
                            if (cur == layerIdx) zoomImage.setCurrentLayerIndex(layerIdx + 1);
                            else if (cur == layerIdx + 1) zoomImage.setCurrentLayerIndex(layerIdx);
                            zoomImage.onLayersChanged();
                            hasUnsavedChanges = true;
                            showLayersTools();
                        } else {
                            toast(R.string.layer_already_bottom);
                        }
                    } else if (which == 5) {
                        LayerManager.LayerItem snap = layer.copyMeta();
                        if (layer.bitmap != null && !layer.bitmap.isRecycled()) {
                            snap.bitmap = layer.bitmap.copy(Bitmap.Config.ARGB_8888, false);
                        }
                        zoomImage.getHistory().addDeleteLayer(snap, layerIdx);

                        if (lm.removeLayer(layerIdx)) {
                            if (zoomImage.getCurrentLayerIndex() >= lm.size()) {
                                zoomImage.setCurrentLayerIndex(lm.size() - 1);
                            }
                            if (zoomImage.getCurrentLayerIndex() <= 0 && lm.size() > 1) {
                                zoomImage.setCurrentLayerIndex(1);
                            }
                            zoomImage.onLayersChanged();
                            hasUnsavedChanges = true;
                            showLayersTools();
                        }
                    }
                }
            });
    }

    /**
     * 生成图层缩略图。
     *
     * 性能要点：不先把整张图层位图 createScaledBitmap 一遍（4000x3000 的图要几百 ms，
     * 图层一多打开面板就卡），而是直接用 Canvas 的 src/dst 绘制让系统内部缩放。
     */
    private Bitmap renderLayerThumb(LayerManager.LayerItem l, int size) {
        try {
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            // 棋盘格垫底，保留透明观感（不能用白色，否则透明层看不出区别）
            drawThumbChecker(c, size);
            if (l.bitmap != null && !l.bitmap.isRecycled()) {
                int bw = l.bitmap.getWidth(), bh = l.bitmap.getHeight();
                if (bw > 0 && bh > 0) {
                    float s = Math.min((float) size / bw, (float) size / bh);
                    int sw = Math.max(1, (int) (bw * s));
                    int sh = Math.max(1, (int) (bh * s));
                    android.graphics.Rect src = new android.graphics.Rect(0, 0, bw, bh);
                    android.graphics.Rect dst = new android.graphics.Rect(
                            (size - sw) / 2, (size - sh) / 2,
                            (size - sw) / 2 + sw, (size - sh) / 2 + sh);
                    Paint lp = thumbPaint;
                    lp.reset();
                    lp.setAlpha(l.alpha);
                    lp.setFilterBitmap(true);
                    c.drawBitmap(l.bitmap, src, dst, lp);
                }
            }
            return bmp;
        } catch (Throwable e) { return null; }
    }

    /** 缩略图复用对象，避免每层都 new。 */
    private final Paint thumbPaint = new Paint();

    /** 画缩略图的灰白棋盘底（表示透明）。 */
    private void drawThumbChecker(Canvas c, int size) {
        Paint p = new Paint();
        p.setColor(0xFFFFFFFF);
        c.drawRect(0, 0, size, size, p);
        p.setColor(0xFFE0E0E0);
        int cell = Math.max(4, size / 8);
        for (int y = 0; y < size; y += cell) {
            for (int x = 0; x < size; x += cell) {
                if (((x / cell) + (y / cell)) % 2 == 1) {
                    c.drawRect(x, y, x + cell, y + cell, p);
                }
            }
        }
    }

    private void showOpacityDialog(final int layerIdx) {
        final LayerManager lm = zoomImage.getLayerManager();
        if (layerIdx < 0 || layerIdx >= lm.size()) return;
        final LayerManager.LayerItem l = lm.get(layerIdx);

        lm.setGlobalAlpha(255);

        int initPct = Math.round(l.alpha * 100f / 255f);
        if (initPct < 0) initPct = 0;
        if (initPct > 100) initPct = 100;
        final int startPct = initPct;

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getPanelLayerBg());
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(10*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(LanguageManager.getString(this, R.string.opacity_dialog_title));
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(Gravity.CENTER);
        tvTitle.setPadding(0, 0, 0, (int)(12*density));
        root.addView(tvTitle);

        final SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        try {
            sb.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#FFB615")));
            sb.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#FFB615")));
        } catch (Throwable ignored) {}
        root.addView(sb);
        sb.setProgress(startPct);
        sb.post(new Runnable() {
                @Override public void run() {
                    sb.setProgress(startPct);
                }
            });

        final TextView tv = new TextView(this);
        tv.setText(LanguageManager.getString(this, R.string.opacity_display_prefix) + startPct + "%");
        tv.setTextColor(ThemeManager.getTextColor(this));
        tv.setTextSize(14);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, (int)(8*density), 0, (int)(8*density));
        root.addView(tv);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (progress < 0) progress = 0;
                    if (progress > 100) progress = 100;
                    l.alpha = Math.round(progress * 255f / 100f);
                    tv.setText(LanguageManager.getString(activity2Main.this, R.string.opacity_display_prefix) + progress + "%");
                    zoomImage.invalidate();
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });

        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        int[] pcts = {0, 25, 50, 75, 100};
        for (int pi = 0; pi < pcts.length; pi++) {
            final int pct = pcts[pi];
            Button qb = new Button(this);
            qb.setText(pct + "%");
            qb.setTextSize(12);
            qb.setTextColor(Color.BLACK);
            qb.setBackground(getRoundBg(0xFFFFB615));
            fixButtonStyle(qb);
            LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            qlp.setMargins((int)(2*density), (int)(8*density), (int)(2*density), 0);
            qb.setLayoutParams(qlp);
            qb.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        sb.setProgress(pct);
                    }
                });
            quickRow.addView(qb);
        }
        root.addView(quickRow);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, (int)(15*density), 0, 0);

        TextView btnCancel = new TextView(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnCancel.setBackground(getRoundBg(0xFF555555));
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp1.setMargins(0, 0, (int)(10*density), 0);
        btnCancel.setLayoutParams(lp1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dialog.dismiss(); }
            });
        btnRow.addView(btnCancel);

        TextView btnOk = new TextView(this);
        btnOk.setText(LanguageManager.getString(this, R.string.confirm));
        btnOk.setTextSize(15);
        btnOk.setTextColor(Color.BLACK);
        btnOk.setGravity(Gravity.CENTER);
        btnOk.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnOk.setBackground(getRoundBg(0xFFFFB615));
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btnOk.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    int pct = sb.getProgress();
                    if (pct < 0) pct = 0;
                    if (pct > 100) pct = 100;
                    l.alpha = Math.round(pct * 255f / 100f);
                    zoomImage.invalidate();

                    if (editFilePath != null && !editFilePath.isEmpty()) {
                        SharedPreferences sp = getSharedPreferences("weifp_filters", MODE_PRIVATE);
                        SharedPreferences.Editor ed = sp.edit();
                        String ld = zoomImage.getLayerManager().getSerializedString();
                        ed.putString(editFilePath + "_layer_data", ld);
                        ed.apply();
                    }

                    hasUnsavedChanges = true;
                    zoomImage.onLayersChanged();
                    dialog.dismiss();
                    showLayersTools();
                }
            });
        btnRow.addView(btnOk);
        root.addView(btnRow);

        dialog.setContentView(root);
        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.85);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void showDrawTools() {
        // 离开蒙版面板：无条件收尾（此时 currentTool 还可能是 "mask"，不能拿它判断）
        try {
            zoomImage.setMaskIndicatorLocked(false);
            zoomImage.setMaskIndicatorVisible(false, -1);
            zoomImage.hideMaskIndicator();
            zoomImage.setMaskBrushMode(false, -1, 0, 0, false);
            zoomImage.setMaskDragMode(false, -1);
            zoomImage.setMaskInteracting(false);
            zoomImage.setMaskIndicatorHideTemporarily(false);
            MaskPanel.commitSession(zoomImage);
        } catch (Throwable ignored) {}
        currentTool = "draw";
        ensureToolbarExpanded();
        updateButtonHighlight(btnDraw);
        zoomImage.setZoomEnabled(true);
        zoomImage.setDrawMode(true);
        toolContent.removeAllViews();
        scrollToolsToTop();

        LayerManager lmx = zoomImage.getLayerManager();
        if (zoomImage.getCurrentLayerIndex() <= 0) {
            int bw = CANVAS_SIZE, bh = CANVAS_SIZE;
            if (zoomImage.getDrawable() != null) {
                int iw = zoomImage.getDrawable().getIntrinsicWidth();
                int ih = zoomImage.getDrawable().getIntrinsicHeight();
                if (iw > 0) bw = iw;
                if (ih > 0) bh = ih;
            }
            lmx.ensureDrawLayer(bw, bh);
            zoomImage.setCurrentLayerIndex(lmx.size() - 1);
        }

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);

        LayerManager lm0 = zoomImage.getLayerManager();
        int cur0 = zoomImage.getCurrentLayerIndex();
        String curName0 = (cur0 >= 0 && cur0 < lm0.size() && lm0.get(cur0).name != null) ? lm0.get(cur0).name : (LanguageManager.getString(this, R.string.layer_default_name) + " " + cur0);
        
        LinearLayout topInfoRow = new LinearLayout(this);
        topInfoRow.setOrientation(LinearLayout.HORIZONTAL);
        topInfoRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvCurLayer = new TextView(this);
        tvCurLayer.setText(LanguageManager.getString(this, R.string.draw_on_prefix) + sep() + curName0);
        tvCurLayer.setTextColor(0xFFFFB615); tvCurLayer.setTextSize(12); tvCurLayer.setPadding(8, 8, 8, 8);
        tvCurLayer.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        topInfoRow.addView(tvCurLayer);

        final Button btnSymmetry = createToolButton(LanguageManager.getString(this, R.string.symmetry_title));
        btnSymmetry.setTextSize(11);
        LinearLayout.LayoutParams symLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (int)(30*density));
        btnSymmetry.setLayoutParams(symLp);
        updateSymmetryBtnState(btnSymmetry);
        btnSymmetry.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSymmetryDialog(btnSymmetry); }
        });
        topInfoRow.addView(btnSymmetry);
        list.addView(topInfoRow);

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        final Button btnBrush = createToolButton(LanguageManager.getString(this, R.string.brush));
        final Button btnEraser = createToolButton(LanguageManager.getString(this, R.string.eraser));
        final Button btnBucket = createToolButton(LanguageManager.getString(this, R.string.bucket));
        
        int modeGap = (int)(4 * density);
        LinearLayout.LayoutParams lpMode = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lpMode.setMargins(modeGap, (int)(10*density), modeGap, (int)(10*density));
        
        btnBrush.setLayoutParams(new LinearLayout.LayoutParams(lpMode));
        btnEraser.setLayoutParams(new LinearLayout.LayoutParams(lpMode));
        btnBucket.setLayoutParams(new LinearLayout.LayoutParams(lpMode));
        
        modeRow.addView(btnBrush); 
        modeRow.addView(btnEraser); 
        modeRow.addView(btnBucket); 

        list.addView(modeRow);

        // 色度抠图：单独一行，主题橙色（0xFFFFB615）。
        // 放进度不用和画笔/橡皮/油漆桶平分宽度，也不会挤掉下方内容。
        LinearLayout chromaRow = new LinearLayout(this);
        chromaRow.setOrientation(LinearLayout.HORIZONTAL);
        final android.widget.TextView btnChroma = createIconButton(R.drawable.ic_chroma,
                LanguageManager.getString(this, R.string.chroma_title));
        btnChroma.setBackground(getRoundBg(0xFFFFB615));
        btnChroma.setTextColor(Color.BLACK);
        LinearLayout.LayoutParams chLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        chLp.setMargins(modeGap, 0, modeGap, (int) (10 * density));
        btnChroma.setLayoutParams(chLp);
        btnChroma.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openChromaKey(); }
        });
        chromaRow.addView(btnChroma);
        list.addView(chromaRow);

        final LinearLayout brushPanel = new LinearLayout(this);
        brushPanel.setOrientation(LinearLayout.VERTICAL);
        brushPanel.setPadding(0, (int)(10*density), 0, 0);
        
        final LinearLayout eraserPanel = new LinearLayout(this);
        eraserPanel.setOrientation(LinearLayout.VERTICAL);
        eraserPanel.setPadding(0, (int)(10*density), 0, 0);

        final LinearLayout bucketPanel = new LinearLayout(this);
        bucketPanel.setOrientation(LinearLayout.VERTICAL);
        bucketPanel.setPadding(0, (int)(10*density), 0, 0);

        // --- 画笔面板 ---
        TextView tvColor = new TextView(this);
        tvColor.setText(LanguageManager.getString(this, R.string.draw_colors_label) + sep());
        tvColor.setTextColor(ThemeManager.getTextColor(this));
        brushPanel.addView(tvColor);
        LinearLayout colorRow = new LinearLayout(this);
        colorRow.setOrientation(LinearLayout.HORIZONTAL);
        brushPanel.addView(colorRow);
        // 圆形色块（参考 HMCLgo 的 swatch）：选中时加橙色外环，尺寸自适应屏幕
        // 按色谱排列：无彩色（黑→灰→白）→ 红 → 棕 → 琥珀 → 绿 → 青绿 → 天蓝 → 靛蓝 → 紫 → 粉
        // 其中琥珀 #FFB615 为本应用品牌色（原 HMCLgo 的 #F57641 已替换）
        final int[] colors = {
            0xFF000000,  // 纯黑
            0xFF808080,  // 中灰
            0xFFFFFFFF,  // 纯白
            0xFFF44336,  // 红      H4
            0xFF795548,  // 棕      H16
            0xFFFFB615,  // 琥珀    H41  ★品牌色
            0xFF4CAF50,  // 绿      H122
            0xFF06D6A0,  // 青绿    H164
            0xFF4A90D9,  // 天蓝    H211
            0xFF3F51B5,  // 靛蓝    H231
            0xFF9C27B0,  // 紫      H291
            0xFFFF69B4,  // 粉      H330
        };
        final boolean darkTheme = ThemeManager.isDark(this);
        swatchViews.clear();
        swatchColors.clear();
        colorRow.setGravity(Gravity.CENTER_VERTICAL);
        for (final int c : colors) {
            final android.widget.FrameLayout sw = UiSpec.swatch(this, c, 28, false, darkTheme);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    sw.getLayoutParams().width, sw.getLayoutParams().height);
            lp.setMargins(UiSpec.dpi(this, 3), 0, UiSpec.dpi(this, 3), 0);
            sw.setLayoutParams(lp);
            sw.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        drawR = Color.red(c); drawG = Color.green(c); drawB = Color.blue(c);
                        applyCustomColor();   // 选中环由 updateSwatchSelection 统一处理
                    }
                });
            swatchViews.add(sw);
            swatchColors.add(c);
            colorRow.addView(sw);
        }

        TextView tvRgbTitle = new TextView(this);
        tvRgbTitle.setText(LanguageManager.getString(this, R.string.draw_custom_rgb));
        tvRgbTitle.setTextColor(ThemeManager.getTextColor(this));
        tvRgbTitle.setPadding(0, 20, 0, 5);
        brushPanel.addView(tvRgbTitle);
        LinearLayout rgbContainer = new LinearLayout(this); rgbContainer.setOrientation(LinearLayout.VERTICAL); brushPanel.addView(rgbContainer);
        addRgbRow(rgbContainer, LanguageManager.getString(this, R.string.draw_channel_r), drawR, new OnSeekBarChangeListener() { @Override public void onProgressChanged(int value) { drawR = value; applyCustomColor(); } });
        addRgbRow(rgbContainer, LanguageManager.getString(this, R.string.draw_channel_g), drawG, new OnSeekBarChangeListener() { @Override public void onProgressChanged(int value) { drawG = value; applyCustomColor(); } });
        addRgbRow(rgbContainer, LanguageManager.getString(this, R.string.draw_channel_b), drawB, new OnSeekBarChangeListener() { @Override public void onProgressChanged(int value) { drawB = value; applyCustomColor(); } });

        final TextView tvWidth = new TextView(this); tvWidth.setText(LanguageManager.getString(this, R.string.draw_width) + (int) zoomImage.getDrawWidth()); tvWidth.setTextColor(ThemeManager.getTextColor(this)); tvWidth.setPadding(0, 20, 0, 5); brushPanel.addView(tvWidth);
        final SeekBar widthSeek = new SeekBar(this); widthSeek.setMax(50); widthSeek.setProgress((int) zoomImage.getDrawWidth());
        fixSeekBarColor(widthSeek);
        widthSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { if (progress < 1) progress = 1; zoomImage.setDrawWidth(progress); tvWidth.setText(LanguageManager.getString(activity2Main.this, R.string.draw_width) + progress); }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        brushPanel.addView(widthSeek);

        final TextView tvAlpha = new TextView(this); tvAlpha.setText(LanguageManager.getString(this, R.string.draw_alpha) + (int)(zoomImage.getDrawAlpha() * 100)); tvAlpha.setTextColor(ThemeManager.getTextColor(this)); tvAlpha.setPadding(0, 20, 0, 5); brushPanel.addView(tvAlpha);
        SeekBar alphaSeek = new SeekBar(this); alphaSeek.setMax(100); alphaSeek.setProgress((int)(zoomImage.getDrawAlpha() * 100));
        fixSeekBarColor(alphaSeek);
        alphaSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { zoomImage.setDrawAlpha(progress / 100f); tvAlpha.setText(LanguageManager.getString(activity2Main.this, R.string.draw_alpha) + progress); }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        brushPanel.addView(alphaSeek);

        // --- 橡皮面板 ---
        final TextView tvEraseWidth = new TextView(this); tvEraseWidth.setText(LanguageManager.getString(this, R.string.erase_width) + (int) zoomImage.getDrawWidth()); tvEraseWidth.setTextColor(ThemeManager.getTextColor(this)); tvEraseWidth.setPadding(0, 10, 0, 5); eraserPanel.addView(tvEraseWidth);
        final SeekBar eraseWidthSeek = new SeekBar(this); eraseWidthSeek.setMax(50); eraseWidthSeek.setProgress((int) zoomImage.getDrawWidth());
        fixSeekBarColor(eraseWidthSeek);
        eraseWidthSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { if (progress < 1) progress = 1; zoomImage.setDrawWidth(progress); tvEraseWidth.setText(LanguageManager.getString(activity2Main.this, R.string.erase_width) + progress); }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        eraserPanel.addView(eraseWidthSeek);

        // --- 油漆桶面板 ---
        TextView tvBucketHint = new TextView(this); tvBucketHint.setText(LanguageManager.getString(this, R.string.draw_fill_hint)); tvBucketHint.setTextColor(ThemeManager.getTextColor(this)); tvBucketHint.setPadding(0, 20, 0, 5); bucketPanel.addView(tvBucketHint);
        final TextView tvTol = new TextView(this); tvTol.setText(LanguageManager.getString(this, R.string.bucket_tolerance) + zoomImage.getBucketTolerance()); tvTol.setTextColor(ThemeManager.getTextColor(this)); tvTol.setPadding(0, 20, 0, 5); bucketPanel.addView(tvTol);
        SeekBar tolSeek = new SeekBar(this); tolSeek.setMax(128); tolSeek.setProgress(zoomImage.getBucketTolerance());
        fixSeekBarColor(tolSeek);
        tolSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { zoomImage.setBucketTolerance(progress); tvTol.setText(LanguageManager.getString(activity2Main.this, R.string.bucket_tolerance) + progress); }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        bucketPanel.addView(tolSeek);

        list.addView(brushPanel);
        list.addView(eraserPanel);
        list.addView(bucketPanel);

        // 套索面板要先声明：下面的画笔/橡皮/油漆桶点击里会用它
        final LinearLayout lassoPanel = new LinearLayout(this);
        lassoPanel.setOrientation(LinearLayout.VERTICAL);
        lassoPanel.setVisibility(View.GONE);
        lassoPanel.setPadding(0, (int)(8*density), 0, 0);

        btnBrush.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    // 从套索切走时清掉残留选区，否则虚线框会一直挂在画面上
                    zoomImage.clearLasso();
                    zoomImage.setBrushMode(0);
                    lassoPanel.setVisibility(View.GONE);
                    eraserPanel.setVisibility(View.GONE);
                    bucketPanel.setVisibility(View.GONE);
                    brushPanel.setVisibility(View.VISIBLE);
                    scrollToolsToTop();
                    updateModeBtnUI(btnBrush, btnEraser, btnBucket);
                    // 切回画笔时刷新宽度滑轨。拖动套索后画笔宽度可能被别处改过，
                    // 这里做一次同步，避免滑轨显示和实际不符。
                    try {
                        int bw = (int) zoomImage.getDrawWidth();
                        tvWidth.setText(LanguageManager.getString(activity2Main.this,
                                R.string.draw_width) + bw);
                        widthSeek.setProgress(Math.max(0, Math.min(widthSeek.getMax(), bw)));
                    } catch (Throwable ignored) {}
                }
            });
        btnEraser.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    zoomImage.clearLasso();
                    zoomImage.setBrushMode(1); // 普通橡皮
                    lassoPanel.setVisibility(View.GONE);
                    brushPanel.setVisibility(View.GONE);
                    bucketPanel.setVisibility(View.GONE);
                    eraserPanel.setVisibility(View.VISIBLE);
                    scrollToolsToTop();
                    updateModeBtnUI(btnBrush, btnEraser, btnBucket);
                    tvEraseWidth.setText(LanguageManager.getString(activity2Main.this, R.string.erase_width) + (int) zoomImage.getDrawWidth());
                    eraseWidthSeek.setProgress((int) zoomImage.getDrawWidth());
                }
            });
        btnBucket.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    zoomImage.clearLasso();
                    zoomImage.setBrushMode(2);
                    lassoPanel.setVisibility(View.GONE);
                    brushPanel.setVisibility(View.GONE);
                    eraserPanel.setVisibility(View.GONE);
                    bucketPanel.setVisibility(View.VISIBLE);
                    scrollToolsToTop();
                    updateModeBtnUI(btnBrush, btnEraser, btnBucket);
                }
            });

        // ===== 套索：圈选后可清除 / 填充 / 剪切 / 粘贴 =====
        final Button btnLasso = createToolButton(str(R.string.lasso_tool));
        btnLasso.setLayoutParams(new LinearLayout.LayoutParams(lpMode));
        modeRow.addView(btnLasso);

        TextView tvLassoHint = new TextView(this);
        tvLassoHint.setText(str(R.string.lasso_hint));
        tvLassoHint.setTextColor(ThemeManager.getTextSecondaryColor(this));
        tvLassoHint.setTextSize(11);
        tvLassoHint.setPadding(0, 0, 0, (int)(6*density));
        lassoPanel.addView(tvLassoHint);

        LinearLayout lassoRow = new LinearLayout(this);
        lassoRow.setOrientation(LinearLayout.HORIZONTAL);

        Button btnLassoErase = createToolButton(str(R.string.lasso_erase));
        btnLassoErase.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!zoomImage.hasLasso()) { toast(R.string.lasso_need_selection); return; }
                    if (zoomImage.lassoErase()) toast(R.string.lasso_done);
                    else toast(R.string.lasso_fail);
                }
            });
        lassoRow.addView(btnLassoErase);

        Button btnLassoFill = createToolButton(str(R.string.lasso_fill));
        btnLassoFill.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!zoomImage.hasLasso()) { toast(R.string.lasso_need_selection); return; }
                    int color = Color.rgb(drawR, drawG, drawB);
                    if (zoomImage.lassoFill(color)) toast(R.string.lasso_done);
                    else toast(R.string.lasso_fail);
                }
            });
        lassoRow.addView(btnLassoFill);

        Button btnLassoCut = createToolButton(str(R.string.lasso_cut));
        btnLassoCut.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!zoomImage.hasLasso()) { toast(R.string.lasso_need_selection); return; }
                    if (zoomImage.lassoCut()) toast(R.string.lasso_cut_done);
                    else toast(R.string.lasso_fail);
                }
            });
        lassoRow.addView(btnLassoCut);

        final Button btnLassoMove = createToolButton(str(R.string.lasso_move));
        btnLassoMove.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (zoomImage.isLassoMoving()) {
                        // 正在移动：点一下就当落下
                        if (zoomImage.lassoEndMove()) toast(R.string.lasso_done);
                        return;
                    }
                    if (!zoomImage.hasLassoClip()) { toast(R.string.lasso_no_clip); return; }
                    if (zoomImage.lassoStartMove()) {
                        btnLassoMove.setText(str(R.string.lasso_move_done));
                        toast(R.string.lasso_move_hint);
                    } else {
                        toast(R.string.lasso_fail);
                    }
                }
            });
        lassoRow.addView(btnLassoMove);

        Button btnLassoPaste = createToolButton(str(R.string.lasso_paste));
        btnLassoPaste.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!zoomImage.hasLassoClip()) { toast(R.string.lasso_no_clip); return; }
                    if (zoomImage.lassoPaste()) toast(R.string.lasso_done);
                    else toast(R.string.lasso_fail);
                }
            });
        lassoRow.addView(btnLassoPaste);

        lassoPanel.addView(lassoRow);
        list.addView(lassoPanel);

        btnLasso.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    btnLassoMove.setText(str(R.string.lasso_move));
                    zoomImage.setBrushMode(3);
                    updateModeBtnUI(btnBrush, btnEraser, btnBucket);
                    brushPanel.setVisibility(View.GONE);
                    eraserPanel.setVisibility(View.GONE);
                    bucketPanel.setVisibility(View.GONE);
                    lassoPanel.setVisibility(View.VISIBLE);
                }
            });

        int curMode = zoomImage.getBrushMode();
        if (curMode == 0) { brushPanel.setVisibility(View.VISIBLE); eraserPanel.setVisibility(View.GONE); bucketPanel.setVisibility(View.GONE); }
        else if (curMode == 1) { brushPanel.setVisibility(View.GONE); eraserPanel.setVisibility(View.VISIBLE); bucketPanel.setVisibility(View.GONE); }
        else if (curMode == 2) { brushPanel.setVisibility(View.GONE); eraserPanel.setVisibility(View.GONE); bucketPanel.setVisibility(View.VISIBLE); }
        else if (curMode == 3) { brushPanel.setVisibility(View.GONE); eraserPanel.setVisibility(View.GONE); bucketPanel.setVisibility(View.GONE); lassoPanel.setVisibility(View.VISIBLE); }
        
        updateModeBtnUI(btnBrush, btnEraser, btnBucket);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, (int)(12*density), 0, (int)(8*density));
        Button btnUndo = createToolButton(LanguageManager.getString(this, R.string.undo_stroke));
        btnUndo.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if (zoomImage.undoDraw()) { hasUnsavedChanges = true; updateHistogram(); } } });
        btnRow.addView(btnUndo);
        Button btnClear = createToolButton(LanguageManager.getString(this, R.string.clear_draw));
        btnClear.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { zoomImage.clearDraw(); hasUnsavedChanges = true; updateHistogram(); } });
        btnRow.addView(btnClear);
        int undoGap = (int)(4 * density);
        for (int i = 0; i < btnRow.getChildCount(); i++) {
            View v = btnRow.getChildAt(i);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(undoGap, 0, undoGap, 0);
            v.setLayoutParams(lp);
        }
        list.addView(btnRow);
        // 内容变多后可能超出可视高度，包一层 ScrollView 保证底部色块/自定义 RGB 能滚动看到
        ScrollView panelScroll = new ScrollView(this);
        panelScroll.setFillViewport(true);
        panelScroll.addView(list);
        toolContent.addView(panelScroll);
    }

    private void updateModeBtnUI(Button b1, Button b2, Button b3) {
        int normalBg = ThemeManager.getButtonColor(this);
        int normalText = ThemeManager.getTextColor(this);
        int mode = zoomImage.getBrushMode();
        
        b1.setBackground(getRoundBg(mode == 0 ? 0xFFFFB615 : normalBg));
        b1.setTextColor(mode == 0 ? Color.BLACK : normalText);
        
        b2.setBackground(getRoundBg(mode == 1 ? 0xFFFFB615 : normalBg));
        b2.setTextColor(mode == 1 ? Color.BLACK : normalText);
        
        b3.setBackground(getRoundBg(mode == 2 ? 0xFFFFB615 : normalBg));
        b3.setTextColor(mode == 2 ? Color.BLACK : normalText);
    }
    
    private void updateSymmetryBtnState(Button btnSymmetry) {
        if (btnSymmetry == null) return;
        if (zoomImage.isSymmetryOn()) {
            btnSymmetry.setBackground(getRoundBg(0xFFFFB615));
            btnSymmetry.setTextColor(Color.BLACK);
        } else {
            btnSymmetry.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
            btnSymmetry.setTextColor(ThemeManager.getTextColor(this));
        }
    }

    private void showSymmetryDialog(final Button btnSymmetry) {
        String[] options = {
            LanguageManager.getString(this, R.string.symmetry_off),
            LanguageManager.getString(this, R.string.symmetry_vertical),
            LanguageManager.getString(this, R.string.symmetry_horizontal),
            LanguageManager.getString(this, R.string.symmetry_center)
        };
        showCustomDialog(LanguageManager.getString(this, R.string.symmetry_title), options, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    zoomImage.setSymmetryOn(false);
                } else if (which == 1) {
                    zoomImage.setSymmetryOn(true);
                    zoomImage.setSymmetryType(0);
                } else if (which == 2) {
                    zoomImage.setSymmetryOn(true);
                    zoomImage.setSymmetryType(1);
                } else if (which == 3) {
                    zoomImage.setSymmetryOn(true);
                    zoomImage.setSymmetryType(2);
                }
                updateSymmetryBtnState(btnSymmetry);
            }
        });
    }

    private void addRgbRow(LinearLayout parent, final String label, int defaultValue, final OnSeekBarChangeListener listener) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView tvLabel = new TextView(this); tvLabel.setText(label + sep()); tvLabel.setTextColor(ThemeManager.getTextColor(this)); row.addView(tvLabel);
        final SeekBar sb = new SeekBar(this); LinearLayout.LayoutParams seekLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); sb.setLayoutParams(seekLp);
        sb.setMax(255); sb.setProgress(defaultValue);
        fixSeekBarColor(sb);
        row.addView(sb);
        final EditText et = new EditText(this); LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(160, LinearLayout.LayoutParams.WRAP_CONTENT); et.setLayoutParams(etLp);
        final int[] lastRgbShown = {defaultValue};
        et.setText(String.valueOf(defaultValue)); et.setInputType(InputType.TYPE_CLASS_NUMBER); et.setTextColor(ThemeManager.getTextColor(this)); et.setBackgroundColor(ThemeManager.isDark(this) ? Color.parseColor("#3A3A3A") : Color.parseColor("#EEEEEE")); row.addView(et);

        if (label.equals("R")) { seekR = sb; etR = et; } else if (label.equals("G")) { seekG = sb; etG = et; } else if (label.equals("B")) { seekB = sb; etB = et; }

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (fromUser) {
                        if (progress != lastRgbShown[0]) {
                            lastRgbShown[0] = progress;
                            et.setText(String.valueOf(progress));
                        }
                        listener.onProgressChanged(progress);
                        if (etHex != null && !isUpdatingColor) { isUpdatingColor = true; etHex.setText(String.format("%02X%02X%02X", drawR, drawG, drawB)); isUpdatingColor = false; }
                    }
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });

        et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        try {
                            int value = Integer.parseInt(et.getText().toString()); if (value < 0) value = 0; if (value > 255) value = 255;
                            sb.setProgress(value); et.setText(String.valueOf(value)); listener.onProgressChanged(value);
                            if (etHex != null && !isUpdatingColor) { isUpdatingColor = true; etHex.setText(String.format("%02X%02X%02X", drawR, drawG, drawB)); isUpdatingColor = false; }
                        } catch (Throwable e) { et.setText("0"); sb.setProgress(0); listener.onProgressChanged(0); }
                    }
                }
            });
        parent.addView(row);
    }

    private void applyCustomColor() {
        int color = Color.rgb(drawR, drawG, drawB); zoomImage.setDrawColor(color);
        // 预设色块高亮：颜色完全一致才亮，否则全部不亮
        try { updateSwatchSelection(); } catch (Throwable ignored) {}
        if (colorPreview != null) colorPreview.setBackground(getRoundBg(color));
        if (!isUpdatingColor) {
            isUpdatingColor = true;
            if (seekR != null) seekR.setProgress(drawR); if (etR != null) etR.setText(String.valueOf(drawR));
            if (seekG != null) seekG.setProgress(drawG); if (etG != null) etG.setText(String.valueOf(drawG));
            if (seekB != null) seekB.setProgress(drawB); if (etB != null) etB.setText(String.valueOf(drawB));
            if (etHex != null) etHex.setText(String.format("%02X%02X%02X", drawR, drawG, drawB));
            isUpdatingColor = false;
        }
    }

    /** 直接导出：点「导出」标签立即执行，去掉中间那个多余的按钮。 */
    private void doExportNow() {
        currentTool = "export";
        updateButtonHighlight(btnExport);
        if (toolContent != null) toolContent.removeAllViews();
        scrollToolsToTop();

                    final LoadingDialog pd = new LoadingDialog(activity2Main.this, LanguageManager.getString(activity2Main.this, R.string.loading_saving));
                    pd.show();

                    new Thread(new Runnable() {
                            @Override
                            public void run() {
                                Bitmap fullBitmap = loadFullResBitmap();
                                if (fullBitmap == null) {
                                    runOnUiThread(new Runnable() { @Override public void run() { pd.dismiss(); toastLong(R.string.raw_load_fail); } });
                                    return;
                                }
                                Bitmap currentBmp = null;
                                try { currentBmp = zoomImage.exportFullRes(fullBitmap); } catch (Throwable e) { currentBmp = null; }
                                if (currentBmp == null) {
                                    runOnUiThread(new Runnable() { @Override public void run() { pd.dismiss(); toastLong(R.string.render_oom_fail); } });
                                    if (fullBitmap != null && !fullBitmap.isRecycled()) fullBitmap.recycle();
                                    return;
                                }
                                if (fullBitmap != currentBmp && !fullBitmap.isRecycled()) fullBitmap.recycle();
                                try {
                                    java.io.File cacheFile = new java.io.File(getCacheDir(), "export_temp.png");
                                    java.io.FileOutputStream fos = new java.io.FileOutputStream(cacheFile);
                                    currentBmp.compress(Bitmap.CompressFormat.PNG, 100, fos); fos.close();
                                    final Intent intent = new Intent(activity2Main.this, ExportActivity.class);
                                    intent.setData(Uri.fromFile(cacheFile));
                                    runOnUiThread(new Runnable() { @Override public void run() { pd.dismiss(); startActivity(intent); hasUnsavedChanges = false; } });
                                } catch (Throwable e) { runOnUiThread(new Runnable() { @Override public void run() { pd.dismiss(); } }); }
                            }
                        }).start();
    }

    /**
     * 读取并保存照片的 EXIF 信息（参考 Lightroom 的「相机信息」面板）。
     *
     * 分组：
     *   [相机]   制造商 / 型号 / 镜头
     *   [拍摄]   光圈 / 快门 / ISO / 焦距 / 等效35mm / 曝光补偿 / 测光 / 闪光
     *   [时间]   拍摄时间 / 数字化时间
     *   [图像]   尺寸 / 朝向 / 色彩空间 / 分辨率
     *   [位置]   经纬度 / 海拔
     *   [软件]   软件 / 作者 / 版权
     */




    private void loadImage(final Uri imageUri, final boolean isBlank) {
        if (isBlank) {
            Bitmap blankBitmap = Bitmap.createBitmap(CANVAS_SIZE, CANVAS_SIZE, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(blankBitmap);
            canvas.drawColor(Color.WHITE);
            zoomImage.setImageBitmap(blankBitmap);
            updateHistogram();
            return;
        }

        final LoadingDialog pd = new LoadingDialog(this, LanguageManager.getString(this, R.string.loading_saving));
        pd.show();

        new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        // 1. 历史记录加载
                        if (editFilePath != null && !editFilePath.isEmpty()) {
                            final Bitmap bitmap = HistoryManager.decodeSampledBitmap(editFilePath, 4000, 4000);
                            runOnUiThread(new Runnable() {
                                    @Override public void run() {
                                        pd.dismiss();
                                        if (bitmap != null) {
                                            zoomImage.setImageBitmap(bitmap);
                                            loadFilterParams();
                                            updateHistogram();
                                        } else {
                                            zoomImage.setImageResource(R.drawable.error_image);
                                        }
                                    }
                                });
                            return;
                        }

                        // 2. 新图片导入
                        if (imageUri != null) {
                            sourceImageUri = imageUri;
                            ExifInfo.save(activity2Main.this, imageUri, currentStepsDir);

                            if (!isCurrentImageRaw) {
                                String fileName = HistoryManager.getFileNameFromUri(activity2Main.this, imageUri);
                                String lowerName = fileName != null ? fileName.toLowerCase() : "";
                                isCurrentImageRaw = lowerName.endsWith(".dng") || lowerName.endsWith(".cr2") ||
                                    lowerName.endsWith(".nef") || lowerName.endsWith(".arw") ||
                                    lowerName.endsWith(".orf") || lowerName.endsWith(".raf") ||
                                    lowerName.endsWith(".pef");
                            }

                            // ★ 3. RAW 真正解码逻辑
                            if (isCurrentImageRaw) {
                                String filePath = null;
                                boolean isTempFile = false; 
                                
                                if (imageUri.getScheme() != null && imageUri.getScheme().equals("file")) {
                                    filePath = imageUri.getPath();
                                } else {
                                    String fileName = HistoryManager.getFileNameFromUri(activity2Main.this, imageUri);
                                    if (fileName == null || fileName.isEmpty()) fileName = "temp_raw.dng";
                                    File tempFile = new File(getCacheDir(), fileName);
                                    try {
                                        InputStream is = getContentResolver().openInputStream(imageUri);
                                        FileOutputStream fos = new FileOutputStream(tempFile);
                                        byte[] buf = new byte[8192]; int len;
                                        while ((len = is.read(buf)) > 0) fos.write(buf, 0, len);
                                        fos.close(); 
                                        is.close();
                                        filePath = tempFile.getAbsolutePath();
                                        isTempFile = true;
                                    } catch (Throwable e) { filePath = null; }
                                }

                                if (filePath != null) {
                                    com.homesoft.photo.libraw.LibRaw raw = null;
                                    try {
                                        raw = new com.homesoft.photo.libraw.LibRaw();
                                        int ret = raw.open(filePath);
                                        if (ret == 0) { 
                                            raw.setQuality(3);
                                            raw.setHalfSize(true); 
                                            
                                            raw.setCameraWhiteBalance(true); 
                                            raw.setAutoWhiteBalance(false); 
                                            raw.setUseCameraMatrix(1); 
                                            raw.setOutputColorSpace(1); 
                                            
                                            ret = raw.dcrawProcess();
                                            if (ret == 0) {
                                                final Bitmap rawBmp = raw.getMutableBitmap(Bitmap.Config.ARGB_8888);
                                                if (rawBmp != null) {
                                                    runOnUiThread(new Runnable() {
                                                            @Override public void run() {
                                                                pd.dismiss();
                                                                zoomImage.setImageBitmap(rawBmp);
                                                                loadFilterParams();
                                                                updateHistogram();
                                                            }
                                                        });
                                                    return; 
                                                }
                                            }
                                        }
                                    } catch (Throwable e) {
                                        e.printStackTrace();
                                    } finally {
                                        if (raw != null) {
                                            try { raw.close(); } catch (Throwable ignored) {}
                                        }
                                        if (isTempFile && filePath != null) {
                                            try { new File(filePath).delete(); } catch (Throwable ignored) {}
                                        }
                                    }
                                }

                                runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            pd.dismiss();
                                            showRawFallbackDialog(imageUri);
                                        }
                                    });
                                return;
                            }

                            // 5. 非 RAW 文件
                            loadAsJpeg(imageUri, pd);
                            return;
                        }
                        
                        runOnUiThread(new Runnable() {
                                @Override public void run() { pd.dismiss(); }
                            });
                    } catch (Throwable e) {
                        runOnUiThread(new Runnable() {
                                @Override public void run() { pd.dismiss(); zoomImage.setImageResource(R.drawable.error_image); }
                            });
                    }
                }
            }).start();
    }

    private void showRawFallbackDialog(final Uri imageUri) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getPanelLayerBg());
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(10*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText("RAW 解析失败");
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        TextView tvMsg = new TextView(this);
        tvMsg.setText("未能提取到高质量预览图，是否强制使用系统内置的低画质 JPEG 打开？\n(可能会出现死白或偏色)");
        tvMsg.setTextSize(13);
        tvMsg.setTextColor(ThemeManager.getTextColor(this));
        tvMsg.setGravity(Gravity.CENTER);
        tvMsg.setPadding(0, (int)(15*density), 0, (int)(20*density));
        root.addView(tvMsg);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnCancel = new TextView(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnCancel.setBackground(getRoundBg(0xFF555555));
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp1.setMargins(0, 0, (int)(10*density), 0);
        btnCancel.setLayoutParams(lp1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dialog.dismiss();
                    finish(); 
                }
            });
        btnRow.addView(btnCancel);

        TextView btnOk = new TextView(this);
        btnOk.setText("使用JPEG");
        btnOk.setTextSize(15);
        btnOk.setTextColor(Color.BLACK);
        btnOk.setGravity(Gravity.CENTER);
        btnOk.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnOk.setBackground(getRoundBg(0xFFFFB615));
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f));
        btnOk.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dialog.dismiss();
                    final LoadingDialog pd = new LoadingDialog(activity2Main.this, LanguageManager.getString(activity2Main.this, R.string.loading_saving));
                    pd.show();
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            loadAsJpeg(imageUri, pd);
                        }
                    }).start();
                }
            });
        btnRow.addView(btnOk);

        root.addView(btnRow);
        dialog.setContentView(root);
        
        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.85);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void loadAsJpeg(final Uri imageUri, final LoadingDialog pd) {
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            InputStream is1 = getContentResolver().openInputStream(imageUri);
            BitmapFactory.decodeStream(is1, null, options);
            if (is1 != null) is1.close();

            options.inSampleSize = calculateInSampleSize(options, 4000, 4000);
            options.inJustDecodeBounds = false;
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            // ★ 可变：抠图等操作要直接改底图像素（原地改，不换 Bitmap 对象）
            options.inMutable = true;

            InputStream is2 = getContentResolver().openInputStream(imageUri);
            Bitmap bitmap = null;
            try { bitmap = BitmapFactory.decodeStream(is2, null, options); } catch (Throwable ignored) {}
            if (is2 != null) is2.close();

            final Bitmap finalBmp = bitmap;
            runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (pd != null && pd.isShowing()) pd.dismiss();
                        if (finalBmp != null) {
                            zoomImage.setImageBitmap(finalBmp);
                            loadFilterParams();
                            updateHistogram();
                        } else {
                            Toast.makeText(activity2Main.this, "JPEG 解码失败", Toast.LENGTH_SHORT).show();
                            zoomImage.setImageResource(R.drawable.error_image);
                        }
                    }
                });
        } catch (Throwable e) {
            runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (pd != null && pd.isShowing()) pd.dismiss();
                        zoomImage.setImageResource(R.drawable.error_image);
                    }
                });
        }
    }

    private void startRawDecoder(final Uri finalUri) {
        new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        byte[] rawData = HistoryManager.readBytesFromUri(activity2Main.this, finalUri);
                        if (rawData == null) return;
                        final File cacheFile = new File(getCacheDir(), "temp_raw_data.raw");
                        java.io.FileOutputStream fos = new java.io.FileOutputStream(cacheFile);
                        fos.write(rawData); fos.close();
                        runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Intent intent = new Intent(activity2Main.this, RawDecoderActivity.class);
                                    intent.putExtra("raw_file_path", cacheFile.getAbsolutePath());
                                    startActivity(intent); finish();
                                }
                            });
                    } catch (final Throwable e) {}
                }
            }).start();
    }

    private int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    /** 去掉步骤图扩展名（本地副本，避免跨类调用的兼容问题）。 */
    private static String stripStepExtLocal(String name) {
        if (name == null) return "";
        if (name.endsWith(".webp")) return name.substring(0, name.length() - 5);
        if (name.endsWith(".png")) return name.substring(0, name.length() - 4);
        return name;
    }

    private String lutToString(int[] lut) {
        if (lut == null) return null;
        byte[] bytes = new byte[lut.length];
        for (int i = 0; i < lut.length; i++) bytes[i] = (byte) lut[i];
        return Base64.encodeToString(bytes, Base64.NO_WRAP);
    }

    private int[] stringToLut(String str) {
        if (str == null) return null;
        try {
            byte[] bytes = Base64.decode(str, Base64.NO_WRAP);
            int[] lut = new int[bytes.length];
            for (int i = 0; i < bytes.length; i++) lut[i] = bytes[i] & 0xFF;
            return lut;
        } catch (Throwable e) { return null; }
    }

    private void saveFilterParams() {
        try {
            CrashLogger.logInfo("滤镜保存", "editFilePath=" + editFilePath
                    + " 亮度=" + zoomImage.getBrightness());
        } catch (Throwable ignored) {}
        if (editFilePath == null || editFilePath.isEmpty()) return;

        SharedPreferences sp = getSharedPreferences("weifp_filters", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        // 用户手动调整过：记录标记，读取时以用户的值为准而不是"AI 烘焙置中性"
        editor.putBoolean(editFilePath + "_user_adjusted", true);
        editor.putFloat(editFilePath + "_bright", zoomImage.getRealBrightness());
        editor.putFloat(editFilePath + "_cont", zoomImage.getRealContrast());
        editor.putFloat(editFilePath + "_sat", zoomImage.getRealSaturation());
        editor.putFloat(editFilePath + "_shadow", zoomImage.getRealShadows());
        editor.putFloat(editFilePath + "_high", zoomImage.getRealHighlights());
        editor.putFloat(editFilePath + "_temp", zoomImage.getRealTemperature());
        editor.putFloat(editFilePath + "_tint", zoomImage.getRealTint());
        editor.putFloat(editFilePath + "_sharp", zoomImage.getSharpness());
        editor.putFloat(editFilePath + "_vibrance", zoomImage.getVibrance());
        editor.putFloat(editFilePath + "_color_noise", zoomImage.getColorNoise());
        editor.putFloat(editFilePath + "_luma_noise", zoomImage.getLumaNoise());

        SplitToning st = zoomImage.getSplitToning();
        // 局部蒙版（JSON 文本，画笔数据 base64）
        try {
            String maskData = Mask.serialize(zoomImage.getMasks(), currentStepsDir);
            if (maskData.length() > 0) {
                editor.putString(editFilePath + "_masks", maskData);
            } else {
                editor.remove(editFilePath + "_masks");
            }
        } catch (Throwable ignored) {}

        editor.putFloat(editFilePath + "_split_sh_hue", st.shadowHue);
        editor.putFloat(editFilePath + "_split_sh_sat", st.shadowSat);
        editor.putFloat(editFilePath + "_split_hi_hue", st.highlightHue);
        editor.putFloat(editFilePath + "_split_hi_sat", st.highlightSat);
        editor.putInt(editFilePath + "_split_bal", st.balance);

        editor.putFloat(editFilePath + "_cb_s0", zoomImage.getCbShadowR());
        editor.putFloat(editFilePath + "_cb_s1", zoomImage.getCbShadowG());
        editor.putFloat(editFilePath + "_cb_s2", zoomImage.getCbShadowB());
        editor.putFloat(editFilePath + "_cb_m0", zoomImage.getCbMidR());
        editor.putFloat(editFilePath + "_cb_m1", zoomImage.getCbMidG());
        editor.putFloat(editFilePath + "_cb_m2", zoomImage.getCbMidB());
        editor.putFloat(editFilePath + "_cb_h0", zoomImage.getCbHighR());
        editor.putFloat(editFilePath + "_cb_h1", zoomImage.getCbHighG());
        editor.putFloat(editFilePath + "_cb_h2", zoomImage.getCbHighB());

        editor.putString(editFilePath + "_lut_m", lutToString(zoomImage.getMasterLUT()));
        editor.putString(editFilePath + "_lut_r", lutToString(zoomImage.getRLUT()));
        editor.putString(editFilePath + "_lut_g", lutToString(zoomImage.getGLUT()));
        editor.putString(editFilePath + "_lut_b", lutToString(zoomImage.getBLUT()));

        String[] pStrs = zoomImage.getCurvePointStrs();
        if (pStrs != null) {
            editor.putString(editFilePath + "_pts_m", pStrs[0]);
            editor.putString(editFilePath + "_pts_r", pStrs[1]);
            editor.putString(editFilePath + "_pts_g", pStrs[2]);
            editor.putString(editFilePath + "_pts_b", pStrs[3]);
        }

        if (currentLutPath != null) {
            editor.putString(editFilePath + "_cube_path", currentLutPath);
            editor.putFloat(editFilePath + "_cube_strength", zoomImage.getCubeStrength());
        } else {
            editor.remove(editFilePath + "_cube_path");
            editor.remove(editFilePath + "_cube_strength");
        }

        zoomImage.getLayerManager().saveLayerBitmaps(currentStepsDir);
        String layerData = zoomImage.getLayerManager().getSerializedString();
        editor.putString(editFilePath + "_layer_data", layerData);

        for (int i = 0; i < 4; i++) {
            editor.putInt(editFilePath + "_lv_b_" + i, zoomImage.getLevelsBlack(i));
            editor.putInt(editFilePath + "_lv_g_" + i, zoomImage.getLevelsGray(i));
            editor.putInt(editFilePath + "_lv_w_" + i, zoomImage.getLevelsWhite(i));
        }

        HslAdjust hsave = zoomImage.getHslAdjust();
        for (int i = 0; i < 8; i++) {
            editor.putFloat(editFilePath + "_hsl_hue_" + i, hsave.hue[i]);
            editor.putFloat(editFilePath + "_hsl_sat_" + i, hsave.sat[i]);
            editor.putFloat(editFilePath + "_hsl_lum_" + i, hsave.lum[i]);
        }

        editor.putInt(editFilePath + "_current_layer", zoomImage.getCurrentLayerIndex());

        editor.putBoolean(editFilePath + "_has_wpb", true);
        editor.putBoolean(editFilePath + "_is_raw", isCurrentImageRaw);

        editor.apply();
    }

    private void saveFilterParamsToKey(String key) {
        SharedPreferences sp = getSharedPreferences("weifp_filters", MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        e.putFloat(key + "_bright", zoomImage.getRealBrightness());
        e.putFloat(key + "_cont", zoomImage.getRealContrast());
        e.putFloat(key + "_sat", zoomImage.getRealSaturation());
        e.putFloat(key + "_shadow", zoomImage.getRealShadows());
        e.putFloat(key + "_high", zoomImage.getRealHighlights());
        e.putFloat(key + "_temp", zoomImage.getRealTemperature());
        e.putFloat(key + "_tint", zoomImage.getRealTint());
        e.putFloat(key + "_sharp", zoomImage.getSharpness());
        e.commit();
    }

    private void loadFilterParams() {
        try {
            CrashLogger.logInfo("滤镜读取", "editFilePath=" + editFilePath
                    + " 亮度=" + (editFilePath == null ? -1
                        : getSharedPreferences("weifp_filters", MODE_PRIVATE)
                            .getFloat(editFilePath + "_bright", 0)));
        } catch (Throwable ignored) {}
        if (editFilePath == null || editFilePath.isEmpty()) return;
        SharedPreferences sp = getSharedPreferences("weifp_filters", MODE_PRIVATE);
        float b = sp.getFloat(editFilePath + "_bright", 0);
        float c = sp.getFloat(editFilePath + "_cont", 1);
        float s = sp.getFloat(editFilePath + "_sat", 1);
        float sh = sp.getFloat(editFilePath + "_shadow", 0);
        float hi = sp.getFloat(editFilePath + "_high", 0);
        float te = sp.getFloat(editFilePath + "_temp", 0);
        float ti = sp.getFloat(editFilePath + "_tint", 0);
        float spd = sp.getFloat(editFilePath + "_sharp", 0);

        isCurrentImageRaw = sp.getBoolean(editFilePath + "_is_raw", false);
        checkRawAndDisableDraw();

        // 恢复局部蒙版
        try {
            String maskData = sp.getString(editFilePath + "_masks", "");
            if (maskData != null && maskData.length() > 0) {
                java.util.List<Mask.MaskItem> list = Mask.deserialize(maskData, currentStepsDir);
                zoomImage.restoreMasks(list);
            }
        } catch (Throwable ignored) {}

        // AI 处理过的图：像素已经烘焙，滤镜必须保持中性，否则会二次叠加。
        //
        // 关键：用户一旦自己调过参数（_bright 等被写过），就以用户的值为准——
        // 否则"AI 处理过的图"永远无法再手动调整，改了也被丢掉。
        boolean aiBaked = false;
        boolean userAdjusted = false;
        try {
            aiBaked = sp.getBoolean(editFilePath + "_ai_baked", false);
            userAdjusted = sp.getBoolean(editFilePath + "_user_adjusted", false);
        } catch (Throwable ignored) {}

        if (aiBaked && !userAdjusted) {
            // 纯 AI 结果：实际滤镜置中性，滑轨显示 AI 用过的数值
            zoomImage.setAllFilters(0, 1, 1, 0, 0, 0, 0, spd);
            try {
                zoomImage.setDisplayOnlyFilters(
                        sp.getFloat(editFilePath + "_ai_bright", 0),
                        sp.getFloat(editFilePath + "_ai_cont", 0),
                        sp.getFloat(editFilePath + "_ai_sat", 0),
                        sp.getFloat(editFilePath + "_ai_shadow", 0),
                        sp.getFloat(editFilePath + "_ai_high", 0),
                        sp.getFloat(editFilePath + "_ai_temp", 0),
                        sp.getFloat(editFilePath + "_ai_tint", 0));
            } catch (Throwable ignored) {}
        } else {
            // 普通图，或者用户已经在 AI 结果上手动调过：以存储的值为准
            // 防呆：饱和度/对比度存成 0 或负数说明数据坏了（正常是 0.01~2），
            // 老版本 bug 会把显示值 0 写进来，这里纠正回中性。
            if (s <= 0.01f) s = 1f;
            if (c <= 0.01f) c = 1f;
            zoomImage.setAllFilters(b, c, s, sh, hi, te, ti, spd);
        }

        float colorNoise = sp.getFloat(editFilePath + "_color_noise", 0);
        float lumaNoise = sp.getFloat(editFilePath + "_luma_noise", 0);
        if (colorNoise > 0.01f || lumaNoise > 0.01f) {
            zoomImage.setColorNoise(colorNoise);
            zoomImage.setLumaNoise(lumaNoise);
        }

        float vib = sp.getFloat(editFilePath + "_vibrance", 0);
        zoomImage.setVibrance(vib);
        SplitToning st = new SplitToning();
        st.shadowHue = sp.getFloat(editFilePath + "_split_sh_hue", 0);
        st.shadowSat = sp.getFloat(editFilePath + "_split_sh_sat", 0);
        st.highlightHue = sp.getFloat(editFilePath + "_split_hi_hue", 0);
        st.highlightSat = sp.getFloat(editFilePath + "_split_hi_sat", 0);
        st.balance = sp.getInt(editFilePath + "_split_bal", 0);
        zoomImage.setSplitToning(st);

        float cs0 = sp.getFloat(editFilePath + "_cb_s0", 0f);
        float cs1 = sp.getFloat(editFilePath + "_cb_s1", 0f);
        float cs2 = sp.getFloat(editFilePath + "_cb_s2", 0f);
        float cm0 = sp.getFloat(editFilePath + "_cb_m0", 0f);
        float cm1 = sp.getFloat(editFilePath + "_cb_m1", 0f);
        float cm2 = sp.getFloat(editFilePath + "_cb_m2", 0f);
        float ch0 = sp.getFloat(editFilePath + "_cb_h0", 0f);
        float ch1 = sp.getFloat(editFilePath + "_cb_h1", 0f);
        float ch2 = sp.getFloat(editFilePath + "_cb_h2", 0f);
        zoomImage.setColorBalance(cs0, cs1, cs2, cm0, cm1, cm2, ch0, ch1, ch2);

        int[] m = stringToLut(sp.getString(editFilePath + "_lut_m", null));
        int[] r = stringToLut(sp.getString(editFilePath + "_lut_r", null));
        int[] g = stringToLut(sp.getString(editFilePath + "_lut_g", null));
        int[] bLut = stringToLut(sp.getString(editFilePath + "_lut_b", null));

        String[] pStrs = new String[4];
        pStrs[0] = sp.getString(editFilePath + "_pts_m", null);
        pStrs[1] = sp.getString(editFilePath + "_pts_r", null);
        pStrs[2] = sp.getString(editFilePath + "_pts_g", null);
        pStrs[3] = sp.getString(editFilePath + "_pts_b", null);

        if (m != null || r != null || g != null || bLut != null || pStrs[0] != null) {
            zoomImage.setRGBLUTs(m, r, g, bLut, pStrs);
        }

        String lutPath = sp.getString(editFilePath + "_cube_path", null);
        if (lutPath != null) {
            File lutFile = new File(lutPath);
            if (lutFile.exists()) {
                CubeLut lut = LutManager.loadLut(lutFile);
                if (lut != null) {
                    zoomImage.setCubeLut(lut);
                    currentLutPath = lutPath;
                    currentLutName = lut.title;
                    zoomImage.setCubeStrength(sp.getFloat(editFilePath + "_cube_strength", 1.0f));
                }
            }
        }

        HslAdjust hload = zoomImage.getHslAdjust();
        for (int i = 0; i < 8; i++) {
            hload.hue[i] = sp.getFloat(editFilePath + "_hsl_hue_" + i, 0f);
            hload.sat[i] = sp.getFloat(editFilePath + "_hsl_sat_" + i, 0f);
            hload.lum[i] = sp.getFloat(editFilePath + "_hsl_lum_" + i, 0f);
        }
        if (!hload.isEmpty()) {
            zoomImage.setHslAdjust(hload);
        }

        String layerData = sp.getString(editFilePath + "_layer_data", null);
        if (layerData != null && layerData.length() > 0) {
            Map<String, String> lm = new java.util.HashMap<String, String>();
            String[] lines = layerData.split("\n");
            for (int i = 0; i < lines.length; i++) {
                String line = lines[i];
                String[] parts = line.split("=", 2);
                if (parts.length == 2) lm.put(parts[0], parts[1]);
            }
            int ww = CANVAS_SIZE, hh = CANVAS_SIZE;
            if (zoomImage.getDrawable() != null) {
                int iw = zoomImage.getDrawable().getIntrinsicWidth();
                int ih = zoomImage.getDrawable().getIntrinsicHeight();
                if (iw > 0) ww = iw;
                if (ih > 0) hh = ih;
            }
            zoomImage.getLayerManager().deserializeFrom(lm, currentStepsDir, ww, hh);
            zoomImage.getLayerManager().setGlobalAlpha(255);

            for (int i = 0; i < 4; i++) {
                int lvB = sp.getInt(editFilePath + "_lv_b_" + i, 0);
                int lvG = sp.getInt(editFilePath + "_lv_g_" + i, 128);
                int lvW = sp.getInt(editFilePath + "_lv_w_" + i, 255);
                zoomImage.setLevels(i, lvB, lvG, lvW);
            }

            final int bwF = ww, bhF = hh;
            final int savedLayerF = sp.getInt(editFilePath + "_current_layer", 1);
            zoomImage.post(new Runnable() {
                    @Override public void run() {
                        LayerManager lmx = zoomImage.getLayerManager();
                        if (lmx.size() <= 1) {
                            lmx.addBlankLayer(bwF, bhF);
                        }
                        int layerCount = lmx.size();
                        int target = savedLayerF;
                        if (target <= 0) target = 1;
                        if (layerCount > 0 && target >= layerCount) target = layerCount - 1;
                        zoomImage.setCurrentLayerIndex(target);
                        zoomImage.onLayersChanged();
                    }
                });
        }
    }
}
