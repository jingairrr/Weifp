package com.sertrt.weifp;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.List;

/**
 * 套索选区工具（仿 Photoshop 的套索）。
 *
 * 工作流：
 *   1. 手指在画布上画一条闭合路径
 *   2. 路径转换成选区（内部用 Path 做包含判定）
 *   3. 对选区执行：清除 / 填充 / 剪切 / 粘贴
 *
 * 实现要点：
 *  - 用 {@link Path} 的边界 + 逐像素判定，简单可靠（不做扫描线优化，图大了慢一点）
 *  - 选区只记录 Path，操作时才去碰像素，内存开销小
 */
public final class LassoSelection {

    /** 选区路径（画布坐标）。 */
    public final Path path = new Path();
    /** 选区包围盒（画布坐标，整数）。 */
    public final Rect bounds = new Rect();

    private final List<Float> xs = new ArrayList<Float>();
    private final List<Float> ys = new ArrayList<Float>();

    public void reset() {
        path.reset();
        bounds.setEmpty();
        xs.clear();
        ys.clear();
        lastX = Float.NaN;
        lastY = Float.NaN;
    }

    public boolean isEmpty() {
        return xs.size() < 3;
    }

    /** 两点至少隔这么远才记录（画布坐标），避免拖动时产生几千个点。 */
    private static final float MIN_DIST = 2.0f;
    /** 上次记录的点，用于距离判断。 */
    private float lastX = Float.NaN, lastY = Float.NaN;

    /**
     * 加一个点（画布坐标）。
     *
     * 距离太近的会跳过：手指快速拖动时每秒能产生上百个事件，
     * 全记下来的话路径重建和内部判定都会变慢。
     */
    public void addPoint(float x, float y) {
        if (!Float.isNaN(lastX)) {
            float dx = x - lastX, dy = y - lastY;
            if (dx * dx + dy * dy < MIN_DIST * MIN_DIST) return;
        }
        lastX = x;
        lastY = y;
        xs.add(x);
        ys.add(y);
        rebuildPath();
    }

    /** 用已有点重建路径与包围盒。 */
    public void rebuildPath() {
        path.reset();
        if (xs.isEmpty()) {
            bounds.setEmpty();
            return;
        }
        path.moveTo(xs.get(0), ys.get(0));
        for (int i = 1; i < xs.size(); i++) {
            path.lineTo(xs.get(i), ys.get(i));
        }
        path.close();
        buildBounds();
    }

    /** 用已有 Path 设置选区（例如从历史恢复）。 */
    public void setPath(Path p) {
        path.reset();
        if (p != null) path.set(p);
        path.close();
        buildBounds();
    }

    private void buildBounds() {
        RectF rf = new RectF();
        path.computeBounds(rf, true);
        bounds.set((int) Math.floor(rf.left), (int) Math.floor(rf.top),
                (int) Math.ceil(rf.right), (int) Math.ceil(rf.bottom));
        // 裁到合法范围由调用方再处理
    }

    /**
     * 点是否在选择区内。
     *
     * 自己用「射线法」判断，因为 Path.contains(x,y) 要 API 26+，
     * 本项目 minSdk 19，不能用。
     */
    public boolean contains(float x, float y) {
        if (xs.size() < 3) return false;
        // 先用包围盒快速排除
        if (!bounds.isEmpty()) {
            if (x < bounds.left || x > bounds.right || y < bounds.top || y > bounds.bottom) {
                return false;
            }
        }
        return pointInPolygon(x, y);
    }

    /** 射线法：从点向右发射水平线，数穿过多边形边的次数，奇数在内。 */
    private boolean pointInPolygon(float px, float py) {
        boolean inside = false;
        int n = xs.size();
        for (int i = 0, j = n - 1; i < n; j = i++) {
            float xi = xs.get(i), yi = ys.get(i);
            float xj = xs.get(j), yj = ys.get(j);
            // 边是否跨越 py
            if ((yi > py) != (yj > py)) {
                // 计算交点 x
                float xCross = (xj - xi) * (py - yi) / (yj - yi) + xi;
                if (px < xCross) inside = !inside;
            }
        }
        return inside;
    }

    /**
     * 把选区内的像素清成透明（等同 PS 的 Delete）。
     *
     * @param bmp   目标位图（会被直接修改，需 mutable）
     * @param scale 位图相对画布的缩放（位图尺寸 / 画布尺寸）
     * @return 是否有像素被清除
     */
    public boolean eraseRegion(Bitmap bmp, float scale) {
        if (bmp == null || bmp.isRecycled() || isEmpty()) return false;
        if (!bmp.isMutable()) return false;
        int w = bmp.getWidth(), h = bmp.getHeight();
        int l = Math.max(0, (int) (bounds.left * scale));
        int t = Math.max(0, (int) (bounds.top * scale));
        int r = Math.min(w, (int) Math.ceil(bounds.right * scale));
        int b = Math.min(h, (int) Math.ceil(bounds.bottom * scale));
        if (r <= l || b <= t) return false;

        int rw = r - l, rh = b - t;
        int[] px = new int[rw * rh];
        bmp.getPixels(px, 0, rw, l, t, rw, rh);

        boolean changed = false;
        float invScale = scale > 0 ? 1f / scale : 1f;
        for (int y = 0; y < rh; y++) {
            for (int x = 0; x < rw; x++) {
                // 位图坐标 -> 画布坐标
                float cx = (l + x) * invScale;
                float cy = (t + y) * invScale;
                if (contains(cx, cy)) {
                    px[y * rw + x] = 0;
                    changed = true;
                }
            }
        }
        if (changed) bmp.setPixels(px, 0, rw, l, t, rw, rh);
        return changed;
    }

    /**
     * 把选区内像素填成指定颜色（等同 PS 的 Alt+Delete）。
     */
    public boolean fillRegion(Bitmap bmp, float scale, int color) {
        if (bmp == null || bmp.isRecycled() || isEmpty()) return false;
        if (!bmp.isMutable()) return false;
        int w = bmp.getWidth(), h = bmp.getHeight();
        int l = Math.max(0, (int) (bounds.left * scale));
        int t = Math.max(0, (int) (bounds.top * scale));
        int r = Math.min(w, (int) Math.ceil(bounds.right * scale));
        int b = Math.min(h, (int) Math.ceil(bounds.bottom * scale));
        if (r <= l || b <= t) return false;

        int rw = r - l, rh = b - t;
        int[] px = new int[rw * rh];
        bmp.getPixels(px, 0, rw, l, t, rw, rh);

        boolean changed = false;
        float invScale = scale > 0 ? 1f / scale : 1f;
        for (int y = 0; y < rh; y++) {
            for (int x = 0; x < rw; x++) {
                float cx = (l + x) * invScale;
                float cy = (t + y) * invScale;
                if (contains(cx, cy)) {
                    px[y * rw + x] = color;
                    changed = true;
                }
            }
        }
        if (changed) bmp.setPixels(px, 0, rw, l, t, rw, rh);
        return changed;
    }

    /**
     * 把选区内的像素剪切出来（透明 + 返回一张只含选区的位图）。
     *
     * @return 剪出的位图（尺寸 = 包围盒）；失败返回 null
     */
    public Bitmap cutRegion(Bitmap bmp, float scale) {
        if (bmp == null || bmp.isRecycled() || isEmpty()) return null;
        if (!bmp.isMutable()) return null;
        int w = bmp.getWidth(), h = bmp.getHeight();
        int l = Math.max(0, (int) (bounds.left * scale));
        int t = Math.max(0, (int) (bounds.top * scale));
        int r = Math.min(w, (int) Math.ceil(bounds.right * scale));
        int b = Math.min(h, (int) Math.ceil(bounds.bottom * scale));
        if (r <= l || b <= t) return null;

        int rw = r - l, rh = b - t;
        int[] px = new int[rw * rh];
        bmp.getPixels(px, 0, rw, l, t, rw, rh);

        int[] outPx = new int[rw * rh];
        float invScale = scale > 0 ? 1f / scale : 1f;
        for (int y = 0; y < rh; y++) {
            for (int x = 0; x < rw; x++) {
                float cx = (l + x) * invScale;
                float cy = (t + y) * invScale;
                if (contains(cx, cy)) {
                    outPx[y * rw + x] = px[y * rw + x];   // 剪切出来
                    px[y * rw + x] = 0;                    // 原位置清空
                }
            }
        }
        bmp.setPixels(px, 0, rw, l, t, rw, rh);
        Bitmap out = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
        out.setPixels(outPx, 0, rw, 0, 0, rw, rh);
        return out;
    }

    /** 把剪切出来的内容贴到新位置（覆盖）。 */
    public static boolean pasteAt(Bitmap bmp, Bitmap content, int destX, int destY) {
        if (bmp == null || content == null || bmp.isRecycled() || content.isRecycled()) return false;
        if (!bmp.isMutable()) return false;
        try {
            Canvas c = new Canvas(bmp);
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
            c.drawBitmap(content, destX, destY, p);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 画出选区边界（PS 的蚂蚁线，这里用虚线代替）。 */
    public void drawOutline(Canvas canvas, Paint paint) {
        if (isEmpty()) return;
        canvas.drawPath(path, paint);
    }
}
