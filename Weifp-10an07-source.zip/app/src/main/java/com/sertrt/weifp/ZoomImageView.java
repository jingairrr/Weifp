package com.sertrt.weifp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ScaleGestureDetector;
import java.io.File;
import java.io.FileOutputStream;
import android.widget.ImageView;

public class ZoomImageView extends ImageView implements ScaleGestureDetector.OnScaleGestureListener {

    public void commitNoise() {
    }

    public interface OnStepListener { void onStepFinished(); }
    private OnStepListener stepListener;
    public void setOnStepListener(OnStepListener listener) { this.stepListener = listener; }

    public interface OnLayerLockedListener { void onLayerLocked(int layerIndex); }
    private OnLayerLockedListener layerLockedListener;
    public void setOnLayerLockedListener(OnLayerLockedListener listener) { this.layerLockedListener = listener; }

    public interface OnNoiseProgressListener {
        void onProgress(int percent);
        void onFinished(Bitmap result);
    }

    private Matrix matrix = new Matrix();
    private ScaleGestureDetector scaleDetector;
    private GestureDetector gestureDetector;
    private boolean isScaling = false;
    private float currentScale = 1.0f;
    private boolean isFirstLayout = true;

    private Bitmap currentBitmap;
    private EditHistory history = new EditHistory();
    private Bitmap originalBitmap;
    private Bitmap thumbnailBase;

    private float[] cropRatio = null;

    private LayerManager layerManager = new LayerManager();
    private int currentLayerIndex = 0;

    private int brushMode = 0; // 0=画笔, 1=橡皮, 2=油漆桶, 3=套索, 4=魔棒, 5=抠图擦笔

    /** 套索选区。 */
    private final LassoSelection lasso = new LassoSelection();
    /** 套索笔画是否进行中。 */
    private boolean lassoDrawing = false;
    /** 剪切板：套索剪出的内容。 */
    private Bitmap lassoClip = null;
    /** 剪切板原始位置（画布坐标）。 */
    private float lassoClipX = 0, lassoClipY = 0;

    /** 移动模式：剪切后内容跟着手指走，松手落下。 */
    private boolean lassoMoving = false;
    /** 移动中的当前偏移（画布坐标）。 */
    private float lassoMoveDx = 0, lassoMoveDy = 0;
    private float lassoMoveLastX = 0, lassoMoveLastY = 0;
    /** 移动开始时该图层的快照（用于预览时从干净状态重绘）。 */
    private Bitmap lassoMoveBase = null;

    /** 是否处于套索移动模式。 */
    public boolean isLassoMoving() { return lassoMoving; }

    /**
     * 开始移动：把剪切板内容浮起来，之后手指拖动就能移动它。
     */
    public boolean lassoStartMove() {
        if (lassoClip == null || lassoClip.isRecycled()) return false;
        Bitmap target = getCurrentLayerBitmap();
        if (target == null || target.isRecycled() || !target.isMutable()) return false;
        if (lassoMoveBase != null && !lassoMoveBase.isRecycled()) lassoMoveBase.recycle();
        // 记下"还没贴回去"的图层状态，拖动时每帧从这里重绘
        lassoMoveBase = target.copy(Bitmap.Config.ARGB_8888, true);
        if (lassoMoveBase == null) return false;
        lassoMoving = true;
        lassoMoveDx = 0;
        lassoMoveDy = 0;
        invalidate();
        return true;
    }

    /** 结束移动：把内容落到当前位置。 */
    public boolean lassoEndMove() {
        if (!lassoMoving) return false;
        lassoMoving = false;
        Bitmap target = getCurrentLayerBitmap();
        if (target == null || target.isRecycled()) return false;
        Bitmap base = originalBitmap != null && !originalBitmap.isRecycled()
                ? originalBitmap : currentBitmap;
        if (base == null) return false;
        float scale = (float) target.getWidth() / base.getWidth();
        int dx = (int) ((lassoClipX + lassoMoveDx) * scale);
        int dy = (int) ((lassoClipY + lassoMoveDy) * scale);
        boolean ok = LassoSelection.pasteAt(target, lassoClip, dx, dy);
        if (lassoMoveBase != null && !lassoMoveBase.isRecycled()) lassoMoveBase.recycle();
        lassoMoveBase = null;
        if (ok) {
            invalidate();
            if (stepListener != null) stepListener.onStepFinished();
        }
        return ok;
    }

    /** 取消移动：内容回到原位。 */
    public void lassoCancelMove() {
        if (!lassoMoving) return;
        lassoMoving = false;
        Bitmap target = getCurrentLayerBitmap();
        if (lassoMoveBase != null && !lassoMoveBase.isRecycled()) {
            if (target != null && target.isMutable()) {
                try {
                    Canvas rc = new Canvas(target);
                    rc.drawColor(0, android.graphics.PorterDuff.Mode.CLEAR);
                    rc.drawBitmap(lassoMoveBase, 0, 0, null);
                } catch (Throwable ignored) {}
            }
            lassoMoveBase.recycle();
            lassoMoveBase = null;
        }
        lassoMoveDx = 0;
        lassoMoveDy = 0;
        invalidate();
    }

    public LassoSelection getLasso() { return lasso; }

    /** 清空套索选区。 */
    public void clearLasso() {
        lasso.reset();
        lassoDrawing = false;
        invalidate();
    }

    /** 是否有套索选区。 */
    public boolean hasLasso() { return !lasso.isEmpty(); }

    /** 套索操作前记录当前图层快照，保证可撤销。 */
    private void snapshotLayerBeforeLasso() {
        try {
            if (currentLayerIndex < 0 || currentLayerIndex >= layerManager.size()) return;
            LayerManager.LayerItem layer = layerManager.get(currentLayerIndex);
            if (layer == null || layer.bitmap == null || layer.bitmap.isRecycled()) return;
            Bitmap snap = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true);
            if (snap != null) {
                history.addDrawLayer(currentLayerIndex, snap);
            }
        } catch (Throwable ignored) {
        }
    }

    /** 清除套索选区内的像素。 */
    public boolean lassoErase() {
        snapshotLayerBeforeLasso();
        Bitmap target = getCurrentLayerBitmap();
        if (target == null || target.isRecycled()) return false;
        // 图层位图与画布尺寸可能不同，算个比例
        Bitmap base = originalBitmap != null && !originalBitmap.isRecycled()
                ? originalBitmap : currentBitmap;
        if (base == null) return false;
        float scale = (float) target.getWidth() / base.getWidth();
        boolean ok = lasso.eraseRegion(target, scale);
        if (ok) {
            lasso.reset();
            invalidate();
            if (stepListener != null) stepListener.onStepFinished();
        }
        return ok;
    }

    /** 用指定颜色填充套索选区。 */
    public boolean lassoFill(int color) {
        snapshotLayerBeforeLasso();
        Bitmap target = getCurrentLayerBitmap();
        if (target == null || target.isRecycled()) return false;
        Bitmap base = originalBitmap != null && !originalBitmap.isRecycled()
                ? originalBitmap : currentBitmap;
        if (base == null) return false;
        float scale = (float) target.getWidth() / base.getWidth();
        boolean ok = lasso.fillRegion(target, scale, color);
        if (ok) {
            lasso.reset();
            invalidate();
            if (stepListener != null) stepListener.onStepFinished();
        }
        return ok;
    }

    /** 剪切套索选区内容到剪切板。 */
    public boolean lassoCut() {
        snapshotLayerBeforeLasso();
        Bitmap target = getCurrentLayerBitmap();
        if (target == null || target.isRecycled()) return false;
        Bitmap base = originalBitmap != null && !originalBitmap.isRecycled()
                ? originalBitmap : currentBitmap;
        if (base == null) return false;
        float scale = (float) target.getWidth() / base.getWidth();
        if (lassoClip != null && !lassoClip.isRecycled()) lassoClip.recycle();
        lassoClip = lasso.cutRegion(target, scale);
        if (lassoClip == null) return false;
        lassoClipX = lasso.bounds.left;
        lassoClipY = lasso.bounds.top;
        lasso.reset();
        invalidate();
        if (stepListener != null) stepListener.onStepFinished();
        return true;
    }

    /** 把剪切板内容贴回（原位置）。 */
    public boolean lassoPaste() {
        if (lassoClip == null || lassoClip.isRecycled()) return false;
        snapshotLayerBeforeLasso();
        Bitmap target = getCurrentLayerBitmap();
        if (target == null || target.isRecycled()) return false;
        Bitmap base = originalBitmap != null && !originalBitmap.isRecycled()
                ? originalBitmap : currentBitmap;
        if (base == null) return false;
        float scale = (float) target.getWidth() / base.getWidth();
        int dx = (int) (lassoClipX * scale);
        int dy = (int) (lassoClipY * scale);
        boolean ok = LassoSelection.pasteAt(target, lassoClip, dx, dy);
        if (ok) {
            invalidate();
            if (stepListener != null) stepListener.onStepFinished();
        }
        return ok;
    }

    public boolean hasLassoClip() {
        return lassoClip != null && !lassoClip.isRecycled();
    }
    private int bucketTolerance = 32;

    private boolean isZoomEnabled = true;
    private boolean isDrawMode = false;
    private Paint currentPaint;
    private boolean isDrawing = false;
    private float lastX = 0f, lastY = 0f;

    private float lastMidX = 0f;
    private float lastMidY = 0f;

    private boolean isMoving = false;
    private float lastMoveX = 0f;
    private float lastMoveY = 0f;

    private ColorMatrix colorMatrix = new ColorMatrix();
    private float brightness = 0f, contrast = 1f, saturation = 1f;
    private float shadows = 0f, highlights = 0f, temperature = 0f, tint = 0f, sharpness = 0f;

    private float colorNoise = 0f;
    private float lumaNoise = 0f;

    private int[] masterLUT = null;
    private int[] rLUT = null;
    private int[] gLUT = null;
    private int[] bLUT = null;
    private String[] curvePointStrs = new String[4];
    private boolean isPreviewingLUT = false;

    private int[] levelsBlack = {0, 0, 0, 0};
    private int[] levelsGray  = {128, 128, 128, 128};
    private int[] levelsWhite = {255, 255, 255, 255};
    private int[][] levelsLut = new int[4][256];
    private boolean levelsDirty = true;

    private CubeLut cubeLut = null;
    private float cubeStrength = 1.0f;

    private HslAdjust hslAdjust = new HslAdjust();
    private float vibrance = 0f;
    private SplitToning splitToning = new SplitToning();

    private float cbShadowR = 0f, cbShadowG = 0f, cbShadowB = 0f;
    private float cbMidR = 0f, cbMidG = 0f, cbMidB = 0f;
    private float cbHighR = 0f, cbHighG = 0f, cbHighB = 0f;

    private Bitmap hslPreviewSrc = null;
    private Bitmap hslPreviewOut = null;
    /** HSL 预览是否正在显示（用覆盖层方式，不替换 ImageView 的 bitmap）。 */
    private boolean hslPreviewVisible = false;
    /** HSL 预览节流：拖得太快时丢弃中间帧，但记下"还有新参数"。 */
    private boolean hslPendingRefresh = false;
    /**
     * HSL 预览分辨率。
     *
     * 原来写的是 160 —— 放到全屏上糊成一片，完全没法判断调整效果。
     * HSL 只是逐像素查表，比噪点计算轻得多，可以用和噪点一样的尺寸。
     */
    private static final int HSL_PREVIEW_SIZE = 1024;
    private Matrix hslSavedMatrix = null;
    private float hslSavedScale = 1.0f;
    private long hslLastRefreshTime = 0L;
    private static final long HSL_MIN_INTERVAL_MS = 30;

    private Bitmap noisePreviewSrc = null;
    private Bitmap noisePreviewOut = null;
    /** 噪点预览是否正在显示（覆盖层方式）。 */
    private boolean noisePreviewVisible = false;
    private Matrix noiseSavedMatrix = null;
    private float noiseSavedScale = 1.0f;
    private static final int NOISE_PREVIEW_SIZE = 1024;
    private long noiseLastRefreshTime = 0L;

    private int currentColor = Color.RED;
    private float brushWidth = 12f;
    private float eraserWidth = 12f;
    private float currentWidth = 12f;

    private float drawAlpha = 1.0f;

    private static final float MIN_SCALE = 0.5f;
    private static final float MAX_SCALE = 4.0f;

    private boolean isShowingOriginal = false;
    private Matrix savedMatrixBeforeOriginal = null;
    private float savedScaleBeforeOriginal = 1.0f;
    private Handler longPressHandler = null;
    private Runnable longPressRunnable = null;
    private boolean longPressTriggered = false;
    private float longPressDownX = 0f;
    private float longPressDownY = 0f;

    private Bitmap preStrokeSnapshot = null;

    private boolean isSymmetryOn = false;

    /** 九宫格对齐参考线（三分法），画布上显示并吸附。 */
    private boolean isGridOn = false;
    /** 吸附命中的屏幕 X 位置（-1 表示没命中）。 */
    private float snappedLineX = -1f;
    /** 吸附命中的屏幕 Y 位置（-1 表示没命中）。 */
    private float snappedLineY = -1f;
    /** 命中的线显示多久（毫秒）。 */
    private static final long SNAP_HINT_MS = 700L;
    private Handler snapHintHandler = null;
    /** 画布上拖拽时的吸附距离（dp）。 */
    private float gridSnapDp = 8f;

    public void setGridOn(boolean on) {
        isGridOn = on;
        if (!on) {
            // 关掉网格时把残留的吸附提示也清掉
            snappedLineX = -1f;
            snappedLineY = -1f;
            if (snapHintHandler != null) snapHintHandler.removeCallbacksAndMessages(null);
        }
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        try {
            if (snapHintHandler != null) snapHintHandler.removeCallbacksAndMessages(null);
        } catch (Throwable ignored) {}
        super.onDetachedFromWindow();
    }
    public boolean isGridOn() { return isGridOn; }

    /** 把画布坐标吸附到最近的九宫格线（半径内才吸）。返回吸附后的坐标。 */
    private float gridSnapX = -1, gridSnapY = -1;
    private void computeGridSnap(float bx, float by, int w, int h) {
        gridSnapX = -1;
        gridSnapY = -1;
        if (!isGridOn || w <= 0 || h <= 0) return;
        float snap = gridSnapDp * getResources().getDisplayMetrics().density;
        // 画布上的目标线：1/3、1/2、2/3
        float[] linesX = {w / 3f, w / 2f, w * 2f / 3f};
        float[] linesY = {h / 3f, h / 2f, h * 2f / 3f};
        float best = snap;
        for (float lx : linesX) {
            float d = Math.abs(bx - lx);
            if (d < best) { best = d; gridSnapX = lx; }
        }
        best = snap;
        for (float ly : linesY) {
            float d = Math.abs(by - ly);
            if (d < best) { best = d; gridSnapY = ly; }
        }
    }

    /**
     * 把图片矩阵吸附到九宫格线。
     *
     * 原理：图片的中心/边缘靠近某个网格线时，微调平移量让它正好对齐。
     * 只在吸附半径内生效，超出范围保持自由移动。
     */
    private void applyGridSnapToMatrix() {
        if (originalBitmap == null || originalBitmap.isRecycled()) return;
        if (getDrawable() == null) return;
        int iw = getDrawable().getIntrinsicWidth();
        int ih = getDrawable().getIntrinsicHeight();
        if (iw <= 0 || ih <= 0) return;

        float snap = gridSnapDp * getResources().getDisplayMetrics().density;
        float[] values = new float[9];
        matrix.getValues(values);
        float tx = values[Matrix.MTRANS_X];
        float ty = values[Matrix.MTRANS_Y];
        float scale = values[Matrix.MSCALE_X];
        if (scale <= 0) return;

        // 图片在屏幕上的四条边
        float left = tx;
        float top = ty;
        float right = tx + iw * scale;
        float bottom = ty + ih * scale;

        // 视口中心
        float vw = getWidth(), vh = getHeight();
        float centerX = (left + right) / 2f;
        float centerY = (top + bottom) / 2f;

        // 候选对齐位置（屏幕坐标）：图片中心对齐视口 1/3、1/2、2/3
        float[] targetsX = {vw / 3f, vw / 2f, vw * 2f / 3f};
        float[] targetsY = {vh / 3f, vh / 2f, vh * 2f / 3f};

        float bestDx = 0;
        float bestDistX = snap;
        for (float t : targetsX) {
            float d = t - centerX;
            if (Math.abs(d) < bestDistX) { bestDistX = Math.abs(d); bestDx = d; }
        }
        float bestDy = 0;
        float bestDistY = snap;
        for (float t : targetsY) {
            float d = t - centerY;
            if (Math.abs(d) < bestDistY) { bestDistY = Math.abs(d); bestDy = d; }
        }
        if (bestDx != 0 || bestDy != 0) {
            matrix.postTranslate(bestDx, bestDy);
            // 记下命中的是哪条线（对齐后的位置），只画这一条
            float newCenterX = centerX + bestDx;
            float newCenterY = centerY + bestDy;
            snappedLineX = bestDx != 0 ? nearestTarget(targetsX, newCenterX) : -1f;
            snappedLineY = bestDy != 0 ? nearestTarget(targetsY, newCenterY) : -1f;
            showSnapHint();
        }
    }

    /** 找离 v 最近的参考线位置。 */
    private float nearestTarget(float[] targets, float v) {
        float best = targets[0];
        float bestD = Math.abs(targets[0] - v);
        for (int i = 1; i < targets.length; i++) {
            float d = Math.abs(targets[i] - v);
            if (d < bestD) { bestD = d; best = targets[i]; }
        }
        return best;
    }

    /** 显示吸附提示线，过一会儿自动消失。 */
    private void showSnapHint() {
        if (snapHintHandler == null) snapHintHandler = new Handler();
        snapHintHandler.removeCallbacksAndMessages(null);
        invalidate();
        snapHintHandler.postDelayed(new Runnable() {
                @Override public void run() {
                    snappedLineX = -1f;
                    snappedLineY = -1f;
                    invalidate();
                }
            }, SNAP_HINT_MS);
    }

    public float getSnappedX(float bx, int w, int h) {
        computeGridSnap(bx, 0, w, h);
        return gridSnapX >= 0 ? gridSnapX : bx;
    }

    public float getSnappedY(float by, int w, int h) {
        computeGridSnap(0, by, w, h);
        return gridSnapY >= 0 ? gridSnapY : by;
    }
    private int symmetryType = 0; 

    public ZoomImageView(Context context) { super(context); init(context); }
    public ZoomImageView(Context context, AttributeSet attrs) { super(context, attrs); init(context); }

    private void init(Context context) {
        super.setClickable(true);
        super.setScaleType(ScaleType.MATRIX);
        scaleDetector = new ScaleGestureDetector(context, this);
        buildPaint();

        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                    if (isScaling || isDrawMode) return false;
                    matrix.postTranslate(-dx, -dy);
                    setImageMatrix(matrix);
                    return true;
                }
            });

        longPressHandler = new Handler();
        longPressRunnable = new Runnable() {
            @Override
            public void run() {
                longPressTriggered = true;
                setShowOriginal(true);
            }
        };
    }

    public void setSymmetryOn(boolean on) { isSymmetryOn = on; invalidate(); }
    public boolean isSymmetryOn() { return isSymmetryOn; }
    public void setSymmetryType(int type) { symmetryType = type; invalidate(); }
    public int getSymmetryType() { return symmetryType; }

    public float getColorNoise() { return colorNoise; }
    public void setColorNoise(float v) { colorNoise = v; refreshUIFromHistory(); }
    public float getLumaNoise() { return lumaNoise; }
    public void setLumaNoise(float v) { lumaNoise = v; refreshUIFromHistory(); }
    public void resetNoise() { colorNoise = 0f; lumaNoise = 0f; refreshUIFromHistory(); }
    public boolean hasNoise() { return colorNoise > 0.01f || lumaNoise > 0.01f; }

    public void setNoisePreviewStart() {
        try {
            noiseSavedMatrix = new Matrix(matrix);
            noiseSavedScale = currentScale;
            if (noisePreviewSrc != null && !noisePreviewSrc.isRecycled()) noisePreviewSrc.recycle();
            noisePreviewSrc = null;
            Bitmap replay = history.replay(originalBitmap);
            if (replay == null) return;

            // 同样：先缩到预览尺寸再绘制，不铺白底
            int tw = NOISE_PREVIEW_SIZE, th = NOISE_PREVIEW_SIZE;
            if (replay.getWidth() > replay.getHeight()) {
                th = (int)((float) NOISE_PREVIEW_SIZE * replay.getHeight() / replay.getWidth());
            } else {
                tw = (int)((float) NOISE_PREVIEW_SIZE * replay.getWidth() / replay.getHeight());
            }
            if (tw < 1) tw = 1;
            if (th < 1) th = 1;

            Bitmap filtered = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(filtered);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setFilterBitmap(true);
            p.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
            c.drawBitmap(replay, 0, 0, p);

            if (replay != originalBitmap && !replay.isRecycled()) replay.recycle();
            noisePreviewSrc = filtered;
        } catch (Throwable e) {}
    }

    /**
     * 噪点实时预览。
     *
     * 和 HSL 一样走最直白的路径：改参数 → 重算 → 显示。
     * （原来用独立的预览源图和覆盖层，参数根本没进正式渲染，
     *   调完再打开图就丢了。）
     */
    public void setNoiseLivePreview(float colorV, float lumaV) {
        colorNoise = colorV;
        lumaNoise = lumaV;
        long now = System.currentTimeMillis();
        if (now - noiseLastRefreshTime < 80L) return;
        noiseLastRefreshTime = now;
        refreshUIFromHistory();
    }

    /**
     * 结束噪点预览。同 HSL：不重放历史，只换回原显示图并还原缩放。
     */
    public void setNoisePreviewEnd() {
        noisePreviewVisible = false;
        noiseLastRefreshTime = 0L;
        if (noiseSavedMatrix != null) {
            matrix.set(noiseSavedMatrix);
            currentScale = noiseSavedScale;
        }
        noiseSavedMatrix = null;
        noiseSavedScale = 1.0f;
        try {
            Bitmap back = currentBitmap;
            if (back == null || back.isRecycled()) back = originalBitmap;
            if (back != null && !back.isRecycled()) {
                isPreviewingLUT = true;
                super.setImageBitmap(back);
                isPreviewingLUT = false;
            }
            setImageMatrix(matrix);
        } catch (Throwable ignored) {}
        if (noisePreviewOut != null && !noisePreviewOut.isRecycled()) noisePreviewOut.recycle();
        noisePreviewOut = null;
        if (noisePreviewSrc != null && !noisePreviewSrc.isRecycled()) noisePreviewSrc.recycle();
        noisePreviewSrc = null;
        invalidate();
    }

    private void applyNoiseToPixels(int[] px, int w, int h, float colorStrength, float lumaStrength) {
        if (colorStrength <= 0.01f && lumaStrength <= 0.01f) return;
        if (colorStrength > 0.01f) {
            float cScale = colorStrength / 100f;
            int[] cbArr = new int[w * h];
            int[] crArr = new int[w * h];
            for (int i = 0; i < px.length; i++) {
                int c = px[i];
                int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                int y = (77 * r + 150 * g + 29 * b) >> 8;
                cbArr[i] = clamp255(128 + ((-43 * r - 85 * g + 128 * b) >> 8));
                crArr[i] = clamp255(128 + ((128 * r - 107 * g - 21 * b) >> 8));
            }
            int[] cbBlur = new int[w * h];
            int[] crBlur = new int[w * h];
            boxBlur3x3(cbArr, cbBlur, w, h);
            boxBlur3x3(crArr, crBlur, w, h);
            for (int i = 0; i < px.length; i++) {
                int c = px[i];
                int a = (c >> 24) & 0xFF;
                int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                int y = (77 * r + 150 * g + 29 * b) >> 8;
                int cb = (int)(cbArr[i] * (1f - cScale) + cbBlur[i] * cScale);
                int cr = (int)(crArr[i] * (1f - cScale) + crBlur[i] * cScale);
                int rr = clamp255(y + ((cr - 128) * 359 >> 8));
                int gg = clamp255(y - ((cb - 128) * 88 + (cr - 128) * 183) >> 8);
                int bb = clamp255(y + ((cb - 128) * 454 >> 8));
                px[i] = (a << 24) | (rr << 16) | (gg << 8) | bb;
            }
        }
        if (lumaStrength > 0.01f) {
            float lScale = lumaStrength / 100f;
            int[] yArr = new int[w * h];
            for (int i = 0; i < px.length; i++) {
                int c = px[i];
                int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                yArr[i] = (77 * r + 150 * g + 29 * b) >> 8;
            }
            int[] yBlur = new int[w * h];
            bilateral3x3Luma(yArr, yBlur, w, h);
            for (int i = 0; i < px.length; i++) {
                int c = px[i];
                int a = (c >> 24) & 0xFF;
                int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                int y = yArr[i];
                int yNew = (int)(y * (1f - lScale) + yBlur[i] * lScale);
                int diff = yNew - y;
                r = clamp255(r + diff);
                g = clamp255(g + diff);
                b = clamp255(b + diff);
                px[i] = (a << 24) | (r << 16) | (g << 8) | b;
            }
        }
    }

    private void boxBlur3x3(int[] src, int[] dst, int w, int h) {
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int sum = 0, count = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w) continue;
                        sum += src[yy * w + xx];
                        count++;
                    }
                }
                dst[y * w + x] = sum / count;
            }
        }
    }

    private void bilateral3x3Luma(int[] src, int[] dst, int w, int h) {
        final int rangeThreshold = 30;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int center = src[y * w + x];
                int sum = 0, weightSum = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w) continue;
                        int v = src[yy * w + xx];
                        int diff = Math.abs(v - center);
                        if (diff > rangeThreshold) continue;
                        int weight = rangeThreshold - diff;
                        sum += v * weight;
                        weightSum += weight;
                    }
                }
                dst[y * w + x] = weightSum > 0 ? sum / weightSum : center;
            }
        }
    }

    private int clamp255(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    public void applyExtremeDenoise(final OnNoiseProgressListener listener) {
        new Thread(new Runnable() {
                @Override public void run() {
                    if (originalBitmap == null) return;
                    Bitmap base = getFinalBitmapFromHistory(false);
                    if (base == null) return;

                    int w = base.getWidth(), h = base.getHeight();
                    int[] px = new int[w * h];
                    base.getPixels(px, 0, w, 0, 0, w, h);

                    applyNoiseToPixels(px, w, h, 80f, 60f);
                    if (listener != null) listener.onProgress(50);

                    int[] yArr = new int[w * h];
                    for (int i = 0; i < px.length; i++) {
                        int c = px[i];
                        yArr[i] = (77 * ((c>>16)&0xFF) + 150 * ((c>>8)&0xFF) + 29 * (c&0xFF)) >> 8;
                    }
                    int[] yBlur = new int[w * h];
                    bilateral3x3Luma(yArr, yBlur, w, h); 

                    for (int i = 0; i < px.length; i++) {
                        int c = px[i];
                        int a = (c >> 24) & 0xFF;
                        int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                        int diff = yBlur[i] - yArr[i];
                        r = clamp255(r + diff);
                        g = clamp255(g + diff);
                        b = clamp255(b + diff);
                        px[i] = (a << 24) | (r << 16) | (g << 8) | b;
                    }
                    if (listener != null) listener.onProgress(90);

                    Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    out.setPixels(px, 0, w, 0, 0, w, h);

                    history.addDrawLayer(currentLayerIndex, out); 

                    if (listener != null) {
                        listener.onProgress(100);
                        listener.onFinished(out);
                    }
                }
            }).start();
    }

    public int getLevelsBlack(int ch) { return (ch >= 0 && ch < 4) ? levelsBlack[ch] : 0; }
    public int getLevelsGray(int ch) { return (ch >= 0 && ch < 4) ? levelsGray[ch] : 128; }
    public int getLevelsWhite(int ch) { return (ch >= 0 && ch < 4) ? levelsWhite[ch] : 255; }

    public void setLevels(int ch, int black, int gray, int white) {
        if (ch < 0 || ch > 3) return;
        if (black < 0) black = 0;
        if (white > 255) white = 255;
        if (black >= white - 2) black = white - 2;
        if (gray < black + 1) gray = black + 1;
        if (gray > white - 1) gray = white - 1;
        levelsBlack[ch] = black;
        levelsGray[ch] = gray;
        levelsWhite[ch] = white;
        levelsDirty = true;
        refreshUIFromHistory();
    }

    public void resetLevels(int ch) {
        if (ch < 0 || ch > 3) return;
        levelsBlack[ch] = 0;
        levelsGray[ch] = 128;
        levelsWhite[ch] = 255;
        levelsDirty = true;
        refreshUIFromHistory();
    }

    public void resetAllLevels() {
        for (int i = 0; i < 4; i++) {
            levelsBlack[i] = 0;
            levelsGray[i] = 128;
            levelsWhite[i] = 255;
        }
        levelsDirty = true;
        refreshUIFromHistory();
    }

    public boolean hasLevels() {
        for (int i = 0; i < 4; i++) {
            if (levelsBlack[i] != 0 || levelsGray[i] != 128 || levelsWhite[i] != 255) return true;
        }
        return false;
    }

    private void rebuildLevelsLut() {
        for (int ch = 0; ch < 4; ch++) {
            int black = levelsBlack[ch];
            int gray = levelsGray[ch];
            int white = levelsWhite[ch];
            if (black == 0 && gray == 128 && white == 255) {
                for (int i = 0; i < 256; i++) levelsLut[ch][i] = i;
                continue;
            }
            float blackF = black;
            float whiteF = white;
            float grayF = gray;
            float range = whiteF - blackF;
            if (range < 1f) range = 1f;
            float midNorm = (grayF - blackF) / range;
            if (midNorm < 0.01f) midNorm = 0.01f;
            if (midNorm > 0.99f) midNorm = 0.99f;
            double gamma = Math.log(0.5) / Math.log(midNorm);
            for (int i = 0; i < 256; i++) {
                float v = i;
                float norm;
                if (v <= blackF) norm = 0f;
                else if (v >= whiteF) norm = 1f;
                else norm = (v - blackF) / range;
                float out = (float) Math.pow(norm, gamma) * 255f;
                int oi = (int)(out + 0.5f);
                if (oi < 0) oi = 0;
                if (oi > 255) oi = 255;
                levelsLut[ch][i] = oi;
            }
        }
        levelsDirty = false;
    }

    public Bitmap getOriginalBitmapCopy() {
        if (originalBitmap == null || originalBitmap.isRecycled()) return null;
        try {
            return originalBitmap.copy(Bitmap.Config.ARGB_8888, false);
        } catch (Throwable e) { return null; }
    }

    public Bitmap getStepBitmapFromHistory(boolean applyFilter) {
        if (originalBitmap == null) return null;
        Bitmap result = history.replay(originalBitmap);
        if (result == null) return null;

        Bitmap finalBmp = Bitmap.createBitmap(result.getWidth(), result.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(finalBmp);
        // ★ 步存档也保留 alpha，否则每步 PNG 里透明会变白
        canvas.drawBitmap(result, 0, 0, null);

        if (result != originalBitmap && !result.isRecycled()) result.recycle();

        if (applyFilter) {
            Bitmap filtered = applyMergedFilters(finalBmp);
            if (filtered != finalBmp && !finalBmp.isRecycled()) finalBmp.recycle();
            return filtered;
        }
        return finalBmp;
    }

    public void clearDraw() {
        if (currentLayerIndex < 0 || currentLayerIndex >= layerManager.size()) return;
        LayerManager.LayerItem layer = layerManager.get(currentLayerIndex);
        if (layer.bitmap == null || layer.bitmap.isRecycled()) return;
        if (!layer.bitmap.isMutable() || layer.bitmap.getConfig() != Bitmap.Config.ARGB_8888) {
            Bitmap mut = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true);
            if (mut == null) return;
            Bitmap old = layer.bitmap;
            layer.bitmap = mut;
            if (!old.isRecycled()) old.recycle();
        }
        Bitmap snap = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true);
        if (snap != null) {
            history.addDrawLayer(currentLayerIndex, snap);
        }
        layer.bitmap.eraseColor(Color.TRANSPARENT);
        invalidate();
        if (stepListener != null) stepListener.onStepFinished();
    }

    public boolean undoDraw() {
        return undo();
    }

    public void setShowOriginal(boolean b) {
        if (isShowingOriginal == b) return;
        isShowingOriginal = b;
        if (b) {
            savedMatrixBeforeOriginal = new Matrix(matrix);
            savedScaleBeforeOriginal = currentScale;
            layerManager.setGlobalAlpha(0);
            setColorFilter(null);
            super.setImageBitmap(originalBitmap);
            matrix.set(savedMatrixBeforeOriginal);
            currentScale = savedScaleBeforeOriginal;
            setImageMatrix(matrix);
        } else {
            layerManager.setGlobalAlpha(255);
            // ★ 走 updateColorMatrix() 而不是直接 setColorFilter：
            //   直接用的话签名还停留在旧值，之后改参数会被去重逻辑误跳过。
            filterSigValid = false;
            updateColorMatrix();
            super.setImageBitmap(currentBitmap);
            if (savedMatrixBeforeOriginal != null) {
                matrix.set(savedMatrixBeforeOriginal);
                currentScale = savedScaleBeforeOriginal;
                setImageMatrix(matrix);
            }
            savedMatrixBeforeOriginal = null;
        }
        invalidate();
    }

    public boolean isShowingOriginal() { return isShowingOriginal; }
    public void setLayersAlpha(int alpha) { layerManager.setGlobalAlpha(alpha); invalidate(); }
    public int getLayersAlpha() { return layerManager.getGlobalAlpha(); }

    private void buildPaint() {
        currentPaint = new Paint();
        currentWidth = (brushMode == 1 || brushMode == 5) ? eraserWidth : brushWidth;
        currentPaint.setStrokeWidth(currentWidth);
        currentPaint.setStyle(Paint.Style.STROKE);
        currentPaint.setAntiAlias(true);
        currentPaint.setStrokeCap(Paint.Cap.ROUND);
        currentPaint.setStrokeJoin(Paint.Join.ROUND);

        if (brushMode == 1 || brushMode == 5) {
            currentPaint.setColor(Color.BLACK);
            currentPaint.setAlpha(255);
            currentPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        } else {
            currentPaint.setColor(currentColor);
            currentPaint.setAlpha((int)(255 * drawAlpha));
            currentPaint.setXfermode(null);
        }
    }

    public void setZoomEnabled(boolean b) { isZoomEnabled = b; }
    public void setDrawMode(boolean b) { isDrawMode = b; invalidate(); }
    public void setBrushMode(int m) { 
        brushMode = m; 
        buildPaint(); 
    }
    public int getBrushMode() { return brushMode; }
    public void setBucketTolerance(int t) { bucketTolerance = t; }
    public int getBucketTolerance() { return bucketTolerance; }

    public void setDrawColor(int c) { currentColor = c; if (brushMode != 1 && brushMode != 5) buildPaint(); }

    public void setDrawWidth(float w) {
        if (brushMode == 1 || brushMode == 5) eraserWidth = w;
        else brushWidth = w;
        currentWidth = w;
        if (currentPaint != null) currentPaint.setStrokeWidth(w);
    }
    public float getDrawWidth() {
        return (brushMode == 1 || brushMode == 5) ? eraserWidth : brushWidth;
    }

    public int getDrawColor() { return currentColor; }
    public void setDrawAlpha(float a) { drawAlpha = a; if (brushMode != 1 && brushMode != 5) buildPaint(); }
    public float getDrawAlpha() { return drawAlpha; }

    public void onLayersChanged() {
        invalidate();
        if (stepListener != null) stepListener.onStepFinished();
    }

    public EditHistory getHistory() { return history; }
    public LayerManager getLayerManager() { return layerManager; }

    public int getCurrentLayerIndex() { return currentLayerIndex; }

    public void setCurrentLayerIndex(int i) {
        if (i < 0) return;
        if (i == 0 && layerManager.size() > 1) i = 1;
        currentLayerIndex = i;
        invalidate();
    }

    public Bitmap getCurrentLayerBitmap() {
        if (currentLayerIndex < 0 || currentLayerIndex >= layerManager.size()) return null;
        return layerManager.get(currentLayerIndex).bitmap;
    }

    public void resetToCenter() { fitCenter(); }

    public void setBrightness(float v) { clearDisplayOnlyFilters(); brightness = v; updateColorMatrix(); }
    public void setContrast(float v) { clearDisplayOnlyFilters(); contrast = v; updateColorMatrix(); }
    public void setSaturation(float v) { clearDisplayOnlyFilters(); saturation = v; updateColorMatrix(); }
    public void setShadows(float v) { clearDisplayOnlyFilters(); shadows = v; updateColorMatrix(); }
    public void setHighlights(float v) { clearDisplayOnlyFilters(); highlights = v; updateColorMatrix(); }
    public void setTemperature(float v) { clearDisplayOnlyFilters(); temperature = v; updateColorMatrix(); }
    public void setTint(float v) { clearDisplayOnlyFilters(); tint = v; updateColorMatrix(); }
    public void setSharpness(float v) { sharpness = v; updateColorMatrix(); }

    public void setColorBalance(float sr, float sg, float sb, float mr, float mg, float mb, float hr, float hg, float hb) {
        cbShadowR = sr; cbShadowG = sg; cbShadowB = sb;
        cbMidR = mr; cbMidG = mg; cbMidB = mb;
        cbHighR = hr; cbHighG = hg; cbHighB = hb;
        refreshUIFromHistory();
    }
    public float getCbShadowR() { return cbShadowR; }
    public float getCbShadowG() { return cbShadowG; }
    public float getCbShadowB() { return cbShadowB; }
    public float getCbMidR() { return cbMidR; }
    public float getCbMidG() { return cbMidG; }
    public float getCbMidB() { return cbMidB; }
    public float getCbHighR() { return cbHighR; }
    public float getCbHighG() { return cbHighG; }
    public float getCbHighB() { return cbHighB; }

    public void setPreviewLUTs(int[] m, int[] r, int[] g, int[] b, String[] pts) {
        masterLUT = m; rLUT = r; gLUT = g; bLUT = b; curvePointStrs = pts;
        Bitmap out = applyRGBLUT(currentBitmap);
        Matrix t = new Matrix(matrix);
        float s = currentScale;
        isPreviewingLUT = true;
        super.setImageBitmap(out);
        isPreviewingLUT = false;
        matrix.set(t); currentScale = s; setImageMatrix(matrix);
    }

    public void setRGBLUTs(int[] m, int[] r, int[] g, int[] b, String[] pts) {
        masterLUT = m; rLUT = r; gLUT = g; bLUT = b; curvePointStrs = pts;
        refreshUIFromHistory();
    }

    public void clearLUTs() {
        masterLUT = null; rLUT = null; gLUT = null; bLUT = null;
        curvePointStrs = new String[4];
        refreshUIFromHistory();
    }

    public int[] getMasterLUT() { return masterLUT; }
    public int[] getRLUT() { return rLUT; }
    public int[] getGLUT() { return gLUT; }
    public int[] getBLUT() { return bLUT; }
    public String[] getCurvePointStrs() { return curvePointStrs; }

    public CubeLut getCubeLut() { return cubeLut; }
    public void setCubeLut(CubeLut l) { cubeLut = l; refreshUIFromHistory(); }
    public void clearCubeLut() { cubeLut = null; refreshUIFromHistory(); }
    public float getCubeStrength() { return cubeStrength; }
    public void setCubeStrength(float s) { cubeStrength = s; refreshUIFromHistory(); }

    public float getVibrance() { return vibrance; }
    public void setVibrance(float v) { vibrance = v; refreshUIFromHistory(); }

    public SplitToning getSplitToning() { return splitToning; }
    public void setSplitToning(SplitToning st) {
        if (st == null) splitToning = new SplitToning();
        else splitToning = st;
        refreshUIFromHistory();
    }
    public void setSplitShadowHue(float v) { splitToning.shadowHue = v; refreshUIFromHistory(); }
    public void setSplitShadowSat(float v) { splitToning.shadowSat = v; refreshUIFromHistory(); }
    public void setSplitHighlightHue(float v) { splitToning.highlightHue = v; refreshUIFromHistory(); }
    public void setSplitHighlightSat(float v) { splitToning.highlightSat = v; refreshUIFromHistory(); }
    public void setSplitBalance(int v) { splitToning.balance = v; refreshUIFromHistory(); }
    public void resetSplitToning() { splitToning.reset(); refreshUIFromHistory(); }

    public HslAdjust getHslAdjust() { return hslAdjust; }
    public void setHslAdjust(HslAdjust h) {
        if (h == null) hslAdjust = new HslAdjust();
        else hslAdjust = h;
        hslAdjust.isEmpty();
        refreshUIFromHistory();
    }
    public void setHslHue(int idx, float v) { if (idx >= 0 && idx < 8) { hslAdjust.hue[idx] = v; hslAdjust.isEmpty(); refreshUIFromHistory(); } }
    public void setHslSat(int idx, float v) { if (idx >= 0 && idx < 8) { hslAdjust.sat[idx] = v; hslAdjust.isEmpty(); refreshUIFromHistory(); } }
    public void setHslLum(int idx, float v) { if (idx >= 0 && idx < 8) { hslAdjust.lum[idx] = v; hslAdjust.isEmpty(); refreshUIFromHistory(); } }
    public void resetHsl() { hslAdjust.reset(); refreshUIFromHistory(); }

    /** 进入预览时正在显示的位图，结束时原样换回来。 */
    private Bitmap hslSavedDisplayBmp = null;

    public void setHslPreviewStart() {
        try {
            hslSavedMatrix = new Matrix(matrix);
            hslSavedScale = currentScale;
            // 记下此刻真正显示着的位图，结束时直接换回它，
            // 不要靠 currentBitmap 猜（它可能已经被别处改写）。
            hslSavedDisplayBmp = currentBitmap != null && !currentBitmap.isRecycled()
                    ? currentBitmap
                    : (originalBitmap != null && !originalBitmap.isRecycled() ? originalBitmap : null);
            if (hslPreviewSrc != null && !hslPreviewSrc.isRecycled()) hslPreviewSrc.recycle();
            hslPreviewSrc = null;
            Bitmap replay = history.replay(originalBitmap);
            if (replay == null) return;

            // ★ 先算出预览尺寸，再把 replay 直接缩到这个尺寸，
            //   而不是先渲染整张图（4000x3000）再缩 —— 那样白算 1200 万像素。
            int tw = HSL_PREVIEW_SIZE, th = HSL_PREVIEW_SIZE;
            if (replay.getWidth() > replay.getHeight()) {
                th = (int)((float) HSL_PREVIEW_SIZE * replay.getHeight() / replay.getWidth());
            } else {
                tw = (int)((float) HSL_PREVIEW_SIZE * replay.getWidth() / replay.getHeight());
            }
            if (tw < 1) tw = 1;
            if (th < 1) th = 1;

            Bitmap filtered = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(filtered);
            // ★ 不铺白底：抠图的透明必须保留，否则预览时透明区域变成白块
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setFilterBitmap(true);
            p.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
            c.drawBitmap(replay, 0, 0, p);

            float lsx = (float) tw / replay.getWidth();
            float lsy = (float) th / replay.getHeight();
            layerManager.drawAll(c, lsx, lsy, new ColorMatrixColorFilter(colorMatrix));

            if (replay != originalBitmap && !replay.isRecycled()) replay.recycle();
            hslPreviewSrc = filtered;
            hslPreviewVisible = false;
        } catch (Throwable e) {}
    }

    /**
     * HSL 滑轨实时预览。
     *
     * 直接对缩略图重算并显示，不用覆盖层、不重放历史：
     * 之前的"预览源图 + 覆盖层 + 历史重放"三层机制耦合太深，
     * 每修一处就冒出新问题（图片消失 / 改了没反应 / 变亮）。
     * 这里改成最直白的做法：参数变了就重算一次当前图。
     */
    public void setHslLivePreview(int idx, float v, int type) {
        if (idx < 0 || idx >= 8) return;
        if (type == 0) hslAdjust.hue[idx] = v;
        else if (type == 1) hslAdjust.sat[idx] = v;
        else if (type == 2) hslAdjust.lum[idx] = v;
        hslAdjust.isEmpty();     // 刷新 hasAny 标志

        // 节流：拖动时最多每 50ms 重算一次，避免主线程被整图渲染拖垮
        long now = System.currentTimeMillis();
        if (now - hslLastRefreshTime < 50L) {
            hslPendingRefresh = true;
            return;
        }
        hslLastRefreshTime = now;
        refreshUIFromHistory();  // 直接重算并显示
    }

    private void fitCenterForPreview() {
        if (getDrawable() == null) return;
        float vw = getWidth(), vh = getHeight();
        float iw = getDrawable().getIntrinsicWidth();
        float ih = getDrawable().getIntrinsicHeight();
        if (vw == 0 || vh == 0 || iw == 0 || ih == 0) return;
        float s = Math.min(vw / iw, vh / ih);
        matrix.reset();
        matrix.postScale(s, s);
        matrix.postTranslate((vw - iw * s) / 2f, (vh - ih * s) / 2f);
        currentScale = 1.0f;
        setImageMatrix(matrix);
    }

    /**
     * 结束 HSL 预览。
     *
     * 关键：这里**不能**调 refreshUIFromHistory()。
     * 它会把整个历史重放一遍，等于把用户已经调好的滤镜又叠加一次，
     * 表现为"松手后图片突然变亮"。预览只是显示层的临时替换，
     * 结束时换回原来的位图并还原缩放即可。
     */
    /**
     * 结束 HSL 预览。
     *
     * 两件事：
     *  1. 丢掉覆盖层（预览期间没动过 ImageView 的位图，所以不会闪白）
     *  2. 调 refreshUIFromHistory() 把新的 HSL 真正烘焙进当前图 —— 
     *     少了这一步，松手后画面会回到调整前的样子，看起来就是"改了没反应"
     */
    public void setHslPreviewEnd() {
        hslPreviewVisible = false;
        hslLastRefreshTime = 0L;
        hslSavedDisplayBmp = null;
        if (hslPreviewOut != null && !hslPreviewOut.isRecycled()) hslPreviewOut.recycle();
        hslPreviewOut = null;
        if (hslPreviewSrc != null && !hslPreviewSrc.isRecycled()) hslPreviewSrc.recycle();
        hslPreviewSrc = null;
        // 缩放：矩阵一直没被改过，无需还原，但保守起见再设一次
        if (hslSavedMatrix != null) {
            matrix.set(hslSavedMatrix);
            currentScale = hslSavedScale;
            setImageMatrix(matrix);
        }
        hslSavedMatrix = null;
        hslSavedScale = 1.0f;
        hslPendingRefresh = false;
        invalidate();
    }

    public float[] getCropRatio() { return cropRatio; }

    public void applyCrop(float[] ratio) {
        if (originalBitmap == null || ratio == null || ratio.length != 4) return;
        int ow = originalBitmap.getWidth(), oh = originalBitmap.getHeight();
        int left = (int)(ratio[0] * ow), top = (int)(ratio[1] * oh);
        int right = (int)(ratio[2] * ow), bottom = (int)(ratio[3] * oh);
        if (left < 0) left = 0; if (top < 0) top = 0;
        if (right > ow) right = ow; if (bottom > oh) bottom = oh;
        if (right <= left || bottom <= top) return;
        if (right - left == ow && bottom - top == oh) return;
        Bitmap newOrig;
        try { newOrig = Bitmap.createBitmap(originalBitmap, left, top, right - left, bottom - top); }
        catch (Throwable e) { return; }
        int nw = right - left, nh = bottom - top;
        for (LayerManager.LayerItem l : layerManager.getLayers()) {
            if (l.bitmap != null && !l.bitmap.isRecycled()) {
                try {
                    Bitmap nb = Bitmap.createBitmap(l.bitmap, left, top, nw, nh);
                    l.bitmap.recycle();
                    l.bitmap = nb;
                } catch (Throwable e) {
                    l.bitmap = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888);
                }
            }
        }
        layerManager.ensureBaseLayer(nw, nh);
        history.clear();
        originalBitmap = newOrig;
        currentBitmap = newOrig;
        try { history.setImageSize(nw, nh); } catch (Throwable ignored) {}
        invalidateAllBaseCaches();
        cropRatio = ratio;
        int tw = 200, th = (int)(200f * nh / nw);
        if (th > 200) { th = 200; tw = (int)(200f * nw / nh); }
        if (tw <= 0) tw = 1; if (th <= 0) th = 1;
        thumbnailBase = Bitmap.createScaledBitmap(newOrig, tw, th, true);
        Bitmap r = applyRGBLUT(newOrig);
        isPreviewingLUT = true;
        super.setImageBitmap(r);
        isPreviewingLUT = false;
        post(new Runnable() { public void run() { fitCenter(); } });
        invalidate();
        if (stepListener != null) stepListener.onStepFinished();
    }

    // ==================== AI 烘焙图的"显示用"数值 ====================
    /** 是否使用显示用数值（AI 处理过的图，像素已烘焙）。 */
    private boolean hasDisplayOnly = false;
    private float displayBrightness = 0, displayContrast = 1, displaySaturation = 1;
    private float displayShadows = 0, displayHighlights = 0;
    private float displayTemperature = 0, displayTint = 0;

    /**
     * 只设置"显示用"的滤镜数值（供滑轨显示），不改实际像素。
     *
     * 用于 AI 处理过的图：像素已经处理好了，滤镜必须保持中性，
     * 但滑轨应该显示 AI 当时用的数值，不然用户看到的全是 0。
     */
    public void setDisplayOnlyFilters(float br, float co, float sa, float sh,
                                      float hi, float tp, float ti) {
        displayBrightness = br;
        displayContrast = co;
        displaySaturation = sa;
        displayShadows = sh;
        displayHighlights = hi;
        displayTemperature = tp;
        displayTint = ti;
        hasDisplayOnly = true;
    }

    /** 用户自己动了滑轨就丢弃显示值，改用真实值。 */
    public void clearDisplayOnlyFilters() { hasDisplayOnly = false; }

    public void setAllFilters(float b, float c, float s, float sh, float hi, float te, float ti, float spd) {
        brightness = b; contrast = c; saturation = s;
        shadows = sh; highlights = hi; temperature = te;
        tint = ti; sharpness = spd;
        updateColorMatrix();
    }

    public float getBrightness() { return hasDisplayOnly ? displayBrightness : brightness; }
    public float getContrast() { return hasDisplayOnly ? displayContrast : contrast; }
    public float getSaturation() { return hasDisplayOnly ? displaySaturation : saturation; }
    public float getShadows() { return hasDisplayOnly ? displayShadows : shadows; }
    public float getHighlights() { return hasDisplayOnly ? displayHighlights : highlights; }
    public float getTemperature() { return hasDisplayOnly ? displayTemperature : temperature; }
    public float getTint() { return hasDisplayOnly ? displayTint : tint; }

    // ---- 真实值（保存时必须用这些，不能用上面的显示值）----
    public float getRealBrightness() { return brightness; }
    public float getRealContrast() { return contrast; }
    public float getRealSaturation() { return saturation; }
    public float getRealShadows() { return shadows; }
    public float getRealHighlights() { return highlights; }
    public float getRealTemperature() { return temperature; }
    public float getRealTint() { return tint; }
    public float getSharpness() { return sharpness; }

    public void resetFilters() {
        brightness = 0f; contrast = 1f; saturation = 1f;
        shadows = 0f; highlights = 0f; temperature = 0f; tint = 0f; sharpness = 0f;
        colorNoise = 0f; lumaNoise = 0f;
        clearLUTs();
        resetAllLevels();
        colorMatrix.reset();
        setColorFilter(null);
        // ★ 必须让签名失效：否则下次再调回相同参数值会被上面的去重逻辑跳过，
        //   滤镜就不会重新应用了。
        appliedColorFilter = null;
        appliedFilterSig = 0L;
        filterSigValid = false;
    }

    private void rebuildColorMatrix() {
        colorMatrix.reset();

        // ===== 设计原则：所有调整都用"乘法 + 曲线上拉"，不用加法平移 =====
        // 加法平移（+N）会把像素推到 0 或 255 之外再被截断，信息永久丢失，
        // 表现就是"调到头再调回来变灰"。乘法只按比例缩放，可逆。

        // 1) 亮度：乘法。0.25 倍（最暗）~ 2.0 倍（最亮）
        float bScale;
        if (brightness >= 0) {
            bScale = 1.0f + (brightness / 100.0f);           // 1.0 ~ 2.0
        } else {
            bScale = 1.0f + (brightness / 100.0f) * 0.75f;   // 0.25 ~ 1.0
        }
        colorMatrix.postConcat(new ColorMatrix(new float[]{
                bScale,0,0,0,0,  0,bScale,0,0,0,  0,0,bScale,0,0,  0,0,0,1,0}));

        // 2) 对比度：围绕中灰 128 缩放。
        //    限制在 0.5~1.6，过强会把暗部/亮部压成纯黑纯白（不可逆）。
        float c = contrast;
        if (c < 0.5f) c = 0.5f;
        if (c > 1.6f) c = 1.6f;
        float cOff = 128f * (1f - c);
        colorMatrix.postConcat(new ColorMatrix(new float[]{
                c,0,0,0,cOff,  0,c,0,0,cOff,  0,0,c,0,cOff,  0,0,0,1,0}));

        // 3) 饱和度：标准亮度加权矩阵（可逆，饱和度 0 = 灰度，2 = 超饱和）
        float sr = (1 - saturation) * 0.3086f;
        float sg = (1 - saturation) * 0.6094f;
        float sb = (1 - saturation) * 0.0820f;
        colorMatrix.postConcat(new ColorMatrix(new float[]{
                sr+saturation,sg,sb,0,0,
                sr,sg+saturation,sb,0,0,
                sr,sg,sb+saturation,0,0,
                0,0,0,1,0}));

        // 4) 阴影：轻微的整体增益，配合很小的偏移。
        //    不用大的加法偏移（会把纯黑抬成灰、纯白压成灰，不可逆）。
        if (shadows != 0) {
            float sf = 1f + (shadows / 100f) * 0.22f;   // 0.78 ~ 1.22
            float so = 255f * (1f - sf) * 0.18f;        // 很小的偏移
            colorMatrix.postConcat(new ColorMatrix(new float[]{
                    sf,0,0,0,so,  0,sf,0,0,so,  0,0,sf,0,so,  0,0,0,1,0}));
        }

        // 5) 高光：增益方向与阴影相反，强度更小
        if (highlights != 0) {
            float hf = 1f + (highlights / 100f) * 0.18f;  // 0.82 ~ 1.18
            float ho = 255f * (1f - hf) * 0.18f;
            colorMatrix.postConcat(new ColorMatrix(new float[]{
                    hf,0,0,0,ho,  0,hf,0,0,ho,  0,0,hf,0,ho,  0,0,0,1,0}));
        }

        // 6) 色温：暖冷用"通道增益"而不是加减常量。
        //    暖 = 红增益>1、蓝增益<1；冷 = 反之。始终围绕 1，不会溢出。
        if (temperature != 0) {
            float t = temperature / 100f;
            float rGain = 1f + t * 0.25f;   // 0.75 ~ 1.25
            float bGain = 1f - t * 0.25f;
            colorMatrix.postConcat(new ColorMatrix(new float[]{
                    rGain,0,0,0,0,  0,1,0,0,0,  0,0,bGain,0,0,  0,0,0,1,0}));
        }

        // 7) 色调：绿-品红轴。品红 = 加红蓝、绿降；绿 = 反之。用增益保持可逆。
        if (tint != 0) {
            float t = tint / 100f;
            float rGain = 1f + t * 0.15f;
            float gGain = 1f - t * 0.18f;
            float bGain = 1f + t * 0.15f;
            colorMatrix.postConcat(new ColorMatrix(new float[]{
                    rGain,0,0,0,0,  0,gGain,0,0,0,  0,0,bGain,0,0,  0,0,0,1,0}));
        }
    }

    /** 上一次应用到视图的滤镜（参数没变就不重复设置）。 */
    private ColorMatrixColorFilter appliedColorFilter = null;
    /** 上一次的滤镜参数签名，用来判断是否真的需要重建。 */
    private long appliedFilterSig = 0L;
    /** 是否已经至少计算过一次（区分"从没算过"和"算过且为默认值"）。 */
    private boolean filterSigValid = false;

    /**
     * 更新色彩矩阵。
     *
     * ColorMatrixColorFilter 是不可变对象，没法「改」只能新建，
     * 所以这里做两件事来减少拖滑轨时的开销：
     *  1. 参数签名没变就完全不重建；
     *  2. 所有参数都为默认值时直接清空滤镜（省掉一次整图着色）。
     */
    private void updateColorMatrix() {
        long sig = 1;
        sig = sig * 31 + Float.floatToIntBits(brightness);
        sig = sig * 31 + Float.floatToIntBits(contrast);
        sig = sig * 31 + Float.floatToIntBits(saturation);
        sig = sig * 31 + Float.floatToIntBits(shadows);
        sig = sig * 31 + Float.floatToIntBits(highlights);
        sig = sig * 31 + Float.floatToIntBits(temperature);
        sig = sig * 31 + Float.floatToIntBits(tint);
        if (filterSigValid && sig == appliedFilterSig) {
            return;   // 参数完全没变，什么都不用做
        }
        appliedFilterSig = sig;
        filterSigValid = true;

        rebuildColorMatrix();
        boolean isDefault = brightness == 0 && contrast == 1f && saturation == 1f
                && shadows == 0 && highlights == 0 && temperature == 0 && tint == 0;
        if (isDefault) {
            appliedColorFilter = null;
            setColorFilter(null);   // 全默认：不需要着色
            return;
        }
        appliedColorFilter = new ColorMatrixColorFilter(colorMatrix);
        setColorFilter(appliedColorFilter);
    }

    /**
     * 提交当前调整到历史，然后立刻重绘。
     *
     * HSL / 噪点这类滑轨必须用这个方法收尾：
     * 先 commitFilter() 把参数写进历史，再 refreshUIFromHistory() 才能渲染出效果。
     * 顺序反了的话，重放的是"没有这次调整"的旧历史，画面会回到调整前的样子。
     */
    public void commitFilterAndRefresh() {
        commitFilter();
        refreshUIFromHistory();
        invalidate();
    }

    public void commitFilter() {
        history.addFilter(brightness, contrast, saturation, shadows, highlights, temperature, tint, sharpness);
        EditHistory.Entry e = history.peekLast();
        if (e != null && e.type == EditHistory.Type.FILTER) {
            e.lutM = masterLUT; e.lutR = rLUT; e.lutG = gLUT; e.lutB = bLUT;
            e.curvePts = curvePointStrs;
            e.hslHue = hslAdjust.hue.clone();
            e.hslSat = hslAdjust.sat.clone();
            e.hslLum = hslAdjust.lum.clone();
            e.lvBlack = levelsBlack.clone();
            e.lvGray = levelsGray.clone();
            e.lvWhite = levelsWhite.clone();
            e.vibrance = vibrance;
            e.splitShadowHue = splitToning.shadowHue;
            e.splitShadowSat = splitToning.shadowSat;
            e.splitHighlightHue = splitToning.highlightHue;
            e.splitHighlightSat = splitToning.highlightSat;
            e.splitBalance = splitToning.balance;
            e.cbShadowR = cbShadowR; e.cbShadowG = cbShadowG; e.cbShadowB = cbShadowB;
            e.cbMidR = cbMidR; e.cbMidG = cbMidG; e.cbMidB = cbMidB;
            e.cbHighR = cbHighR; e.cbHighG = cbHighG; e.cbHighB = cbHighB;
            e.cubeLut = cubeLut;
            e.cubeStrength = cubeStrength;
        }
    }

    public void rotate90() {
        history.addRotate();
        for (LayerManager.LayerItem l : layerManager.getLayers()) {
            if (l.bitmap != null && !l.bitmap.isRecycled()) {
                Matrix m = new Matrix();
                m.postRotate(90);
                Bitmap b = Bitmap.createBitmap(l.bitmap, 0, 0, l.bitmap.getWidth(), l.bitmap.getHeight(), m, true);
                if (b != l.bitmap) {
                    l.bitmap.recycle();
                    l.bitmap = b;
                }
            }
        }
        refreshUIFromHistory();
        post(new Runnable() { public void run() { fitCenter(); } });
        if (stepListener != null) stepListener.onStepFinished();
    }

    public void flipHorizontal() {
        history.addFlipH();
        for (LayerManager.LayerItem l : layerManager.getLayers()) {
            if (l.bitmap != null && !l.bitmap.isRecycled()) {
                Matrix m = new Matrix();
                m.postScale(-1, 1);
                Bitmap b = Bitmap.createBitmap(l.bitmap, 0, 0, l.bitmap.getWidth(), l.bitmap.getHeight(), m, true);
                if (b != l.bitmap) {
                    l.bitmap.recycle();
                    l.bitmap = b;
                }
            }
        }
        refreshUIFromHistory();
        post(new Runnable() { public void run() { fitCenter(); } });
        if (stepListener != null) stepListener.onStepFinished();
    }

    public void flipVertical() {
        history.addFlipV();
        for (LayerManager.LayerItem l : layerManager.getLayers()) {
            if (l.bitmap != null && !l.bitmap.isRecycled()) {
                Matrix m = new Matrix();
                m.postScale(1, -1);
                Bitmap b = Bitmap.createBitmap(l.bitmap, 0, 0, l.bitmap.getWidth(), l.bitmap.getHeight(), m, true);
                if (b != l.bitmap) {
                    l.bitmap.recycle();
                    l.bitmap = b;
                }
            }
        }
        refreshUIFromHistory();
        post(new Runnable() { public void run() { fitCenter(); } });
        if (stepListener != null) stepListener.onStepFinished();
    }

    public void resizeBitmap(int nw, int nh) {
        if (currentBitmap == null) return;
        Bitmap nb = Bitmap.createScaledBitmap(currentBitmap, nw, nh, true);
        if (originalBitmap != null && !originalBitmap.isRecycled()) {
            Bitmap scaledOrig = Bitmap.createScaledBitmap(originalBitmap, nw, nh, true);
            if (scaledOrig != originalBitmap) {
                originalBitmap.recycle();
                originalBitmap = scaledOrig;
            }
        }
        for (LayerManager.LayerItem l : layerManager.getLayers()) {
            if (l.bitmap != null && !l.bitmap.isRecycled()) {
                Bitmap scaled = Bitmap.createScaledBitmap(l.bitmap, nw, nh, true);
                if (scaled != l.bitmap) {
                    l.bitmap.recycle();
                    l.bitmap = scaled;
                }
            }
        }
        setImageBitmap(nb);
        resetToCenter();
        history.addResize(nw, nh);
    }

    // ==================== 色度抠图（Chroma Key） ====================

    /**
     * 取得抠图要作用的目标位图。
     *
     * 规则：只作用于**当前图层**。如果当前是底图层（index 0），
     * 先复制成一个新图层再抠，避免破坏底图。
     *
     * @return 目标图层的位图（可能是新复制出来的），失败返回 null
     */
    public Bitmap prepareChromaTarget() {
        int w = originalBitmap != null ? originalBitmap.getWidth() : 0;
        int h = originalBitmap != null ? originalBitmap.getHeight() : 0;
        if (w <= 0 || h <= 0) return null;
        // ★ 按用户思路：抠图就作用于"看到的这张图"，也就是底图本身。
        //   返回副本用于计算，真正的写入在 applyChromaPixels 里原地改底图。
        try {
            if (originalBitmap.isMutable()
                    && originalBitmap.getConfig() == Bitmap.Config.ARGB_8888) {
                return originalBitmap.copy(Bitmap.Config.ARGB_8888, false);
            }
            // 底图不可变：先复制一份可变的再返回（apply 时会替换掉）
            return originalBitmap.copy(Bitmap.Config.ARGB_8888, true);
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * 抠图前的准备：不新建图层，只返回"将会被作用的位图"和图层序号。
     * 真正的图层创建放到 applyChromaKey 里，用户取消就不留痕迹。
     */
    public int chromaTargetLayerSize() {
        return layerManager.size();
    }

    /**
     * 把抠图结果应用到当前图层（必要时先建层），并写入历史。
     *
     * @param px 处理后的像素（长度 = w*h）
     * @param w  宽
     * @param h  高
     * @return 是否成功
     */
    public boolean applyChromaPixels(int[] px, int w, int h) {
        if (px == null || w <= 0 || h <= 0) return false;
        if (originalBitmap == null || originalBitmap.isRecycled()) return false;
        if (originalBitmap.getWidth() != w || originalBitmap.getHeight() != h) return false;

        // ★ 直接改底图：把抠好的像素原样写回去。
        //   底图就是用户看到的那张图，所以透明会真实呈现出来，
        //   不会再被"下面垫着的底图"盖住。
        Bitmap before = null;
        try {
            before = originalBitmap.copy(Bitmap.Config.ARGB_8888, false);
        } catch (Throwable ignored) {
        }

        if (originalBitmap.isMutable()) {
            try {
                originalBitmap.setPixels(px, 0, w, 0, 0, w, h);
            } catch (Throwable t) {
                // 某些设备 mutable 位图也可能拒绝 setPixels，退回整张替换
                try {
                    Bitmap nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    nb.setPixels(px, 0, w, 0, 0, w, h);
                    originalBitmap = nb;
                    currentBitmap = nb;
                    super.setImageBitmap(nb);
                } catch (Throwable t2) {
                    return false;
                }
            }
        } else {
            try {
                Bitmap nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                nb.setPixels(px, 0, w, 0, 0, w, h);
                originalBitmap = nb;
                currentBitmap = nb;
                super.setImageBitmap(nb);
            } catch (Throwable t) {
                return false;
            }
        }

        // 历史：记录底图变化，可撤销
        if (before != null) {
            history.addDrawLayer(0, before);
        }
        basePixelModified = true;
        transparentDirty = true;
        // ★ 底图像素变了，所有基于底图的缓存都必须作废：
        //   否则画布上还盖着"抠图前"的蒙版缓存图（不透明），
        //   把刚抠出来的透明区域整个遮住 —— 表现就是"天空变白"。
        maskCacheDirty = true;
        maskOverlayDirty = true;
        thumbFilteredSig = 0L;
        invalidate();
        if (stepListener != null) stepListener.onStepFinished();
        return true;
    }

    /** 底图像素是否被直接改过（抠图/超分等），保存时必须用内存版本而非重读原文件。 */
    private boolean basePixelModified = false;

    /** 底图是否被像素级修改过。 */
    public boolean isBasePixelModified() {
        return basePixelModified;
    }

    /** 标记底图已被像素级修改。 */
    public void markBasePixelModified() {
        basePixelModified = true;
    }

    // ==================== 局部蒙版 ====================
    /** 当前图片上的所有蒙版（按添加顺序叠加）。 */
    private final java.util.List<Mask.MaskItem> masks =
            new java.util.ArrayList<Mask.MaskItem>();

    public java.util.List<Mask.MaskItem> getMasks() {
        return masks;
    }

    public void addMask(Mask.MaskItem m) {
        if (m != null) {
            java.util.List<Mask.MaskItem> before = snapshotMasks();
            masks.add(m);
            maskCacheDirty = true;
            maskOverlayDirty = true;
            history.addMasks(before);   // 记录"加之前"的状态，撤销即可回到没蒙版
            invalidate();
        }
    }

    /** 直接从存储还原蒙版列表（不写历史，供加载时用）。 */
    public void restoreMasks(java.util.List<Mask.MaskItem> list) {
        masks.clear();
        if (list != null) {
            for (Mask.MaskItem m : list) {
                if (m != null) masks.add(m);
            }
        }
        maskCacheDirty = true;
        maskOverlayDirty = true;
        invalidate();
    }

    /** 当前蒙版的深拷贝快照。 */
    public java.util.List<Mask.MaskItem> snapshotMasks() {
        java.util.List<Mask.MaskItem> list = new java.util.ArrayList<Mask.MaskItem>();
        for (Mask.MaskItem m : masks) {
            if (m != null) list.add(m.copy());
        }
        return list;
    }

    /** 蒙版参数被外部改过之后，记一笔历史（供撤销）。 */
    public void commitMaskChange(java.util.List<Mask.MaskItem> before) {
        if (before != null) history.addMasks(before);
        maskCacheDirty = true;
        maskOverlayDirty = true;
        invalidate();
    }

    public void removeMask(int index) {
        if (index >= 0 && index < masks.size()) {
            java.util.List<Mask.MaskItem> before = snapshotMasks();
            masks.remove(index);
            maskCacheDirty = true;
            maskOverlayDirty = true;
            history.addMasks(before);
            invalidate();
        }
    }

    public void clearMasks() {
        masks.clear();
        invalidate();
    }

    public boolean hasMasks() {
        for (Mask.MaskItem m : masks) {
            if (m.enabled && m.hasAdjustment()) return true;
        }
        return false;
    }

    /** 把蒙版应用到像素数组（在所有滤镜之后调用）。 */
    private void applyMasksToPixels(int[] px, int w, int h) {
        applyMasksToPixels(px, w, h, w, h);
    }

    private void applyMasksToPixels(int[] px, int w, int h, int fullW, int fullH) {
        if (px == null || masks.isEmpty()) return;
        for (Mask.MaskItem m : masks) {
            if (m == null || !m.enabled || !m.hasAdjustment()) continue;
            try {
                Mask.apply(px, w, h, m);
            } catch (Throwable ignored) {
            }
        }
    }

    /** 是否显示蒙版范围提示（只在蒙版面板打开时为 true）。 */
    private boolean showMaskIndicator = false;
    /** 当前正在编辑的蒙版索引（-1 表示不显示）。 */
    private int editingMaskIndex = -1;

    /** 径向蒙版拖拽模式：true 时单指拖动移动中心，双指缩放大小。 */
    private boolean isMaskDragMode = false;
    private int maskDragIndex = -1;
    private float dragLastX = -1, dragLastY = -1;
    private float dragBaseDist = -1;
    private float dragBaseRx = 0.3f, dragBaseRy = 0.3f;

    public void setMaskDragMode(boolean on, int maskIndex) {
        this.isMaskDragMode = on;
        this.maskDragIndex = maskIndex;
        this.dragLastX = -1;
        this.dragLastY = -1;
        this.dragBaseDist = -1;
        invalidate();
    }

    /** 正在拖动的控制点：0=左 1=右 2=上 3=下 -1=无 */
    private int dragHandle = -1;

    /**
     * 检测是否按到了椭圆上的控制点。
     * 控制点位置（与绘制一致）：中心 ± (rx,0) 和中心 ± (0,ry)，经过旋转。
     * 返回 0..3 或 -1。
     */
    private int hitTestHandle(Mask.MaskItem m, float bx, float by, int w, int h) {
        if (m == null || m.type != Mask.TYPE_RADIAL) return -1;
        float aspect = (float) w / h;
        double rad = Math.toRadians(m.rotation);
        double cos = Math.cos(rad), sin = Math.sin(rad);
        // 四个控制点在"未旋转椭圆坐标系"中的位置
        float[] lx = {-1f, 1f, 0f, 0f};
        float[] ly = {0f, 0f, -1f, 1f};
        // 触摸容差：按图片尺寸给，但设上限，并且不能超过椭圆自身半径的 80%，
        // 否则小椭圆上四个点会挤在一起，点哪都算命中。
        float rxPx = Math.max(1f, m.rx * w);
        float ryPx = Math.max(1f, m.ry * h);
        float hitRadius = Math.min(Math.max(w, h) * 0.05f,
                Math.min(rxPx, ryPx) * 0.8f);
        hitRadius = Math.max(hitRadius, 18f);   // 太小时手指点不中
        for (int i = 0; i < 4; i++) {
            // 椭圆上的点（相对中心，已含 aspect 修正）
            float ex = lx[i] * m.rx * aspect;
            float ey = ly[i] * m.ry;
            // 旋转到图片坐标
            float rxr = (float) (ex * cos - ey * sin);
            float ryr = (float) (ex * sin + ey * cos);
            // 转回像素坐标
            float hx = (m.cx + rxr / aspect) * w;
            float hy = (m.cy + ryr) * h;
            float dx = bx - hx, dy = by - hy;
            if (dx * dx + dy * dy <= hitRadius * hitRadius) {
                return i;
            }
        }
        return -1;
    }

    /** 径向蒙版拖动：移动中心 / 缩放大小。 */
    private boolean handleMaskDragTouch(MotionEvent e) {
        if (maskDragIndex < 0 || maskDragIndex >= masks.size()) return false;
        Mask.MaskItem m = masks.get(maskDragIndex);
        if (m == null || m.type != Mask.TYPE_RADIAL) return false;
        float[] pt = screenToBitmap(e.getX(), e.getY());
        int w = originalBitmap != null ? originalBitmap.getWidth() : 0;
        int h = originalBitmap != null ? originalBitmap.getHeight() : 0;
        if (w <= 0 || h <= 0) return false;

        int action = e.getActionMasked();
        if (e.getPointerCount() >= 2) {
            // 双指缩放：按两指距离比例调整 rx/ry
            float dx = e.getX(0) - e.getX(1);
            float dy = e.getY(0) - e.getY(1);
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            if (action == MotionEvent.ACTION_POINTER_DOWN || dragBaseDist < 0) {
                dragBaseDist = dist;
                dragBaseRx = m.rx;
                dragBaseRy = m.ry;
            } else if (dragBaseDist > 1f) {
                float ratio = dist / dragBaseDist;
                m.rx = Math.max(0.03f, Math.min(1.5f, dragBaseRx * ratio));
                m.ry = Math.max(0.03f, Math.min(1.5f, dragBaseRy * ratio));
                maskCacheDirty = true;
                invalidate();
            }
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                dragLastX = pt[0];
                dragLastY = pt[1];
                dragHandle = hitTestHandle(m, pt[0], pt[1], w, h);
                if (maskAppliedCache == null || maskAppliedCache.isRecycled()) {
                    maskCacheDirty = true;
                    getMaskAppliedBitmap();
                }
                maskInteracting = true;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragHandle >= 0) {
                    // 拖动控制点：把触摸位置换算到椭圆坐标系，直接改 rx 或 ry
                    float aspect2 = (float) w / h;
                    double rad2 = Math.toRadians(m.rotation);
                    double cs = Math.cos(rad2), sn = Math.sin(rad2);
                    // 触摸点相对中心的偏移（图片坐标）
                    float ox = pt[0] - m.cx * w;
                    float oy = pt[1] - m.cy * h;
                    // 反向旋转到椭圆坐标
                    float ux = (float) (ox * cs + oy * sn);
                    float uy = (float) (-ox * sn + oy * cs);
                    if (dragHandle == 0 || dragHandle == 1) {
                        // 左右控制点：改 rx
                        float newRx = Math.abs(ux) / w / aspect2;
                        m.rx = Math.max(0.03f, Math.min(1.5f, newRx));
                    } else {
                        // 上下控制点：改 ry
                        float newRy = Math.abs(uy) / h;
                        m.ry = Math.max(0.03f, Math.min(1.5f, newRy));
                    }
                    maskInteracting = true;
                    invalidate();
                } else if (dragLastX >= 0) {
                    float ddx = (pt[0] - dragLastX) / w;
                    float ddy = (pt[1] - dragLastY) / h;
                    m.cx = Math.max(0f, Math.min(1f, m.cx + ddx));
                    m.cy = Math.max(0f, Math.min(1f, m.cy + ddy));
                    maskInteracting = true;
                    invalidate();
                }
                dragLastX = pt[0];
                dragLastY = pt[1];
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragLastX = -1;
                dragLastY = -1;
                dragBaseDist = -1;
                dragHandle = -1;
                maskInteracting = false;
                maskCacheDirty = true;   // 松手后重算一次完整效果
                invalidate();
                if (stepListener != null) stepListener.onStepFinished();
                return true;
        }
        return false;
    }

    /** 蒙版效果缓存位图（避免每帧重算）与失效标记。 */
    private Bitmap maskAppliedCache = null;
    private boolean maskCacheDirty = true;
    private int maskCacheW = 0, maskCacheH = 0;
    /** 蒙版重算用的像素缓冲（复用，避免反复分配大数组）。 */
    private int[] maskPixBuf = null;
    /** 提示色覆盖图缓存（画笔/颜色类，避免每帧重建全尺寸位图）。 */
    private Bitmap maskOverlayCache = null;
    private boolean maskOverlayDirty = true;
    private int maskOverlayType = -1;
    private int maskOverlayPixHash = 0;
    /** 正在拖动/涂抹中：冻结效果重算，只重画提示色（避免大图逐像素重算导致卡顿）。 */
    private volatile boolean maskInteracting = false;

    /** 蒙版参数变化时调用：让缓存失效。 */
    public void setMaskInteracting(boolean on) {
        maskInteracting = on;
        invalidate();
    }

    /**
     * 主动释放可选缓存，降低内存占用（切换图片、进入后台、内存紧张时调用）。
     *
     * 这些缓存都是「可以随时重建」的，留着只是省点时间，代价是几十 MB 常驻。
     */
    public void releaseOptionalCaches() {
        try {
            if (maskAppliedCache != null && !maskAppliedCache.isRecycled()) maskAppliedCache.recycle();
            maskAppliedCache = null;
            maskCacheDirty = true;
        } catch (Throwable ignored) {}
        try {
            if (maskOverlayCache != null && !maskOverlayCache.isRecycled()) maskOverlayCache.recycle();
            maskOverlayCache = null;
            maskOverlayDirty = true;
        } catch (Throwable ignored) {}
        try {
            if (thumbFilteredCache != null && !thumbFilteredCache.isRecycled()) thumbFilteredCache.recycle();
            thumbFilteredCache = null;
            thumbFilteredSig = 0L;
        } catch (Throwable ignored) {}
        try {
            if (maskPixBuf != null) maskPixBuf = null;   // int[w*h] 也有几十 MB
        } catch (Throwable ignored) {}
        try {
            if (hslPreviewSrc != null && !hslPreviewSrc.isRecycled()) hslPreviewSrc.recycle();
            hslPreviewSrc = null;
            if (hslPreviewOut != null && !hslPreviewOut.isRecycled()) hslPreviewOut.recycle();
            hslPreviewOut = null;
            if (noisePreviewSrc != null && !noisePreviewSrc.isRecycled()) noisePreviewSrc.recycle();
            noisePreviewSrc = null;
            if (noisePreviewOut != null && !noisePreviewOut.isRecycled()) noisePreviewOut.recycle();
            noisePreviewOut = null;
            if (preStrokeSnapshot != null && !preStrokeSnapshot.isRecycled()) preStrokeSnapshot.recycle();
            preStrokeSnapshot = null;
            // 套索的剪切板和移动快照也可能有好几 MB
            if (lassoClip != null && !lassoClip.isRecycled()) lassoClip.recycle();
            lassoClip = null;
            if (lassoMoveBase != null && !lassoMoveBase.isRecycled()) lassoMoveBase.recycle();
            lassoMoveBase = null;
            lassoMoving = false;
            lasso.reset();
        } catch (Throwable ignored) {}
    }

    /**
     * 底图像素/尺寸变了之后，把所有「依赖底图内容」的缓存一次性作废。
     * 漏掉任何一项都会导致画布上盖着旧图（例如抠图的透明被旧的不透明缓存遮住）。
     */
    private void invalidateAllBaseCaches() {
        maskCacheDirty = true;
        maskOverlayDirty = true;
        transparentDirty = true;
        thumbFilteredSig = 0L;
    }

    public void invalidateMaskCache() {
        maskCacheDirty = true;
        maskOverlayDirty = true;   // 参数变了，颜色类提示色也要重算
        // 后台预计算：不要等 onDraw 时再算（那时在 UI 线程，会卡住拖动）
        scheduleMaskRecompute();
        invalidate();
    }

    /** 后台重算标志，避免堆积多个任务。 */
    private volatile boolean maskRecomputeScheduled = false;

    /**
     * 在后台线程重算蒙版效果，算好后回到 UI 线程换缓存。
     *
     * 好处：拖动滑轨时 UI 线程只负责绘制，不参与逐像素计算。
     */
    private void scheduleMaskRecompute() {
        if (maskRecomputeScheduled) return;
        if (masks.isEmpty()) return;
        maskRecomputeScheduled = true;
        new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        // 在后台准备好源图（缩放 + 拷贝），再做逐像素计算
                        Bitmap base = currentBitmap != null && !currentBitmap.isRecycled()
                                ? currentBitmap : originalBitmap;
                        if (base == null || base.isRecycled()) return;
                        int bw = base.getWidth(), bh = base.getHeight();
                        final long PREVIEW_AREA = 1200000L;
                        long area = (long) bw * bh;
                        Bitmap src = base;
                        boolean scaled = false;
                        if (area > PREVIEW_AREA) {
                            float f = (float) Math.sqrt((double) PREVIEW_AREA / area);
                            int pw = Math.max(1, Math.round(bw * f));
                            int ph = Math.max(1, Math.round(bh * f));
                            Bitmap small = Bitmap.createScaledBitmap(base, pw, ph, true);
                            if (small != null) { src = small; scaled = true; }
                        }
                        int w = src.getWidth(), h = src.getHeight();
                        int[] px = new int[w * h];
                        src.getPixels(px, 0, w, 0, 0, w, h);
                        applyMasksToPixels(px, w, h, bw, bh);
                        final Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                        out.setPixels(px, 0, w, 0, 0, w, h);
                        if (scaled && src != base && !src.isRecycled()) src.recycle();

                        final int ow = w, oh = h;
                        post(new Runnable() {
                                @Override public void run() {
                                    try {
                                        if (maskAppliedCache != null && !maskAppliedCache.isRecycled()) {
                                            maskAppliedCache.recycle();
                                        }
                                        maskAppliedCache = out;
                                        maskCacheW = ow;
                                        maskCacheH = oh;
                                        maskCacheDirty = false;
                                        invalidate();
                                    } catch (Throwable ignored) {
                                    }
                                    maskRecomputeScheduled = false;
                                }
                            });
                    } catch (Throwable t) {
                        maskRecomputeScheduled = false;
                    }
                }
            }, "weifp-mask").start();
    }

    /**
     * 生成"叠加了蒙版"的图片（带缓存）。
     * onDraw 每帧都会调 getDrawable() 的原图，蒙版需要在这一层生效。
     */
    /**
     * 蒙版效果图（供 onDraw 叠加）。
     *
     * 性能策略（这是原来卡顿的根因：每次拖动都全分辨率逐像素重算）：
     *  - 低位预览：宽高按屏幕能显示的最大尺寸封顶，像素量控制在 ~100 万以内
     *  - 复用位图：尺寸不变就复用同一张 Bitmap，不反复 createBitmap
     *  - 拖动滑轨时只重算预览尺寸，松手后补一次全分辨率
     */
    public Bitmap getMaskAppliedBitmap() {
        Bitmap base = currentBitmap != null && !currentBitmap.isRecycled()
                ? currentBitmap : originalBitmap;
        if (base == null || base.isRecycled()) return null;
        if (!hasMasks()) return base;

        if (maskInteracting && maskAppliedCache != null && !maskAppliedCache.isRecycled()) {
            return maskAppliedCache;
        }
        if (!maskCacheDirty && maskAppliedCache != null && !maskAppliedCache.isRecycled()
                && maskAppliedCache.getWidth() == maskCacheW
                && maskAppliedCache.getHeight() == maskCacheH) {
            return maskAppliedCache;
        }
        // ★ 缓存过期时不在 UI 线程算：先返回旧缓存（或原图），
        //   让后台线程算好了再换上去。这样拖动滑轨不会卡。
        if (maskAppliedCache != null && !maskAppliedCache.isRecycled()) {
            scheduleMaskRecompute();
            return maskAppliedCache;
        }
        scheduleMaskRecompute();
        return base;
    }

    /** 蒙版画笔模式 */
    private boolean isMaskBrushMode = false;
    private int maskBrushIndex = -1;
    private float maskBrushRadius = 40f;
    private int maskBrushStrength = 100;
    private boolean isMaskBrushErase = false;
    private float lastMaskX = -1, lastMaskY = -1;

    /** 开启/关闭蒙版画笔模式。 */
    public void setMaskBrushMode(boolean on, int maskIndex, float radiusDp, int strength,
                                 boolean erase) {
        this.isMaskBrushMode = on;
        this.maskBrushIndex = maskIndex;
        this.maskBrushRadius = radiusDp;
        this.maskBrushStrength = strength;
        this.isMaskBrushErase = erase;
        this.lastMaskX = -1;
        this.lastMaskY = -1;
        invalidate();
    }

    /** 处理蒙版画笔触摸。返回 true 表示已消费该事件。 */
    /**
     * 套索触摸处理：单指画选区。
     *
     * 画的过程中实时显示路径；抬手后选区生效，
     * 之后由工具栏的操作按钮（清除/填充/剪切/粘贴）作用在选区上。
     */
    private boolean handleLassoTouch(MotionEvent e) {
        Bitmap base = originalBitmap != null && !originalBitmap.isRecycled()
                ? originalBitmap : currentBitmap;
        if (base == null) return false;
        float[] pt = screenToBitmap(e.getX(), e.getY());

        // ---- 移动模式：拖动浮起来的内容 ----
        if (lassoMoving) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lassoMoveLastX = pt[0];
                    lassoMoveLastY = pt[1];
                    return true;
                case MotionEvent.ACTION_MOVE:
                    lassoMoveDx += pt[0] - lassoMoveLastX;
                    lassoMoveDy += pt[1] - lassoMoveLastY;
                    lassoMoveLastX = pt[0];
                    lassoMoveLastY = pt[1];
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                    lassoEndMove();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    lassoCancelMove();
                    return true;
            }
            return true;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lasso.reset();
                lasso.addPoint(pt[0], pt[1]);
                lassoDrawing = true;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (lassoDrawing) {
                    lasso.addPoint(pt[0], pt[1]);
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                lassoDrawing = false;
                if (lasso.isEmpty()) {
                    lasso.reset();
                }
                invalidate();
                return true;
        }
        return false;
    }

    private boolean handleMaskBrushTouch(MotionEvent e) {
        if (maskBrushIndex < 0 || maskBrushIndex >= masks.size()) return false;
        Mask.MaskItem m = masks.get(maskBrushIndex);
        if (m == null || m.type != Mask.TYPE_BRUSH) return false;
        Bitmap base = originalBitmap != null ? originalBitmap : currentBitmap;
        if (base == null || base.isRecycled()) return false;
        int w = base.getWidth(), h = base.getHeight();
        if (w <= 0 || h <= 0) return false;
        if (m.brushAlpha == null || m.brushAlpha.length != w * h) {
            m.brushAlpha = new byte[w * h];
        }
        float[] pt = screenToBitmap(e.getX(), e.getY());
        float x = pt[0], y = pt[1];
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastMaskX = x; lastMaskY = y;
                maskInteracting = true;
                Mask.brushStamp(m, w, h, x, y, maskBrushRadius, maskBrushStrength, isMaskBrushErase);
                maskOverlayDirty = true;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (lastMaskX >= 0) {
                    Mask.brushLine(m, w, h, lastMaskX, lastMaskY, x, y,
                            maskBrushRadius, maskBrushStrength, isMaskBrushErase);
                } else {
                    Mask.brushStamp(m, w, h, x, y, maskBrushRadius, maskBrushStrength, isMaskBrushErase);
                }
                lastMaskX = x; lastMaskY = y;
                maskOverlayDirty = true;
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                lastMaskX = -1; lastMaskY = -1;
                maskInteracting = false;
                maskCacheDirty = true;
                invalidate();
                if (stepListener != null) stepListener.onStepFinished();
                return true;
        }
        return false;
    }

    /** 蒙版提示色：蓝紫半透明。 */
    private static final int MASK_TINT = 0x558A7CF0;

    public void setMaskIndicatorVisible(boolean visible, int editingIndex) {
        this.showMaskIndicator = visible;
        this.editingMaskIndex = editingIndex;
        maskOverlayDirty = true;   // 切换蒙版：提示色缓存作废
        invalidate();
    }

    /** 蒙版面板锁定：锁定期间忽略 hideMaskIndicator（防止调参时提示被误关）。 */
    private boolean maskIndicatorLocked = false;
    /** 调数值期间临时隐藏提示圈/画笔线（效果照常）。 */
    private boolean maskIndicatorTempHidden = false;

    public void setMaskIndicatorHideTemporarily(boolean hidden) {
        this.maskIndicatorTempHidden = hidden;
        invalidate();
    }

    public void setMaskIndicatorLocked(boolean locked) {
        this.maskIndicatorLocked = locked;
    }

    public void hideMaskIndicator() {
        if (maskIndicatorLocked) return;   // 锁定中不关
        this.showMaskIndicator = false;
        this.editingMaskIndex = -1;
        invalidate();
    }

    /** 画蒙版范围提示（在图片坐标系内绘制，跟随缩放）。 */
    // 提示层复用的绘制对象（避免每帧 new，拖动时会产生大量垃圾）
    private final Paint indFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indGrad = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indHandleFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indHandleRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final android.graphics.RectF indRect = new android.graphics.RectF();
    private final android.graphics.RectF indRect2 = new android.graphics.RectF();

    private void drawMaskIndicator(Canvas canvas) {
        if (maskIndicatorTempHidden) return;   // 调数值期间不画提示
        if (!showMaskIndicator || editingMaskIndex < 0
                || editingMaskIndex >= masks.size()) return;
        Mask.MaskItem m = masks.get(editingMaskIndex);
        if (m == null) return;
        Bitmap base = originalBitmap != null ? originalBitmap : currentBitmap;
        if (base == null || base.isRecycled()) return;
        int w = base.getWidth(), h = base.getHeight();
        if (w <= 0 || h <= 0) return;

        Paint p = indFill;
        p.setStyle(Paint.Style.FILL);
        p.setColor(MASK_TINT);
        p.setFilterBitmap(true);

        if (m.type == Mask.TYPE_RADIAL) {
            // Lightroom 风格：画出内外两个椭圆
            //   内椭圆 = 满强度区域，外椭圆 = 发散边界，中间用径向渐变填充
            canvas.save();
            float aspect = (float) w / h;
            canvas.translate(m.cx * w, m.cy * h);
            canvas.rotate(m.rotation);
            // ★ 不要在这里再乘宽高比：权重计算里 aspect 已经相互抵消，
            //   真实生效范围就是 rx=rx*w、ry=ry*h 的椭圆。
            //   多乘一次会让椭圆框比实际生效区宽 aspect 倍（对不上）。

            float rx = Math.max(1f, m.rx * w);
            float ry = Math.max(1f, m.ry * h);
            double spread = 1.0 + (m.feather / 100.0) * 1.5;
            float orx = (float) (rx * spread);
            float ory = (float) (ry * spread);

            // 1) 内椭圆：实心蓝紫（表示完全生效）
            android.graphics.RectF innerRect = indRect;
            innerRect.set(-rx, -ry, rx, ry);
            p.setColor(0x4D8A7CF0);   // 30% 蓝紫
            canvas.drawOval(innerRect, p);

            // 2) 内外之间：径向渐变（表示发散范围）
            //    先把画布压成椭圆比例，再画圆形径向渐变，最终呈现为椭圆渐变。
            if (spread > 1.01) {
                Paint gradP = indGrad;
                float gradR = 1.0f;   // 归一化半径，靠 canvas 缩放映射到椭圆
                gradP.setStyle(Paint.Style.FILL);
                gradP.setColor(0xFFFFFFFF);
                gradP.setShader(new android.graphics.RadialGradient(
                        0, 0, gradR,
                        new int[]{0x4D8A7CF0, 0x338A7CF0, 0x008A7CF0},
                        new float[]{0f, (float) (1.0 / spread), 1f},
                        android.graphics.Shader.TileMode.CLAMP));
                canvas.save();
                canvas.scale(orx, ory);   // 半径 1 -> 椭圆
                canvas.drawCircle(0, 0, gradR, gradP);
                canvas.restore();
                gradP.setShader(null);    // 用完清掉
            }

            // 3) 外椭圆描边（发散边界）
            Paint outerStroke = indStroke;
            outerStroke.setShader(null);
            outerStroke.setStyle(Paint.Style.STROKE);
            outerStroke.setStrokeWidth(Math.max(1.5f, w / 600f));
            outerStroke.setColor(0x668A7CF0);
            indRect2.set(-orx, -ory, orx, ory);
            canvas.drawOval(indRect2, outerStroke);

            // 4) 内椭圆描边（主边界，实线）
            Paint innerStroke = indStroke;
            innerStroke.setShader(null);
            innerStroke.setStyle(Paint.Style.STROKE);
            innerStroke.setStrokeWidth(Math.max(2f, w / 400f));
            innerStroke.setColor(0xCC8A7CF0);
            canvas.drawOval(innerRect, innerStroke);

            // 5) 四个控制点（Lightroom 风格）：左右改长度、上下改高度
            float hr = Math.max(w, h) * 0.022f;   // 控制点半径
            Paint handleFill = indHandleFill;
            handleFill.setStyle(Paint.Style.FILL);
            handleFill.setColor(0xFFFFFFFF);
            Paint handleRing = indHandleRing;
            handleRing.setStyle(Paint.Style.STROKE);
            handleRing.setStrokeWidth(Math.max(2f, w / 500f));
            handleRing.setColor(0xCC8A7CF0);
            float[] hx = {-rx, rx, 0f, 0f};
            float[] hy = {0f, 0f, -ry, ry};
            for (int i = 0; i < 4; i++) {
                canvas.drawCircle(hx[i], hy[i], hr, handleFill);
                canvas.drawCircle(hx[i], hy[i], hr, handleRing);
            }

            canvas.restore();
        } else if (m.type == Mask.TYPE_BRUSH) {
            // 画笔：把 brushAlpha 画成蓝紫色蒙层（带缓存，涂抹时不重建位图）
            if (m.brushAlpha == null || m.brushAlpha.length != w * h) return;
            if (maskOverlayCache == null || maskOverlayCache.isRecycled()
                    || maskOverlayDirty || maskOverlayType != Mask.TYPE_BRUSH
                    || maskOverlayCache.getWidth() != w || maskOverlayCache.getHeight() != h) {
                if (maskOverlayCache != null && !maskOverlayCache.isRecycled()) {
                    maskOverlayCache.recycle();
                }
                int[] overlay = new int[w * h];
                for (int i = 0; i < overlay.length; i++) {
                    int a = m.brushAlpha[i] & 0xFF;
                    if (a == 0) { overlay[i] = 0; continue; }
                    int alpha = (int) (a * 0.33);
                    overlay[i] = (alpha << 24) | 0x8A7CF0;
                }
                maskOverlayCache = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                maskOverlayCache.setPixels(overlay, 0, w, 0, 0, w, h);
                maskOverlayDirty = false;
                maskOverlayType = Mask.TYPE_BRUSH;
            }
            if (maskOverlayCache != null && !maskOverlayCache.isRecycled()) {
                canvas.drawBitmap(maskOverlayCache, 0, 0, null);
            }
        } else if (m.type == Mask.TYPE_COLOR) {
            // 颜色：把命中的像素画成蓝紫色
            int[] px = new int[w * h];
            base.getPixels(px, 0, w, 0, 0, w, h);
            int[] overlay = new int[w * h];
            for (int i = 0; i < px.length; i++) {
                int wt = Mask.weightAt(m, i % w, i / w, w, h, px[i]);
                if (wt <= 0) { overlay[i] = 0; continue; }
                int alpha = (int) (wt * 0.30);
                overlay[i] = (alpha << 24) | 0x8A7CF0;
            }
            Bitmap ov = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            ov.setPixels(overlay, 0, w, 0, 0, w, h);
            canvas.drawBitmap(ov, 0, 0, null);
            ov.recycle();
        }
    }

    /** 透明检测缓存。 */
    private boolean hasTransparent = false;
    private boolean transparentDirty = true;

    /** 画布上是否存在透明区域（决定是否显示棋盘格）。 */
    private boolean hasTransparentContent() {
        if (transparentDirty) {
            try {
                Bitmap b = originalBitmap;
                if (b != null && !b.isRecycled()) {
                    int w = b.getWidth(), h = b.getHeight();
                    boolean found = false;
                    // ★ 采样密度提高到 64x64，并且一次性读一片而不是逐点 getPixels。
                    //   原来 24x24 逐点采样，大图上步长上百像素，
                    //   天空这种大块区域可能整个被跳过 → 判定"无透明" → 不画棋盘格 → 看着像纯白。
                    int stepY = Math.max(1, h / 64);
                    int stepX = Math.max(1, w / 64);
                    // 一次读一整行，避免 4000+ 次单像素 getPixels 调用
                    int[] lineBuf = new int[w];
                    for (int y = 0; y < h && !found; y += stepY) {
                        b.getPixels(lineBuf, 0, w, 0, y, w, 1);
                        for (int x = 0; x < w; x += stepX) {
                            if (((lineBuf[x] >>> 24) & 0xFF) < 250) { found = true; break; }
                        }
                    }
                    hasTransparent = found;
                }
            } catch (Throwable ignored) {
            }
            transparentDirty = false;
        }
        return hasTransparent;
    }

    /** 标记透明状态需要重新检测。 */
    public void invalidateTransparencyCheck() {
        transparentDirty = true;
        invalidate();
    }

    /** 图片在当前坐标系下的宽度。 */
    private float imageRectWidth() {
        Bitmap b = originalBitmap != null ? originalBitmap : currentBitmap;
        return b != null && !b.isRecycled() ? b.getWidth() : 0;
    }

    /** 图片在当前坐标系下的高度。 */
    private float imageRectHeight() {
        Bitmap b = originalBitmap != null ? originalBitmap : currentBitmap;
        return b != null && !b.isRecycled() ? b.getHeight() : 0;
    }

    /**
     * 画棋盘格表示透明区域。只在图片矩形内绘制，并跟随缩放矩阵。
     */
    private void drawCheckerboard(Canvas canvas, float w, float h) {
        if (w <= 0 || h <= 0) return;
        Paint p = new Paint();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFDDDDDD);
        canvas.drawRect(0, 0, w, h, p);
        p.setColor(0xFFBBBBBB);
        float cell = Math.max(8f, Math.min(w, h) / 24f);
        int cols = (int) Math.ceil(w / cell);
        int rows = (int) Math.ceil(h / cell);
        if ((long) cols * rows > 40000) {
            cell = Math.max(cell, Math.max(w, h) / 200f);
            cols = (int) Math.ceil(w / cell);
            rows = (int) Math.ceil(h / cell);
        }
        for (int ry = 0; ry < rows; ry++) {
            for (int cx = 0; cx < cols; cx++) {
                if (((cx + ry) & 1) == 0) continue;
                float l = cx * cell, t = ry * cell;
                canvas.drawRect(l, t, Math.min(l + cell, w), Math.min(t + cell, h), p);
            }
        }
    }

    /** 抠图预览覆盖层（只显示，不写入图层）。 */
    private Bitmap chromaPreview = null;

    /** 设置/清除抠图预览。传 null 清除。 */
    public void setChromaPreview(Bitmap b) {
        if (chromaPreview != null && !chromaPreview.isRecycled()) chromaPreview.recycle();
        chromaPreview = b;
        invalidate();
    }

    /** 是否正在显示抠图预览。 */
    public boolean hasChromaPreview() {
        return chromaPreview != null && !chromaPreview.isRecycled();
    }

    /** 把抠图结果提交进历史（可撤销）。 */
    public void commitChromaKey(Bitmap before) {
        if (before == null) return;
        history.addDrawLayer(currentLayerIndex, before);
        onLayersChanged();
        invalidate();
        if (stepListener != null) stepListener.onStepFinished();
    }

    /**
     * 取屏幕上某点对应的当前图层像素颜色。
     *
     * @return ARGB，越界或失败返回 0
     */
    public int pickColorAtScreen(float sx, float sy, int radius) {
        float[] p = screenToBitmap(sx, sy);
        int x = (int) p[0], y = (int) p[1];

        // ① 优先从"当前看得见的合成画面"取色：吸管语义就是"取我看到的颜色"。
        //    之前只看当前图层，遇到空白图层就取不到（返回 0），表现为"点了没反应"。
        Bitmap comp = getCompositeForPick();
        if (comp != null && !comp.isRecycled()) {
            int tw = comp.getWidth(), th = comp.getHeight();
            if (x >= 0 && y >= 0 && x < tw && y < th) {
                int[] all = new int[tw * th];
                comp.getPixels(all, 0, tw, 0, 0, tw, th);
                int c = ChromaKey.sampleColor(all, tw, th, x, y, radius);
                comp.recycle();
                if (c != 0) return c;
            } else if (!comp.isRecycled()) {
                comp.recycle();
            }
        }

        // ② 兜底：直接取底图/当前位图
        Bitmap target = currentBitmap != null && !currentBitmap.isRecycled()
                ? currentBitmap : originalBitmap;
        if (target == null || target.isRecycled()) return 0;
        int tw = target.getWidth(), th = target.getHeight();
        if (x < 0 || y < 0 || x >= tw || y >= th) return 0;
        int[] row = new int[1];
        target.getPixels(row, 0, 1, x, y, 1, 1);
        return row[0];
    }

    /**
     * 生成一张"当前看到的画面"用于吸管取色。
     * 会带上滤镜，保证取到的颜色和用户眼睛看到的一致。
     */
    private Bitmap getCompositeForPick() {
        try {
            Bitmap base = originalBitmap;
            if (base == null || base.isRecycled()) return null;
            int w = base.getWidth(), h = base.getHeight();
            if (w <= 0 || h <= 0) return null;
            Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(out);
            c.drawColor(Color.WHITE);
            c.drawBitmap(base, 0, 0, null);
            layerManager.drawAll(c, 1f, 1f);
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 当前图层是否可编辑（用于 UI 判断）。 */
    public boolean canEditCurrentLayer() {
        return currentLayerIndex >= 0 && currentLayerIndex < layerManager.size();
    }

    /** 当前图层序号（调试/展示用）。 */
    public int currentLayerForChroma() {
        return currentLayerIndex;
    }

    /** 底图是否已经超分放大过（避免 RAW 重复全尺寸解码）。 */
    private boolean superResApplied = false;

    public boolean wasSuperResApplied() {
        return superResApplied;
    }

    /**
     * 取出"超分用的底图"：底图 + 历史里的几何/绘制修改，**不含任何滤镜**。
     *
     * A 方案的关键：超分只放大这个，滤镜参数留着原样生效，
     * 所以既不会重复叠加，超分后还能继续调。
     */
    public Bitmap getBaseForSuperRes() {
        if (originalBitmap == null || originalBitmap.isRecycled()) return null;
        // 省内存版：replay 已经返回一张新图，直接在这张图上铺白底，不再额外新建
        Bitmap base;
        try {
            base = history.replay(originalBitmap);
        } catch (Throwable t) {
            base = null;
        }
        if (base == null) {
            try {
                base = originalBitmap.copy(Bitmap.Config.ARGB_8888, true);
            } catch (Throwable t) {
                return null;
            }
        }
        if (base == null) return null;
        if (!base.isMutable()) {
            Bitmap m = base.copy(Bitmap.Config.ARGB_8888, true);
            if (base != originalBitmap && !base.isRecycled()) base.recycle();
            if (m == null) return null;
            base = m;
        }
        // 用 DST_OVER 只在不透明的地方盖白，避免把已有内容擦掉，也不再复制一份
        try {
            Canvas c = new Canvas(base);
            c.drawColor(Color.WHITE, android.graphics.PorterDuff.Mode.DST_OVER);
        } catch (Throwable ignored) {
        }
        return base;
    }

    /**
     * 把超分结果换回底图，**保留所有滤镜参数和图层结构**。
     *
     * 与 replaceDocument 的区别：不清滤镜、不合并图层（图层按新尺寸等比缩放占位）。
     */
    public void applySuperResToBase(Bitmap upscaled) {
        if (upscaled == null || upscaled.isRecycled()) return;
        Bitmap oldOriginal = originalBitmap;
        Bitmap oldCurrent = currentBitmap;
        int oldW = oldOriginal != null ? oldOriginal.getWidth() : 0;
        int oldH = oldOriginal != null ? oldOriginal.getHeight() : 0;
        final int newW = upscaled.getWidth();
        final int newH = upscaled.getHeight();

        // 历史里记录的是旧尺寸的几何操作，清掉；滤镜参数在字段里，不受影响
        try { history.clear(); } catch (Throwable ignored) {}

        // ★ 顺序很重要：先重建图层骨架（layer0 = 新尺寸底图占位），再缩放涂鸦层。
        //   之前"先缩放图层、后 setImageBitmap"会让 layer0 与 drawable 尺寸不一致，
        //   显示时按旧比例拉伸，表现为图片下半部分变形。
        try {
            // drawAll 从不绘制 layer0（由 ImageView 底图负责显示），
            // 所以这里只保留涂鸦层（index >= 1）并等比缩放，不丢用户的笔迹。
            java.util.List<LayerManager.LayerItem> oldLayers =
                    new java.util.ArrayList<LayerManager.LayerItem>(layerManager.getLayers());
            layerManager.clear();
            layerManager.ensureBaseLayer(newW, newH);
            layerManager.addBlankLayer(newW, newH);
            if (oldW > 0 && oldH > 0) {
                for (int i = 1; i < oldLayers.size(); i++) {
                    LayerManager.LayerItem src = oldLayers.get(i);
                    if (src.bitmap == null || src.bitmap.isRecycled()) continue;
                    Bitmap scaled = Bitmap.createScaledBitmap(src.bitmap, newW, newH, true);
                    LayerManager.LayerItem nl = layerManager.canAddLayer()
                            ? layerManager.addBlankLayer(newW, newH) : null;
                    if (nl != null) {
                        nl.bitmap.recycle();
                        nl.bitmap = scaled;
                        nl.visible = src.visible;
                        nl.alpha = src.alpha;
                        nl.applyFilter = src.applyFilter;
                        nl.name = src.name;
                    } else if (scaled != null && !scaled.isRecycled()) {
                        scaled.recycle();
                    }
                    if (!src.bitmap.isRecycled()) src.bitmap.recycle();
                }
            }
            currentLayerIndex = layerManager.size() > 1 ? 1 : 0;
        } catch (Throwable ignored) {}

        // 预览用的临时缩略图是旧尺寸，丢掉让它按需重建
        if (hslPreviewSrc != null && !hslPreviewSrc.isRecycled()) hslPreviewSrc.recycle();
        hslPreviewSrc = null;
        hslPreviewOut = null;
        if (noisePreviewSrc != null && !noisePreviewSrc.isRecycled()) noisePreviewSrc.recycle();
        noisePreviewSrc = null;
        noisePreviewOut = null;
        preStrokeSnapshot = null;
        levelsDirty = true;

        // 先设底图，再覆盖字段，确保 drawable 与 originalBitmap 是同一张
        super.setImageBitmap(upscaled);
        originalBitmap = upscaled;
        currentBitmap = upscaled;
        superResApplied = true;
        basePixelModified = true;
        try { history.setImageSize(upscaled.getWidth(), upscaled.getHeight()); } catch (Throwable ignored) {}
        invalidateAllBaseCaches();
        // 注意：这里**不调用 resetFilters()**，滤镜参数全部保留

        // 缩略图按新尺寸重建（直方图依赖它）
        try {
            if (thumbnailBase != null && !thumbnailBase.isRecycled()) thumbnailBase.recycle();
            int tw = 200, th = newH > 0 ? (int) (200f * newH / newW) : 1;
            if (th > 200) { th = 200; tw = newW > 0 ? (int) (200f * newW / newH) : 1; }
            thumbnailBase = Bitmap.createScaledBitmap(upscaled, Math.max(1, tw),
                    Math.max(1, th), true);
        } catch (Throwable t) {
            thumbnailBase = null;   // 失败就让直方图稍后重建，别让它拖垮整个流程
        }

        if (oldOriginal != null && oldOriginal != upscaled && !oldOriginal.isRecycled()) {
            oldOriginal.recycle();
        }
        if (oldCurrent != null && oldCurrent != upscaled && oldCurrent != oldOriginal
                && !oldCurrent.isRecycled()) {
            oldCurrent.recycle();
        }
        // ★ 刷新显示：super.setImageBitmap 会重置 ImageMatrix，
        //   这里连做两轮 fitCenter（立即一次 + 下一帧一次），
        //   确保无论当前是否还有待处理的布局，矩阵都是新尺寸的正确值。
        fitCenterNow();
        requestRefit();
        debugLog("applySuperResToBase done: drawable="
                + (getDrawable() != null ? getDrawable().getIntrinsicWidth() + "x"
                        + getDrawable().getIntrinsicHeight() : "null")
                + " original=" + (originalBitmap != null ? originalBitmap.getWidth() + "x"
                        + originalBitmap.getHeight() : "null")
                + " current=" + (currentBitmap != null ? currentBitmap.getWidth() + "x"
                        + currentBitmap.getHeight() : "null")
                + " layers=" + layerManager.size()
                + " view=" + getWidth() + "x" + getHeight()
                + " matrix=" + matrix.toShortString());
    }

    /** 立即按当前 drawable 尺寸重算居中矩阵（不强依赖 View 已完成布局）。 */
    private void fitCenterNow() {
        if (getDrawable() == null) return;
        float iw = getDrawable().getIntrinsicWidth();
        float ih = getDrawable().getIntrinsicHeight();
        if (iw <= 0 || ih <= 0) return;
        float vw = getWidth(), vh = getHeight();
        if (vw <= 0 || vh <= 0) {
            // 尚未布局完成：用父容器尺寸兜底
            View parent = (View) getParent();
            if (parent != null) {
                vw = parent.getWidth();
                vh = parent.getHeight();
            }
        }
        if (vw <= 0 || vh <= 0) return;
        float s = Math.min(vw / iw, vh / ih);
        matrix.reset();
        matrix.postScale(s, s);
        matrix.postTranslate((vw - iw * s) / 2f, (vh - ih * s) / 2f);
        currentScale = 1.0f;
        setImageMatrix(matrix);
        invalidate();
    }

    /**
     * 一次性替换整篇文档（超分放大用）。
     *
     * 新图已经是合并后的成品，所以这里把图层清空、历史清空、滤镜参数复位，
     * 避免旧尺寸的图层/历史与新图错位。属于纯新增路径，不影响原有编辑流程。
     */
    public void replaceDocument(Bitmap bmp) {
        if (bmp == null || bmp.isRecycled()) return;
        Bitmap oldOriginal = originalBitmap;
        Bitmap oldCurrent = currentBitmap;

        try { history.clear(); } catch (Throwable ignored) {}
        try { layerManager.clear(); } catch (Throwable ignored) {}

        // 预览用的临时缩略图是旧尺寸/旧内容，一并丢掉
        if (hslPreviewSrc != null && !hslPreviewSrc.isRecycled()) hslPreviewSrc.recycle();
        hslPreviewSrc = null;
        hslPreviewOut = null;
        if (noisePreviewSrc != null && !noisePreviewSrc.isRecycled()) noisePreviewSrc.recycle();
        noisePreviewSrc = null;
        noisePreviewOut = null;
        preStrokeSnapshot = null;

        originalBitmap = bmp;
        currentBitmap = bmp;
        invalidateAllBaseCaches();
        try { resetFilters(); } catch (Throwable ignored) {}
        // setImageBitmap 内部会重建缩略图、基底层和空白绘画层
        super.setImageBitmap(bmp);
        currentBitmap = bmp;

        if (oldOriginal != null && oldOriginal != bmp && !oldOriginal.isRecycled()) {
            oldOriginal.recycle();
        }
        if (oldCurrent != null && oldCurrent != bmp && oldCurrent != oldOriginal
                && !oldCurrent.isRecycled()) {
            oldCurrent.recycle();
        }
        resetToCenter();
        invalidate();
    }

    public boolean undo() {
        EditHistory.Entry e = history.undoAndReturn();
        if (e == null) return false;

        if (e.type == EditHistory.Type.DRAW_LAYER) {
            if (e.layerIndex >= 0 && e.layerIndex < layerManager.size()) {
                LayerManager.LayerItem layer = layerManager.get(e.layerIndex);
                Bitmap cur = layer.bitmap;
                layer.bitmap = e.drawLayerSnapshot;
                e.drawLayerSnapshot = cur;
            }
            invalidate();
            if (stepListener != null) stepListener.onStepFinished();
            return true;
        }

        if (e.type == EditHistory.Type.DELETE_LAYER) {
            layerManager.restoreLayer(e.layerIndex, e.layerSnapshot);
            e.layerSnapshot = null;
            invalidate();
            if (stepListener != null) stepListener.onStepFinished();
            return true;
        }

        if (e.type == EditHistory.Type.ADD_LAYER) {
            layerManager.removeLayerForUndo(layerManager.size() - 1);
            if (e.layerSnapshot != null && e.layerSnapshot.bitmap != null && !e.layerSnapshot.bitmap.isRecycled()) {
                e.layerSnapshot.bitmap.recycle();
            }
            e.layerSnapshot = null;
            int cur = getCurrentLayerIndex();
            if (cur >= layerManager.size()) setCurrentLayerIndex(Math.max(1, layerManager.size() - 1));
            invalidate();
            if (stepListener != null) stepListener.onStepFinished();
            return true;
        }

        if (e.type == EditHistory.Type.NOISE) {
            EditHistory.Entry prev = null;
            for (int i = history.size() - 1; i >= 0; i--) {
                if (history.getEntry(i).type == EditHistory.Type.NOISE) {
                    prev = history.getEntry(i);
                    break;
                }
            }
            if (prev != null) {
                colorNoise = prev.noiseColor;
                lumaNoise = prev.noiseLuma;
            } else {
                colorNoise = 0f;
                lumaNoise = 0f;
            }
        }

        if (e.type == EditHistory.Type.FILTER) {
            EditHistory.Entry prev = null;
            for (int i = history.size() - 1; i >= 0; i--) {
                if (history.getEntry(i).type == EditHistory.Type.FILTER) {
                    prev = history.getEntry(i);
                    break;
                }
            }
            if (prev != null) {
                brightness = prev.brightness;
                contrast = prev.contrast;
                saturation = prev.saturation;
                shadows = prev.shadows;
                highlights = prev.highlights;
                temperature = prev.temperature;
                tint = prev.tint;
                sharpness = prev.sharpness;
                masterLUT = prev.lutM; rLUT = prev.lutR; gLUT = prev.lutG; bLUT = prev.lutB;
                curvePointStrs = prev.curvePts != null ? prev.curvePts : new String[4];
                if (prev.hslHue != null) {
                    hslAdjust.hue = prev.hslHue.clone();
                    hslAdjust.sat = prev.hslSat.clone();
                    hslAdjust.lum = prev.hslLum.clone();
                    hslAdjust.isEmpty();
                }
                if (prev.lvBlack != null) {
                    levelsBlack = prev.lvBlack.clone();
                    levelsGray = prev.lvGray.clone();
                    levelsWhite = prev.lvWhite.clone();
                    levelsDirty = true;
                }
                vibrance = prev.vibrance;
                splitToning.shadowHue = prev.splitShadowHue;
                splitToning.shadowSat = prev.splitShadowSat;
                splitToning.highlightHue = prev.splitHighlightHue;
                splitToning.highlightSat = prev.splitHighlightSat;
                splitToning.balance = prev.splitBalance;
                cbShadowR = prev.cbShadowR; cbShadowG = prev.cbShadowG; cbShadowB = prev.cbShadowB;
                cbMidR = prev.cbMidR; cbMidG = prev.cbMidG; cbMidB = prev.cbMidB;
                cbHighR = prev.cbHighR; cbHighG = prev.cbHighG; cbHighB = prev.cbHighB;
                cubeLut = prev.cubeLut;
                cubeStrength = prev.cubeStrength;
            } else {
                brightness = 0f; contrast = 1f; saturation = 1f;
                shadows = 0f; highlights = 0f; temperature = 0f; tint = 0f; sharpness = 0f;
                masterLUT = null; rLUT = null; gLUT = null; bLUT = null;
                curvePointStrs = new String[4];
                hslAdjust.reset();
                for (int i = 0; i < 4; i++) { levelsBlack[i] = 0; levelsGray[i] = 128; levelsWhite[i] = 255; }
                levelsDirty = true;
                vibrance = 0f;
                splitToning.reset();
                cbShadowR = 0; cbShadowG = 0; cbShadowB = 0;
                cbMidR = 0; cbMidG = 0; cbMidB = 0;
                cbHighR = 0; cbHighG = 0; cbHighB = 0;
                cubeLut = null;
                cubeStrength = 1f;
            }
            rebuildColorMatrix();
            setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        }

        refreshUIFromHistory();
        if (stepListener != null) stepListener.onStepFinished();
        return true;
    }

    public boolean redo() {
        EditHistory.Entry e = history.redoAndReturn();
        if (e == null) return false;

        if (e.type == EditHistory.Type.DRAW_LAYER) {
            if (e.layerIndex >= 0 && e.layerIndex < layerManager.size()) {
                LayerManager.LayerItem layer = layerManager.get(e.layerIndex);
                Bitmap cur = layer.bitmap;
                layer.bitmap = e.drawLayerSnapshot;
                e.drawLayerSnapshot = cur;
            }
            invalidate();
            if (stepListener != null) stepListener.onStepFinished();
            return true;
        }

        if (e.type == EditHistory.Type.ADD_LAYER) {
            layerManager.restoreLayer(layerManager.size(), e.layerSnapshot);
            e.layerSnapshot = null;
            invalidate();
            if (stepListener != null) stepListener.onStepFinished();
            return true;
        }

        if (e.type == EditHistory.Type.DELETE_LAYER) {
            layerManager.removeLayerForUndo(e.layerIndex);
            if (e.layerSnapshot != null && e.layerSnapshot.bitmap != null && !e.layerSnapshot.bitmap.isRecycled()) {
                e.layerSnapshot.bitmap.recycle();
            }
            e.layerSnapshot = null;
            int cur = getCurrentLayerIndex();
            if (cur >= layerManager.size()) setCurrentLayerIndex(Math.max(1, layerManager.size() - 1));
            invalidate();
            if (stepListener != null) stepListener.onStepFinished();
            return true;
        }

        if (e.type == EditHistory.Type.NOISE) {
            colorNoise = e.noiseColor;
            lumaNoise = e.noiseLuma;
        }

        if (e.type == EditHistory.Type.FILTER) {
            brightness = e.brightness;
            contrast = e.contrast;
            saturation = e.saturation;
            shadows = e.shadows;
            highlights = e.highlights;
            temperature = e.temperature;
            tint = e.tint;
            sharpness = e.sharpness;
            masterLUT = e.lutM; rLUT = e.lutR; gLUT = e.lutG; bLUT = e.lutB;
            curvePointStrs = e.curvePts != null ? e.curvePts : new String[4];
            if (e.hslHue != null) {
                hslAdjust.hue = e.hslHue.clone();
                hslAdjust.sat = e.hslSat.clone();
                hslAdjust.lum = e.hslLum.clone();
                hslAdjust.isEmpty();
            }
            if (e.lvBlack != null) {
                levelsBlack = e.lvBlack.clone();
                levelsGray = e.lvGray.clone();
                levelsWhite = e.lvWhite.clone();
                levelsDirty = true;
            }
            vibrance = e.vibrance;
            splitToning.shadowHue = e.splitShadowHue;
            splitToning.shadowSat = e.splitShadowSat;
            splitToning.highlightHue = e.splitHighlightHue;
            splitToning.highlightSat = e.splitHighlightSat;
            splitToning.balance = e.splitBalance;
            cbShadowR = e.cbShadowR; cbShadowG = e.cbShadowG; cbShadowB = e.cbShadowB;
            cbMidR = e.cbMidR; cbMidG = e.cbMidG; cbMidB = e.cbMidB;
            cbHighR = e.cbHighR; cbHighG = e.cbHighG; cbHighB = e.cbHighB;
            cubeLut = e.cubeLut;
            cubeStrength = e.cubeStrength;
            rebuildColorMatrix();
            setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        }

        refreshUIFromHistory();
        if (stepListener != null) stepListener.onStepFinished();
        return true;
    }

    public void applyOverlayResult(Bitmap r) { history.addOverlay(r, 0, 0); refreshUIFromHistory(); }

    private void refreshUIFromHistory() {
        if (originalBitmap == null) return;
        Bitmap result = history.replay(originalBitmap);
        // ★ 撤销/重做后同步蒙版：历史里有蒙版记录就按它恢复
        if (history.sawMaskEntry) {
            masks.clear();
            if (history.lastReplayedMasks != null) {
                for (Mask.MaskItem m : history.lastReplayedMasks) masks.add(m);
            }
            maskCacheDirty = true;
            maskOverlayDirty = true;
        }
        if (result != null) {
            Bitmap out = applyRGBLUT(result);
            if (result != originalBitmap && result != out && !result.isRecycled()) {
                result.recycle();
            }
            currentBitmap = out;
            Matrix t = new Matrix(matrix);
            float s = currentScale;
            isPreviewingLUT = true;
            super.setImageBitmap(out);
            isPreviewingLUT = false;
            matrix.set(t); currentScale = s; setImageMatrix(matrix);
            invalidate();
        }
    }

    /** 缩略图绘制复用对象。 */
    private final Paint thumbPaint = new Paint();
    private ColorFilter colorFilterCache = null;

    /** 缩略图缓存：参数没变就直接复用（直方图/缩略图调用极频繁）。 */
    private Bitmap thumbFilteredCache = null;
    private long thumbFilteredSig = 0L;

    /** 当前滤镜参数的签名，用来判断缩略图缓存是否可用。 */
    public long filterSignature() {
        long sig = 1;
        sig = sig * 31 + Float.floatToIntBits(brightness);
        sig = sig * 31 + Float.floatToIntBits(contrast);
        sig = sig * 31 + Float.floatToIntBits(saturation);
        sig = sig * 31 + Float.floatToIntBits(shadows);
        sig = sig * 31 + Float.floatToIntBits(highlights);
        sig = sig * 31 + Float.floatToIntBits(temperature);
        sig = sig * 31 + Float.floatToIntBits(tint);
        sig = sig * 31 + Float.floatToIntBits(sharpness);
        sig = sig * 31 + Float.floatToIntBits(vibrance);
        sig = sig * 31 + layerManager.size();
        sig = sig * 31 + masks.size();
        // LUT / HSL / 分色调 / 噪点 都会影响缩略图，必须进签名，
        // 否则改了 LUT 直方图还显示旧数据。
        sig = sig * 31 + (masterLUT != null ? masterLUT.hashCode() : 0);
        sig = sig * 31 + (rLUT != null ? rLUT.hashCode() : 0);
        sig = sig * 31 + (gLUT != null ? gLUT.hashCode() : 0);
        sig = sig * 31 + (bLUT != null ? bLUT.hashCode() : 0);
        sig = sig * 31 + (cubeLut != null ? cubeLut.hashCode() : 0);
        sig = sig * 31 + Float.floatToIntBits(cubeStrength);
        sig = sig * 31 + hslAdjust.hashCode();
        sig = sig * 31 + splitToning.hashCode();
        sig = sig * 31 + Float.floatToIntBits(colorNoise);
        sig = sig * 31 + Float.floatToIntBits(lumaNoise);
        sig = sig * 31 + layerManager.size();
        for (int i = 0; i < layerManager.size(); i++) {
            LayerManager.LayerItem li = layerManager.get(i);
            if (li == null) continue;
            sig = sig * 31 + (li.visible ? 1 : 0);
            sig = sig * 31 + li.alpha;
        }
        for (Mask.MaskItem m : masks) {
            if (m == null) continue;
            sig = sig * 31 + (m.enabled ? 1 : 0);
            sig = sig * 31 + Float.floatToIntBits(m.exposure);
            sig = sig * 31 + Float.floatToIntBits(m.contrast);
            sig = sig * 31 + Float.floatToIntBits(m.saturation);
            sig = sig * 31 + Float.floatToIntBits(m.temperature);
            sig = sig * 31 + Float.floatToIntBits(m.clarity);
        }
        return sig;
    }

    /** 缩略图重绘锁：直方图可能在后台线程调用本方法。 */
    private final Object thumbLock = new Object();

    /**
     * 取带滤镜的缩略图。
     *
     * 注意：直方图会从后台线程调用这个方法，所以内部要加锁，
     * 避免和主线程重建 thumbnailBase / 编辑图层时撞车。
     */
    public Bitmap getFilteredThumbnail() {
        synchronized (thumbLock) {
            return getFilteredThumbnailLocked();
        }
    }

    private Bitmap getFilteredThumbnailLocked() {
        if (thumbnailBase == null || thumbnailBase.isRecycled()) return null;
        long sig = filterSignature();
        if (thumbFilteredCache != null && !thumbFilteredCache.isRecycled() && sig == thumbFilteredSig) {
            return thumbFilteredCache;
        }
        int w = thumbnailBase.getWidth(), h = thumbnailBase.getHeight();
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        // ★ 不能用纯黑垫底：缩略图缩放产生的半透明边缘会和黑色混合，
        //   在低亮度段堆积出假的像素，直方图上表现为某处突然升高又断层。
        //   改用中性灰，和照片的实际观感一致。
        c.drawColor(0xFF808080);
        Paint p = thumbPaint;
        p.setFilterBitmap(true);
        colorFilterCache = new ColorMatrixColorFilter(colorMatrix);
        p.setColorFilter(colorFilterCache);
        c.drawBitmap(thumbnailBase, 0, 0, p);

        int ow = originalBitmap != null && !originalBitmap.isRecycled()
                ? originalBitmap.getWidth() : 0;
        int oh = originalBitmap != null && !originalBitmap.isRecycled()
                ? originalBitmap.getHeight() : 0;
        if (ow > 0 && oh > 0) {
            layerManager.drawAll(c, (float) w / ow, (float) h / oh, colorFilterCache);
        }

        Bitmap finalOut = applyRGBLUT(out);
        if (finalOut != out && !out.isRecycled()) out.recycle();

        // 缓存（缩略图很小，长期持有没有内存压力）
        if (thumbFilteredCache != null && !thumbFilteredCache.isRecycled()) {
            // 只有新建的对象才需回收
            if (thumbFilteredCache != finalOut) thumbFilteredCache.recycle();
        }
        thumbFilteredCache = finalOut;
        thumbFilteredSig = sig;
        return finalOut;
    }

    private Bitmap applyRGBLUT(Bitmap src) {
        if (src == null || src.isRecycled()) return src;
        boolean hasRgb = masterLUT != null || rLUT != null || gLUT != null || bLUT != null;
        boolean hasCube = cubeLut != null && cubeStrength > 0f;
        boolean hasHsl = !hslAdjust.isEmpty();
        boolean hasVib = vibrance != 0f;
        boolean hasSplit = !splitToning.isEmpty();
        boolean hasCb = cbShadowR != 0 || cbShadowG != 0 || cbShadowB != 0 || cbMidR != 0 || cbMidG != 0 || cbMidB != 0 || cbHighR != 0 || cbHighG != 0 || cbHighB != 0;
        boolean hasLv = hasLevels();
        boolean hasNs = hasNoise();
        if (hasLv && levelsDirty) rebuildLevelsLut();

        if (!hasRgb && !hasCube && !hasHsl && !hasVib && !hasSplit && !hasCb && !hasLv && !hasNs) return src;

        int w = src.getWidth(), h = src.getHeight();
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);

        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            int a = (c >> 24) & 0xFF;
            int cr = (c >> 16) & 0xFF, cg = (c >> 8) & 0xFF, cb = c & 0xFF;
            if (hasLv) {
                if (levelsBlack[0] != 0 || levelsGray[0] != 128 || levelsWhite[0] != 255) {
                    cr = levelsLut[0][cr]; cg = levelsLut[0][cg]; cb = levelsLut[0][cb];
                }
                if (levelsBlack[1] != 0 || levelsGray[1] != 128 || levelsWhite[1] != 255) cr = levelsLut[1][cr];
                if (levelsBlack[2] != 0 || levelsGray[2] != 128 || levelsWhite[2] != 255) cg = levelsLut[2][cg];
                if (levelsBlack[3] != 0 || levelsGray[3] != 128 || levelsWhite[3] != 255) cb = levelsLut[3][cb];
            }
            if (masterLUT != null) { cr = masterLUT[cr]; cg = masterLUT[cg]; cb = masterLUT[cb]; }
            if (rLUT != null) cr = rLUT[cr];
            if (gLUT != null) cg = gLUT[cg];
            if (bLUT != null) cb = bLUT[cb];
            if (vibrance != 0f) {
                float vf = vibrance / 100f;
                float rf2 = cr / 255f, gf2 = cg / 255f, bf2 = cb / 255f;
                float mx = Math.max(rf2, Math.max(gf2, bf2));
                float mn = Math.min(rf2, Math.min(gf2, bf2));
                float sat = (mx > 0.001f) ? (mx - mn) / mx : 0f;
                float boost = vf * (1f - sat);
                float lum = 0.2126f * rf2 + 0.7152f * gf2 + 0.0722f * bf2;
                rf2 = lum + (rf2 - lum) * (1f + boost);
                gf2 = lum + (gf2 - lum) * (1f + boost);
                bf2 = lum + (bf2 - lum) * (1f + boost);
                int nr2 = (int)(rf2 * 255f), ng2 = (int)(gf2 * 255f), nb2 = (int)(bf2 * 255f);
                if (nr2 < 0) nr2 = 0; if (nr2 > 255) nr2 = 255;
                if (ng2 < 0) ng2 = 0; if (ng2 > 255) ng2 = 255;
                if (nb2 < 0) nb2 = 0; if (nb2 > 255) nb2 = 255;
                cr = nr2; cg = ng2; cb = nb2;
            }
            if (hasSplit) {
                int o = splitToning.applyPixel(cr, cg, cb);
                cr = (o >> 16) & 0xFF; cg = (o >> 8) & 0xFF; cb = o & 0xFF;
            }
            if (hasCb) {
                float lum2 = (0.299f * cr + 0.587f * cg + 0.114f * cb) / 255f;
                float sW = Math.max(0f, 1f - lum2 * 2f);
                float hW = Math.max(0f, lum2 * 2f - 1f);
                float mW = 1f - sW - hW;
                float dR2 = (sW * cbShadowR + mW * cbMidR + hW * cbHighR) * 0.5f;
                float dG2 = (sW * cbShadowG + mW * cbMidG + hW * cbHighG) * 0.5f;
                float dB2 = (sW * cbShadowB + mW * cbMidB + hW * cbHighB) * 0.5f;
                cr = Math.max(0, Math.min(255, cr + (int)dR2));
                cg = Math.max(0, Math.min(255, cg + (int)dG2));
                cb = Math.max(0, Math.min(255, cb + (int)dB2));
            }
            if (hasHsl) {
                int o = hslAdjust.applyPixel(cr, cg, cb);
                cr = (o >> 16) & 0xFF; cg = (o >> 8) & 0xFF; cb = o & 0xFF;
            }
            if (hasCube) {
                int o = cubeLut.applyPixel(cr, cg, cb, cubeStrength);
                cr = (o >> 16) & 0xFF; cg = (o >> 8) & 0xFF; cb = o & 0xFF;
            }
            px[i] = (a << 24) | (cr << 16) | (cg << 8) | cb;
        }

        // 噪点：之前只存在于预览图里，从没烘焙进图片，
        // 导致调完再打开就没了。这里统一在最后一步加上。
        if (hasNs) {
            applyNoiseToPixels(px, w, h, colorNoise, lumaNoise);
        }
        out.setPixels(px, 0, w, 0, 0, w, h);
        return out;
    }

    public Bitmap applyMergedFilters(Bitmap mergedSrc) {
        if (mergedSrc == null || mergedSrc.isRecycled()) return mergedSrc;

        Bitmap colored = Bitmap.createBitmap(mergedSrc.getWidth(), mergedSrc.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(colored);
        Paint p = new Paint();
        p.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        c.drawBitmap(mergedSrc, 0, 0, p);

        Bitmap result = applyRGBLUT(colored);
        if (result != colored && !colored.isRecycled()) colored.recycle();

        // 最后叠加局部蒙版（此时 result 已经是滤镜处理后的图）
        if (hasMasks() && result != null && !result.isRecycled()) {
            int mw = result.getWidth(), mh = result.getHeight();
            try {
                Bitmap mutable = result.isMutable()
                        ? result : result.copy(Bitmap.Config.ARGB_8888, true);
                if (mutable != null) {
                    int[] mpx = new int[mw * mh];
                    mutable.getPixels(mpx, 0, mw, 0, 0, mw, mh);
                    applyMasksToPixels(mpx, mw, mh);
                    mutable.setPixels(mpx, 0, mw, 0, 0, mw, mh);
                    if (mutable != result) {
                        result.recycle();
                        result = mutable;
                    }
                }
            } catch (Throwable ignored) {
            }
        }
        return result;
    }

    public Bitmap getFinalBitmapFromHistory(boolean applyFilter) {
        if (originalBitmap == null) return null;
        Bitmap result = history.replay(originalBitmap);
        if (result == null) return null;

        Bitmap finalBmp = Bitmap.createBitmap(result.getWidth(), result.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(finalBmp);
        // ★ 不再铺白底：抠图产生的透明区域必须保留，否则保存后又会变白。
        canvas.drawBitmap(result, 0, 0, null);
        layerManager.drawAll(canvas, 1f, 1f);

        if (result != originalBitmap && !result.isRecycled()) result.recycle();

        if (applyFilter) {
            Bitmap filtered = applyMergedFilters(finalBmp);
            if (filtered != finalBmp && !finalBmp.isRecycled()) finalBmp.recycle();
            return filtered;
        }
        return finalBmp;
    }

    public Bitmap exportFullRes(Bitmap fullBitmap) { return exportFullRes(fullBitmap, true); }

    public Bitmap exportFullRes(Bitmap fullBitmap, boolean applyFilter) {
        if (fullBitmap == null) return null;
        Bitmap work = fullBitmap;
        boolean cropped = false;
        if (cropRatio != null) {
            int w = fullBitmap.getWidth(), h = fullBitmap.getHeight();
            int l = (int)(cropRatio[0] * w), t = (int)(cropRatio[1] * h);
            int r = (int)(cropRatio[2] * w), b = (int)(cropRatio[3] * h);
            if (l < 0) l = 0; if (t < 0) t = 0; if (r > w) r = w; if (b > h) b = h;
            if (r > l && b > t && (r - l < w || b - t < h)) {
                try {
                    Bitmap c = Bitmap.createBitmap(fullBitmap, l, t, r - l, b - t);
                    if (c != fullBitmap) { work = c; cropped = true; }
                } catch (Throwable e) { return null; }
            }
        }
        Bitmap filtered = null;
        try {
            filtered = Bitmap.createBitmap(work.getWidth(), work.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(filtered);
            // ★ 不铺白底：导出/保存必须保留抠图产生的透明区域
            canvas.drawBitmap(work, 0, 0, null);

            if (!layerManager.getLayers().isEmpty()) {
                LayerManager.LayerItem l0 = layerManager.get(0);
                float baseW = (l0.bitmap != null && !l0.bitmap.isRecycled()) ? l0.bitmap.getWidth() : work.getWidth();
                float baseH = (l0.bitmap != null && !l0.bitmap.isRecycled()) ? l0.bitmap.getHeight() : work.getHeight();
                if (baseW <= 0) baseW = 1; if (baseH <= 0) baseH = 1;
                Canvas dc = new Canvas(filtered);
                layerManager.drawAll(dc, (float) work.getWidth() / baseW, (float) work.getHeight() / baseH);
            }

            if (applyFilter) {
                Bitmap result = applyMergedFilters(filtered);
                if (result != filtered && !filtered.isRecycled()) filtered.recycle();
                filtered = result;
            }
        } catch (Throwable e) {
            if (filtered != null && !filtered.isRecycled()) filtered.recycle();
            if (cropped && work != null && !work.isRecycled()) work.recycle();
            return null;
        }
        if (cropped && work != null && !work.isRecycled()) work.recycle();
        return filtered;
    }

    /**
     * 保存用的底图基准。
     *
     * 返回"底图 + 历史里的几何操作"（旋转/翻转/裁剪/叠加/文字），
     * 尺寸与当前编辑状态一致，保证保存时图层能正确对齐。
     * 抠图/超分也是直接改的 originalBitmap，所以一并包含。
     */
    public Bitmap getSaveBaseBitmap() {
        if (originalBitmap == null || originalBitmap.isRecycled()) return null;
        try {
            // 只回放几何变换：画笔已在图层位图里，不能再回放一次
            Bitmap replayed = history.replayGeometryOnly(originalBitmap);
            if (replayed != null) {
                if (replayed != originalBitmap) return replayed;   // 新的，调用方可回收
                // ★ 没有几何操作时 replay 直接返回了原图本体，
                //   但调用方保存完会 recycle()，那会把用户正在编辑的底图毁掉。
                //   所以这里必须再复制一份交出去。
                return originalBitmap.copy(Bitmap.Config.ARGB_8888, false);
            }
        } catch (Throwable ignored) {
        }
        try {
            return originalBitmap.copy(Bitmap.Config.ARGB_8888, false);
        } catch (Throwable t) {
            return null;
        }
    }

    public Bitmap renderFullSize(Bitmap fullBitmap, boolean applyFilter) {
        return renderFullSize(fullBitmap, applyFilter, true);
    }

    public Bitmap renderFullSize(Bitmap fullBitmap, boolean applyFilter, boolean includeLayers) {
        if (fullBitmap == null || fullBitmap.isRecycled()) return null;

        // 说明：几何变换（旋转/翻转/叠加/文字）由调用方通过 getSaveBaseBitmap()
        // 事先应用好。这里**不再 replay**，否则会重复应用导致尺寸翻倍或方向错乱。
        Bitmap geomBase = fullBitmap;

        int cw = geomBase.getWidth(), ch = geomBase.getHeight();
        int cropL = 0, cropT = 0;
        if (cropRatio != null && cropRatio.length == 4) {
            int l = (int)(cropRatio[0] * cw);
            int t = (int)(cropRatio[1] * ch);
            int r = (int)(cropRatio[2] * cw);
            int b = (int)(cropRatio[3] * ch);
            if (r > l && b > t) { cropL = l; cropT = t; cw = r - l; ch = b - t; }
        }
        // ★ 直接用 Canvas 绘制，不再 getPixels → setPixels 搬运整张图。
        //   大图上这一步原来要额外读写 2 × (w*h×4) 字节，是保存慢的主因。
        Bitmap output;
        try {
            output = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888);
            Canvas oc = new Canvas(output);
            android.graphics.Rect sRect = new android.graphics.Rect(
                    cropL, cropT, cropL + cw, cropT + ch);
            android.graphics.Rect dRect = new android.graphics.Rect(0, 0, cw, ch);
            Paint cp = new Paint();
            cp.setFilterBitmap(false);
            cp.setDither(false);
            oc.drawBitmap(geomBase, sRect, dRect, cp);
            // ★ 不铺白底：抠图产生的透明必须原样保留
        } catch (Throwable e) { return null; }

        if (includeLayers && geomBase.getWidth() > 0 && geomBase.getHeight() > 0
            && layerManager.size() > 0) {
            Canvas canvas = new Canvas(output);
            // 图层尺寸基准 = 图层位图自身的尺寸（不是 geomBase，geomBase 可能已被裁剪）
            int layerW = geomBase.getWidth(), layerH = geomBase.getHeight();
            if (layerManager.size() > 0) {
                LayerManager.LayerItem l0 = layerManager.get(0);
                if (l0.bitmap != null && !l0.bitmap.isRecycled()
                        && l0.bitmap.getWidth() > 0 && l0.bitmap.getHeight() > 0) {
                    layerW = l0.bitmap.getWidth();
                    layerH = l0.bitmap.getHeight();
                }
            }
            float sx = (float) cw / layerW;
            float sy = (float) ch / layerH;
            // 有裁剪时先平移再缩放，保证涂鸦跟底图对齐
            if (cropL != 0 || cropT != 0) {
                canvas.translate(-cropL, -cropT);
            }
            layerManager.drawAll(canvas, sx, sy);
        }

        if (applyFilter) {
            Bitmap filtered = applyMergedFilters(output);
            if (filtered != output && !output.isRecycled()) output.recycle();
            if (geomBase != fullBitmap && !geomBase.isRecycled()) geomBase.recycle();
            return filtered;
        }
        if (geomBase != fullBitmap && !geomBase.isRecycled()) geomBase.recycle();
        return output;
    }

    private void floodFill(int sx, int sy) {
        Bitmap target = getCurrentLayerBitmap();
        if (target == null || target.isRecycled()) return;
        int w = target.getWidth(), h = target.getHeight();
        if (sx < 0 || sy < 0 || sx >= w || sy >= h) return;
        int[] px = new int[w * h];
        target.getPixels(px, 0, w, 0, 0, w, h);
        int tgt = px[sy * w + sx];
        int fill = Color.argb((int)(255 * drawAlpha), Color.red(currentColor), Color.green(currentColor), Color.blue(currentColor));
        if (match(tgt, fill, 0)) return;
        boolean[] vis = new boolean[w * h];
        int[] q = new int[w * h];
        int head = 0, tail = 0;
        q[tail++] = sy * w + sx;
        vis[sy * w + sx] = true;
        while (head < tail) {
            int idx = q[head++];
            if (!match(px[idx], tgt, bucketTolerance)) continue;
            px[idx] = fill;
            int x = idx % w, y = idx / w;
            if (x > 0 && !vis[idx-1]) { vis[idx-1] = true; q[tail++] = idx-1; }
            if (x < w-1 && !vis[idx+1]) { vis[idx+1] = true; q[tail++] = idx+1; }
            if (y > 0 && !vis[idx-w]) { vis[idx-w] = true; q[tail++] = idx-w; }
            if (y < h-1 && !vis[idx+w]) { vis[idx+w] = true; q[tail++] = idx+w; }
        }
        target.setPixels(px, 0, w, 0, 0, w, h);
        invalidate();
        if (stepListener != null) stepListener.onStepFinished();
    }

    private void copyBaseToNewLayer() {
        LayerManager.LayerItem base = layerManager.get(0);
        if (base != null && base.bitmap != null) {
            LayerManager.LayerItem newLayer = layerManager.addBlankLayer(base.bitmap.getWidth(), base.bitmap.getHeight());
            if (newLayer != null) {
                Canvas c = new Canvas(newLayer.bitmap);
                c.drawBitmap(base.bitmap, 0, 0, null);

                LayerManager.LayerItem snap = newLayer.copyMeta();
                snap.bitmap = newLayer.bitmap.copy(Bitmap.Config.ARGB_8888, false);
                history.addAddLayer(snap);

                setCurrentLayerIndex(layerManager.size() - 1);
                onLayersChanged();
            }
        }
    }

    private void magicWandSelect(int x, int y) {
        if (currentLayerIndex <= 0) {
            copyBaseToNewLayer();
        }
        if (currentLayerIndex < 0 || currentLayerIndex >= layerManager.size()) return;
        LayerManager.LayerItem layer = layerManager.get(currentLayerIndex);
        if (layer.bitmap == null) return;

        int w = layer.bitmap.getWidth(), h = layer.bitmap.getHeight();
        if (x < 0 || x >= w || y < 0 || y >= h) return;

        Bitmap snap = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true);
        history.addDrawLayer(currentLayerIndex, snap);

        int[] px = new int[w * h];
        layer.bitmap.getPixels(px, 0, w, 0, 0, w, h);
        int target = px[y * w + x];

        if ((target & 0x00FFFFFF) == 0) return;

        boolean[] visited = new boolean[w * h];
        int[] q = new int[w * h];
        int head = 0, tail = 0;
        q[tail++] = y * w + x;
        visited[y * w + x] = true;

        while (head < tail) {
            int idx = q[head++];
            if (!match(px[idx], target, 40)) continue;
            px[idx] = 0x00000000; 
            int cx = idx % w, cy = idx / w;
            if (cx > 0 && !visited[idx-1]) { visited[idx-1] = true; q[tail++] = idx-1; }
            if (cx < w-1 && !visited[idx+1]) { visited[idx+1] = true; q[tail++] = idx+1; }
            if (cy > 0 && !visited[idx-w]) { visited[idx-w] = true; q[tail++] = idx-w; }
            if (cy < h-1 && !visited[idx+w]) { visited[idx+w] = true; q[tail++] = idx+w; }
        }
        layer.bitmap.setPixels(px, 0, w, 0, 0, w, h);
        invalidate();
        if (stepListener != null) stepListener.onStepFinished();
    }

    private boolean match(int a, int b, int tol) {
        return Math.abs(((a>>24)&0xFF)-((b>>24)&0xFF)) <= tol
            && Math.abs(((a>>16)&0xFF)-((b>>16)&0xFF)) <= tol
            && Math.abs(((a>>8)&0xFF)-((b>>8)&0xFF)) <= tol
            && Math.abs((a&0xFF)-(b&0xFF)) <= tol;
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (isFirstLayout && w > 0 && h > 0 && getDrawable() != null) {
            fitCenter();
            isFirstLayout = false;
        } else if (isPendingRefit) {
            // 超分等操作换了底图后，等 View 布局稳定再重新居中
            isPendingRefit = false;
            post(new Runnable() { public void run() { fitCenter(); invalidate(); } });
        }
    }

    /** 待重新居中标记（换底图后置位）。 */
    private boolean isPendingRefit = false;

    /** 下次 onDraw 时打印一次状态（超分后置位）。 */
    private boolean sLogDrawOnce = false;

    /**
     * 诊断日志：同时写系统日志和文件（/sdcard/Android/data/包名/cache/weifp_sr.log）。
     * AIDE 里看不到 logcat 时，可以直接用文件管理器打开这个文件。
     */
    private void debugLog(String msg) {
        try {
            android.util.Log.i("WeifpSR", msg);
        } catch (Throwable ignored) {
        }
        try {
            android.content.Context c = getContext();
            File f = new File(c.getExternalCacheDir(), "weifp_sr.log");
            if (f.length() > 256 * 1024) f.delete();  // 防止无限增长
            FileOutputStream fos = new FileOutputStream(f, true);
            fos.write((new java.text.SimpleDateFormat("MM-dd HH:mm:ss")
                    .format(new java.util.Date()) + "  " + msg + "\n").getBytes("UTF-8"));
            fos.close();
        } catch (Throwable ignored) {
        }
    }

    /** 请求在布局稳定后重新居中。 */
    public void requestRefit() {
        isPendingRefit = true;
        sLogDrawOnce = true;
        post(new Runnable() { public void run() { fitCenter(); invalidate(); } });
        requestLayout();
    }

    @Override public void setImageBitmap(Bitmap bm) {
        super.setImageBitmap(bm);
        transparentDirty = true;
        if (isPreviewingLUT) return;
        currentBitmap = bm;
        // 按新图尺寸重算历史上限（大图能存的步数更少，避免 OOM）
        try {
            if (bm != null && !bm.isRecycled()) history.setImageSize(bm.getWidth(), bm.getHeight());
        } catch (Throwable ignored) {}
        // 换图时先释放上一张图的所有可选缓存，避免新旧两份同时驻留
        releaseOptionalCaches();
        invalidateAllBaseCaches();
        // 换图：之前算好的蒙版缓存必须丢掉，否则尺寸/内容都会对不上
        if (maskAppliedCache != null && !maskAppliedCache.isRecycled()) {
            maskAppliedCache.recycle();
        }
        maskAppliedCache = null;
        maskCacheDirty = true;
        if (maskOverlayCache != null && !maskOverlayCache.isRecycled()) {
            maskOverlayCache.recycle();
        }
        maskOverlayCache = null;
        maskOverlayDirty = true;
        if (originalBitmap == null) originalBitmap = bm;
        if (bm != null && !bm.isRecycled()) {
            int w = bm.getWidth(), h = bm.getHeight();
            int tw = 200, th = (int)(200f * h / w);
            if (th > 200) { th = 200; tw = (int)(200f * w / h); }
            thumbnailBase = Bitmap.createScaledBitmap(bm, tw, th, true);
            // 按图片尺寸 + 设备可用内存重算图层上限
            try { layerManager.updateLimits(w, h, getContext()); } catch (Throwable ignored) {}
            layerManager.ensureBaseLayer(w, h);
            if (layerManager.size() <= 1) {
                layerManager.addBlankLayer(w, h);
            }
            if (currentLayerIndex <= 0 && layerManager.size() > 1) {
                currentLayerIndex = 1;
            }
        }
        post(new Runnable() { public void run() { fitCenter(); } });
        requestLayout();
        invalidate();
    }

    private void fitCenter() {
        if (getDrawable() == null) return;
        float vw = getWidth(), vh = getHeight();
        float iw = getDrawable().getIntrinsicWidth(), ih = getDrawable().getIntrinsicHeight();
        if (vw == 0 || vh == 0 || iw == 0 || ih == 0) return;
        float s = Math.min(vw / iw, vh / ih);
        matrix.reset(); matrix.postScale(s, s);
        matrix.postTranslate((vw - iw * s) / 2f, (vh - ih * s) / 2f);
        currentScale = 1.0f; setImageMatrix(matrix);
    }

    private float[] screenToBitmap(float x, float y) {
        float[] pts = {x, y};
        Matrix inv = new Matrix();
        matrix.invert(inv);
        inv.mapPoints(pts);
        return pts;
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        // ★ 蒙版交互优先级最高
        if (isMaskBrushMode) {
            if (handleMaskBrushTouch(event)) return true;
        }
        if (isMaskDragMode) {
            if (handleMaskDragTouch(event)) return true;
        }
        if (!isZoomEnabled) return false;
        int action = event.getActionMasked(), pc = event.getPointerCount();

        // ==================== 套索 ====================
        if (isDrawMode && brushMode == 3) {
            return handleLassoTouch(event);
        }

        if (isDrawMode && brushMode == 4) {
            if (action == MotionEvent.ACTION_DOWN) {
                float[] p0 = screenToBitmap(event.getX(), event.getY());
                magicWandSelect((int) p0[0], (int) p0[1]);
            }
            return true;
        }

        if (isDrawMode) {
            if (pc >= 2) {
                if (isDrawing) {
                    isDrawing = false;
                    if (preStrokeSnapshot != null && currentLayerIndex >= 0 && currentLayerIndex < layerManager.size()) {
                        LayerManager.LayerItem cl = layerManager.get(currentLayerIndex);
                        Bitmap old = cl.bitmap;
                        cl.bitmap = preStrokeSnapshot.copy(Bitmap.Config.ARGB_8888, true);
                        preStrokeSnapshot.recycle();
                        preStrokeSnapshot = null;
                        if (old != null && !old.isRecycled()) old.recycle();
                        invalidate();
                    }
                }
                scaleDetector.onTouchEvent(event);
                switch (action) {
                    case MotionEvent.ACTION_POINTER_DOWN:
                        isMoving = true;
                        lastMoveX = (event.getX(0) + event.getX(1)) / 2f;
                        lastMoveY = (event.getY(0) + event.getY(1)) / 2f;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (isMoving) {
                            float cx = (event.getX(0) + event.getX(1)) / 2f, cy = (event.getY(0) + event.getY(1)) / 2f;
                            matrix.postTranslate(cx - lastMoveX, cy - lastMoveY);
                            setImageMatrix(matrix);
                            lastMoveX = cx; lastMoveY = cy;
                        }
                        return true;
                    case MotionEvent.ACTION_POINTER_UP:
                        isMoving = false;
                        scaleDetector.onTouchEvent(event);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        isMoving = false;
                        scaleDetector.onTouchEvent(event);
                        return true;
                }
            }

            if (pc == 1) {
                if (action == MotionEvent.ACTION_DOWN) {
                    isMoving = false;

                    if (currentLayerIndex <= 0) {
                        if (brushMode == 5) {
                            copyBaseToNewLayer();
                        } else {
                            if (layerLockedListener != null) layerLockedListener.onLayerLocked(currentLayerIndex);
                            return true;
                        }
                    }

                    LayerManager.LayerItem cl = (currentLayerIndex >= 0 && currentLayerIndex < layerManager.size()) ? layerManager.get(currentLayerIndex) : null;
                    if (cl == null || cl.alpha <= 0) {
                        if (layerLockedListener != null) layerLockedListener.onLayerLocked(currentLayerIndex);
                        return true;
                    }
                    if (cl.bitmap == null || cl.bitmap.isRecycled()) {
                        if (originalBitmap != null) cl.bitmap = Bitmap.createBitmap(originalBitmap.getWidth(), originalBitmap.getHeight(), Bitmap.Config.ARGB_8888);
                        if (cl.bitmap == null) return true;
                    } else if (!cl.bitmap.isMutable() || cl.bitmap.getConfig() != Bitmap.Config.ARGB_8888) {
                        Bitmap mut = cl.bitmap.copy(Bitmap.Config.ARGB_8888, true);
                        if (mut == null) return true;
                        Bitmap old = cl.bitmap;
                        cl.bitmap = mut;
                        if (!old.isRecycled()) old.recycle();
                    }

                    float[] p0 = screenToBitmap(event.getX(), event.getY());
                    if (brushMode == 2) { floodFill((int) p0[0], (int) p0[1]); return true; }

                    if (preStrokeSnapshot != null && !preStrokeSnapshot.isRecycled()) preStrokeSnapshot.recycle();
                    preStrokeSnapshot = null;
                    if (cl.bitmap != null && !cl.bitmap.isRecycled()) preStrokeSnapshot = cl.bitmap.copy(Bitmap.Config.ARGB_8888, true);

                    isDrawing = true;
                    lastX = p0[0]; lastY = p0[1];
                    lastMidX = lastX; lastMidY = lastY;

                    invalidate();
                    return true;
                }

                if (action == MotionEvent.ACTION_MOVE && isDrawing) {
                    LayerManager.LayerItem cl2 = (currentLayerIndex >= 0 && currentLayerIndex < layerManager.size()) ? layerManager.get(currentLayerIndex) : null;
                    if (cl2 != null && cl2.bitmap != null && !cl2.bitmap.isRecycled()) {
                        float[] p1 = screenToBitmap(event.getX(), event.getY());
                        if (p1[0] >= -500 && p1[0] <= cl2.bitmap.getWidth() + 500 &&
                            p1[1] >= -500 && p1[1] <= cl2.bitmap.getHeight() + 500) {
                            float curX = p1[0], curY = p1[1];
                            float midX = (lastX + curX) / 2f, midY = (lastY + curY) / 2f;
                            Canvas c1 = new Canvas(cl2.bitmap);
                            Path path = new Path();
                            path.moveTo(lastMidX, lastMidY);
                            path.quadTo(lastX, lastY, midX, midY);
                            c1.drawPath(path, currentPaint);
                            if (isSymmetryOn) {
                                float w = cl2.bitmap.getWidth(), h = cl2.bitmap.getHeight();
                                if (symmetryType == 0 || symmetryType == 2) { Path pX = new Path(); pX.moveTo(w - lastMidX, lastMidY); pX.quadTo(w - lastX, lastY, w - midX, midY); c1.drawPath(pX, currentPaint); }
                                if (symmetryType == 1 || symmetryType == 2) { Path pY = new Path(); pY.moveTo(lastMidX, h - lastMidY); pY.quadTo(lastX, h - lastY, midX, h - midY); c1.drawPath(pY, currentPaint); }
                                if (symmetryType == 2) { Path pXY = new Path(); pXY.moveTo(w - lastMidX, h - lastMidY); pXY.quadTo(w - lastX, h - lastY, w - midX, h - midY); c1.drawPath(pXY, currentPaint); }
                            }
                            lastMidX = midX; lastMidY = midY;
                        }
                        lastX = p1[0]; lastY = p1[1];
                        invalidate();
                    }
                    return true;
                }

                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    if (isDrawing) {
                        isDrawing = false;
                        LayerManager.LayerItem cl = (currentLayerIndex >= 0 && currentLayerIndex < layerManager.size()) ? layerManager.get(currentLayerIndex) : null;
                        if (cl != null && cl.bitmap != null) {
                            float[] p1 = screenToBitmap(event.getX(), event.getY());
                            if (Math.hypot(p1[0] - lastX, p1[1] - lastY) < 2.0f && brushMode == 0) {
                                Canvas c = new Canvas(cl.bitmap);
                                c.drawPoint(lastX, lastY, currentPaint);
                            }
                        }
                        if (preStrokeSnapshot != null) {
                            history.addDrawLayer(currentLayerIndex, preStrokeSnapshot);
                            preStrokeSnapshot = null;
                        }
                        if (stepListener != null) stepListener.onStepFinished();
                    }
                    return true;
                }
            }
        } else {
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    longPressTriggered = false;
                    longPressDownX = event.getX();
                    longPressDownY = event.getY();
                    if (longPressHandler != null && longPressRunnable != null) {
                        longPressHandler.removeCallbacks(longPressRunnable);
                        longPressHandler.postDelayed(longPressRunnable, 500);
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (!longPressTriggered && longPressHandler != null && longPressRunnable != null) {
                        float dx = event.getX() - longPressDownX;
                        float dy = event.getY() - longPressDownY;
                        float limit = 20 * getResources().getDisplayMetrics().density;
                        if (Math.hypot(dx, dy) > limit) longPressHandler.removeCallbacks(longPressRunnable);
                    }
                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (longPressHandler != null && longPressRunnable != null) longPressHandler.removeCallbacks(longPressRunnable);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (longPressHandler != null && longPressRunnable != null) longPressHandler.removeCallbacks(longPressRunnable);
                    if (longPressTriggered) { longPressTriggered = false; setShowOriginal(false); }
                    // 松手时才吸附：拖动过程中保持跟手，不打断手感
                    if (isGridOn && !isDrawMode && !isScaling) {
                        try {
                            applyGridSnapToMatrix();
                            setImageMatrix(matrix);
                        } catch (Throwable ignored) {}
                    }
                    break;
            }
            if (!longPressTriggered) {
                scaleDetector.onTouchEvent(event);
                gestureDetector.onTouchEvent(event);
            }
            return true;
        }
        return super.onTouchEvent(event);
    }

    @Override protected void onDraw(Canvas canvas) {
        // ★ 顺序关键：棋盘格必须**垫在底图下面**。
        //   之前先 super.onDraw 画底图、再画棋盘格，棋盘格就把图片整个盖住了，
        //   只要图里有任何透明像素，整片区域都会被格子遮住 —— 看起来就是"全透明"。
        if (hasTransparentContent()) {
            canvas.save();
            canvas.concat(matrix);
            drawCheckerboard(canvas, imageRectWidth(), imageRectHeight());
            canvas.restore();
        }
        super.onDraw(canvas);
        canvas.save();
        canvas.concat(matrix);

        ColorFilter cf = null;
        boolean hasFilter = brightness != 0 || contrast != 1 || saturation != 1 ||
            shadows != 0 || highlights != 0 || temperature != 0 || tint != 0;
        if (hasFilter) {
            cf = new ColorMatrixColorFilter(colorMatrix);
        }

        if (sLogDrawOnce) {
            sLogDrawOnce = false;
            StringBuilder sb = new StringBuilder("onDraw: drawable=");
            sb.append(getDrawable() != null ? getDrawable().getIntrinsicWidth() + "x"
                    + getDrawable().getIntrinsicHeight() : "null");
            sb.append(" layers=[");
            for (int i = 0; i < layerManager.size(); i++) {
                Bitmap lb = layerManager.get(i).bitmap;
                sb.append(i).append(":").append(lb != null ? lb.getWidth() + "x" + lb.getHeight() : "null").append(" ");
            }
            sb.append("] matrix=").append(matrix.toShortString());
            debugLog(sb.toString());
        }
        // ★ 蒙版效果：底图在上一步由 super.onDraw 画出，这里把"蒙版处理后的图"盖上去
        if (hasMasks()) {
            Bitmap masked = getMaskAppliedBitmap();
            if (masked != null && masked != currentBitmap && masked != originalBitmap
                    && !masked.isRecycled()) {
                Paint mp = new Paint();
                mp.setFilterBitmap(true);
                mp.setDither(true);
                // ★ 必须带上全局滤镜：super.onDraw 画的底图已被 colorFilter 处理过，
                //   而 masked 是原始像素，不加滤镜会把这些调整整个盖掉。
                if (cf != null) mp.setColorFilter(cf);
                // 预览图尺寸小于原图时，拉伸回原图坐标
                int bw = currentBitmap != null && !currentBitmap.isRecycled()
                        ? currentBitmap.getWidth()
                        : (originalBitmap != null ? originalBitmap.getWidth() : 0);
                int bh = currentBitmap != null && !currentBitmap.isRecycled()
                        ? currentBitmap.getHeight()
                        : (originalBitmap != null ? originalBitmap.getHeight() : 0);
                if (bw > 0 && bh > 0
                        && (masked.getWidth() != bw || masked.getHeight() != bh)) {
                    android.graphics.Rect src = new android.graphics.Rect(0, 0,
                            masked.getWidth(), masked.getHeight());
                    android.graphics.RectF dst = new android.graphics.RectF(0, 0, bw, bh);
                    canvas.drawBitmap(masked, src, dst, mp);
                } else {
                    canvas.drawBitmap(masked, 0, 0, mp);
                }
            }
        }

        if (chromaPreview != null && !chromaPreview.isRecycled()) {
            // 抠图预览：直接盖在最上层，底图/图层保持不变
            Paint pp = new Paint();
            pp.setFilterBitmap(true);
            canvas.drawBitmap(chromaPreview, 0, 0, pp);
        } else {
            layerManager.drawAll(canvas, 1f, 1f, cf);
        }

        // 噪点预览覆盖层
        if (noisePreviewVisible && noisePreviewOut != null && !noisePreviewOut.isRecycled()) {
            Bitmap nb = originalBitmap != null && !originalBitmap.isRecycled()
                    ? originalBitmap : currentBitmap;
            if (nb != null && !nb.isRecycled()) {
                Paint np = new Paint();
                np.setFilterBitmap(true);
                np.setDither(true);
                android.graphics.Rect ns = new android.graphics.Rect(0, 0,
                        noisePreviewOut.getWidth(), noisePreviewOut.getHeight());
                android.graphics.RectF nd = new android.graphics.RectF(0, 0,
                        nb.getWidth(), nb.getHeight());
                canvas.drawBitmap(noisePreviewOut, ns, nd, np);
            }
        }

        // HSL 预览覆盖层：画在图片坐标系里，铺满整张图。
        // 预览图可能比原图小（1024px），这里靠 drawBitmap 拉伸还原。
        if (hslPreviewVisible && hslPreviewOut != null && !hslPreviewOut.isRecycled()) {
            float iw = imageRectWidth(), ih = imageRectHeight();
            if (iw > 0 && ih > 0) {
                Paint hp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                android.graphics.Rect hs = new android.graphics.Rect(0, 0,
                        hslPreviewOut.getWidth(), hslPreviewOut.getHeight());
                android.graphics.RectF hd = new android.graphics.RectF(0, 0, iw, ih);
                canvas.drawBitmap(hslPreviewOut, hs, hd, hp);
            }
        }

        // 套索移动预览：把剪出的内容画在当前偏移位置
        if (lassoMoving && lassoClip != null && !lassoClip.isRecycled()) {
            Bitmap mb = originalBitmap != null && !originalBitmap.isRecycled()
                    ? originalBitmap : currentBitmap;
            if (mb != null && !mb.isRecycled()) {
                // 画布坐标 -> 图层位图坐标的比例
                Bitmap tl = getCurrentLayerBitmap();
                float sc = (tl != null && !tl.isRecycled() && mb.getWidth() > 0)
                        ? (float) tl.getWidth() / mb.getWidth() : 1f;
                Paint mp = new Paint(Paint.FILTER_BITMAP_FLAG);
                mp.setAlpha(230);
                float dx = (lassoClipX + lassoMoveDx) * sc;
                float dy = (lassoClipY + lassoMoveDy) * sc;
                android.graphics.RectF dst = new android.graphics.RectF(
                        dx, dy,
                        dx + lassoClip.getWidth(),
                        dy + lassoClip.getHeight());
                canvas.drawBitmap(lassoClip, null, dst, mp);
            }
        }

        // 套索选区外框：主题橙实线 + 外发光，比之前的黑白虚线好看也清楚
        if (brushMode == 3 && !lasso.isEmpty()) {
            float sc = Math.max(0.01f, currentScale);
            Paint lp = new Paint();
            lp.setStyle(Paint.Style.STROKE);
            lp.setAntiAlias(true);

            // ① 外层柔光：半透明橙，宽一点，营造"发光"感
            lp.setColor(0x55FFB615);
            lp.setStrokeWidth(3.5f / sc);
            lasso.drawOutline(canvas, lp);

            // ② 主线条：主题橙实线，细而清晰
            lp.setColor(0xFFFFB615);
            lp.setStrokeWidth(1.6f / sc);
            lasso.drawOutline(canvas, lp);

            // ③ 内侧白色细线：在深色图片上也看得见边界
            lp.setColor(0xCCFFFFFF);
            lp.setStrokeWidth(0.8f / sc);
            lasso.drawOutline(canvas, lp);
        }

        // 对齐提示线：只在吸附命中后短暂显示，而且只画命中的那一条
        if (snappedLineX >= 0f || snappedLineY >= 0f) {
            Paint gp = new Paint();
            gp.setColor(0xFFFFB615);
            gp.setStyle(Paint.Style.STROKE);
            gp.setStrokeWidth(1f);           // 细线，屏幕坐标不随缩放变粗
            gp.setAntiAlias(true);
            if (snappedLineX >= 0f) canvas.drawLine(snappedLineX, 0, snappedLineX, getHeight(), gp);
            if (snappedLineY >= 0f) canvas.drawLine(0, snappedLineY, getWidth(), snappedLineY, gp);
        }

        // ★ 蒙版范围提示：必须画在所有内容之上，否则会被图层/对称辅助盖住
        drawMaskIndicator(canvas);

        if (isSymmetryOn && isDrawMode && originalBitmap != null && brushMode != 3) {
            Paint p = new Paint();
            p.setColor(0xFFFFB615); 
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3f / currentScale);
            p.setAntiAlias(true);
            p.setPathEffect(new android.graphics.DashPathEffect(new float[]{15f, 15f}, 0));
            float w = originalBitmap.getWidth();
            float h = originalBitmap.getHeight();

            if (symmetryType == 0 || symmetryType == 2) {
                canvas.drawLine(w / 2f, 0, w / 2f, h, p);
            }
            if (symmetryType == 1 || symmetryType == 2) {
                canvas.drawLine(0, h / 2f, w, h / 2f, p);
            }
        }

        canvas.restore();
    }

    @Override public boolean onScaleBegin(ScaleGestureDetector d) { isScaling = true; return true; }
    @Override public boolean onScale(ScaleGestureDetector d) {
        float f = d.getScaleFactor(), ns = currentScale * f;
        if (ns < MIN_SCALE || ns > MAX_SCALE) return true;
        matrix.postScale(f, f, d.getFocusX(), d.getFocusY());
        setImageMatrix(matrix);
        currentScale = ns;
        return true;
    }
    @Override public void onScaleEnd(ScaleGestureDetector d) { isScaling = false; }
}
