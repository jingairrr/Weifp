# Weifp

一个基于 Java 的 Android 图片编辑器。

## 功能

调整亮度、对比度、高光、阴影、色温、清晰度，以及 HSL、曲线、色阶、直方图。
支持局部蒙版、超分辨率放大、色度抠图。
可以绘制图案、添加图片和文字、使用多图层编辑。
可以读取 RAW 文件（基于 LibRaw）。

## 构建

用 Android Studio 或 AIDE 打开项目构建。

源码见 release 附件里的源码包。

## 开源声明

- [AndroidLibRaw](https://github.com/dburckh/AndroidLibRaw) — LGPL-2.1
- [OpenMP](https://www.openmp.org/) — Apache 2.0
- [Android Open Source Project](https://source.android.com/) — Apache 2.0

## AI 参与说明

本项目在开发过程中大量使用了 AI 辅助编写代码。

## 许可

MIT License
