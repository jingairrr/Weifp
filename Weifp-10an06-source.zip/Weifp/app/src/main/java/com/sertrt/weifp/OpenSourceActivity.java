package com.sertrt.weifp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class OpenSourceActivity extends Activity {

    private float density;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getBaseContext().getResources().updateConfiguration(
            LanguageManager.wrap(this).getResources().getConfiguration(),
            getBaseContext().getResources().getDisplayMetrics()
        );

        density = getResources().getDisplayMetrics().density;

        getWindow().setBackgroundDrawable(new ColorDrawable(ThemeManager.getBgColor(this)));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ScrollView.LayoutParams(
                                       ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.MATCH_PARENT));
        scrollView.setBackgroundColor(ThemeManager.getBgColor(this));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding((int)(20*density), (int)(80*density), (int)(20*density), (int)(30*density));
        root.setLayoutParams(new ScrollView.LayoutParams(
                                 ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        // --- 开源库 1: LibRaw ---
        addItem(root, 
                "LibRaw / AndroidLibRaw", 
                "LGPL-2.1 License", 
                "用于读取和解析 RAW 相机文件格式（NEF, CR2, ARW 等）。", 
                "https://github.com/dburckh/AndroidLibRaw");

        // --- 开源库 2: OpenMP ---
        addItem(root, 
                "OpenMP / libomp", 
                "Apache License 2.0", 
                "用于提供多线程并行计算，大幅提升 RAW 解析和滤镜渲染速度。", 
                "https://www.openmp.org/");

        // --- 开源库 3: AOSP Android 开源项目 ---
        addItem(root,
                "Android Open Source Project (AOSP)",
                "Apache License 2.0",
                "使用 Android 框架提供的位图、画布、图形与网络等基础能力。",
                "https://source.android.com/");

        scrollView.addView(root);
        setContentView(scrollView);

        BackButtonHelper.addBackButton(this, null);
    }

    private void addItem(LinearLayout parent, String name, String license, String desc, final String url) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding((int)(16*density), (int)(16*density), (int)(16*density), (int)(16*density));

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(UiSpec.dp(this, UiSpec.RADIUS_M));
        bg.setColor(ThemeManager.getButtonColor(this));
        block.setBackground(bg);

        TextView tvName = new TextView(this);
        tvName.setText(name);
        tvName.setTextSize(16);
        tvName.setTypeface(null, android.graphics.Typeface.BOLD);
        tvName.setTextColor(0xFFFFB615);
        block.addView(tvName);

        TextView tvLicense = new TextView(this);
        tvLicense.setText(license);
        tvLicense.setTextSize(13);
        tvLicense.setTextColor(ThemeManager.getTextColor(this));
        tvLicense.setPadding(0, (int)(4*density), 0, (int)(8*density));
        block.addView(tvLicense);

        TextView tvDesc = new TextView(this);
        tvDesc.setText(desc);
        tvDesc.setTextSize(13);
        tvDesc.setTextColor(ThemeManager.getTextColor(this));
        tvDesc.setAlpha(0.8f);
        block.addView(tvDesc);

        TextView tvLink = new TextView(this);
        tvLink.setText(url);
        tvLink.setTextSize(13);
        tvLink.setTextColor(0xFF2196F3);
        tvLink.setPadding(0, (int)(8*density), 0, 0);
        block.addView(tvLink);

        block.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);
                    } catch (Throwable e) {
                        // ★ 走系统自带的多语言文本，避免在 strings.xml 里加新 key 报错
                        Toast.makeText(OpenSourceActivity.this, android.R.string.no, Toast.LENGTH_SHORT).show();
                    }
                }
            });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, (int)(16*density));
        block.setLayoutParams(lp);

        parent.addView(block);
    }
}
