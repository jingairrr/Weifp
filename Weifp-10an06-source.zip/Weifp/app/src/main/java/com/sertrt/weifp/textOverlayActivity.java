package com.sertrt.weifp;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;

public class textOverlayActivity extends Activity {

    private ImageView baseView;
    private ImageView textView;
    private FrameLayout previewArea;

    private Bitmap baseBitmap;
    private Bitmap textBitmap;
    private Bitmap scaledText;

    private Matrix textMatrix = new Matrix();
    private ScaleGestureDetector scaleDetector;

    private float lastX, lastY;
    private float textScale = 1.0f;
    private float textRotation = 0f;

    private String currentText = "Hello";
    private int currentTextColor = Color.RED;
    private float currentTextSize = 80f;

    private int drawR = 255, drawG = 0, drawB = 0;
    private View colorPreview;
    private EditText etHexRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getBaseContext().getResources().updateConfiguration(
            LanguageManager.wrap(this).getResources().getConfiguration(),
            getBaseContext().getResources().getDisplayMetrics()
        );

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF1E1E1E);

        previewArea = new FrameLayout(this);
        previewArea.setLayoutParams(new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        previewArea.setPadding(0, (int)(50 * getResources().getDisplayMetrics().density), 0, 0);

        baseView = new ImageView(this);
        baseView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        previewArea.addView(baseView);

        textView = new ImageView(this);
        textView.setScaleType(ImageView.ScaleType.MATRIX);
        previewArea.addView(textView);

        root.addView(previewArea);

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setBackgroundColor(0xFF2A2A2A);
        inputRow.setPadding(10, 10, 10, 10);

        final EditText etText = new EditText(this);
        etText.setHint(LanguageManager.getString(this, R.string.text_input_hint));
        etText.setText("Hello");
        etText.setTextColor(Color.WHITE);
        etText.setBackground(getRoundBg(0xFF3A3A3A));
        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(0,
                                                                       LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        etLp.setMargins(0, 0, 10, 0);
        etText.setLayoutParams(etLp);
        inputRow.addView(etText);

        final EditText etSize = new EditText(this);
        etSize.setHint(LanguageManager.getString(this, R.string.text_size_hint));
        etSize.setText("80");
        etSize.setInputType(InputType.TYPE_CLASS_NUMBER);
        etSize.setTextColor(Color.WHITE);
        etSize.setBackground(getRoundBg(0xFF3A3A3A));
        LinearLayout.LayoutParams szLp = new LinearLayout.LayoutParams(120,
                                                                       LinearLayout.LayoutParams.WRAP_CONTENT);
        szLp.setMargins(0, 0, 10, 0);
        etSize.setLayoutParams(szLp);
        inputRow.addView(etSize);

        // ★ 去掉"设置"按钮：输入内容/字号变化时立即刷新，所见即所得。
        final Runnable applyInput = new Runnable() {
            @Override public void run() {
                try {
                    String t = etText.getText().toString();
                    currentText = t.isEmpty() ? " " : t;
                    try {
                        int sz = Integer.parseInt(etSize.getText().toString().trim());
                        currentTextSize = sz > 0 ? sz : 80;
                    } catch (Throwable e) {
                        // 输入到一半（空或非数字）时保持上次字号，避免画面闪来闪去
                    }
                    refreshTextBitmap();
                    centerText();
                } catch (Throwable ignored) {
                }
            }
        };
        android.text.TextWatcher watcher = new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
            @Override public void afterTextChanged(android.text.Editable s) {
                applyInput.run();
            }
        };
        etText.addTextChangedListener(watcher);
        etSize.addTextChangedListener(watcher);

        root.addView(inputRow);

        LinearLayout colorRow = new LinearLayout(this);
        colorRow.setOrientation(LinearLayout.HORIZONTAL);
        colorRow.setBackgroundColor(0xFF1E1E1E);
        colorRow.setPadding(10, 10, 10, 10);

        TextView tvPreset = new TextView(this);
        tvPreset.setText(LanguageManager.getString(this, R.string.text_preset_color));
        tvPreset.setTextColor(Color.WHITE);
        colorRow.addView(tvPreset);

        // 与涂鸦面板同一套调色板（按色谱排列）+ 圆形色块
        final int[] colors = {
            0xFF000000, 0xFF808080, 0xFFFFFFFF,
            0xFFF44336, 0xFF795548, 0xFFFFB615,
            0xFF4CAF50, 0xFF06D6A0, 0xFF4A90D9,
            0xFF3F51B5, 0xFF9C27B0, 0xFFFF69B4,
        };
        for (int c : colors) {
            final int color = c;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    UiSpec.dpi(this, 26), UiSpec.dpi(this, 26));
            lp.setMargins(UiSpec.dpi(this, 3), 0, UiSpec.dpi(this, 3), 0);
            View sw = UiSpec.swatch(this, color, 26, false, true);
            sw.setLayoutParams(lp);
            sw.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        drawR = Color.red(color);
                        drawG = Color.green(color);
                        drawB = Color.blue(color);
                        applyCustomColor();
                    }
                });
            colorRow.addView(sw);
        }
        root.addView(colorRow);

        addRgbRow(root, "R", drawR, new OnSeekBarChangeListener() {
                @Override public void onProgressChanged(int value) { drawR = value; applyCustomColor(); }
            });
        addRgbRow(root, "G", drawG, new OnSeekBarChangeListener() {
                @Override public void onProgressChanged(int value) { drawG = value; applyCustomColor(); }
            });
        addRgbRow(root, "B", drawB, new OnSeekBarChangeListener() {
                @Override public void onProgressChanged(int value) { drawB = value; applyCustomColor(); }
            });

        LinearLayout previewRow = new LinearLayout(this);
        previewRow.setOrientation(LinearLayout.HORIZONTAL);
        previewRow.setPadding(10, 10, 10, 10);
        previewRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        TextView tvPreviewLabel = new TextView(this);
        tvPreviewLabel.setText(LanguageManager.getString(this, R.string.text_current));
        tvPreviewLabel.setTextColor(Color.WHITE);
        previewRow.addView(tvPreviewLabel);

        colorPreview = new View(this);
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(80, 50);
        previewLp.setMargins(10, 0, 10, 0);
        colorPreview.setLayoutParams(previewLp);
        colorPreview.setBackground(getRoundBg(Color.rgb(drawR, drawG, drawB)));
        previewRow.addView(colorPreview);

        TextView tvHash = new TextView(this);
        tvHash.setText("#");
        tvHash.setTextColor(Color.WHITE);
        previewRow.addView(tvHash);

        etHexRef = new EditText(this);
        LinearLayout.LayoutParams hexLp = new LinearLayout.LayoutParams(180,
                                                                        LinearLayout.LayoutParams.WRAP_CONTENT);
        etHexRef.setLayoutParams(hexLp);
        etHexRef.setText(String.format("%02X%02X%02X", drawR, drawG, drawB));
        etHexRef.setInputType(InputType.TYPE_CLASS_TEXT);
        etHexRef.setTextColor(Color.WHITE);
        etHexRef.setBackground(getRoundBg(0xFF3A3A3A));
        etHexRef.setMaxEms(6);
        previewRow.addView(etHexRef);

        etHexRef.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override
                public void afterTextChanged(Editable s) {
                    String str = s.toString().replace("#", "").trim();
                    if (str.length() == 6) {
                        try {
                            int r = Integer.parseInt(str.substring(0, 2), 16);
                            int g = Integer.parseInt(str.substring(2, 4), 16);
                            int b = Integer.parseInt(str.substring(4, 6), 16);
                            if (r != drawR || g != drawG || b != drawB) {
                                drawR = r; drawG = g; drawB = b;
                                currentTextColor = Color.rgb(drawR, drawG, drawB);
                                if (colorPreview != null) {
                                    colorPreview.setBackground(getRoundBg(currentTextColor));
                                }
                                refreshTextBitmap();
                            }
                        } catch (Throwable ignored) {}
                    }
                }
            });

        root.addView(previewRow);

        LinearLayout resetRow = new LinearLayout(this);
        resetRow.setOrientation(LinearLayout.HORIZONTAL);
        resetRow.setBackgroundColor(0xFF1E1E1E);
        resetRow.setPadding(10, 10, 10, 10);

        Button btnResetX = new Button(this);
        btnResetX.setText(LanguageManager.getString(this, R.string.overlay_reset_x));
        btnResetX.setAllCaps(false);
        btnResetX.setStateListAnimator(null);
        btnResetX.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetX.setTextColor(0xFFFFFFFF);
        btnResetX.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetX(); }
            });
        resetRow.addView(btnResetX);

        Button btnResetY = new Button(this);
        btnResetY.setText(LanguageManager.getString(this, R.string.overlay_reset_y));
        btnResetY.setAllCaps(false);
        btnResetY.setStateListAnimator(null);
        btnResetY.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetY.setTextColor(0xFFFFFFFF);
        btnResetY.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetY(); }
            });
        resetRow.addView(btnResetY);

        Button btnResetRot = new Button(this);
        btnResetRot.setText(LanguageManager.getString(this, R.string.overlay_reset_rot));
        btnResetRot.setAllCaps(false);
        btnResetRot.setStateListAnimator(null);
        btnResetRot.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetRot.setTextColor(0xFFFFFFFF);
        btnResetRot.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetRotation(); }
            });
        resetRow.addView(btnResetRot);

        Button btnResetScale = new Button(this);
        btnResetScale.setText(LanguageManager.getString(this, R.string.overlay_reset_scale));
        btnResetScale.setAllCaps(false);
        btnResetScale.setStateListAnimator(null);
        btnResetScale.setBackground(getRoundBg(0xFF3A3A3A));
        btnResetScale.setTextColor(0xFFFFFFFF);
        btnResetScale.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetScale(); }
            });
        resetRow.addView(btnResetScale);

        root.addView(resetRow);

        Button btnDone = new Button(this);
        btnDone.setText(LanguageManager.getString(this, R.string.text_done_return));
        btnDone.setAllCaps(false);
        btnDone.setStateListAnimator(null);
        btnDone.setBackground(getRoundBg(0xFFFFB615));
        btnDone.setTextColor(0xFF000000);
        LinearLayout.LayoutParams doneLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        doneLp.setMargins(10, 10, 10, 10);
        btnDone.setLayoutParams(doneLp);
        btnDone.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { finishAndReturn(); }
            });
        root.addView(btnDone);

        setContentView(root);

        BackButtonHelper.addBackButton(this, new BackButtonHelper.OnBackListener() {
                @Override
                public void onBack() {
                    showExitDialog();
                }
            });

        Uri baseUri = getIntent().getData();
        if (baseUri != null) {
            try {
                InputStream is = getContentResolver().openInputStream(baseUri);
                baseBitmap = BitmapFactory.decodeStream(is);
                if (is != null) is.close();
                baseView.setImageBitmap(baseBitmap);
            } catch (Throwable e) {
                Toast.makeText(this, LanguageManager.getString(this, R.string.text_base_fail), Toast.LENGTH_SHORT).show();
            }
        }

        refreshTextBitmap();

        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector detector) {
                    if (textBitmap == null) return false;
                    float factor = detector.getScaleFactor();
                    textScale *= factor;
                    if (textScale < 0.2f) textScale = 0.2f;
                    if (textScale > 8.0f) textScale = 8.0f;

                    int w = (int) (textBitmap.getWidth() * textScale);
                    int h = (int) (textBitmap.getHeight() * textScale);
                    if (w > 0 && h > 0) {
                        scaledText = Bitmap.createScaledBitmap(textBitmap, w, h, true);
                        textView.setImageBitmap(scaledText);
                    }
                    return true;
                }
            });

        textView.setOnTouchListener(new View.OnTouchListener() {
                private float lastRotate = 0f;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if (textBitmap == null) return false;
                    scaleDetector.onTouchEvent(event);

                    if (event.getPointerCount() >= 2) {
                        float angle = (float) Math.toDegrees(
                            Math.atan2(event.getY(1) - event.getY(0),
                                       event.getX(1) - event.getX(0)));
                        if (event.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
                            lastRotate = angle;
                        } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                            float delta = angle - lastRotate;
                            textRotation += delta;
                            textMatrix.postRotate(delta,
                                                  textView.getWidth() / 2f, textView.getHeight() / 2f);
                            textView.setImageMatrix(textMatrix);
                            textView.invalidate();
                            lastRotate = angle;
                        }
                        return true;
                    }

                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            lastX = event.getX();
                            lastY = event.getY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            float dx = event.getX() - lastX;
                            float dy = event.getY() - lastY;
                            textMatrix.postTranslate(dx, dy);
                            textView.setImageMatrix(textMatrix);
                            textView.invalidate();
                            lastX = event.getX();
                            lastY = event.getY();
                            return true;
                    }
                    return false;
                }
            });
    }

    private void showExitDialog() {
        final float density = getResources().getDisplayMetrics().density;
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getRoundBg(ThemeManager.getPanelColor(this)));
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(10*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(LanguageManager.getString(this, R.string.text_abandon_title));
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(android.view.Gravity.CENTER);
        root.addView(tvTitle);

        TextView tvMsg = new TextView(this);
        tvMsg.setText(LanguageManager.getString(this, R.string.text_abandon_msg));
        tvMsg.setTextSize(13);
        tvMsg.setTextColor(ThemeManager.getTextColor(this));
        tvMsg.setGravity(android.view.Gravity.CENTER);
        tvMsg.setPadding(0, (int)(15*density), 0, (int)(15*density));
        root.addView(tvMsg);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, (int)(10*density), 0, 0);

        TextView btnCancel = new TextView(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setGravity(android.view.Gravity.CENTER);
        btnCancel.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnCancel.setBackground(getRoundBg(0xFF555555));
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp1.setMargins(0, 0, (int)(10*density), 0);
        btnCancel.setLayoutParams(lp1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dialog.dismiss(); }
            });
        btnRow.addView(btnCancel);

        TextView btnOk = new TextView(this);
        btnOk.setText(LanguageManager.getString(this, R.string.overlay_exit));
        btnOk.setTextSize(15);
        btnOk.setTextColor(Color.BLACK);
        btnOk.setGravity(android.view.Gravity.CENTER);
        btnOk.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnOk.setBackground(getRoundBg(0xFFFFB615));
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btnOk.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dialog.dismiss();
                    finish();
                }
            });
        btnRow.addView(btnOk);
        root.addView(btnRow);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dialog.setContentView(sv);

        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.8);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private GradientDrawable getRoundBg(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(8 * getResources().getDisplayMetrics().density);
        bg.setColor(color);
        return bg;
    }

    private void fixSeekBarColor(SeekBar sb) {
        if (sb == null) return;
        try {
            sb.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#FFB615")));
            sb.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#FFB615")));
        } catch (Throwable ignored) {}
    }

    private void refreshTextBitmap() {
        Paint p = new Paint();
        p.setColor(currentTextColor);
        p.setTextSize(currentTextSize);
        p.setAntiAlias(true);

        float textWidth = p.measureText(currentText);
        Paint.FontMetrics fm = p.getFontMetrics();
        int w = (int) Math.ceil(textWidth) + 20;
        int h = (int) Math.ceil(fm.bottom - fm.top) + 20;
        if (w <= 0) w = 100;
        if (h <= 0) h = 100;

        if (textBitmap != null && !textBitmap.isRecycled() && textBitmap != scaledText) {
            textBitmap.recycle();
        }
        if (scaledText != null && !scaledText.isRecycled() && scaledText != textBitmap) {
            scaledText.recycle();
        }

        textBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(textBitmap);
        c.drawText(currentText, 10, 10 - fm.top, p);

        textScale = 1.0f;
        scaledText = textBitmap;
        textView.setImageBitmap(scaledText);
        textView.setScaleType(ImageView.ScaleType.MATRIX);
        textView.post(new Runnable() {
                @Override public void run() { centerText(); }
            });
    }

    private void centerText() {
        if (scaledText == null) return;
        textMatrix.reset();
        float cx = (textView.getWidth() - scaledText.getWidth()) / 2f;
        float cy = (textView.getHeight() - scaledText.getHeight()) / 2f;
        textMatrix.postTranslate(cx, cy);
        textView.setImageMatrix(textMatrix);
    }

    private void applyCustomColor() {
        currentTextColor = Color.rgb(drawR, drawG, drawB);
        if (colorPreview != null) {
            colorPreview.setBackground(getRoundBg(currentTextColor));
        }
        if (etHexRef != null) {
            etHexRef.setText(String.format("%02X%02X%02X", drawR, drawG, drawB));
        }
        refreshTextBitmap();
    }

    interface OnSeekBarChangeListener {
        void onProgressChanged(int value);
    }

    private void addRgbRow(LinearLayout parent, final String label, int defaultValue,
                           final OnSeekBarChangeListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(10, 0, 10, 0);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label + "：");
        tvLabel.setTextColor(Color.WHITE);
        row.addView(tvLabel);

        final SeekBar sb = new SeekBar(this);
        LinearLayout.LayoutParams seekLp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        sb.setLayoutParams(seekLp);
        sb.setMax(255);
        sb.setProgress(defaultValue);

        fixSeekBarColor(sb);
        row.addView(sb);

        final EditText et = new EditText(this);
        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(120,
                                                                       LinearLayout.LayoutParams.WRAP_CONTENT);
        et.setLayoutParams(etLp);
        et.setText(String.valueOf(defaultValue));
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setTextColor(Color.WHITE);
        et.setBackground(getRoundBg(0xFF3A3A3A));
        row.addView(et);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (fromUser) {
                        et.setText(String.valueOf(progress));
                        listener.onProgressChanged(progress);
                    }
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });

        et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        try {
                            int value = Integer.parseInt(et.getText().toString());
                            if (value < 0) value = 0;
                            if (value > 255) value = 255;
                            sb.setProgress(value);
                            et.setText(String.valueOf(value));
                            listener.onProgressChanged(value);
                        } catch (Throwable e) {
                            et.setText("0");
                            sb.setProgress(0);
                            listener.onProgressChanged(0);
                        }
                    }
                }
            });

        parent.addView(row);
    }

    private void resetX() {
        if (scaledText == null) return;
        float[] v = new float[9];
        textMatrix.getValues(v);
        float ty = v[Matrix.MTRANS_Y];
        textMatrix.reset();
        float cx = (textView.getWidth() - scaledText.getWidth()) / 2f;
        textMatrix.postTranslate(cx, ty);
        textView.setImageMatrix(textMatrix);
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_x_toast), Toast.LENGTH_SHORT).show();
    }

    private void resetY() {
        if (scaledText == null) return;
        float[] v = new float[9];
        textMatrix.getValues(v);
        float tx = v[Matrix.MTRANS_X];
        textMatrix.reset();
        float cy = (textView.getHeight() - scaledText.getHeight()) / 2f;
        textMatrix.postTranslate(tx, cy);
        textView.setImageMatrix(textMatrix);
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_y_toast), Toast.LENGTH_SHORT).show();
    }

    private void resetRotation() {
        textRotation = 0f;
        if (scaledText == null) return;
        float[] v = new float[9];
        textMatrix.getValues(v);
        float tx = v[Matrix.MTRANS_X];
        float ty = v[Matrix.MTRANS_Y];
        textMatrix.reset();
        textMatrix.postTranslate(tx, ty);
        textView.setImageMatrix(textMatrix);
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_rot_toast), Toast.LENGTH_SHORT).show();
    }

    private void resetScale() {
        textScale = 1.0f;
        if (textBitmap != null) {
            scaledText = textBitmap;
            textView.setImageBitmap(scaledText);
        }
        Toast.makeText(this, LanguageManager.getString(this, R.string.overlay_reset_scale_toast), Toast.LENGTH_SHORT).show();
    }

    private void finishAndReturn() {
        if (baseBitmap == null) {
            setResult(RESULT_CANCELED);
            finish();
            return;
        }

        Bitmap result = Bitmap.createBitmap(baseBitmap.getWidth(), baseBitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);

        if (scaledText != null) {
            Matrix inverseBaseMatrix = new Matrix();
            baseView.getImageMatrix().invert(inverseBaseMatrix);

            Matrix drawMatrix = new Matrix(textMatrix);
            drawMatrix.postConcat(inverseBaseMatrix);

            canvas.drawBitmap(scaledText, drawMatrix, null);
        }

        try {
            java.io.File cacheFile = new java.io.File(getCacheDir(), "text_result.png");
            java.io.FileOutputStream fos = new java.io.FileOutputStream(cacheFile);
            result.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();

            Intent resultIntent = new Intent();
            resultIntent.setData(Uri.fromFile(cacheFile));
            setResult(RESULT_OK, resultIntent);
            finish();
        } catch (Throwable e) {
            Toast.makeText(this, LanguageManager.getString(this, R.string.text_compose_fail), Toast.LENGTH_SHORT).show();
            setResult(RESULT_CANCELED);
            finish();
        }
    }
}
