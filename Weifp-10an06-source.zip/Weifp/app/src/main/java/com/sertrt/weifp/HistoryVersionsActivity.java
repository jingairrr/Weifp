package com.sertrt.weifp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.File;
import java.util.List;
import java.util.Map;

public class HistoryVersionsActivity extends Activity {

    private GridView gridView;
    private String imagePath;
    private List<File> stepFiles;
    private int itemSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imagePath = getIntent().getStringExtra("image_path");

        String fileName = new File(imagePath).getName();
        final File stepsDir = HistoryManager.getStepsDir(this, fileName);

        stepFiles = HistoryManager.getSortedStepFiles(stepsDir);

        if (stepFiles == null || stepFiles.isEmpty()) {
            Toast.makeText(this, "这个项目还没有历史版本哦", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int screenWidth = metrics.widthPixels;
        int padding = (int)(16 * getResources().getDisplayMetrics().density);
        int spacing = (int)(16 * getResources().getDisplayMetrics().density);
        itemSize = (screenWidth - padding * 2 - spacing * 2) / 3;

        gridView = new GridView(this);
        gridView.setNumColumns(3);
        gridView.setPadding(padding, padding + (int)(50 * getResources().getDisplayMetrics().density), padding, padding);
        gridView.setVerticalSpacing(spacing);
        gridView.setHorizontalSpacing(spacing);
        gridView.setBackgroundColor(ThemeManager.getBgColor(this));

        gridView.setAdapter(new VersionAdapter());
        setContentView(gridView);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    final File selectedFile = stepFiles.get(position);
                    new AlertDialog.Builder(HistoryVersionsActivity.this)
                        .setTitle("恢复历史版本")
                        .setMessage("确定要覆盖当前图片为选中的版本吗？\n(当前操作会作为新版本追加，不会删除原有历史记录)")
                        .setPositiveButton("确定恢复", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                rollbackToVersion(selectedFile);
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
                }
            });

        BackButtonHelper.addBackButton(this, null);
    }

    private void rollbackToVersion(final File versionFile) {
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("正在恢复版本...");
        pd.setCancelable(false);
        pd.show();

        new Thread(new Runnable() {
                @Override
                public void run() {
                    final boolean ok = HistoryManager.rollbackToVersion(HistoryVersionsActivity.this, imagePath, versionFile);
                    runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                pd.dismiss();
                                if (ok) {
                                    Toast.makeText(HistoryVersionsActivity.this, "已恢复到该历史版本！", Toast.LENGTH_SHORT).show();
                                    finish();
                                } else {
                                    Toast.makeText(HistoryVersionsActivity.this, "恢复失败啦 (｡•́︿•̀｡)", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                }
            }).start();
    }

    private class VersionAdapter extends BaseAdapter {
        @Override public int getCount() { return stepFiles.size(); }
        @Override public Object getItem(int position) { return stepFiles.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView iv = new ImageView(HistoryVersionsActivity.this);
            GridView.LayoutParams lp = new GridView.LayoutParams(itemSize, itemSize);
            iv.setLayoutParams(lp);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackgroundColor(ThemeManager.getButtonColor(HistoryVersionsActivity.this));

            File pngFile = stepFiles.get(position);
            Bitmap bmp = renderStepPreview(pngFile);
            if (bmp != null) iv.setImageBitmap(bmp);

            return iv;
        }
    }

    // ★ 参考主页逻辑：步骤图（数据图）+ wpb 参数 = 视觉预览
    private Bitmap renderStepPreview(File pngFile) {
        Bitmap src = HistoryManager.decodeSampledBitmap(pngFile.getAbsolutePath(), itemSize, itemSize);
        if (src == null) return null;

        File stepsDir = pngFile.getParentFile();
        Map<String, String> wpb = HistoryManager.readStepWpb(stepsDir, pngFile.getName());
        if (wpb == null || wpb.isEmpty()) {
            return src;
        }
        return applyWpbToBitmap(src, wpb);
    }

    private Bitmap applyWpbToBitmap(Bitmap src, Map<String, String> wpb) {
        try {
            float bright = parseFloat(wpb.get("bright"), 0);
            float cont = parseFloat(wpb.get("cont"), 1);
            float sat = parseFloat(wpb.get("sat"), 1);
            float shadow = parseFloat(wpb.get("shadow"), 0);
            float high = parseFloat(wpb.get("high"), 0);
            float temp = parseFloat(wpb.get("temp"), 0);
            float tint = parseFloat(wpb.get("tint"), 0);

            int[] lutM = stringToLut(wpb.get("lut_m"));
            int[] lutR = stringToLut(wpb.get("lut_r"));
            int[] lutG = stringToLut(wpb.get("lut_g"));
            int[] lutB = stringToLut(wpb.get("lut_b"));

            // ★ Bug 15：读色阶 4 通道 × 黑/灰/白
            int[] lvBlack = new int[4];
            int[] lvGray = new int[4];
            int[] lvWhite = new int[4];
            for (int i = 0; i < 4; i++) {
                lvBlack[i] = parseInt(wpb.get("lv_b_" + i), 0);
                lvGray[i] = parseInt(wpb.get("lv_g_" + i), 128);
                lvWhite[i] = parseInt(wpb.get("lv_w_" + i), 255);
            }
            boolean hasLevels = false;
            for (int i = 0; i < 4; i++) {
                if (lvBlack[i] != 0 || lvGray[i] != 128 || lvWhite[i] != 255) { hasLevels = true; break; }
            }
            int[][] lvLut = null;
            if (hasLevels) {
                lvLut = new int[4][256];
                for (int ch = 0; ch < 4; ch++) {
                    float blackF = lvBlack[ch];
                    float whiteF = lvWhite[ch];
                    float grayF = lvGray[ch];
                    float range = whiteF - blackF;
                    if (range < 1f) range = 1f;
                    float midNorm = (grayF - blackF) / range;
                    if (midNorm < 0.01f) midNorm = 0.01f;
                    if (midNorm > 0.99f) midNorm = 0.99f;
                    double gamma = Math.log(0.5) / Math.log(midNorm);
                    for (int i = 0; i < 256; i++) {
                        float v = i;
                        float norm;
                        if (v <= blackF) norm = 0f;
                        else if (v >= whiteF) norm = 1f;
                        else norm = (v - blackF) / range;
                        float out = (float) Math.pow(norm, gamma) * 255f;
                        int oi = (int)(out + 0.5f);
                        if (oi < 0) oi = 0;
                        if (oi > 255) oi = 255;
                        lvLut[ch][i] = oi;
                    }
                }
            }

            
            
            HslAdjust hsl = new HslAdjust();
            for (int i = 0; i < 8; i++) {
                hsl.hue[i] = parseFloat(wpb.get("hsl_hue_" + i), 0);
                hsl.sat[i] = parseFloat(wpb.get("hsl_sat_" + i), 0);
                hsl.lum[i] = parseFloat(wpb.get("hsl_lum_" + i), 0);
            }
            hsl.isEmpty();

            boolean hasFilter = bright != 0 || cont != 1 || sat != 1
                || shadow != 0 || high != 0 || temp != 0 || tint != 0;
            boolean hasLut = lutM != null || lutR != null || lutG != null || lutB != null;
            boolean hasHsl = !hsl.isEmpty();

            if (!hasFilter && !hasLut && !hasHsl && !hasLevels) return src;

            int w = src.getWidth(), h = src.getHeight();
            Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(out);
            Paint p = new Paint();

            if (hasFilter) {
                ColorMatrix cm = new ColorMatrix();
                float bAdd = bright * 2.55f;
                float bScale = bright > 0 ? 1.0f + bright / 100f : 1.0f;
                cm.postConcat(new ColorMatrix(new float[]{bScale,0,0,0,bAdd, 0,bScale,0,0,bAdd, 0,0,bScale,0,bAdd, 0,0,0,1,0}));
                float t = (1 - cont) * 128;
                cm.postConcat(new ColorMatrix(new float[]{cont,0,0,0,t, 0,cont,0,0,t, 0,0,cont,0,t, 0,0,0,1,0}));
                float sr = (1 - sat) * 0.3086f, sg = (1 - sat) * 0.6094f, sb = (1 - sat) * 0.0820f;
                cm.postConcat(new ColorMatrix(new float[]{sr+sat,sg,sb,0,0, sr,sg+sat,sb,0,0, sr,sg,sb+sat,0,0, 0,0,0,1,0}));
                float so = shadow * 0.5f;
                cm.postConcat(new ColorMatrix(new float[]{1,0,0,0,so, 0,1,0,0,so, 0,0,1,0,so, 0,0,0,1,0}));
                float ho = high * 0.5f;
                cm.postConcat(new ColorMatrix(new float[]{1,0,0,0,ho, 0,1,0,0,ho, 0,0,1,0,ho, 0,0,0,1,0}));
                float tR = temp * 0.5f, tB = -temp * 0.5f;
                cm.postConcat(new ColorMatrix(new float[]{1,0,0,0,tR, 0,1,0,0,0, 0,0,1,0,tB, 0,0,0,1,0}));
                float tG = -tint * 0.5f, tM = tint * 0.5f;
                cm.postConcat(new ColorMatrix(new float[]{1,0,0,0,tM, 0,1,0,0,tG, 0,0,1,0,tM, 0,0,0,1,0}));
                p.setColorFilter(new ColorMatrixColorFilter(cm));
            }
            canvas.drawBitmap(src, 0, 0, p);

            if (hasLut || hasHsl || hasLevels) {
                int[] px = new int[w * h];
                out.getPixels(px, 0, w, 0, 0, w, h);
                for (int i = 0; i < px.length; i++) {
                    int c = px[i];
                    int a = (c >> 24) & 0xFF;
                    int cr = (c >> 16) & 0xFF, cg = (c >> 8) & 0xFF, cb = c & 0xFF;

                    // ★ Bug 15：色阶先应用
                    if (hasLevels) {
                        if (lvBlack[0] != 0 || lvGray[0] != 128 || lvWhite[0] != 255) {
                            cr = lvLut[0][cr]; cg = lvLut[0][cg]; cb = lvLut[0][cb];
                        }
                        if (lvBlack[1] != 0 || lvGray[1] != 128 || lvWhite[1] != 255) cr = lvLut[1][cr];
                        if (lvBlack[2] != 0 || lvGray[2] != 128 || lvWhite[2] != 255) cg = lvLut[2][cg];
                        if (lvBlack[3] != 0 || lvGray[3] != 128 || lvWhite[3] != 255) cb = lvLut[3][cb];
                    }

                    if (lutM != null) { cr = lutM[cr]; cg = lutM[cg]; cb = lutM[cb]; }
                    if (lutR != null) cr = lutR[cr];
                    if (lutG != null) cg = lutG[cg];
                    if (lutB != null) cb = lutB[cb];
                    if (hasHsl) {
                        int o = hsl.applyPixel(cr, cg, cb);
                        cr = (o >> 16) & 0xFF; cg = (o >> 8) & 0xFF; cb = o & 0xFF;
                    }
                    px[i] = (a << 24) | (cr << 16) | (cg << 8) | cb;
                }
                out.setPixels(px, 0, w, 0, 0, w, h);
            }
            return out;
        } catch (Throwable e) {
            return src;
        }
    }

    private float parseFloat(String s, float def) {
        if (s == null) return def;
        try { return Float.parseFloat(s); } catch (Throwable e) { return def; }
    }
    
    private int parseInt(String s, int def) {
        if (s == null) return def;
        try { return Integer.parseInt(s); } catch (Throwable e) { return def; }
    }

    private int[] stringToLut(String str) {
        if (str == null) return null;
        try {
            byte[] bytes = Base64.decode(str, Base64.NO_WRAP);
            int[] lut = new int[bytes.length];
            for (int i = 0; i < bytes.length; i++) lut[i] = bytes[i] & 0xFF;
            return lut;
        } catch (Throwable e) { return null; }
    }
}
