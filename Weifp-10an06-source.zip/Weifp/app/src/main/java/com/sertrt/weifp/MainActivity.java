package com.sertrt.weifp;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int PICK_IMAGE_GALLERY = 100;
    private static final int PICK_IMAGE_FILE = 101;
    private static final int SAVE_WP_REQUEST = 201;
    private static final int SAVE_WPC_REQUEST = 202;
    private static final int IMPORT_WP_REQUEST = 301;
    private static final int IMPORT_WPC_REQUEST = 302;

    private GridView historyGrid;
    private View rootView;
    private File pendingSaveFile;
    private float density;
    private int itemSize;
    private Bitmap cachedCheckBadge = null;
    private String lastDataSignature = "";

    private android.content.SharedPreferences filterSp;
    private boolean cachedHasWpb;
    private int cachedTextColor;
    private int cachedButtonColor;
    private int cachedPanelColor;

    private boolean isScrolling = false;
    private Handler scrollIdleHandler = new Handler();
    private Runnable scrollIdleRunnable = null;
    private static final int SCROLL_IDLE_DELAY = 500;

    private java.util.concurrent.ExecutorService thumbExecutor = java.util.concurrent.Executors.newFixedThreadPool(2);
    private android.util.LruCache<String, Bitmap> thumbCache;

    private boolean isMultiSelectMode = false;
    private List<String> selectedPaths = new ArrayList<>();
    private LinearLayout multiSelectBar;
    private TextView tvSelectCount;
    private TextView btnMultiSelect;
    private HistoryAdapter adapter;

    static class ViewHolder {
        FrameLayout coverLayout;
        ImageView img;
        View overlay;
        ImageView checkIcon;
        ImageView rawBadge;
        ImageView wpbBadge;
        TextView tvName;
    }

    private String sep() {
        int lang = LanguageManager.getLanguage(this);
        if (lang == LanguageManager.LANG_ENGLISH) return ": ";
        return "：";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        

        if (LanguageManager.getLanguage(this) == LanguageManager.LANG_CLASSICAL) {
            LanguageManager.setLanguage(this, LanguageManager.LANG_SIMPLIFIED);
        }

        getBaseContext().getResources().updateConfiguration(
            LanguageManager.wrap(this).getResources().getConfiguration(),
            getBaseContext().getResources().getDisplayMetrics()
        );

        setContentView(R.layout.activity_main);
        density = getResources().getDisplayMetrics().density;

        filterSp = getSharedPreferences("weifp_filters", MODE_PRIVATE);
        cachedHasWpb = ThemeManager.isWpbEnabled(this);
        cachedTextColor = ThemeManager.getTextColor(this);
        cachedButtonColor = ThemeManager.getButtonColor(this);
        cachedPanelColor = ThemeManager.getPanelColor(this);

        int maxMemKb = (int)(Runtime.getRuntime().maxMemory() / 1024 / 8);
        thumbCache = new android.util.LruCache<String, Bitmap>(maxMemKb) {
            @Override protected int sizeOf(String key, Bitmap bmp) {
                return bmp.getByteCount() / 1024;
            }
        };

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int screenWidth = metrics.widthPixels;
        int margin = (int)(8 * density);
        itemSize = (screenWidth - (margin * 8)) / 4;

        rootView = findViewById(android.R.id.content);
        historyGrid = (GridView) findViewById(R.id.history_grid);

        historyGrid.setOnScrollListener(new AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {
                    if (scrollIdleRunnable != null) {
                        scrollIdleHandler.removeCallbacks(scrollIdleRunnable);
                        scrollIdleRunnable = null;
                    }
                    if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                        scrollIdleRunnable = new Runnable() {
                            @Override public void run() {
                                isScrolling = false;
                                if (adapter != null) adapter.notifyDataSetChanged();
                            }
                        };
                        scrollIdleHandler.postDelayed(scrollIdleRunnable, SCROLL_IDLE_DELAY);
                    } else {
                        isScrolling = true;
                    }
                }
                @Override public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {}
            });

        applyThemeBg();
        setupMultiSelectBar();

        ImageView logo = (ImageView) findViewById(R.id.logo);
        logo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                }
            });

        btnMultiSelect = new TextView(this);
        btnMultiSelect.setText(LanguageManager.getString(this, R.string.multi_select));
        btnMultiSelect.setTextSize(13);
        btnMultiSelect.setTextColor(Color.BLACK);
        btnMultiSelect.setGravity(Gravity.CENTER);
        btnMultiSelect.setBackground(getRoundBg(0xFFFFB615));

        FrameLayout.LayoutParams lpMulti = new FrameLayout.LayoutParams(
            (int)(60 * density), (int)(34 * density));
        lpMulti.gravity = Gravity.TOP | Gravity.END;
        lpMulti.setMargins(0, (int)(10 * density), (int)(12 * density), 0);
        btnMultiSelect.setLayoutParams(lpMulti);
        btnMultiSelect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isMultiSelectMode) {
                        exitMultiSelectMode();
                    } else {
                        isMultiSelectMode = true;
                        btnMultiSelect.setVisibility(View.GONE);
                        multiSelectBar.setVisibility(View.VISIBLE);
                        refreshHistoryGrid();
                    }
                }
            });
        if (rootView != null) ((FrameLayout) rootView).addView(btnMultiSelect);

        historyGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (adapter == null) return;
                    if (adapter.isAddPosition(position)) {
                        showAddDialog();
                        return;
                    }
                    HistoryItem item = adapter.getItemAtPosition(position);
                    if (item == null) return;
                    String filePath = item.file.getAbsolutePath();
                    if (isMultiSelectMode) {
                        if (selectedPaths.contains(filePath)) {
                            selectedPaths.remove(filePath);
                        } else {
                            selectedPaths.add(filePath);
                        }
                        tvSelectCount.setText(LanguageManager.getString(MainActivity.this, R.string.selected_count, selectedPaths.size()));
                        adapter.notifyDataSetChanged();
                    } else {
                        Intent intent = new Intent(MainActivity.this, activity2Main.class);
                        intent.putExtra("is_blank", false);
                        intent.putExtra("edit_file_path", filePath);
                        startActivity(intent);
                    }
                }
            });

        historyGrid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    if (adapter == null) return false;
                    if (adapter.isAddPosition(position)) return false;
                    HistoryItem item = adapter.getItemAtPosition(position);
                    if (item == null) return false;
                    if (!isMultiSelectMode) {
                        showFileOptions(item);
                    }
                    return true;
                }
            });

        preGenerateMissingCovers();
    }

    private void preGenerateMissingCovers() {
        Thread t = new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        List<HistoryItem> items = HistoryManager.getAllHistory(MainActivity.this);
                        boolean generatedAny = false;
                        for (HistoryItem it : items) {
                            File coverFile = new File(HistoryManager.getCoverDir(MainActivity.this), it.file.getName());
                            if (coverFile.exists() && coverFile.length() > 0) continue;
                            try { Thread.sleep(120); } catch (Throwable ignored) {}
                            Bitmap bmp = null;
                            Bitmap filtered = null;
                            try {
                                bmp = HistoryManager.decodeSampledBitmap(it.file.getAbsolutePath(), 512, 512);
                                if (bmp != null) {
                                    filtered = HistoryManager.applyFiltersToThumbnail(MainActivity.this, bmp, it.file.getAbsolutePath());
                                    Bitmap save = (filtered != null) ? filtered : bmp;
                                    FileOutputStream fos = new FileOutputStream(coverFile);
                                    save.compress(Bitmap.CompressFormat.PNG, 85, fos);
                                    fos.close();
                                    generatedAny = true;
                                }
                            } catch (Throwable e) {
                            } finally {
                                if (filtered != null && filtered != bmp && !filtered.isRecycled()) filtered.recycle();
                                if (bmp != null && !bmp.isRecycled()) bmp.recycle();
                            }
                        }
                        if (generatedAny) {
                            runOnUiThread(new Runnable() {
                                    @Override public void run() {
                                        lastDataSignature = "";
                                        refreshHistoryGrid();
                                    }
                                });
                        }
                    } catch (Throwable e) {}
                }
            });
        t.setPriority(Thread.MIN_PRIORITY);
        t.start();
    }

    private void setupMultiSelectBar() {
        multiSelectBar = new LinearLayout(this);
        multiSelectBar.setOrientation(LinearLayout.HORIZONTAL);
        multiSelectBar.setBackgroundColor(0xFF2A2A2A);
        multiSelectBar.setGravity(Gravity.CENTER_VERTICAL);
        multiSelectBar.setPadding((int)(20*density), (int)(15*density), (int)(20*density), (int)(15*density));
        multiSelectBar.setVisibility(View.GONE);

        tvSelectCount = new TextView(this);
        tvSelectCount.setTextColor(Color.WHITE);
        tvSelectCount.setTextSize(15);
        tvSelectCount.setText(LanguageManager.getString(this, R.string.selected_count, 0));
        LinearLayout.LayoutParams lpText = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tvSelectCount.setLayoutParams(lpText);
        multiSelectBar.addView(tvSelectCount);

        TextView btnConfirm = new TextView(this);
        btnConfirm.setText(LanguageManager.getString(this, R.string.confirm));
        btnConfirm.setTextSize(13);
        btnConfirm.setGravity(Gravity.CENTER);
        btnConfirm.setTextColor(Color.BLACK);
        btnConfirm.setBackground(getRoundBg(0xFFFFB615));
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams((int)(60*density), (int)(32*density));
        lp1.setMargins(0, 0, (int)(10*density), 0);
        btnConfirm.setLayoutParams(lp1);
        btnConfirm.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { showConfirmOptions(); }
            });
        multiSelectBar.addView(btnConfirm);

        TextView btnCancel = new TextView(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setTextSize(13);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setBackground(getRoundBg(0xFF555555));
        btnCancel.setLayoutParams(new LinearLayout.LayoutParams((int)(60*density), (int)(32*density)));
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { exitMultiSelectMode(); }
            });
        multiSelectBar.addView(btnCancel);

        FrameLayout.LayoutParams lpBar = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        lpBar.gravity = Gravity.TOP;
        multiSelectBar.setLayoutParams(lpBar);
        if (rootView != null) ((FrameLayout) rootView).addView(multiSelectBar);
    }

    /** 自动检查更新的节流标记（一次会话只查一次）。 */
    private boolean autoUpdateChecked = false;

    @Override
    protected void onResume() {
        super.onResume();
        // 每天首次打开时静默检查一次更新
        if (!autoUpdateChecked) {
            autoUpdateChecked = true;
            try {
                if (UpdateChecker.shouldAutoCheck(this)) {
                    UpdateChecker.markChecked(this);
                    UpdateChecker.check(new UpdateChecker.Callback() {
                            @Override public void onUpdateAvailable(final String vn, final int vc,
                                                                    final String url, final String notes) {
                                runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            UpdateDialog.show(MainActivity.this, vn, vc, url, notes);
                                        }
                                    });
                            }
                            @Override public void onUpToDate() {}
                            @Override public void onError(String reason) {}
                        });
                }
            } catch (Throwable ignored) {
            }
        }
        cachedHasWpb = ThemeManager.isWpbEnabled(this);
        cachedTextColor = ThemeManager.getTextColor(this);
        cachedButtonColor = ThemeManager.getButtonColor(this);
        cachedPanelColor = ThemeManager.getPanelColor(this);
        applyThemeBg();
        // 编辑页保存过（保存不再退出，主页收不到回调）就强制刷新
        try {
            if (HistoryManager.consumeNeedsRefresh()) {
                // 有列表适配器就重置，保证缩略图重新解码
                if (historyGrid != null && historyGrid.getAdapter() != null) {
                    ((android.widget.BaseAdapter) historyGrid.getAdapter()).notifyDataSetChanged();
                }
            }
        } catch (Throwable ignored) {
        }
        refreshHistoryGrid();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (scrollIdleRunnable != null) {
            scrollIdleHandler.removeCallbacks(scrollIdleRunnable);
            scrollIdleRunnable = null;
        }
        if (thumbExecutor != null && !thumbExecutor.isShutdown()) {
            thumbExecutor.shutdownNow();
        }
        if (cachedCheckBadge != null && !cachedCheckBadge.isRecycled()) {
            cachedCheckBadge.recycle();
            cachedCheckBadge = null;
        }
    }

    private void applyThemeBg() {
        int bgColor = ThemeManager.getBgColor(this);
        getWindow().setBackgroundDrawable(new ColorDrawable(bgColor));
        if (rootView != null) rootView.setBackgroundColor(bgColor);
        if (historyGrid != null) historyGrid.setBackgroundColor(bgColor);
    }

    private void refreshHistoryGrid() {
        List<HistoryItem> historyItems = HistoryManager.getAllHistory(this);
        StringBuilder sig = new StringBuilder();
        for (HistoryItem it : historyItems) {
            // 签名里同时带长度，避免"内容变了但 mtime 精度不够"时误判为没变化
            sig.append(it.file.getAbsolutePath())
               .append(":").append(it.file.lastModified())
               .append(":").append(it.file.length())
               .append(";");
        }
        String newSig = sig.toString();
        boolean forced = HistoryManager.consumeNeedsRefreshLazy();
        if (!forced && newSig.equals(lastDataSignature) && adapter != null) {
            adapter.notifyDataSetChanged();
            return;
        }
        lastDataSignature = newSig;
        // 重建前清掉缩略图缓存，保证新图能显示出来
        try {
            if (thumbCache != null) thumbCache.evictAll();
        } catch (Throwable ignored) {
        }
        adapter = new HistoryAdapter(historyItems);
        historyGrid.setAdapter(adapter);
    }

    class HistoryAdapter extends BaseAdapter {
        private static final int VIEW_TYPE_ADD = 0;
        private static final int VIEW_TYPE_ITEM = 1;

        private List<HistoryItem> items;

        HistoryAdapter(List<HistoryItem> items) {
            this.items = items;
        }

        boolean isAddPosition(int position) {
            return !isMultiSelectMode && position == 0;
        }

        HistoryItem getItemAtPosition(int position) {
            int idx = position - (isMultiSelectMode ? 0 : 1);
            if (idx < 0 || idx >= items.size()) return null;
            return items.get(idx);
        }

        @Override public int getCount() {
            return items.size() + (isMultiSelectMode ? 0 : 1);
        }

        @Override public Object getItem(int position) {
            return getItemAtPosition(position);
        }

        @Override public long getItemId(int position) { return position; }

        @Override public int getViewTypeCount() { return 2; }

        @Override public int getItemViewType(int position) {
            return isAddPosition(position) ? VIEW_TYPE_ADD : VIEW_TYPE_ITEM;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            int type = getItemViewType(position);

            if (type == VIEW_TYPE_ADD) {
                ImageView addBtn = (ImageView) convertView;
                if (addBtn == null || !(addBtn.getLayoutParams() instanceof GridView.LayoutParams)) {
                    addBtn = new ImageView(MainActivity.this);
                    addBtn.setLayoutParams(new GridView.LayoutParams(itemSize, itemSize));
                    addBtn.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                }
                addBtn.setImageResource(R.drawable.add_plus);
                addBtn.setBackgroundColor(cachedButtonColor);
                return addBtn;
            }

            HistoryItem item = getItemAtPosition(position);
            if (item == null) {
                View empty = new View(MainActivity.this);
                empty.setLayoutParams(new GridView.LayoutParams(itemSize, itemSize));
                return empty;
            }

            String filePath = item.file.getAbsolutePath();
            boolean isSelected = selectedPaths.contains(filePath);

            ViewHolder holder;
            if (convertView != null && convertView.getTag() instanceof ViewHolder) {
                holder = (ViewHolder) convertView.getTag();
            } else {
                holder = new ViewHolder();
                LinearLayout itemLayout = new LinearLayout(MainActivity.this);
                itemLayout.setOrientation(LinearLayout.VERTICAL);
                itemLayout.setGravity(Gravity.CENTER_HORIZONTAL);
                itemLayout.setLayoutParams(new GridView.LayoutParams(itemSize, ViewGroup.LayoutParams.WRAP_CONTENT));
                itemLayout.setPadding(0, 0, 0, (int)(4 * density));

                holder.coverLayout = new FrameLayout(MainActivity.this);
                holder.coverLayout.setLayoutParams(new LinearLayout.LayoutParams(itemSize, itemSize));
                itemLayout.addView(holder.coverLayout);

                holder.img = new ImageView(MainActivity.this);
                holder.img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                holder.img.setBackgroundColor(cachedButtonColor);
                holder.img.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                holder.coverLayout.addView(holder.img);

                holder.overlay = new View(MainActivity.this);
                holder.overlay.setBackgroundColor(0x80000000);
                holder.overlay.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                holder.overlay.setVisibility(View.GONE);
                holder.coverLayout.addView(holder.overlay);

                holder.checkIcon = new ImageView(MainActivity.this);
                holder.checkIcon.setImageBitmap(createCheckBadge());
                int badgePx = (int)(36 * density);
                FrameLayout.LayoutParams lpCheck = new FrameLayout.LayoutParams(badgePx, badgePx);
                int badgeMargin = (int)(6 * density);
                lpCheck.gravity = Gravity.TOP | Gravity.END;
                lpCheck.setMargins(0, badgeMargin, badgeMargin, 0);
                holder.checkIcon.setLayoutParams(lpCheck);
                holder.checkIcon.setVisibility(View.GONE);
                holder.coverLayout.addView(holder.checkIcon);

                int badgeSize = (int)(32 * density);
                int badgeGap = (int)(4 * density);

                holder.rawBadge = new ImageView(MainActivity.this);
                holder.rawBadge.setImageResource(R.drawable.ic_raw);
                FrameLayout.LayoutParams lpRaw = new FrameLayout.LayoutParams(badgeSize, badgeSize);
                lpRaw.gravity = Gravity.BOTTOM | Gravity.END;
                lpRaw.setMargins(0, 0, badgeGap, badgeGap);
                holder.rawBadge.setLayoutParams(lpRaw);
                holder.rawBadge.setVisibility(View.GONE);
                holder.coverLayout.addView(holder.rawBadge);

                holder.wpbBadge = new ImageView(MainActivity.this);
                holder.wpbBadge.setImageResource(R.drawable.ic_wpb_badge);
                FrameLayout.LayoutParams lpWpb = new FrameLayout.LayoutParams(badgeSize, badgeSize);
                lpWpb.gravity = Gravity.BOTTOM | Gravity.END;
                lpWpb.setMargins(0, 0, badgeGap, badgeGap);
                holder.wpbBadge.setLayoutParams(lpWpb);
                holder.wpbBadge.setVisibility(View.GONE);
                holder.coverLayout.addView(holder.wpbBadge);

                holder.tvName = new TextView(MainActivity.this);
                holder.tvName.setTextSize(11);
                holder.tvName.setSingleLine(true);
                holder.tvName.setGravity(Gravity.CENTER);
                holder.tvName.setEllipsize(android.text.TextUtils.TruncateAt.END);
                holder.tvName.setPadding((int)(2*density), (int)(4*density), (int)(2*density), 0);
                itemLayout.addView(holder.tvName);

                convertView = itemLayout;
                convertView.setTag(holder);
            }

            holder.tvName.setText(item.displayName);
            holder.tvName.setTextColor(cachedTextColor);

            holder.overlay.setVisibility(isSelected ? View.VISIBLE : View.GONE);
            holder.checkIcon.setVisibility(isSelected ? View.VISIBLE : View.GONE);

            boolean isRaw = filterSp.getBoolean(filePath + "_is_raw", false);

            holder.rawBadge.setVisibility(isRaw ? View.VISIBLE : View.GONE);

            if (cachedHasWpb) {
                holder.wpbBadge.setVisibility(View.VISIBLE);
                int badgeSize = (int)(32 * density);
                int badgeGap = (int)(4 * density);
                int bottomMargin = badgeGap;
                if (isRaw) bottomMargin += badgeSize + badgeGap;
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) holder.wpbBadge.getLayoutParams();
                lp.bottomMargin = bottomMargin;
                holder.wpbBadge.setLayoutParams(lp);
            } else {
                holder.wpbBadge.setVisibility(View.GONE);
            }

            final String cacheKey = filePath + "_" + item.file.lastModified() + "_" + itemSize;

            Bitmap cached = thumbCache.get(cacheKey);
            if (cached != null && !cached.isRecycled()) {
                holder.img.setImageBitmap(cached);
                holder.img.setTag(null);
            } else if (isScrolling) {
                holder.img.setImageDrawable(null);
                holder.img.setTag(null);
            } else {
                holder.img.setImageDrawable(null);
                holder.img.setTag(cacheKey);
                final ImageView targetImg = holder.img;
                final HistoryItem finalItem = item;
                thumbExecutor.execute(new Runnable() {
                        @Override public void run() {
                            Bitmap displayBmp = null;
                            try {
                                File coverFile = new File(HistoryManager.getCoverDir(MainActivity.this), finalItem.file.getName());
                                if (coverFile.exists() && coverFile.length() > 0) {
                                    displayBmp = HistoryManager.decodeSampledBitmap(coverFile.getAbsolutePath(), itemSize, itemSize);
                                } else {
                                    displayBmp = HistoryManager.decodeSampledBitmap(finalItem.file.getAbsolutePath(), itemSize, itemSize);
                                }
                                if (displayBmp != null) {
                                    thumbCache.put(cacheKey, displayBmp);
                                }
                            } catch (Throwable e) {}
                            final Bitmap finalBmp = displayBmp;
                            runOnUiThread(new Runnable() {
                                    @Override public void run() {
                                        Object tag = targetImg.getTag();
                                        if (tag == null || !cacheKey.equals(tag.toString())) return;
                                        if (finalBmp != null && !finalBmp.isRecycled()) {
                                            targetImg.setImageBitmap(finalBmp);
                                        } else {
                                            targetImg.setImageDrawable(null);
                                        }
                                    }
                                });
                        }
                    });
            }

            return convertView;
        }
    }

    private Bitmap createCheckBadge() {
        if (cachedCheckBadge != null && !cachedCheckBadge.isRecycled()) return cachedCheckBadge;
        int size = (int)(36 * density);
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        float cx = size / 2f, cy = size / 2f, r = size / 2f - 2;

        Paint circle = new Paint();
        circle.setAntiAlias(true);
        circle.setColor(0xFFFFB615);
        c.drawCircle(cx, cy, r, circle);

        Paint check = new Paint();
        check.setAntiAlias(true);
        check.setColor(Color.WHITE);
        check.setStyle(Paint.Style.STROKE);
        check.setStrokeWidth(size * 0.11f);
        check.setStrokeCap(Paint.Cap.ROUND);
        check.setStrokeJoin(Paint.Join.ROUND);

        Path p = new Path();
        p.moveTo(size * 0.28f, size * 0.52f);
        p.lineTo(size * 0.44f, size * 0.68f);
        p.lineTo(size * 0.74f, size * 0.34f);
        c.drawPath(p, check);

        cachedCheckBadge = bmp;
        return bmp;
    }

    private void exitMultiSelectMode() {
        isMultiSelectMode = false;
        selectedPaths.clear();
        multiSelectBar.setVisibility(View.GONE);
        if (btnMultiSelect != null) btnMultiSelect.setVisibility(View.VISIBLE);
        lastDataSignature = "";
        refreshHistoryGrid();
    }

    private GradientDrawable getRoundBg(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE); bg.setCornerRadius(UiSpec.dp(this, UiSpec.RADIUS_S)); bg.setColor(color);
        return bg;
    }

    private void showCustomDialog(String title, String[] items, final DialogInterface.OnClickListener listener) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getRoundBg(cachedPanelColor));
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(10*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(cachedTextColor);
        tvTitle.setGravity(Gravity.CENTER);
        tvTitle.setPadding(0, 0, 0, (int)(20*density));
        root.addView(tvTitle);

        if (items != null) {
            for (int i = 0; i < items.length; i++) {
                final int index = i;
                TextView tvItem = new TextView(this);
                tvItem.setText(items[i]);
                tvItem.setTextSize(15);
                tvItem.setTextColor(cachedTextColor);
                tvItem.setGravity(Gravity.CENTER);
                tvItem.setPadding(0, (int)(15*density), 0, (int)(15*density));
                tvItem.setBackground(getRoundBg(cachedButtonColor));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 0, 0, (int)(10*density));
                tvItem.setLayoutParams(lp);
                tvItem.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            if (listener != null) listener.onClick(dialog, index);
                            dialog.dismiss();
                        }
                    });
                root.addView(tvItem);
            }
        }

        TextView btnCancel = new TextView(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setPadding(0, (int)(15*density), 0, (int)(15*density));
        btnCancel.setBackground(getRoundBg(0xFFB61515));
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dialog.dismiss(); }
            });
        root.addView(btnCancel);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dialog.setContentView(sv);

        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.8);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void showCustomPrompt(String title, String msg, final EditText input, final DialogInterface.OnClickListener listener) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getRoundBg(cachedPanelColor));
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(10*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(cachedTextColor);
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        if (msg != null) {
            TextView tvMsg = new TextView(this);
            tvMsg.setText(msg);
            tvMsg.setTextSize(13);
            tvMsg.setTextColor(cachedTextColor);
            tvMsg.setGravity(Gravity.CENTER);
            tvMsg.setPadding(0, (int)(10*density), 0, (int)(10*density));
            root.addView(tvMsg);
        }
        if (input != null) {
            root.addView(input);
        }

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, (int)(20*density), 0, 0);

        TextView btnCancel = new TextView(this);
        btnCancel.setText(LanguageManager.getString(this, R.string.cancel));
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.WHITE);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnCancel.setBackground(getRoundBg(0xFF555555));
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp1.setMargins(0, 0, (int)(10*density), 0);
        btnCancel.setLayoutParams(lp1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dialog.dismiss(); }
            });
        btnRow.addView(btnCancel);

        TextView btnOk = new TextView(this);
        btnOk.setText(LanguageManager.getString(this, R.string.confirm));
        btnOk.setTextSize(15);
        btnOk.setTextColor(Color.BLACK);
        btnOk.setGravity(Gravity.CENTER);
        btnOk.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnOk.setBackground(getRoundBg(0xFFFFB615));
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btnOk.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (listener != null) listener.onClick(dialog, 0);
                    dialog.dismiss();
                }
            });
        btnRow.addView(btnOk);

        root.addView(btnRow);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dialog.setContentView(sv);

        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.8);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void showConfirmOptions() {
        if (selectedPaths.isEmpty()) {
            Toast.makeText(this, LanguageManager.getString(this, R.string.toast_no_selection), Toast.LENGTH_SHORT).show();
            return;
        }
        String[] options = {LanguageManager.getString(this, R.string.copy), LanguageManager.getString(this, R.string.delete)};
        showCustomDialog(LanguageManager.getString(this, R.string.selected_count, selectedPaths.size()), options, new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if (which == 0) copyMultiSelected();
                    else deleteMultiSelected();
                }
            });
    }

    private void copyMultiSelected() {
        if (selectedPaths.isEmpty()) return;
        int selectedCount = selectedPaths.size();
        if (selectedCount > 5) {
            showCustomDialog(LanguageManager.getString(this, R.string.toast_too_many),
                             new String[]{LanguageManager.getString(this, R.string.toast_max_copy_5)}, null);
            return;
        }
        final LoadingDialog pd = new LoadingDialog(this, LanguageManager.getString(this, R.string.loading_copying));
        pd.show();
        new Thread(new Runnable() {
                @Override public void run() {
                    final List<String> paths = new ArrayList<>(selectedPaths);
                    int successCount = 0;
                    for (String path : paths) {
                        File f = new File(path);
                        if (!f.exists()) continue;
                        String baseName = f.getName();
                        if (baseName.endsWith(".png")) baseName = baseName.substring(0, baseName.length() - 4);
                        String newName = HistoryManager.generateUniqueFileName(MainActivity.this, baseName + " 副本");
                        if (HistoryManager.copyHistoryItem(MainActivity.this, f, newName)) successCount++;
                    }
                    final int finalSuccess = successCount;
                    runOnUiThread(new Runnable() {
                            @Override public void run() {
                                pd.dismiss();
                                Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_copy_success) + " " + finalSuccess, Toast.LENGTH_SHORT).show();
                                exitMultiSelectMode();
                            }
                        });
                }
            }).start();
    }

    private void deleteMultiSelected() {
        if (selectedPaths.isEmpty()) return;
        showCustomPrompt(LanguageManager.getString(this, R.string.dialog_batch_delete),
            LanguageManager.getString(this, R.string.dialog_batch_delete_msg, selectedPaths.size()), null, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    for (String path : selectedPaths) {
                        HistoryManager.deleteHistoryItem(MainActivity.this, new File(path));
                    }
                    thumbCache.evictAll();
                    Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_deleted), Toast.LENGTH_SHORT).show();
                    exitMultiSelectMode();
                }
            });
    }

    private void showAddDialog() {
        String[] options = {
            LanguageManager.getString(this, R.string.blank_canvas),
            LanguageManager.getString(this, R.string.import_image),
            LanguageManager.getString(this, R.string.import_wp),
            LanguageManager.getString(this, R.string.import_wpc)
        };
        showCustomDialog(LanguageManager.getString(this, R.string.new_project), options, new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if (which == 0) {
                        Intent intent = new Intent(MainActivity.this, activity2Main.class);
                        intent.putExtra("is_blank", true);
                        startActivity(intent);
                    } else if (which == 1) {
                        showImageImportOptions();
                    } else if (which == 2) {
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("*/*");
                        startActivityForResult(intent, IMPORT_WP_REQUEST);
                    } else if (which == 3) {
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("*/*");
                        startActivityForResult(intent, IMPORT_WPC_REQUEST);
                    }
                }
            });
    }

    private void showImageImportOptions() {
        String[] options = {
            LanguageManager.getString(this, R.string.dialog_from_album),
            LanguageManager.getString(this, R.string.dialog_from_file)
        };
        showCustomDialog(LanguageManager.getString(this, R.string.dialog_choose_source), options, new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if (which == 0) {
                        Intent pickIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        startActivityForResult(pickIntent, PICK_IMAGE_GALLERY);
                    } else if (which == 1) {
                        Intent pickIntent = new Intent(Intent.ACTION_GET_CONTENT);
                        pickIntent.setType("*/*");
                        startActivityForResult(pickIntent, PICK_IMAGE_FILE);
                    }
                }
            });
    }

    private void showFileOptions(final HistoryItem item) {
        String[] options = {
            LanguageManager.getString(this, R.string.history_version),
            LanguageManager.getString(this, R.string.copy),
            LanguageManager.getString(this, R.string.export_wp),
            LanguageManager.getString(this, R.string.export_wpc),
            LanguageManager.getString(this, R.string.rename),
            LanguageManager.getString(this, R.string.info_title),
            LanguageManager.getString(this, R.string.delete)
        };
        showCustomDialog(item.displayName, options, new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if (which == 0) {
                        Intent intent = new Intent(MainActivity.this, HistoryVersionsActivity.class);
                        intent.putExtra("image_path", item.file.getAbsolutePath());
                        startActivity(intent);
                    } else if (which == 1) {
                        if (HistoryManager.getAllHistory(MainActivity.this).size() >= 5) {
                            showCustomDialog(LanguageManager.getString(MainActivity.this, R.string.dialog_cannot_copy),
                                             new String[]{LanguageManager.getString(MainActivity.this, R.string.dialog_history_over_5)}, null);
                            return;
                        }
                        copyItem(item);
                    }
                    else if (which == 2) exportWpItem(item);
                    else if (which == 3) exportWpcItem(item);
                    else if (which == 4) showRenameDialog(item);
                    else if (which == 5) showImageInfoDialog(item);
                    else if (which == 6) showDeleteConfirmDialog(item);
                }
            });
    }

    private void showImageInfoDialog(HistoryItem item) {
        StringBuilder info = new StringBuilder();
        info.append(LanguageManager.getString(this, R.string.info_filename)).append(sep()).append(item.displayName).append("\n");
        info.append(LanguageManager.getString(this, R.string.info_size)).append(sep())
            .append(item.file.length() / 1024).append(" ").append(LanguageManager.getString(this, R.string.info_kb_unit)).append("\n");

        File stepsDir = HistoryManager.getStepsDir(this, item.file.getName());
        File infoFile = new File(stepsDir, "info.txt");

        if (infoFile.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(infoFile), "UTF-8"));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("=", 2);
                    if (parts.length == 2) {
                        if (parts[0].equals("model")) info.append(LanguageManager.getString(this, R.string.info_model)).append(sep()).append(parts[1]).append("\n");
                        if (parts[0].equals("width")) info.append(LanguageManager.getString(this, R.string.info_width)).append(sep()).append(parts[1]).append("\n");
                        if (parts[0].equals("height")) info.append(LanguageManager.getString(this, R.string.info_height)).append(sep()).append(parts[1]).append("\n");
                        if (parts[0].equals("aperature")) info.append(LanguageManager.getString(this, R.string.info_aperture)).append(sep()).append("F/").append(parts[1]).append("\n");
                        if (parts[0].equals("exposure")) info.append(LanguageManager.getString(this, R.string.info_exposure)).append(sep()).append(parts[1]).append(" s\n");
                        if (parts[0].equals("iso")) info.append(LanguageManager.getString(this, R.string.info_iso)).append(sep()).append(parts[1]).append("\n");
                        if (parts[0].equals("focal")) info.append(LanguageManager.getString(this, R.string.info_focal)).append(sep()).append(parts[1]).append(" mm\n");
                    }
                }
                reader.close();
            } catch (Throwable e) {}
        } else {
            info.append("\n").append(LanguageManager.getString(this, R.string.info_no_exif)).append("\n");
            info.append(LanguageManager.getString(this, R.string.info_no_exif_hint));
        }

        showCustomDialog(LanguageManager.getString(this, R.string.info_title), new String[]{info.toString()}, null);
    }

    private void copyItem(final HistoryItem item) {
        final String newName = HistoryManager.generateUniqueFileName(this, item.displayName + " 副本");
        final LoadingDialog pd = new LoadingDialog(this, LanguageManager.getString(this, R.string.loading_copying));
        pd.show();
        new Thread(new Runnable() {
                @Override public void run() {
                    final boolean success = HistoryManager.copyHistoryItem(MainActivity.this, item.file, newName);
                    runOnUiThread(new Runnable() {
                            @Override public void run() {
                                pd.dismiss();
                                if (success) { lastDataSignature = ""; Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_copy_success), Toast.LENGTH_SHORT).show(); refreshHistoryGrid(); }
                                else { Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_copy_fail), Toast.LENGTH_SHORT).show(); }
                            }
                        });
                }
            }).start();
    }

    private void exportWpItem(final HistoryItem item) {
        final LoadingDialog pd = new LoadingDialog(this, LanguageManager.getString(this, R.string.loading_packing_wp));
        pd.show();
        new Thread(new Runnable() {
                @Override public void run() {
                    pendingSaveFile = HistoryManager.createTempWp(MainActivity.this, item.file);
                    runOnUiThread(new Runnable() {
                            @Override public void run() {
                                pd.dismiss();
                                if (pendingSaveFile != null && pendingSaveFile.exists()) {
                                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                                    intent.setType("application/octet-stream");
                                    intent.putExtra(Intent.EXTRA_TITLE, item.displayName + ".wp");
                                    startActivityForResult(intent, SAVE_WP_REQUEST);
                                } else { Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_pack_fail), Toast.LENGTH_SHORT).show(); }
                            }
                        });
                }
            }).start();
    }

    private void exportWpcItem(final HistoryItem item) {
        final LoadingDialog pd = new LoadingDialog(this, LanguageManager.getString(this, R.string.loading_packing_wpc));
        pd.show();
        new Thread(new Runnable() {
                @Override public void run() {
                    pendingSaveFile = HistoryManager.createTempWpc(MainActivity.this, item.file);
                    runOnUiThread(new Runnable() {
                            @Override public void run() {
                                pd.dismiss();
                                if (pendingSaveFile != null && pendingSaveFile.exists()) {
                                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                                    intent.setType("application/octet-stream");
                                    intent.putExtra(Intent.EXTRA_TITLE, item.displayName + ".wpc");
                                    startActivityForResult(intent, SAVE_WPC_REQUEST);
                                } else {
                                    showCustomDialog(LanguageManager.getString(MainActivity.this, R.string.dialog_no_record),
                                                     new String[]{LanguageManager.getString(MainActivity.this, R.string.dialog_no_record_hint)}, null);
                                }
                            }
                        });
                }
            }).start();
    }

    private void showRenameDialog(final HistoryItem item) {
        final EditText et = new EditText(this);
        et.setText(item.displayName);
        et.setSingleLine(true);
        et.setTextColor(cachedTextColor);
        et.setBackgroundColor(ThemeManager.isDark(this) ? 0xFF333333 : 0xFFEEEEEE);

        showCustomPrompt(LanguageManager.getString(this, R.string.rename), null, et, new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    String newName = et.getText().toString().trim();
                    if (newName.isEmpty()) return;
                    if (HistoryManager.renameFile(MainActivity.this, item.file, newName)) {
                        thumbCache.evictAll();
                        lastDataSignature = "";
                        refreshHistoryGrid();
                    }
                    else Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_rename_fail), Toast.LENGTH_SHORT).show();
                }
            });
    }

    private void showDeleteConfirmDialog(final HistoryItem item) {
        showCustomPrompt(LanguageManager.getString(this, R.string.delete_confirm),
            LanguageManager.getString(this, R.string.sure_to_delete), null, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    HistoryManager.deleteHistoryItem(MainActivity.this, item.file);
                    thumbCache.evictAll();
                    lastDataSignature = "";
                    refreshHistoryGrid();
                }
            });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_GALLERY && resultCode == RESULT_OK && data != null) {
            Intent intent = new Intent(MainActivity.this, activity2Main.class);
            intent.putExtra("is_blank", false);
            intent.setData(data.getData());
            startActivity(intent);
        }
        else if (requestCode == PICK_IMAGE_FILE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            String fileName = HistoryManager.getFileNameFromUri(this, uri);
            String lowerName = fileName != null ? fileName.toLowerCase() : "";
            boolean isRaw = lowerName.endsWith(".dng") || lowerName.endsWith(".cr2") || lowerName.endsWith(".nef") || lowerName.endsWith(".arw") || lowerName.endsWith(".orf") || lowerName.endsWith(".raf");
            Intent intent = new Intent(MainActivity.this, activity2Main.class);
            intent.putExtra("is_blank", false);
            intent.putExtra("is_raw", isRaw);
            intent.setData(uri);
            startActivity(intent);
        }
        else if ((requestCode == SAVE_WP_REQUEST || requestCode == SAVE_WPC_REQUEST) && resultCode == RESULT_OK && data != null) {
            final Uri targetUri = data.getData();
            if (targetUri != null && pendingSaveFile != null) {
                final LoadingDialog pd = new LoadingDialog(this, LanguageManager.getString(this, R.string.loading_saving)); pd.show();
                new Thread(new Runnable() {
                        @Override public void run() {
                            boolean success = false;
                            try {
                                InputStream in = new FileInputStream(pendingSaveFile);
                                OutputStream out = getContentResolver().openOutputStream(targetUri);
                                if (out != null) { byte[] buf = new byte[8192]; int len; while ((len = in.read(buf)) > 0) out.write(buf, 0, len); out.close(); success = true; }
                                in.close();
                            } catch (Throwable e) {}
                            final boolean isSuccess = success;
                            runOnUiThread(new Runnable() {
                                    @Override public void run() {
                                        pd.dismiss();
                                        if (isSuccess) Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_export_success), Toast.LENGTH_SHORT).show();
                                        else Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_pack_fail), Toast.LENGTH_SHORT).show();
                                    }
                                });
                        }
                    }).start();
            }
        }
        else if (requestCode == IMPORT_WP_REQUEST && resultCode == RESULT_OK && data != null) {
            final Uri uri = data.getData(); if (uri == null) return;
            String fileName = HistoryManager.getFileNameFromUri(this, uri);
            if (fileName == null || !fileName.toLowerCase().endsWith(".wp")) { Toast.makeText(this, LanguageManager.getString(this, R.string.toast_select_wp), Toast.LENGTH_LONG).show(); return; }
            final LoadingDialog pd = new LoadingDialog(this, LanguageManager.getString(this, R.string.loading_unpacking_wp)); pd.show();
            new Thread(new Runnable() {
                    @Override public void run() {
                        final boolean ok = HistoryManager.importWp(MainActivity.this, uri, "导入工程");
                        runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    pd.dismiss();
                                    if (ok) { thumbCache.evictAll(); lastDataSignature = ""; Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_import_success), Toast.LENGTH_SHORT).show(); refreshHistoryGrid(); }
                                    else Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_import_fail), Toast.LENGTH_SHORT).show();
                                }
                            });
                    }
                }).start();
        }
        else if (requestCode == IMPORT_WPC_REQUEST && resultCode == RESULT_OK && data != null) {
            final Uri uri = data.getData(); if (uri == null) return;
            String fileName = HistoryManager.getFileNameFromUri(this, uri);
            if (fileName == null || !fileName.toLowerCase().endsWith(".wpc")) { Toast.makeText(this, LanguageManager.getString(this, R.string.toast_select_wpc), Toast.LENGTH_LONG).show(); return; }
            final LoadingDialog pd = new LoadingDialog(this, LanguageManager.getString(this, R.string.loading_unpacking_wpc)); pd.show();
            new Thread(new Runnable() {
                    @Override public void run() {
                        final boolean ok = HistoryManager.importWpc(MainActivity.this, uri, "导入存档");
                        runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    pd.dismiss();
                                    if (ok) { thumbCache.evictAll(); lastDataSignature = ""; Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_import_success), Toast.LENGTH_SHORT).show(); refreshHistoryGrid(); }
                                    else Toast.makeText(MainActivity.this, LanguageManager.getString(MainActivity.this, R.string.toast_import_fail), Toast.LENGTH_SHORT).show();
                                }
                            });
                    }
                }).start();
        }
    }
}
