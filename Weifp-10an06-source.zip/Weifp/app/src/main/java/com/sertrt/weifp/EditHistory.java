package com.sertrt.weifp;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import java.util.ArrayList;
import java.util.List;

public class EditHistory {

    public enum Type { MATRIX, FILTER, DRAW, RESIZE, OVERLAY, TEXT, ROTATE, FLIP_H, FLIP_V, DRAW_LAYER, ADD_LAYER, DELETE_LAYER, NOISE, MASKS }

    /**
     * 历史记录上限。
     *
     * 每条 DRAW_LAYER / ADD_LAYER 都持有一份完整的图层位图快照，
     * 一次 4000x3000 就是 48MB。不设上限的话，连续涂几十笔就会 OOM。
     */
    /**
     * 历史记录上限：按位图大小动态计算，而不是写死。
     *
     * 每笔画笔/图层操作都存一份完整图层快照：
     *   4000x3000 = 45.8 MB/笔，8000x6000 = 183 MB/笔。
     * 写死 30 条在 RAW 上就是 5.5 GB，必然 OOM。
     *
     * 策略：历史记录总占用控制在 ~800MB 以内，并夹在 [5, 30] 之间。
     *   （RAW 8000x6000 每笔 183MB，5 笔 = 915MB，已接近普通设备的极限）
     */
    private static final int MIN_HISTORY = 5;
    private static final int MAX_HISTORY_HARD = 30;
    private static final long HISTORY_BUDGET_BYTES = 800L * 1024 * 1024;

    /** 当前位图尺寸决定的安全上限（在 setImageSize 里更新）。 */
    private int maxHistory = MIN_HISTORY;

    /** 图片尺寸变化时调用，重算安全上限。 */
    public void setImageSize(int w, int h) {
        try {
            long oneShot = (long) w * h * 4;
            if (oneShot <= 0) { maxHistory = MIN_HISTORY; return; }
            int n = (int) (HISTORY_BUDGET_BYTES / oneShot);
            if (n < MIN_HISTORY) n = MIN_HISTORY;
            if (n > MAX_HISTORY_HARD) n = MAX_HISTORY_HARD;
            maxHistory = n;
            // 上限变小了，立刻裁到新上限
            while (history.size() > maxHistory) {
                releaseEntry(history.remove(0));
            }
        } catch (Throwable ignored) {
            maxHistory = MIN_HISTORY;
        }
    }

    /** 当前生效的历史上限（供 UI 显示）。 */
    public int getHistoryLimit() {
        return maxHistory;
    }

    public static class Entry {
        public Type type;
        public Matrix matrix;
        public float brightness, contrast, saturation;
        public float shadows, highlights, temperature, tint;
        public float sharpness;
        public Path path;
        public Paint paint;
        public Bitmap overlayBitmap;
        public int resizeW, resizeH;
        public int overlayX, overlayY;
        public String text;
        public float textX, textY, textSize;
        public int textColor;

        // DRAW_LAYER
        public Bitmap drawLayerSnapshot;

        // DRAW_LAYER / ADD_LAYER / DELETE_LAYER
        public int layerIndex;

        // ADD_LAYER / DELETE_LAYER
        public LayerManager.LayerItem layerSnapshot;

        // NOISE
        public float noiseColor;
        public float noiseLuma;

        // MASKS：蒙版列表快照（深浅拷贝，画笔数据也会被复制）
        public java.util.List<Mask.MaskItem> maskSnapshot;

        // FILTER 全量快照（Bug 11）
        public int[] lutM, lutR, lutG, lutB;
        public String[] curvePts;
        public float[] hslHue, hslSat, hslLum;
        public int[] lvBlack, lvGray, lvWhite;
        public float vibrance;
        public float splitShadowHue, splitShadowSat, splitHighlightHue, splitHighlightSat;
        public int splitBalance;
        public float cbShadowR, cbShadowG, cbShadowB;
        public float cbMidR, cbMidG, cbMidB;
        public float cbHighR, cbHighG, cbHighB;
        public CubeLut cubeLut;
        public float cubeStrength;
    }

    private static final int MAX_DRAW_LAYER_STEPS = 5;

    private List<Entry> history = new ArrayList<Entry>();
    private List<Entry> redoStack = new ArrayList<Entry>();

    private void clearRedo() {
        for (Entry e : redoStack) {
            if (e.type == Type.DRAW_LAYER && e.drawLayerSnapshot != null && !e.drawLayerSnapshot.isRecycled()) {
                e.drawLayerSnapshot.recycle();
            }
            if (e.layerSnapshot != null && e.layerSnapshot.bitmap != null && !e.layerSnapshot.bitmap.isRecycled()) {
                e.layerSnapshot.bitmap.recycle();
            }
        }
        redoStack.clear();
    }

    /** 入栈并裁剪：超出上限时丢掉最旧的一条（同时释放它持有的位图）。 */
    private void pushTrim(Entry e) {
        history.add(e);
        while (history.size() > maxHistory) {
            Entry old = history.remove(0);
            releaseEntry(old);
        }
        clearRedo();
    }

    /** 释放一条记录持有的位图。 */
    private static void releaseEntry(Entry e) {
        if (e == null) return;
        try {
            if (e.drawLayerSnapshot != null && !e.drawLayerSnapshot.isRecycled()) {
                e.drawLayerSnapshot.recycle();
            }
            if (e.layerSnapshot != null && e.layerSnapshot.bitmap != null
                    && !e.layerSnapshot.bitmap.isRecycled()) {
                e.layerSnapshot.bitmap.recycle();
            }
            if (e.overlayBitmap != null && !e.overlayBitmap.isRecycled()) {
                e.overlayBitmap.recycle();
            }
        } catch (Throwable ignored) {
        }
    }

    public void addMatrix(Matrix m) {
        Entry e = new Entry();
        e.type = Type.MATRIX;
        e.matrix = new Matrix(m);
        pushTrim(e);
    }

    /** 记录一次蒙版状态变化（撤销时整体恢复）。 */
    public void addMasks(java.util.List<Mask.MaskItem> snapshot) {
        Entry e = new Entry();
        e.type = Type.MASKS;
        e.maskSnapshot = new java.util.ArrayList<Mask.MaskItem>();
        if (snapshot != null) {
            for (Mask.MaskItem m : snapshot) {
                if (m != null) e.maskSnapshot.add(m.copy());
            }
        }
        pushTrim(e);
    }

    public void addRotate() {
        Entry e = new Entry();
        e.type = Type.ROTATE;
        pushTrim(e);
    }

    public void addFlipH() {
        Entry e = new Entry();
        e.type = Type.FLIP_H;
        pushTrim(e);
    }

    public void addFlipV() {
        Entry e = new Entry();
        e.type = Type.FLIP_V;
        pushTrim(e);
    }

    public void addFilter(float brightness, float contrast, float saturation,
                          float shadows, float highlights, float temperature,
                          float tint, float sharpness) {
        Entry e = new Entry();
        e.type = Type.FILTER;
        e.brightness = brightness;
        e.contrast = contrast;
        e.saturation = saturation;
        e.shadows = shadows;
        e.highlights = highlights;
        e.temperature = temperature;
        e.tint = tint;
        e.sharpness = sharpness;
        pushTrim(e);
    }

    public void addNoise(float colorV, float lumaV) {
        Entry e = new Entry();
        e.type = Type.NOISE;
        e.noiseColor = colorV;
        e.noiseLuma = lumaV;
        pushTrim(e);
    }

    public void addDraw(Path path, Paint paint) {
        Entry e = new Entry();
        e.type = Type.DRAW;
        e.path = new Path(path);
        e.paint = new Paint(paint);
        pushTrim(e);
    }

    public void addDrawLayer(int layerIndex, Bitmap beforeSnapshot) {
        if (beforeSnapshot == null) return;
        int count = 0;
        for (int i = 0; i < history.size(); i++) {
            if (history.get(i).type == Type.DRAW_LAYER) count++;
        }
        while (count >= MAX_DRAW_LAYER_STEPS) {
            int removed = -1;
            for (int i = 0; i < history.size(); i++) {
                if (history.get(i).type == Type.DRAW_LAYER) { removed = i; break; }
            }
            if (removed < 0) break;
            Entry old = history.remove(removed);
            if (old.drawLayerSnapshot != null && !old.drawLayerSnapshot.isRecycled()) old.drawLayerSnapshot.recycle();
            count--;
        }
        Entry e = new Entry();
        e.type = Type.DRAW_LAYER;
        e.layerIndex = layerIndex;
        e.drawLayerSnapshot = beforeSnapshot;
        pushTrim(e);
    }

    public void addAddLayer(LayerManager.LayerItem snapshot) {
        if (snapshot == null) return;
        Entry e = new Entry();
        e.type = Type.ADD_LAYER;
        e.layerSnapshot = snapshot;
        e.layerIndex = 0;
        pushTrim(e);
    }

    public void addDeleteLayer(LayerManager.LayerItem snapshot, int index) {
        if (snapshot == null) return;
        Entry e = new Entry();
        e.type = Type.DELETE_LAYER;
        e.layerSnapshot = snapshot;
        e.layerIndex = index;
        pushTrim(e);
    }

    public Entry peekLast() {
        if (history.isEmpty()) return null;
        return history.get(history.size() - 1);
    }

    public void undoDraw() {
        for (int i = history.size() - 1; i >= 0; i--) {
            if (history.get(i).type == Type.DRAW) {
                history.remove(i);
                clearRedo();
                break;
            }
        }
    }

    public void clearDraws() {
        for (int i = history.size() - 1; i >= 0; i--) {
            if (history.get(i).type == Type.DRAW) {
                history.remove(i);
            }
        }
        clearRedo();
    }

    public void addResize(int w, int h) {
        Entry e = new Entry();
        e.type = Type.RESIZE;
        e.resizeW = w;
        e.resizeH = h;
        pushTrim(e);
    }

    public void addOverlay(Bitmap overlay, int x, int y) {
        Entry e = new Entry();
        e.type = Type.OVERLAY;
        e.overlayBitmap = overlay;
        e.overlayX = x;
        e.overlayY = y;
        pushTrim(e);
    }

    public void addText(String text, float x, float y, float size, int color) {
        Entry e = new Entry();
        e.type = Type.TEXT;
        e.text = text;
        e.textX = x;
        e.textY = y;
        e.textSize = size;
        e.textColor = color;
        pushTrim(e);
    }

    public boolean undo() {
        if (history.isEmpty()) return false;
        redoStack.add(history.remove(history.size() - 1));
        return true;
    }

    public Entry undoAndReturn() {
        if (history.isEmpty()) return null;
        Entry e = history.remove(history.size() - 1);
        redoStack.add(e);
        return e;
    }

    public boolean redo() {
        if (redoStack.isEmpty()) return false;
        history.add(redoStack.remove(redoStack.size() - 1));
        return true;
    }

    public Entry redoAndReturn() {
        if (redoStack.isEmpty()) return null;
        Entry e = redoStack.remove(redoStack.size() - 1);
        history.add(e);
        // 重做回来也可能超出上限，同样裁剪
        while (history.size() > maxHistory) {
            releaseEntry(history.remove(0));
        }
        return e;
    }

    public void clear() {
        for (Entry e : history) {
            if (e.type == Type.DRAW_LAYER && e.drawLayerSnapshot != null && !e.drawLayerSnapshot.isRecycled()) {
                e.drawLayerSnapshot.recycle();
            }
            if (e.layerSnapshot != null && e.layerSnapshot.bitmap != null && !e.layerSnapshot.bitmap.isRecycled()) {
                e.layerSnapshot.bitmap.recycle();
            }
        }
        for (Entry e : redoStack) {
            if (e.type == Type.DRAW_LAYER && e.drawLayerSnapshot != null && !e.drawLayerSnapshot.isRecycled()) {
                e.drawLayerSnapshot.recycle();
            }
            if (e.layerSnapshot != null && e.layerSnapshot.bitmap != null && !e.layerSnapshot.bitmap.isRecycled()) {
                e.layerSnapshot.bitmap.recycle();
            }
        }
        history.clear();
        redoStack.clear();
    }

    public int size() { return history.size(); }

    public Entry getEntry(int i) { return history.get(i); }

    /**
     * 只回放几何变换（旋转/翻转/裁剪/叠加/文字），跳过画笔和图层操作。
     *
     * 保存时用它得到"底图基准"：画笔已经写进图层位图，不能再回放一次，
     * 否则会和图层叠加出双份；而旋转翻转只记在历史里，必须回放。
     */
    public Bitmap replayGeometryOnly(Bitmap original) {
        if (original == null) return null;
        // ★ 先看有没有几何操作：没有就直接返回原图，省掉一次整图复制
        //   （4000x3000 复制一次就是 48MB，保存慢的大头之一）
        boolean hasGeometry = false;
        for (Entry e : history) {
            if (e == null || e.type == null) continue;
            switch (e.type) {
                case ROTATE: case FLIP_H: case FLIP_V:
                case RESIZE: case OVERLAY: case TEXT:
                    hasGeometry = true;
                    break;
                default:
                    break;
            }
            if (hasGeometry) break;
        }
        if (!hasGeometry) return original;   // 调用方不要回收这个返回值

        Bitmap result = original.copy(Bitmap.Config.ARGB_8888, true);
        if (result == null) return null;
        for (Entry e : history) {
            if (e == null || e.type == null) continue;
            Bitmap out = null;
            switch (e.type) {
                case ROTATE: {
                    Matrix m = new Matrix();
                    m.postRotate(90, result.getWidth() / 2f, result.getHeight() / 2f);
                    out = Bitmap.createBitmap(result.getWidth(), result.getHeight(),
                            Bitmap.Config.ARGB_8888);
                    Canvas c = new Canvas(out);
                    c.drawBitmap(result, m, null);
                    break;
                }
                case FLIP_H: {
                    Matrix m = new Matrix();
                    m.postScale(-1, 1, result.getWidth() / 2f, result.getHeight() / 2f);
                    out = Bitmap.createBitmap(result.getWidth(), result.getHeight(),
                            Bitmap.Config.ARGB_8888);
                    Canvas c = new Canvas(out);
                    c.drawBitmap(result, m, null);
                    break;
                }
                case FLIP_V: {
                    Matrix m = new Matrix();
                    m.postScale(1, -1, result.getWidth() / 2f, result.getHeight() / 2f);
                    out = Bitmap.createBitmap(result.getWidth(), result.getHeight(),
                            Bitmap.Config.ARGB_8888);
                    Canvas c = new Canvas(out);
                    c.drawBitmap(result, m, null);
                    break;
                }
                case RESIZE: {
                    Bitmap scaled = Bitmap.createScaledBitmap(result,
                            Math.max(1, e.resizeW), Math.max(1, e.resizeH), true);
                    if (scaled != result) out = scaled;
                    break;
                }
                case OVERLAY: {
                    out = Bitmap.createBitmap(result.getWidth(), result.getHeight(),
                            Bitmap.Config.ARGB_8888);
                    Canvas c = new Canvas(out);
                    c.drawBitmap(result, 0, 0, null);
                    if (e.overlayBitmap != null) {
                        c.drawBitmap(e.overlayBitmap, e.overlayX, e.overlayY, null);
                    }
                    break;
                }
                case TEXT: {
                    out = Bitmap.createBitmap(result.getWidth(), result.getHeight(),
                            Bitmap.Config.ARGB_8888);
                    Canvas c = new Canvas(out);
                    c.drawBitmap(result, 0, 0, null);
                    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                    p.setColor(e.textColor);
                    p.setTextSize(e.textSize);
                    if (e.text != null) c.drawText(e.text, e.textX, e.textY, p);
                    break;
                }
                default:
                    continue;   // 画笔/图层/滤镜等不需要在底图上回放
            }
            if (out != null && out != result) {
                result.recycle();
                result = out;
            }
        }
        return result;
    }

    /**
     * 回放到某一步时应恢复的蒙版状态（由回放过程填上）。
     * 调用方在 replay() 之后读取它来同步蒙版列表。
     */
    public java.util.List<Mask.MaskItem> lastReplayedMasks = null;
    /** 是否在回放中遇到了 MASKS 记录。 */
    public boolean sawMaskEntry = false;

    public Bitmap replay(Bitmap original) {
        if (original == null) return null;
        Bitmap result = original.copy(Bitmap.Config.ARGB_8888, true);

        lastReplayedMasks = null;
        sawMaskEntry = false;
        for (Entry e : history) {
            // 蒙版记录不参与像素运算，只用来同步蒙版列表状态
            if (e.type == Type.MASKS) {
                sawMaskEntry = true;
                lastReplayedMasks = new java.util.ArrayList<Mask.MaskItem>();
                if (e.maskSnapshot != null) {
                    for (Mask.MaskItem m : e.maskSnapshot) {
                        if (m != null) lastReplayedMasks.add(m.copy());
                    }
                }
                continue;
            }
            switch (e.type) {
                case MATRIX: {
                        Bitmap out = Bitmap.createBitmap(result.getWidth(), result.getHeight(), Bitmap.Config.ARGB_8888);
                        Canvas c = new Canvas(out);
                        c.drawBitmap(result, e.matrix, null);
                        if (result != out) result.recycle();
                        result = out;
                        break;
                    }
                case ROTATE: {
                        Matrix m = new Matrix();
                        m.postRotate(90, result.getWidth() / 2f, result.getHeight() / 2f);
                        Bitmap out = Bitmap.createBitmap(result.getWidth(), result.getHeight(), Bitmap.Config.ARGB_8888);
                        Canvas c = new Canvas(out);
                        c.drawBitmap(result, m, null);
                        if (result != out) result.recycle();
                        result = out;
                        break;
                    }
                case FLIP_H: {
                        Matrix m = new Matrix();
                        m.postScale(-1, 1, result.getWidth() / 2f, result.getHeight() / 2f);
                        Bitmap out = Bitmap.createBitmap(result.getWidth(), result.getHeight(), Bitmap.Config.ARGB_8888);
                        Canvas c = new Canvas(out);
                        c.drawBitmap(result, m, null);
                        if (result != out) result.recycle();
                        result = out;
                        break;
                    }
                case FLIP_V: {
                        Matrix m = new Matrix();
                        m.postScale(1, -1, result.getWidth() / 2f, result.getHeight() / 2f);
                        Bitmap out = Bitmap.createBitmap(result.getWidth(), result.getHeight(), Bitmap.Config.ARGB_8888);
                        Canvas c = new Canvas(out);
                        c.drawBitmap(result, m, null);
                        if (result != out) result.recycle();
                        result = out;
                        break;
                    }
                case FILTER: {
                        Bitmap out = Bitmap.createBitmap(result.getWidth(), result.getHeight(), Bitmap.Config.ARGB_8888);
                        Canvas c = new Canvas(out);
                        Paint p = new Paint();
                        p.setColorFilter(new ColorMatrixColorFilter(buildFilterMatrix(e)));
                        c.drawBitmap(result, 0, 0, p);
                        if (result != out) result.recycle();
                        result = out;

                        if (e.sharpness > 0) {
                            Bitmap sharp = applySharpness(result, e.sharpness);
                            if (result != sharp) result.recycle();
                            result = sharp;
                        }
                        break;
                    }
                case DRAW: {
                        Bitmap out = Bitmap.createBitmap(result.getWidth(), result.getHeight(), Bitmap.Config.ARGB_8888);
                        Canvas c = new Canvas(out);
                        c.drawBitmap(result, 0, 0, null);
                        c.drawPath(e.path, e.paint);
                        if (result != out) result.recycle();
                        result = out;
                        break;
                    }
                case RESIZE: {
                        Bitmap out = Bitmap.createScaledBitmap(result, e.resizeW, e.resizeH, true);
                        if (result != out) result.recycle();
                        result = out;
                        break;
                    }
                case OVERLAY: {
                        Bitmap out = Bitmap.createBitmap(result.getWidth(), result.getHeight(), Bitmap.Config.ARGB_8888);
                        Canvas c = new Canvas(out);
                        c.drawBitmap(result, 0, 0, null);
                        if (e.overlayBitmap != null) {
                            c.drawBitmap(e.overlayBitmap, e.overlayX, e.overlayY, null);
                        }
                        if (result != out) result.recycle();
                        result = out;
                        break;
                    }
                case TEXT: {
                        Bitmap out = Bitmap.createBitmap(result.getWidth(), result.getHeight(), Bitmap.Config.ARGB_8888);
                        Canvas c = new Canvas(out);
                        c.drawBitmap(result, 0, 0, null);
                        Paint p = new Paint();
                        p.setColor(e.textColor);
                        p.setTextSize(e.textSize);
                        p.setAntiAlias(true);
                        c.drawText(e.text, e.textX, e.textY, p);
                        if (result != out) result.recycle();
                        result = out;
                        break;
                    }
                case DRAW_LAYER:
                case ADD_LAYER:
                case DELETE_LAYER:
                case NOISE:
                default:
                    break;
            }
        }
        return result;
    }

    /** 锐化用的复用缓冲。 */
    private static int[] sSharpIn = null;
    private static int[] sSharpOut = null;

    private Bitmap applySharpness(Bitmap src, float amount) {
        int w = src.getWidth();
        int h = src.getHeight();
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);

        // 复用缓冲：锐化可能要连续跑多次（每调一下滑轨一次），
        // 每次都 new 两个 w*h 数组会造成频繁 GC。
        if (sSharpIn == null || sSharpIn.length != w * h) {
            sSharpIn = new int[w * h];
            sSharpOut = new int[w * h];
        }
        int[] pixels = sSharpIn;
        int[] outPixels = sSharpOut;
        src.getPixels(pixels, 0, w, 0, 0, w, h);

        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int idx = y * w + x;
                int c = pixels[idx];
                int left = pixels[idx - 1];
                int right = pixels[idx + 1];
                int top = pixels[idx - w];
                int bottom = pixels[idx + w];

                int a = (c >> 24) & 0xff;
                int r = (c >> 16) & 0xff;
                int g = (c >> 8) & 0xff;
                int b = c & 0xff;

                int lr = (left >> 16) & 0xff, lg = (left >> 8) & 0xff, lb = left & 0xff;
                int rr = (right >> 16) & 0xff, rg = (right >> 8) & 0xff, rb = right & 0xff;
                int tr = (top >> 16) & 0xff, tg = (top >> 8) & 0xff, tb = top & 0xff;
                int br = (bottom >> 16) & 0xff, bg = (bottom >> 8) & 0xff, bb = bottom & 0xff;

                float k = amount * 0.5f;
                int nr = (int) (r + k * (4 * r - lr - rr - tr - br));
                int ng = (int) (g + k * (4 * g - lg - rg - tg - bg));
                int nb = (int) (b + k * (4 * b - lb - rb - tb - bb));

                outPixels[idx] = (a << 24) | (clamp(nr) << 16) | (clamp(ng) << 8) | clamp(nb);
            }
        }

        for (int x = 0; x < w; x++) {
            outPixels[x] = pixels[x];
            outPixels[(h - 1) * w + x] = pixels[(h - 1) * w + x];
        }
        for (int y = 0; y < h; y++) {
            outPixels[y * w] = pixels[y * w];
            outPixels[y * w + (w - 1)] = pixels[y * w + (w - 1)];
        }

        out.setPixels(outPixels, 0, w, 0, 0, w, h);
        return out;
    }

    private int clamp(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    private ColorMatrix buildFilterMatrix(Entry e) {
        ColorMatrix cm = new ColorMatrix();
        float[] bm = {1, 0, 0, 0, e.brightness, 0, 1, 0, 0, e.brightness, 0, 0, 1, 0, e.brightness, 0, 0, 0, 1, 0};
        cm.postConcat(new ColorMatrix(bm));
        float t = (1 - e.contrast) * 128;
        float[] cmx = {e.contrast, 0, 0, 0, t, 0, e.contrast, 0, 0, t, 0, 0, e.contrast, 0, t, 0, 0, 0, 1, 0};
        cm.postConcat(new ColorMatrix(cmx));
        float sr = (1 - e.saturation) * 0.3086f;
        float sg = (1 - e.saturation) * 0.6094f;
        float sb = (1 - e.saturation) * 0.0820f;
        float[] sm = {sr + e.saturation, sg, sb, 0, 0, sr, sg + e.saturation, sb, 0, 0, sr, sg, sb + e.saturation, 0, 0, 0, 0, 0, 1, 0};
        cm.postConcat(new ColorMatrix(sm));
        float so = e.shadows * 0.5f;
        float[] shm = {1, 0, 0, 0, so, 0, 1, 0, 0, so, 0, 0, 1, 0, so, 0, 0, 0, 1, 0};
        cm.postConcat(new ColorMatrix(shm));
        float ho = e.highlights * 0.5f;
        float[] hm = {1, 0, 0, 0, ho, 0, 1, 0, 0, ho, 0, 0, 1, 0, ho, 0, 0, 0, 1, 0};
        cm.postConcat(new ColorMatrix(hm));
        float tR = e.temperature * 0.5f, tB = -e.temperature * 0.5f;
        float[] tm = {1, 0, 0, 0, tR, 0, 1, 0, 0, 0, 0, 0, 1, 0, tB, 0, 0, 0, 1, 0};
        cm.postConcat(new ColorMatrix(tm));
        float tG = -e.tint * 0.5f, tM = e.tint * 0.5f;
        float[] tim = {1, 0, 0, 0, tM, 0, 1, 0, 0, tG, 0, 0, 1, 0, tM, 0, 0, 0, 1, 0};
        cm.postConcat(new ColorMatrix(tim));
        return cm;
    }
}
