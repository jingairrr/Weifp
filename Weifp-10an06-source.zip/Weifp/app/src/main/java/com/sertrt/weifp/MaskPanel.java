package com.sertrt.weifp;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 局部蒙版面板：径向 / 画笔 / 颜色三种区域，带 5 个调整参数。
 *
 * 交互设计：
 *  - 顶部：三个按钮切换蒙版类型（新建）
 *  - 中部：当前蒙版的参数滑轨（曝光/对比度/饱和度/色温/清晰度）
 *  - 形状参数：径向有位置/大小/旋转/羽化；画笔有笔刷大小/擦除；颜色有取色/容差
 *  - 底部：反相、删除、完成
 *
 * 蒙版直接作用于 ZoomImageView 的 masks 列表，实时预览。
 */
public final class MaskPanel {

    /** 回调：蒙版变化后刷新统计等。 */
    public interface Callback {
        void onMaskChanged();
    }

    private MaskPanel() {
    }

    /** 在给定容器里构建蒙版面板。 */
    public static void build(final Activity act, final ZoomImageView zoom,
                             final LinearLayout container, final Callback cb) {
        if (act == null || zoom == null || container == null) return;
        final float d = act.getResources().getDisplayMetrics().density;
        final int textColor = ThemeManager.getTextColor(act);
        final int buttonColor = ThemeManager.getButtonColor(act);
        container.removeAllViews();
        // 复位"调参时临时隐藏"，保证提示正常显示
        try { zoom.setMaskIndicatorHideTemporarily(false); } catch (Throwable ignored) {}
        // 打开蒙版面板时显示范围提示色
        // 进入面板时记一份快照，作为本次编辑的撤销基点
        if (!sSessionStarted) {
            sSessionBefore = zoom.snapshotMasks();
            sSessionStarted = true;
        }
        int maskCount = zoom.getMasks().size();
        if (sSelectedIndex < 0 || sSelectedIndex >= maskCount) {
            sSelectedIndex = maskCount - 1;
        }
        int editingIdx = maskCount == 0 ? -1 : sSelectedIndex;
        sEditingIndex = editingIdx;
        try {
            zoom.setMaskIndicatorLocked(true);   // 面板打开期间锁定提示
            zoom.setMaskIndicatorVisible(true, editingIdx);
        } catch (Throwable ignored) {}

        // ---------- 类型选择 ----------
        LinearLayout typeRow = new LinearLayout(act);
        typeRow.setOrientation(LinearLayout.HORIZONTAL);
        typeRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvLabel = new TextView(act);
        tvLabel.setText(LanguageManager.getString(act, R.string.mask_type_label));
        tvLabel.setTextColor(textColor);
        tvLabel.setTextSize(13);
        tvLabel.setPadding(0, 0, UiSpec.dpi(act, 8), 0);
        typeRow.addView(tvLabel);

        final String[] typeNames = {
            LanguageManager.getString(act, R.string.mask_radial),
            LanguageManager.getString(act, R.string.mask_brush),
            LanguageManager.getString(act, R.string.mask_color),
        };
        final int[] types = {Mask.TYPE_RADIAL, Mask.TYPE_BRUSH, Mask.TYPE_COLOR};
        for (int i = 0; i < types.length; i++) {
            final int type = types[i];
            Button b = new Button(act);
            b.setText(typeNames[i]);
            b.setTextSize(13);
            b.setAllCaps(false);
            b.setStateListAnimator(null);
            b.setTextColor(textColor);
            b.setBackground(UiSpec.pressable(act, buttonColor, UiSpec.RADIUS_S));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(UiSpec.dpi(act, 3), 0, UiSpec.dpi(act, 3), 0);
            b.setLayoutParams(lp);
            b.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        // 只退出上一轮的手势模式；蒙版效果本身、以及其它蒙版都要保留
                        try { zoom.setMaskDragMode(false, -1); } catch (Throwable ignored) {}
                        try { zoom.setMaskBrushMode(false, -1, 0, 0, false); } catch (Throwable ignored) {}
                        createMask(act, zoom, type, cb);
                        build(act, zoom, container, cb);   // 重建面板
                    }
                });
            typeRow.addView(b);
        }
        container.addView(typeRow);

        // ---------- 当前蒙版列表 ----------
        java.util.List<Mask.MaskItem> masks = zoom.getMasks();
        final TextView tvCount = new TextView(act);
        tvCount.setText(LanguageManager.getString(act, R.string.mask_count)
                + " " + masks.size());
        tvCount.setTextColor(0xFF9E9E9E);
        tvCount.setTextSize(12);
        tvCount.setPadding(0, UiSpec.dpi(act, 6), 0, UiSpec.dpi(act, 4));
        container.addView(tvCount);

        // 蒙版列表：始终显示，点编号切换编辑
        if (masks.size() >= 1) {
            LinearLayout numRow = new LinearLayout(act);
            numRow.setOrientation(LinearLayout.HORIZONTAL);
            numRow.setPadding(0, UiSpec.dpi(act, 2), 0, UiSpec.dpi(act, 6));
            for (int i = 0; i < masks.size(); i++) {
                final int idx = i;
                final boolean sel = (i == sSelectedIndex);
                Button nb = new Button(act);
                String tn = masks.get(i).type == Mask.TYPE_RADIAL ? "○"
                        : (masks.get(i).type == Mask.TYPE_BRUSH ? "✎" : "◐");
                nb.setText((i + 1) + " " + tn);
                nb.setTextSize(12);
                nb.setAllCaps(false);
                nb.setStateListAnimator(null);
                nb.setTextColor(sel ? Color.BLACK : textColor);
                nb.setBackground(UiSpec.pressable(act,
                        sel ? UiSpec.ACCENT : buttonColor, UiSpec.RADIUS_S));
                LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                nlp.setMargins(0, 0, UiSpec.dpi(act, 4), 0);
                nb.setLayoutParams(nlp);
                nb.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            sSelectedIndex = idx;
                            build(act, zoom, container, cb);
                        }
                    });
                numRow.addView(nb);
            }
            container.addView(numRow);
        }

        if (masks.isEmpty()) {
            TextView tvEmpty = new TextView(act);
            tvEmpty.setText(LanguageManager.getString(act, R.string.mask_empty_hint2));
            tvEmpty.setTextColor(0xFF9E9E9E);
            tvEmpty.setTextSize(12);
            tvEmpty.setPadding(0, UiSpec.dpi(act, 8), 0, UiSpec.dpi(act, 8));
            container.addView(tvEmpty);
            return;
        }

        // 当前编辑的蒙版：默认最后一个，可通过上面的编号条切换
        if (sSelectedIndex < 0 || sSelectedIndex >= masks.size()) {
            sSelectedIndex = masks.size() - 1;
        }
        final Mask.MaskItem cur = masks.get(sSelectedIndex);
        final int curIndex = sSelectedIndex;

        // ---------- 调整参数（5 个滑轨） ----------
        addSlider(act, container, zoom, R.string.mask_exposure, -100, 100,
                (int) cur.exposure, textColor, new SliderCb() {
                    @Override public void onVal(int v) { cur.exposure = v; refresh(zoom, cb); }
                });
        addSlider(act, container, zoom, R.string.mask_contrast, -100, 100,
                (int) cur.contrast, textColor, new SliderCb() {
                    @Override public void onVal(int v) { cur.contrast = v; refresh(zoom, cb); }
                });
        addSlider(act, container, zoom, R.string.mask_saturation, -100, 100,
                (int) cur.saturation, textColor, new SliderCb() {
                    @Override public void onVal(int v) { cur.saturation = v; refresh(zoom, cb); }
                });
        addSlider(act, container, zoom, R.string.mask_temperature, -100, 100,
                (int) cur.temperature, textColor, new SliderCb() {
                    @Override public void onVal(int v) { cur.temperature = v; refresh(zoom, cb); }
                });
        addSlider(act, container, zoom, R.string.mask_clarity, -100, 100,
                (int) cur.clarity, textColor, new SliderCb() {
                    @Override public void onVal(int v) { cur.clarity = v; refresh(zoom, cb); }
                });

        // ---------- 形状参数 ----------
        if (cur.type == Mask.TYPE_RADIAL) {
            // 进入拖动模式：单指移动中心，双指缩放
            try { zoom.setMaskDragMode(true, curIndex); } catch (Throwable ignored) {}
            TextView tvDragHint = new TextView(act);
            tvDragHint.setText(LanguageManager.getString(act, R.string.mask_radial_hint2));
            tvDragHint.setTextColor(0xFF9E9E9E);
            tvDragHint.setTextSize(11);
            tvDragHint.setPadding(0, UiSpec.dpi(act, 4), 0, UiSpec.dpi(act, 4));
            container.addView(tvDragHint);
            // 横向/纵向大小不再用滑轨：直接拖动椭圆上的四个白色控制点
            addSlider(act, container, zoom, R.string.mask_rotation, 0, 360,
                    Math.round(cur.rotation), textColor, new SliderCb() {
                        @Override public void onVal(int v) { cur.rotation = v; refresh(zoom, cb); }
                    });
        } else if (cur.type == Mask.TYPE_BRUSH) {
            addSlider(act, container, zoom, R.string.mask_brush_strength, 10, 100,
                    cur.brushStrength, textColor, new SliderCb() {
                        @Override public void onVal(int v) {
                            cur.brushStrength = v;
                            zoom.setMaskBrushMode(true, curIndex, 40f, v, false);
                            refresh(zoom, cb);
                        }
                    });
            // 进入画笔模式：单指涂抹
            try { zoom.setMaskBrushMode(true, curIndex, 40f, cur.brushStrength, false); }
            catch (Throwable ignored) {}
            TextView tvHint = new TextView(act);
            tvHint.setText(LanguageManager.getString(act, R.string.mask_brush_hint));
            tvHint.setTextColor(0xFF9E9E9E);
            tvHint.setTextSize(11);
            tvHint.setPadding(0, UiSpec.dpi(act, 4), 0, UiSpec.dpi(act, 4));
            container.addView(tvHint);
        } else if (cur.type == Mask.TYPE_COLOR) {
            addSlider(act, container, zoom, R.string.mask_color_tolerance, 5, 100,
                    cur.colorTolerance, textColor, new SliderCb() {
                        @Override public void onVal(int v) { cur.colorTolerance = v; refresh(zoom, cb); }
                    });
            TextView tvHint = new TextView(act);
            tvHint.setText(LanguageManager.getString(act, R.string.mask_color_hint));
            tvHint.setTextColor(0xFF9E9E9E);
            tvHint.setTextSize(11);
            tvHint.setPadding(0, UiSpec.dpi(act, 4), 0, UiSpec.dpi(act, 4));
            container.addView(tvHint);
        }

        if (cur.type != Mask.TYPE_BRUSH) {
            try { zoom.setMaskBrushMode(false, -1, 0, 0, false); } catch (Throwable ignored) {}
        }

        // 羽化（径向和颜色都有）
        if (cur.type != Mask.TYPE_BRUSH) {
            addSlider(act, container, zoom, R.string.mask_feather, 0, 100,
                    cur.feather, textColor, new SliderCb() {
                        @Override public void onVal(int v) { cur.feather = v; refresh(zoom, cb); }
                    });
        }

        // 发散值：光的柔和程度（对所有类型都有效）
        addSlider(act, container, zoom, R.string.mask_spread, 0, 100,
                cur.spread, textColor, new SliderCb() {
                    @Override public void onVal(int v) { cur.spread = v; refresh(zoom, cb); }
                });

        // ---------- 底部操作 ----------
        LinearLayout btnRow = new LinearLayout(act);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, UiSpec.dpi(act, 8), 0, 0);

        Button btnInvert = new Button(act);
        btnInvert.setText(LanguageManager.getString(act,
                cur.invert ? R.string.mask_inverted : R.string.mask_invert));
        btnInvert.setTextSize(12);
        btnInvert.setAllCaps(false);
        btnInvert.setStateListAnimator(null);
        btnInvert.setTextColor(cur.invert ? Color.BLACK : textColor);
        btnInvert.setBackground(UiSpec.pressable(act,
                cur.invert ? UiSpec.ACCENT : buttonColor, UiSpec.RADIUS_S));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        blp.setMargins(0, 0, UiSpec.dpi(act, 4), 0);
        btnInvert.setLayoutParams(blp);
        btnInvert.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    cur.invert = !cur.invert;
                    refresh(zoom, cb);
                    build(act, zoom, container, cb);
                }
            });
        btnRow.addView(btnInvert);

        Button btnDelete = new Button(act);
        btnDelete.setText(LanguageManager.getString(act, R.string.mask_delete_item));
        btnDelete.setTextSize(12);
        btnDelete.setAllCaps(false);
        btnDelete.setStateListAnimator(null);
        btnDelete.setTextColor(Color.WHITE);
        btnDelete.setBackground(UiSpec.pressable(act, UiSpec.DANGER, UiSpec.RADIUS_S));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        dlp.setMargins(UiSpec.dpi(act, 4), 0, 0, 0);
        btnDelete.setLayoutParams(dlp);
        btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    zoom.removeMask(curIndex);
                    sSelectedIndex = Math.min(curIndex, zoom.getMasks().size() - 1);
                    refresh(zoom, cb);
                    build(act, zoom, container, cb);
                }
            });
        btnRow.addView(btnDelete);

        container.addView(btnRow);
    }

    // ==================== 创建蒙版 ====================

    /** 新建一个指定类型的蒙版（带合理默认值）。 */
    public static void createMask(Activity act, ZoomImageView zoom, int type, Callback cb) {
        Mask.MaskItem m = new Mask.MaskItem();
        m.type = type;
        m.exposure = 20;   // 默认轻微提亮，让用户立刻看到范围

        if (type == Mask.TYPE_BRUSH) {
            int w = zoom.getDrawable() != null
                    ? zoom.getDrawable().getIntrinsicWidth() : 0;
            int h = zoom.getDrawable() != null
                    ? zoom.getDrawable().getIntrinsicHeight() : 0;
            if (w > 0 && h > 0) {
                m.brushAlpha = new byte[w * h];
                m.brushW = w;
                m.brushH = h;
            }
        } else if (type == Mask.TYPE_COLOR) {
            // 默认取画面中央的颜色
            Bitmap owned = null;   // 只有自己创建的副本才能回收
            try {
                Bitmap cur = zoom.getCurrentLayerBitmap();
                if (cur == null || cur.isRecycled()) {
                    cur = zoom.getOriginalBitmapCopy();
                    owned = cur;   // 这个是副本，可以回收
                }
                if (cur != null && !cur.isRecycled()) {
                    int cw = cur.getWidth(), ch = cur.getHeight();
                    int px = cur.getPixel(cw / 2, ch / 2);
                    m.keyColor = 0xFF000000 | (px & 0xFFFFFF);
                }
            } catch (Throwable ignored) {
            } finally {
                // ★ 绝对不能回收 getCurrentLayerBitmap() 返回的位图（那是用户的图层本体）
                if (owned != null && !owned.isRecycled()) owned.recycle();
            }
        }

        zoom.addMask(m);
        sSelectedIndex = zoom.getMasks().size() - 1;   // 新建后自动选中
        refresh(zoom, cb);
    }

    /** 触发重绘并回调。 */
    /** 当前正在编辑的蒙版索引（refresh 时用来保持提示可见）。 */
    static int sEditingIndex = -1;
    /** 用户在编号条里选中的蒙版。 */
    static int sSelectedIndex = -1;

    /** 本次编辑会话的撤销基点。 */
    static java.util.List<Mask.MaskItem> sSessionBefore = null;
    static boolean sSessionStarted = false;

    /**
     * 蒙版自动落盘：即使没点保存，退出重进也能恢复。
     *
     * ★ 必须和 loadFilterParams 用同一个 key（xxx_masks）和同一种格式
     *   （Mask.serialize），否则存进去也读不出来。
     */
    private static android.os.Handler sAutoSaveHandler = null;
    private static Runnable sAutoSaveTask = null;

    /** 防抖后的自动保存：600ms 内多次改动只写一次盘。 */
    static void autoSaveMasksDebounced(final ZoomImageView zoom) {
        if (zoom == null) return;
        if (sAutoSaveHandler == null) {
            sAutoSaveHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        }
        if (sAutoSaveTask != null) sAutoSaveHandler.removeCallbacks(sAutoSaveTask);
        sAutoSaveTask = new Runnable() {
            @Override public void run() {
                autoSaveMasksDebounced(zoom);
            }
        };
        sAutoSaveHandler.postDelayed(sAutoSaveTask, 600);
    }

    static void autoSaveMasks(ZoomImageView zoom) {
        try {
            String key = sOwnerPath;
            if (key == null || key.length() == 0) return;
            android.content.Context ctx = zoom.getContext();
            if (ctx == null) return;
            java.io.File stepsDir = null;
            try {
                stepsDir = HistoryManager.getStepsDir(ctx, new java.io.File(key).getName());
            } catch (Throwable ignored) {
            }
            String data = Mask.serialize(zoom.getMasks(), stepsDir);
            android.content.SharedPreferences sp =
                    ctx.getSharedPreferences("weifp_filters", android.content.Context.MODE_PRIVATE);
            android.content.SharedPreferences.Editor e = sp.edit();
            if (data != null && data.length() > 0) {
                e.putString(key + "_masks", data);
            } else {
                e.remove(key + "_masks");
            }
            e.commit();
        } catch (Throwable ignored) {
        }
    }

    /** 当前编辑的图片路径（由 activity2Main 设置，用于自动落盘的 key）。 */
    static String sOwnerPath = null;

    public static void setOwnerPath(String path) {
        sOwnerPath = path;
    }

    /** 结束编辑会话：把整段修改记成一笔可撤销的历史。 */
    public static void commitSession(ZoomImageView zoom) {
        if (zoom != null && sSessionStarted && sSessionBefore != null) {
            zoom.commitMaskChange(sSessionBefore);
        }
        sSessionStarted = false;
        sSessionBefore = null;
    }

    /** 重置选中状态（打开面板/换图时调用）。 */
    public static void resetSelection() {
        sSelectedIndex = -1;
    }

    static void refresh(ZoomImageView zoom, Callback cb) {
        try {
            autoSaveMasksDebounced(zoom);
            zoom.invalidateMaskCache();
            // 调数值时隐藏提示圈/画笔线（效果照常实时变化）
            zoom.setMaskIndicatorHideTemporarily(true);
            zoom.invalidate();
        } catch (Throwable ignored) {
        }
        if (cb != null) {
            try {
                cb.onMaskChanged();
            } catch (Throwable ignored) {
            }
        }
    }

    // ==================== 滑轨辅助 ====================

    interface SliderCb {
        void onVal(int v);
    }

    private static void addSlider(Activity act, LinearLayout root, final ZoomImageView zoomRef,
                                  int labelRes, final int min, int max, int init, int textColor,
                                  final SliderCb cb) {
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, UiSpec.dpi(act, 2), 0, UiSpec.dpi(act, 2));

        TextView tv = new TextView(act);
        tv.setText(LanguageManager.getString(act, labelRes));
        tv.setTextColor(textColor);
        tv.setTextSize(12);
        tv.setLayoutParams(new LinearLayout.LayoutParams(UiSpec.dpi(act, 68),
                LinearLayout.LayoutParams.WRAP_CONTENT));
        row.addView(tv);

        final SeekBar sb = new SeekBar(act);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(max - min, init - min)));
        try {
            sb.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFFFB615));
            sb.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFFFB615));
        } catch (Throwable ignored) {
        }
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        sb.setLayoutParams(slp);
        row.addView(sb);

        final TextView val = new TextView(act);
        val.setText(String.valueOf(init));
        val.setTextColor(0xFFFFB615);
        val.setTextSize(12);
        val.setGravity(Gravity.CENTER);
        val.setLayoutParams(new LinearLayout.LayoutParams(UiSpec.dpi(act, 40),
                LinearLayout.LayoutParams.WRAP_CONTENT));
        row.addView(val);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                    int v = p + min;
                    val.setText(String.valueOf(v));
                    if (fromUser) cb.onVal(v);
                }
                @Override public void onStartTrackingTouch(SeekBar s) {
                    // 开始调数值：隐藏提示圈/画笔线，专心看效果
                    try { zoomRef.setMaskIndicatorHideTemporarily(true); }
                    catch (Throwable ignored) {}
                }
                @Override public void onStopTrackingTouch(SeekBar s) {
                    // 松手：恢复提示显示，并重算一次完整效果
                    try {
                        zoomRef.invalidateMaskCache();
                        zoomRef.setMaskIndicatorHideTemporarily(false);
                    } catch (Throwable ignored) {}
                }
            });

        root.addView(row);
    }
}
