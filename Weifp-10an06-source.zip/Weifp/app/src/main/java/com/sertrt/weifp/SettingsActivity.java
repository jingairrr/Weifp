package com.sertrt.weifp;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private TextView btnRefined;
    private TextView btnCrashLog;
    private TextView btnCheckUpdate;
    private TextView btnHighPerf;


    private LinearLayout rootLayout;
    private TextView btnDark, btnLight, btnAuto, btnHistogram;
    private TextView btnStepPerAction, btnStepOnExit, btnWpbToggle;
    private TextView btnLanguage, btnClearCache;

    private int classicClickCount = 0;
    private long lastClassicClickTime = 0;
    private float density;

    private Handler langClickHandler = new Handler();
    private Runnable langCloseRunnable = null;
    private static final long LANG_CLOSE_DELAY = 300;
    private static final long CLASSIC_COUNT_RESET_MS = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 同步"精致界面"开关到 UiSpec
        try {
            UiSpec.setRefined(getSharedPreferences("weifp_theme", MODE_PRIVATE)
                    .getBoolean("ui_refined", true));
        } catch (Throwable ignored) {
        }
        super.onCreate(savedInstanceState);

        getBaseContext().getResources().updateConfiguration(
            LanguageManager.wrap(this).getResources().getConfiguration(),
            getBaseContext().getResources().getDisplayMetrics()
        );

        density = getResources().getDisplayMetrics().density;

        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ScrollView.LayoutParams(
                                       ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.MATCH_PARENT));

        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        rootLayout.setPadding((int)(30*density), (int)(60*density), (int)(30*density), (int)(30*density));
        rootLayout.setLayoutParams(new ScrollView.LayoutParams(
                                       ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        ImageView logo = new ImageView(this);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams((int)(100*density), (int)(100*density));
        logoLp.setMargins(0, 0, 0, (int)(20*density));
        logo.setLayoutParams(logoLp);
        logo.setImageResource(R.drawable.ic_launcher);
        rootLayout.addView(logo);

        TextView tvAppName = new TextView(this);
        tvAppName.setText("Weifp");
        tvAppName.setTextSize(22);
        tvAppName.setTypeface(null, android.graphics.Typeface.BOLD);
        tvAppName.setGravity(Gravity.CENTER);
        rootLayout.addView(tvAppName);

        TextView tvVersion = new TextView(this);
        tvVersion.setText(AppVersion.VERSION_NAME);
        tvVersion.setTextSize(13);
        tvVersion.setGravity(Gravity.CENTER);
        tvVersion.setPadding(0, (int)(10*density), 0, (int)(40*density));
        rootLayout.addView(tvVersion);

        btnLanguage = createSettingsButton(LanguageManager.getCurrentLangName(this));
        btnLanguage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { showLanguageDialog(); }
            });
        rootLayout.addView(btnLanguage);

        TextView tvThemeTitle = new TextView(this);
        tvThemeTitle.setText(LanguageManager.getString(this, R.string.theme_title));
        tvThemeTitle.setTextSize(15);
        tvThemeTitle.setGravity(Gravity.START);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleLp.setMargins(0, (int)(20*density), 0, (int)(10*density));
        tvThemeTitle.setLayoutParams(titleLp);
        rootLayout.addView(tvThemeTitle);

        btnDark = createSettingsButton(LanguageManager.getString(this, R.string.theme_dark));
        btnDark.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ThemeManager.setThemeMode(SettingsActivity.this, ThemeManager.THEME_DARK);
                    updateThemeUI();
                }
            });
        rootLayout.addView(btnDark);

        btnLight = createSettingsButton(LanguageManager.getString(this, R.string.theme_light));
        btnLight.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ThemeManager.setThemeMode(SettingsActivity.this, ThemeManager.THEME_LIGHT);
                    updateThemeUI();
                }
            });
        rootLayout.addView(btnLight);

        btnAuto = createSettingsButton(LanguageManager.getString(this, R.string.theme_auto));
        btnAuto.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ThemeManager.setThemeMode(SettingsActivity.this, ThemeManager.THEME_AUTO);
                    updateThemeUI();
                }
            });
        rootLayout.addView(btnAuto);

        btnHistogram = createSettingsButton("");
        btnHistogram.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean current = ThemeManager.isHistogramEnabled(SettingsActivity.this);
                    ThemeManager.setHistogramEnabled(SettingsActivity.this, !current);
                    updateThemeUI();
                }
            });
        rootLayout.addView(btnHistogram);

        // 精致模式：控制细描边等观感增强，关掉回到原来的纯色块
        btnRefined = createSettingsButton("");
        final java.lang.String refinedOn = LanguageManager.getString(this, R.string.refined_on);
        final java.lang.String refinedOff = LanguageManager.getString(this, R.string.refined_off);
        final Runnable refreshRefined = new Runnable() {
            @Override public void run() {
                boolean on = getSharedPreferences("weifp_theme", MODE_PRIVATE)
                        .getBoolean("ui_refined", true);
                String state = on ? refinedOn : refinedOff;
                String def = on ? "" : LanguageManager.getString(SettingsActivity.this,
                        R.string.refined_default_on);
                btnRefined.setText(LanguageManager.getString(SettingsActivity.this,
                        R.string.refined_title) + "：" + state + def);
            }
        };
        refreshRefined.run();
        btnRefined.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    android.content.SharedPreferences sp =
                            getSharedPreferences("weifp_theme", MODE_PRIVATE);
                    boolean on = sp.getBoolean("ui_refined", true);
                    sp.edit().putBoolean("ui_refined", !on).commit();
                    UiSpec.setRefined(!on);
                    refreshRefined.run();
                    updateThemeUI();   // 立即刷新开/关配色
                    Toast.makeText(SettingsActivity.this,
                            getString(R.string.refined_tip), Toast.LENGTH_SHORT).show();
                }
            });
        rootLayout.addView(btnRefined);   // 沿用 createSettingsButton 的统一高度

        // 高性能模式：影响抠图/蒙版/锐化等是否用多核
        btnHighPerf = createSettingsButton("");
        btnHighPerf.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    boolean on = Parallel.isHighPerformance(SettingsActivity.this);
                    Parallel.setHighPerformance(SettingsActivity.this, !on);
                    updateThemeUI();
                    Toast.makeText(SettingsActivity.this,
                            LanguageManager.getString(SettingsActivity.this,
                                on ? R.string.high_perf_off : R.string.high_perf_on),
                            Toast.LENGTH_SHORT).show();
                }
            });
        rootLayout.addView(btnHighPerf);

        // 错误日志：出问题时可以查看原因
        btnCrashLog = createSettingsButton(LanguageManager.getString(this, R.string.crash_log_title));
        btnCrashLog.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { showCrashLogDialog(); }
            });
        rootLayout.addView(btnCrashLog);

        btnCheckUpdate = createSettingsButton(
                LanguageManager.getString(this, R.string.update_check_title));
        btnCheckUpdate.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Toast.makeText(SettingsActivity.this,
                            R.string.update_downloading, Toast.LENGTH_SHORT).show();
                    UpdateChecker.check(new UpdateChecker.Callback() {
                            @Override public void onUpdateAvailable(final String vn, final int vc,
                                                                    final String url, final String notes) {
                                runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            UpdateDialog.show(SettingsActivity.this, vn, vc, url, notes);
                                        }
                                    });
                            }
                            @Override public void onUpToDate() {
                                runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            Toast.makeText(SettingsActivity.this,
                                                    R.string.update_current, Toast.LENGTH_SHORT).show();
                                        }
                                    });
                            }
                            @Override public void onError(final String reason) {
                                runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            Toast.makeText(SettingsActivity.this,
                                                    R.string.update_fail, Toast.LENGTH_SHORT).show();
                                        }
                                    });
                            }
                        });
                }
            });
        rootLayout.addView(btnCheckUpdate);   // 沿用统一高度


        TextView tvSaveTitle = new TextView(this);
        tvSaveTitle.setText(LanguageManager.getString(this, R.string.save_settings_title));
        tvSaveTitle.setTextSize(15);
        tvSaveTitle.setGravity(Gravity.START);
        LinearLayout.LayoutParams saveTitleLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        saveTitleLp.setMargins(0, (int)(20*density), 0, (int)(10*density));
        tvSaveTitle.setLayoutParams(saveTitleLp);
        rootLayout.addView(tvSaveTitle);

        btnStepPerAction = createSettingsButton(LanguageManager.getString(this, R.string.wpc_save_per_action));
        btnStepPerAction.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ThemeManager.setStepPerActionEnabled(SettingsActivity.this, true);
                    updateThemeUI();
                }
            });
        rootLayout.addView(btnStepPerAction);

        btnStepOnExit = createSettingsButton(LanguageManager.getString(this, R.string.wpc_save_on_exit));
        btnStepOnExit.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ThemeManager.setStepPerActionEnabled(SettingsActivity.this, false);
                    updateThemeUI();
                }
            });
        rootLayout.addView(btnStepOnExit);

        btnWpbToggle = createSettingsButton("");
        btnWpbToggle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean current = ThemeManager.isWpbEnabled(SettingsActivity.this);
                    ThemeManager.setWpbEnabled(SettingsActivity.this, !current);
                    updateThemeUI();
                }
            });
        rootLayout.addView(btnWpbToggle);

        btnClearCache = createSettingsButton(LanguageManager.getString(this, R.string.clear_cache_btn));
        btnClearCache.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    clearAppCache();
                }
            });
        rootLayout.addView(btnClearCache);

        TextView btnBottom = createSettingsButton(LanguageManager.getString(this, R.string.about_app));
        btnBottom.setGravity(Gravity.CENTER);
        btnBottom.setBackground(getRoundBg(0xFFFFB615));
        btnBottom.setTextColor(Color.BLACK);
        LinearLayout.LayoutParams bottomLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (int)(56 * density));
        bottomLp.setMargins(0, (int)(30*density), 0, 0);
        btnBottom.setLayoutParams(bottomLp);
        btnBottom.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    startActivity(new Intent(SettingsActivity.this, AboutActivity.class));
                }
            });
        rootLayout.addView(btnBottom);

        scrollView.addView(rootLayout);
        setContentView(scrollView);
        updateThemeUI();

        BackButtonHelper.addBackButton(this, null);
    }

    private void showLanguageDialog() {
        final String[] items = {"简体中文", "繁體中文", "English (US)"};
        int current = LanguageManager.getLanguage(this);
        if (current == LanguageManager.LANG_CLASSICAL) current = LanguageManager.LANG_SIMPLIFIED;
        final int[] selectedIndex = {current};
        classicClickCount = 0;
        
        // ★ 新增：只要打开语言弹窗，先撤销彩蛋计数，防止误触
        classicClickCount = 0;
        lastClassicClickTime = 0;

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCanceledOnTouchOutside(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getRoundBg(ThemeManager.getPanelColor(this)));
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(20*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(LanguageManager.getString(this, R.string.lang_select));
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(Gravity.CENTER);
        tvTitle.setPadding(0, 0, 0, (int)(20*density));
        root.addView(tvTitle);

        for (int i = 0; i < items.length; i++) {
            final int index = i;
            TextView tvItem = new TextView(this);
            tvItem.setText(items[i]);
            tvItem.setTextSize(15);
            tvItem.setTextColor(ThemeManager.getTextColor(this));
            tvItem.setGravity(Gravity.CENTER);
            tvItem.setPadding(0, (int)(15*density), 0, (int)(15*density));
            tvItem.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, (int)(10*density));
            tvItem.setLayoutParams(lp);

            tvItem.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (langCloseRunnable != null) {
                            langClickHandler.removeCallbacks(langCloseRunnable);
                            langCloseRunnable = null;
                        }

                        if (index == LanguageManager.LANG_TRADITIONAL) {
                            long now = System.currentTimeMillis();
                            if (now - lastClassicClickTime > CLASSIC_COUNT_RESET_MS) classicClickCount = 0;
                            lastClassicClickTime = now;
                            classicClickCount++;

                            if (classicClickCount >= 10) {
                                classicClickCount = 0;
                                dialog.dismiss();
                                triggerEasterEgg();
                                return;
                            }
                        } else {
                            classicClickCount = 0;
                        }

                        selectedIndex[0] = index;

                        langCloseRunnable = new Runnable() {
                            @Override public void run() {
                                langCloseRunnable = null;
                                LanguageManager.setLanguage(SettingsActivity.this, selectedIndex[0]);
                                if (dialog.isShowing()) dialog.dismiss();
                                recreate();
                            }
                        };
                        langClickHandler.postDelayed(langCloseRunnable, LANG_CLOSE_DELAY);
                    }
                });
            root.addView(tvItem);
        }

        dialog.setContentView(root);
        dialog.setCancelable(false);
        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.8);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void triggerEasterEgg() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(getRoundBg(ThemeManager.getPanelColor(this)));
        root.setPadding((int)(20*density), (int)(20*density), (int)(20*density), (int)(10*density));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(LanguageManager.getString(this, R.string.easter_egg_title));
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(ThemeManager.getTextColor(this));
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        TextView tvMsg = new TextView(this);
        tvMsg.setText(LanguageManager.getString(this, R.string.easter_egg_msg));
        tvMsg.setTextSize(13);
        tvMsg.setTextColor(ThemeManager.getTextColor(this));
        tvMsg.setGravity(Gravity.CENTER);
        tvMsg.setPadding(0, (int)(10*density), 0, (int)(20*density));
        root.addView(tvMsg);

        TextView btnOk = new TextView(this);
        btnOk.setText(LanguageManager.getString(this, R.string.confirm));
        btnOk.setTextSize(15);
        btnOk.setTextColor(Color.BLACK);
        btnOk.setGravity(Gravity.CENTER);
        btnOk.setPadding(0, (int)(12*density), 0, (int)(12*density));
        btnOk.setBackground(getRoundBg(0xFFFFB615));
        btnOk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    LanguageManager.setLanguage(SettingsActivity.this, LanguageManager.LANG_CLASSICAL);
                    dialog.dismiss();
                    recreate();
                }
            });
        root.addView(btnOk);

        dialog.setContentView(root);
        dialog.setCancelable(false);
        android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.8);
        dialog.getWindow().setAttributes(params);
        dialog.show();
    }

    private void clearAppCache() {
        long totalSize = 0L;
        try {
            java.io.File cacheDir = getCacheDir();
            if (cacheDir != null) {
                java.io.File[] files = cacheDir.listFiles();
                if (files != null) {
                    for (java.io.File f : files) {
                        totalSize += f.length();
                        f.delete();
                    }
                }
            }
            java.io.File extCache = getExternalCacheDir();
            if (extCache != null) {
                java.io.File[] files = extCache.listFiles();
                if (files != null) {
                    for (java.io.File f : files) {
                        totalSize += f.length();
                        f.delete();
                    }
                }
            }
        } catch (Throwable e) {}
        float mb = totalSize / 1024f / 1024f;
        Toast.makeText(this,
                       LanguageManager.getString(this, R.string.toast_cache_cleared)
                       + " " + String.format("%.1f", mb) + " MB",
                       Toast.LENGTH_SHORT).show();
    }

    private TextView createSettingsButton(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(14);
        tv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (int)(40 * density));
        lp.setMargins(0, 0, 0, (int)(6 * density));
        tv.setLayoutParams(lp);
        return tv;
    }

    private GradientDrawable getRoundBg(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(UiSpec.dp(this, UiSpec.RADIUS_M));
        bg.setColor(color);
        return bg;
    }

    private void updateThemeUI() {
        rootLayout.setBackgroundColor(ThemeManager.getBgColor(this));
        int textColor = ThemeManager.getTextColor(this);
        int currentSetting = ThemeManager.getThemeModeSetting(this);

        for (int i = 0; i < rootLayout.getChildCount(); i++) {
            View child = rootLayout.getChildAt(i);
            if (child instanceof TextView && child != btnDark && child != btnLight
                && child != btnAuto && child != btnHistogram
                && child != btnStepPerAction && child != btnStepOnExit && child != btnWpbToggle
                && child != btnLanguage && child != btnClearCache
                && child != btnRefined && child != btnCrashLog
                && child != btnCheckUpdate && child != btnHighPerf) {
                ((TextView) child).setTextColor(textColor);
            }
        }

        btnLanguage.setText(LanguageManager.getCurrentLangName(this));
        btnLanguage.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
        btnLanguage.setTextColor(ThemeManager.getTextColor(this));

        // 精致界面 / 错误日志：同样要有按钮底色，不能是裸文字
        if (btnRefined != null) {
            boolean refinedOn = getSharedPreferences("weifp_theme", MODE_PRIVATE)
                    .getBoolean("ui_refined", true);
            btnRefined.setBackground(getRoundBg(refinedOn ? 0xFFFFB615
                    : ThemeManager.getButtonColor(this)));
            btnRefined.setTextColor(refinedOn ? Color.BLACK : ThemeManager.getTextColor(this));
        }
        if (btnCrashLog != null) {
            btnCrashLog.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
            btnCrashLog.setTextColor(ThemeManager.getTextColor(this));
        }
        if (btnCheckUpdate != null) {
            btnCheckUpdate.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
            btnCheckUpdate.setTextColor(ThemeManager.getTextColor(this));
        }
        if (btnHighPerf != null) {
            boolean perf = Parallel.isHighPerformance(this);
            btnHighPerf.setText(LanguageManager.getString(this,
                    perf ? R.string.high_perf_on : R.string.high_perf_off));
            btnHighPerf.setBackground(getRoundBg(perf ? 0xFFFFB615
                    : ThemeManager.getButtonColor(this)));
            btnHighPerf.setTextColor(perf ? Color.BLACK : ThemeManager.getTextColor(this));
        }

        btnDark.setBackground(getRoundBg(currentSetting == ThemeManager.THEME_DARK ? 0xFFFFB615 : ThemeManager.getButtonColor(this)));
        btnDark.setTextColor(currentSetting == ThemeManager.THEME_DARK ? Color.BLACK : ThemeManager.getTextColor(this));

        btnLight.setBackground(getRoundBg(currentSetting == ThemeManager.THEME_LIGHT ? 0xFFFFB615 : ThemeManager.getButtonColor(this)));
        btnLight.setTextColor(currentSetting == ThemeManager.THEME_LIGHT ? Color.BLACK : ThemeManager.getTextColor(this));

        btnAuto.setBackground(getRoundBg(currentSetting == ThemeManager.THEME_AUTO ? 0xFFFFB615 : ThemeManager.getButtonColor(this)));
        btnAuto.setTextColor(currentSetting == ThemeManager.THEME_AUTO ? Color.BLACK : ThemeManager.getTextColor(this));

        boolean hist = ThemeManager.isHistogramEnabled(this);
        btnHistogram.setBackground(getRoundBg(hist ? 0xFFFFB615 : ThemeManager.getButtonColor(this)));
        btnHistogram.setTextColor(hist ? Color.BLACK : ThemeManager.getTextColor(this));
        btnHistogram.setText(LanguageManager.getString(this, hist ? R.string.histogram_on : R.string.histogram_off));

        boolean stepPerAction = ThemeManager.isStepPerActionEnabled(this);
        btnStepPerAction.setBackground(getRoundBg(stepPerAction ? 0xFFFFB615 : ThemeManager.getButtonColor(this)));
        btnStepPerAction.setTextColor(stepPerAction ? Color.BLACK : ThemeManager.getTextColor(this));

        btnStepOnExit.setBackground(getRoundBg(!stepPerAction ? 0xFFFFB615 : ThemeManager.getButtonColor(this)));
        btnStepOnExit.setTextColor(!stepPerAction ? Color.BLACK : ThemeManager.getTextColor(this));

        boolean wpb = ThemeManager.isWpbEnabled(this);
        btnWpbToggle.setText(LanguageManager.getString(this, wpb ? R.string.wpb_on : R.string.wpb_off));
        btnWpbToggle.setBackground(getRoundBg(wpb ? 0xFFFFB615 : ThemeManager.getButtonColor(this)));
        btnWpbToggle.setTextColor(wpb ? Color.BLACK : ThemeManager.getTextColor(this));

        btnClearCache.setBackground(getRoundBg(ThemeManager.getButtonColor(this)));
        btnClearCache.setTextColor(ThemeManager.getTextColor(this));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (langClickHandler != null) {
            if (langCloseRunnable != null) {
                langClickHandler.removeCallbacks(langCloseRunnable);
                langCloseRunnable = null;
            }
            langClickHandler.removeCallbacksAndMessages(null);
        }
    }

    /** 查看/清空错误日志。 */
    private void showCrashLogDialog() {
        String path = CrashLogger.logPath();
        String content = "（暂无记录）";
        try {
            java.io.File f = new java.io.File(path);
            if (f.exists() && f.length() > 0) {
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                java.io.FileInputStream fis = new java.io.FileInputStream(f);
                byte[] buf = new byte[4096];
                int n;
                while ((n = fis.read(buf)) > 0) bos.write(buf, 0, n);
                fis.close();
                String all = bos.toString("UTF-8");
                // 只显示最后 4000 字，避免弹窗过大
                content = all.length() > 4000 ? all.substring(all.length() - 4000) : all;
            }
        } catch (Throwable ignored) {
        }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        TextView tvPath = new TextView(this);
        tvPath.setText(LanguageManager.getString(this, R.string.crash_log_path) + "\n" + path);
        tvPath.setTextSize(11);
        tvPath.setTextColor(ThemeManager.getTextSecondaryColor(this));
        box.addView(tvPath);

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        TextView tvBody = new TextView(this);
        tvBody.setText(content);
        tvBody.setTextSize(10);
        tvBody.setTextColor(ThemeManager.getTextColor(this));
        tvBody.setTextIsSelectable(true);
        sv.addView(tvBody);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (int)(260 * density));
        sv.setLayoutParams(slp);
        box.addView(sv);

        TextView tvClear = new TextView(this);
        tvClear.setText(LanguageManager.getString(this, R.string.crash_log_clear));
        tvClear.setTextSize(14);
        tvClear.setGravity(Gravity.CENTER);
        tvClear.setPadding(0, (int)(12*density), 0, (int)(12*density));
        tvClear.setBackgroundColor(0xFFB61515);
        tvClear.setTextColor(Color.WHITE);
        tvClear.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    CrashLogger.clear();
                    Toast.makeText(SettingsActivity.this,
                            getString(R.string.crash_log_cleared), Toast.LENGTH_SHORT).show();
                    dismissCurrentDialog();
                }
            });
        box.addView(tvClear);

        showSimpleDialog(LanguageManager.getString(this, R.string.crash_log_title), box);
    }

    private Dialog currentDialog;
    private void dismissCurrentDialog() {
        try { if (currentDialog != null) currentDialog.dismiss(); } catch (Throwable ignored) {}
    }

    /** 统一的简单弹窗。 */
    private void showSimpleDialog(String title, View content) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        currentDialog = d;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding((int)(16*density), (int)(16*density), (int)(16*density), (int)(12*density));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.getSurfaceColor(this));
        bg.setCornerRadius(UiSpec.dp(this, UiSpec.RADIUS_L));
        root.setBackground(bg);
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(15);
        tv.setGravity(Gravity.CENTER);
        tv.setTextColor(ThemeManager.getTextColor(this));
        tv.setPadding(0, 0, 0, (int)(10*density));
        root.addView(tv);
        root.addView(content);
        d.setContentView(root);
        d.show();
    }
}
