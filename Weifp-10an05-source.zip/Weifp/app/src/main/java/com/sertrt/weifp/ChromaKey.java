package com.sertrt.weifp;

/**
 * 色度抠图（Chroma Key）算法 —— 纯 Java，可离线测试。
 *
 * 设计要点（与常见绿幕抠像一致）：
 *
 * 1. **色度分离**：把 RGB 转成「色度距离」而不是简单 RGB 差值，
 *    这样同一颜色在明暗变化下仍能被识别（绿色阴影里的绿也能扣掉）。
 *
 * 2. **灵敏度**：控制颜色容差半径。越大扣得越干净，但也越容易误伤主体。
 *
 * 3. **羽化**：在色度边界附近生成半透明过渡，避免生硬锯齿。
 *
 * 4. **溢出抑制（Spill Suppression）**：绿幕拍摄时主体边缘会沾一层绿，
 *    这部分靠近边界但不该被扣掉的像素，把绿色分量压回中性。
 *
 * 所有参数都在 0..100，UI 直接可用。
 *
 * 适用范围（重要）：
 *   - 对高饱和纯色背景（绿幕/蓝幕）效果最好；
 *   - 对低饱和、与主体色相接近的照片（如灰霾天空与灰山）会有误伤，
 *     这是色度抠图的固有限制，不是 bug。此时应调低灵敏度并配合羽化。
 */
public final class ChromaKey {

    private ChromaKey() {
    }

    /** 抠图参数。 */
    public static class Settings {
        /** 目标颜色（ARGB）。 */
        public int keyColor = 0xFF00FF00;
        /** 灵敏度 0..100：色彩容差半径。 */
        public int sensitivity = 40;
        /** 羽化 0..100：边界过渡宽度。 */
        public int feather = 20;
        /** 溢出抑制 0..100：0 = 关闭。 */
        public int spillSuppress = 30;
        /** 取色点容差（吸管取样时平均多少像素），由 UI 自动给。 */
        public int sampleRadius = 2;

        public Settings() {
        }

        public Settings(int keyColor, int sensitivity, int feather, int spillSuppress) {
            this.keyColor = keyColor;
            this.sensitivity = sensitivity;
            this.feather = feather;
            this.spillSuppress = spillSuppress;
        }

        public Settings copy() {
            Settings s = new Settings();
            s.keyColor = keyColor;
            s.sensitivity = sensitivity;
            s.feather = feather;
            s.spillSuppress = spillSuppress;
            s.sampleRadius = sampleRadius;
            return s;
        }
    }

    /** 处理统计，用于给用户反馈。 */
    public static class Result {
        /** 被完全抠掉的像素数。 */
        public int removedPixels;
        /** 半透明的过渡像素数。 */
        public int fadedPixels;
        /** 处理的总像素数。 */
        public int totalPixels;

        public double removedRatio() {
            return totalPixels <= 0 ? 0 : (double) removedPixels / totalPixels;
        }
    }

    // ==================== 主入口 ====================

    /**
     * 原地抠图：把匹配 keyColor 的像素变透明，并做羽化 + 溢出抑制。
     *
     * @param px     像素数组（ARGB_8888），会被就地修改
     * @param w      宽
     * @param h      高
     * @param s      参数
     * @return 统计结果
     */
    public static Result apply(int[] px, int w, int h, Settings s) {
        Result r = new Result();
        if (px == null || w <= 0 || h <= 0 || s == null) {
            return r;
        }
        r.totalPixels = w * h;

        // 目标色的色度与色相
        double[] keyChroma = toChroma(s.keyColor);
        double[] keyHsv = toHsv(s.keyColor);

        // 灵敏度 -> 色相容差（度）。0 = 只扣几乎同色；100 = 扣到相近色相。
        double hueTol = 2.0 + (s.sensitivity / 100.0) * 28.0;
        // 饱和度下限：太低（接近灰白黑）的像素不算这个颜色
        double satFloor = Math.max(0.03, keyHsv[1] * 0.40);
        // 羽化 -> 容差外再扩的过渡带（度）
        double featherBand = (s.feather / 100.0) * 12.0;
        double outer = hueTol + featherBand;
        double spill = s.spillSuppress / 100.0;

        // 亮度约束：目标色附近的亮度区间更容易误判，用取样色亮度做参考
        double keyVal = keyHsv[2];
        double valTol = 0.18 + (s.sensitivity / 100.0) * 0.42;
        // ★ 饱和度约束：同为蓝色但浓淡不同（深蓝底 vs 浅蓝字）时，
        //   光看色相分不开，必须比较饱和度差异。
        double keySat = keyHsv[1];
        double satTol = 0.08 + (s.sensitivity / 100.0) * 0.20;


        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            int a = (c >>> 24) & 0xFF;
            if (a == 0) {
                continue; // 本来就透明
            }
            int red = (c >> 16) & 0xFF;
            int green = (c >> 8) & 0xFF;
            int blue = c & 0xFF;

            double[] hsv = toHsv(c);
            double dh = hueDelta(hsv[0], keyHsv[0]);
            // 三个条件同时满足才算背景：
            // ① 色相接近  ② 饱和度够（灰白黑不算）  ③ 亮度在取样色附近
            boolean sameDirection = hsv[1] >= satFloor
                    && dh <= outer
                    && Math.abs(hsv[2] - keyVal) <= valTol
                    && Math.abs(hsv[1] - keySat) <= satTol;
            double dist = dh;
            double tol = hueTol;

            if (sameDirection && dist <= tol) {
                // 完全匹配：抠掉
                px[i] = c & 0x00FFFFFF;
                r.removedPixels++;
            } else if (sameDirection && dist <= outer) {
                // 过渡带：按距离线性降低不透明度
                double t = (dist - tol) / Math.max(1e-6, outer - tol);
                if (t < 0) t = 0;
                if (t > 1) t = 1;
                int na = (int) Math.round(a * t);
                int nr = red, ng = green, nb = blue;

                // 过渡带里的像素几乎都带溢出，全部按强度抑制（越靠近边界越强）
                if (spill > 0) {
                    double strength = spill * Math.max(0.35, 1.0 - t * 0.65);
                    int[] sup = suppressSpill(red, green, blue, keyChroma, strength);
                    nr = sup[0];
                    ng = sup[1];
                    nb = sup[2];
                }
                px[i] = (na << 24) | (nr << 16) | (ng << 8) | nb;
                r.fadedPixels++;
            } else if (spill > 0) {
                // 普通像素：轻度溢出抑制，防止边缘泛绿
                if (looksSpilled(red, green, blue, keyChroma)) {
                    int[] sup = suppressSpill(red, green, blue, keyChroma, spill * 0.6);
                    px[i] = (a << 24) | (sup[0] << 16) | (sup[1] << 8) | sup[2];
                }
            }
        }
        return r;
    }

    /**
     * 从取样点周围取平均色（吸管）。
     *
     * @return ARGB；取不到返回 0
     */
    public static int sampleColor(int[] px, int w, int h, int cx, int cy, int radius) {
        if (px == null || w <= 0 || h <= 0) return 0;
        int r = Math.max(0, radius);
        long ra = 0, rr = 0, rg = 0, rb = 0;
        int n = 0;
        for (int y = cy - r; y <= cy + r; y++) {
            if (y < 0 || y >= h) continue;
            for (int x = cx - r; x <= cx + r; x++) {
                if (x < 0 || x >= w) continue;
                int c = px[y * w + x];
                if (((c >>> 24) & 0xFF) == 0) continue;
                ra += (c >>> 24) & 0xFF;
                rr += (c >> 16) & 0xFF;
                rg += (c >> 8) & 0xFF;
                rb += c & 0xFF;
                n++;
            }
        }
        if (n == 0) return 0;
        // 允许色度编码里带小数，这里用四舍五入保留整数，另存精确色度在内部
        return ((int) (ra / n) << 24) | ((int) (rr / n) << 16)
                | ((int) (rg / n) << 8) | (int) (rb / n);
    }

    /**
     * 带小数的精确取样色，避免取整后色度偏移。
     * 返回 {a, r, g, b} 的浮点值，编码进 int 的高位不现实，所以单独返回 double[]。
     */
    public static double[] sampleColorExact(int[] px, int w, int h, int cx, int cy, int radius) {
        if (px == null || w <= 0 || h <= 0) return null;
        int r = Math.max(0, radius);
        double sa = 0, sr = 0, sg = 0, sb = 0;
        int n = 0;
        for (int y = cy - r; y <= cy + r; y++) {
            if (y < 0 || y >= h) continue;
            for (int x = cx - r; x <= cx + r; x++) {
                if (x < 0 || x >= w) continue;
                int c = px[y * w + x];
                if (((c >>> 24) & 0xFF) == 0) continue;
                sa += (c >>> 24) & 0xFF;
                sr += (c >> 16) & 0xFF;
                sg += (c >> 8) & 0xFF;
                sb += c & 0xFF;
                n++;
            }
        }
        if (n == 0) return null;
        return new double[]{sa / n, sr / n, sg / n, sb / n};
    }

    // ==================== 颜色工具 ====================
    /** RGB -> HSV（h 0..360, s 0..1, v 0..1）。 */
    static double[] toHsv(int c) {
        double r = ((c >> 16) & 0xFF) / 255.0;
        double g = ((c >> 8) & 0xFF) / 255.0;
        double b = (c & 0xFF) / 255.0;
        double max = Math.max(r, Math.max(g, b));
        double min = Math.min(r, Math.min(g, b));
        double d = max - min;
        double hh;
        if (d < 1e-9) {
            hh = 0;
        } else if (max == r) {
            hh = 60 * (((g - b) / d) % 6);
        } else if (max == g) {
            hh = 60 * (((b - r) / d) + 2);
        } else {
            hh = 60 * (((r - g) / d) + 4);
        }
        if (hh < 0) hh += 360;
        double sat = max <= 1e-9 ? 0 : d / max;
        return new double[]{hh, sat, max};
    }

    /** 两个色相的夹角（0..180）。 */
    static double hueDelta(double a, double b) {
        double d = Math.abs(a - b) % 360;
        return d > 180 ? 360 - d : d;
    }



    /** RGB -> 色度（去掉亮度，保留颜色方向），归一化到单位长度附近。 */
    static double[] toChroma(int argb) {
        double r = (argb >> 16) & 0xFF;
        double g = (argb >> 8) & 0xFF;
        double b = argb & 0xFF;
        double y = 0.299 * r + 0.587 * g + 0.114 * b;
        double cb = (b - y) / 255.0;
        double cr = (r - y) / 255.0;
        return new double[]{cb, cr};
    }

    static double luma(int argb) {
        double r = (argb >> 16) & 0xFF;
        double g = (argb >> 8) & 0xFF;
        double b = argb & 0xFF;
        return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0;
    }

    /** 两个色度之间的距离（0 表示同色）。 */
    static double chromaDistance(double[] a, double[] b) {
        double d0 = a[0] - b[0];
        double d1 = a[1] - b[1];
        return Math.sqrt(d0 * d0 + d1 * d1);
    }

    /** 判断这个像素是否明显带有目标色的色偏（用于溢出抑制判定）。 */
    static boolean looksSpilled(int r, int g, int b, double[] keyChroma) {
        double[] cc = toChroma((0xFF << 24) | (r << 16) | (g << 8) | b);
        // 色度方向与目标色同向且分量明显，才认为有溢出
        double dot = cc[0] * keyChroma[0] + cc[1] * keyChroma[1];
        double keyLen = Math.sqrt(keyChroma[0] * keyChroma[0] + keyChroma[1] * keyChroma[1]);
        double cLen = Math.sqrt(cc[0] * cc[0] + cc[1] * cc[1]);
        if (keyLen < 1e-6 || cLen < 1e-6) return false;
        double cos = dot / (keyLen * cLen);
        return cos > 0.75 && cLen > keyLen * 0.12;
    }

    /**
     * 溢出抑制：把目标色方向的色度分量按 strength 压掉。
     *
     * 例：绿幕下主体边缘的绿 → 把绿色分量往 (r+b)/2 拉，得到中性色。
     */
    static int[] suppressSpill(int r, int g, int b, double[] keyChroma, double strength) {
        double[] cc = toChroma((0xFF << 24) | (r << 16) | (g << 8) | b);
        double keyLen = Math.sqrt(keyChroma[0] * keyChroma[0] + keyChroma[1] * keyChroma[1]);
        if (keyLen < 1e-6) {
            return new int[]{r, g, b};
        }
        double ux = keyChroma[0] / keyLen;
        double uy = keyChroma[1] / keyLen;
        // 当前像素在目标色方向上的投影
        double proj = cc[0] * ux + cc[1] * uy;
        if (proj <= 0) {
            return new int[]{r, g, b};   // 反向偏移，不是溢出
        }
        // 沿该方向回退。strength=1 时完全去掉该方向的色偏（可能略过头，视觉上更干净）
        double k = proj * Math.min(1.6, strength * 1.8);
        double ncb = cc[0] - k * ux;
        double ncr = cc[1] - k * uy;
        // 由 (cb, cr) 反推 RGB：保持亮度不变
        double y = 0.299 * r + 0.587 * g + 0.114 * b;
        double nr = y + ncr * 255.0;
        double nb = y + ncb * 255.0;
        // Cr/Cb 是相对亮度的差值，G 由亮度关系反解
        double ng = (y - 0.299 * nr - 0.114 * nb) / 0.587;
        return new int[]{
                clamp255((int) Math.round(nr)),
                clamp255((int) Math.round(ng)),
                clamp255((int) Math.round(nb))
        };
    }

    private static int clamp255(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }

    // ==================== 预览辅助 ====================

    /**
     * 只计算不修改：返回一个透明度数组（0..255），供预览用。
     * 与 apply 使用完全相同的判定，保证预览和最终结果一致。
     */
    public static void computeAlpha(int[] px, int w, int h, Settings s, int[] outAlpha) {
        if (px == null || outAlpha == null || w <= 0 || h <= 0 || s == null) return;
        double[] keyHsv = toHsv(s.keyColor);
        double tol = 3.0 + (s.sensitivity / 100.0) * 40.0;
        double satFloor = Math.max(0.03, keyHsv[1] * 0.40);
        double featherBand = (s.feather / 100.0) * 12.0;
        double outer = tol + featherBand;

        int n = Math.min(px.length, outAlpha.length);
        for (int i = 0; i < n; i++) {
            int c = px[i];
            int a = (c >>> 24) & 0xFF;
            if (a == 0) {
                outAlpha[i] = 0;
                continue;
            }
            double[] hsv = toHsv(c);
            double dist = hueDelta(hsv[0], keyHsv[0]);
            boolean sameDirection = hsv[1] >= satFloor && dist <= outer
                    && Math.abs(hsv[2] - keyHsv[2]) <= (0.18 + (s.sensitivity / 100.0) * 0.42)
                    && Math.abs(hsv[1] - keyHsv[1]) <= (0.08 + (s.sensitivity / 100.0) * 0.20);
            if (sameDirection && dist <= tol) {
                outAlpha[i] = 0;
            } else if (sameDirection && dist <= outer) {
                double t = (dist - tol) / Math.max(1e-6, outer - tol);
                if (t < 0) t = 0;
                if (t > 1) t = 1;
                outAlpha[i] = (int) Math.round(a * t);
            } else {
                outAlpha[i] = a;
            }
        }
    }
}
