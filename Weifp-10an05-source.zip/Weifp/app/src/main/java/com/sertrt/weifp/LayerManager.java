package com.sertrt.weifp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class LayerManager {

    public static final int MAX_LAYERS = 20;
    private static final int CANVAS_FALLBACK = 1024;

    private int globalAlpha = 255;

    public static class LayerItem {
        public Bitmap bitmap;
        public String imageFile;
        public boolean visible = true;
        public int alpha = 255;
        public boolean applyFilter = true;
        public String name;

        public LayerItem copyMeta() {
            LayerItem c = new LayerItem();
            c.imageFile = imageFile;
            c.visible = visible;
            c.alpha = alpha;
            c.applyFilter = applyFilter;
            c.name = name;
            return c;
        }
    }

    private List<LayerItem> layers = new ArrayList<LayerItem>();

    public List<LayerItem> getLayers() { return layers; }
    public int size() { return layers.size(); }
    public LayerItem get(int i) { return layers.get(i); }
    public boolean canAddLayer() { return layers.size() < MAX_LAYERS; }

    public void setGlobalAlpha(int a) {
        if (a < 0) a = 0;
        if (a > 255) a = 255;
        globalAlpha = a;
    }
    public int getGlobalAlpha() { return globalAlpha; }

    public void ensureBaseLayer(int w, int h) {
        if (layers.isEmpty()) {
            LayerItem l = new LayerItem();
            l.bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            l.name = "主图";
            layers.add(l);
        }
    }

    public boolean ensureDrawLayer(int w, int h) {
        if (layers.size() <= 1) {
            return addBlankLayer(w, h) != null;
        }
        return true;
    }

    public LayerItem addBlankLayer(int w, int h) {
        if (!canAddLayer()) return null;
        LayerItem l = new LayerItem();
        l.bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        l.name = "图层 " + layers.size();
        layers.add(l);
        return l;
    }

    public LayerItem addImageLayer(Bitmap bmp, int w, int h) {
        if (!canAddLayer() || bmp == null) return null;
        LayerItem l = new LayerItem();
        l.bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(l.bitmap);
        float s = Math.min((float) w / bmp.getWidth(), (float) h / bmp.getHeight());
        int dw = (int)(bmp.getWidth() * s);
        int dh = (int)(bmp.getHeight() * s);
        if (dw <= 0) dw = 1;
        if (dh <= 0) dh = 1;
        Paint p = new Paint();
        p.setFilterBitmap(true);
        Bitmap scaled = Bitmap.createScaledBitmap(bmp, dw, dh, true);
        c.drawBitmap(scaled, (w - dw) / 2f, (h - dh) / 2f, p);
        if (scaled != bmp && !scaled.isRecycled()) scaled.recycle();
        l.name = "图层 " + layers.size();
        layers.add(l);
        return l;
    }

    public boolean removeLayer(int index) {
        if (index <= 0 || index >= layers.size()) return false;
        if (layers.size() <= 1) return false;
        LayerItem l = layers.remove(index);
        if (l.bitmap != null && !l.bitmap.isRecycled()) l.bitmap.recycle();
        return true;
    }

    // ★ 撤销"删层"：把快照塞回指定位置
    public boolean restoreLayer(int index, LayerItem snapshot) {
        if (snapshot == null || snapshot.bitmap == null || snapshot.bitmap.isRecycled()) return false;
        if (!snapshot.bitmap.isMutable()) {
            Bitmap m = snapshot.bitmap.copy(Bitmap.Config.ARGB_8888, true);
            if (m == null) return false;
            snapshot.bitmap = m;
        }
        if (index < 0) index = 0;
        if (index > layers.size()) index = layers.size();
        layers.add(index, snapshot);
        return true;
    }

    // ★ 撤销"加层"：删掉指定位置那层
    public boolean removeLayerForUndo(int index) {
        if (index <= 0 || index >= layers.size()) return false;
        LayerItem l = layers.remove(index);
        if (l.bitmap != null && !l.bitmap.isRecycled()) l.bitmap.recycle();
        return true;
    }

    public boolean moveUp(int index) {
        if (index <= 1 || index >= layers.size()) return false;
        LayerItem t = layers.get(index);
        layers.set(index, layers.get(index - 1));
        layers.set(index - 1, t);
        return true;
    }

    public boolean moveDown(int index) {
        if (index <= 1 || index >= layers.size() - 1) return false;
        LayerItem t = layers.get(index);
        layers.set(index, layers.get(index + 1));
        layers.set(index + 1, t);
        return true;
    }

    public boolean toggleVisible(int index) {
        if (index < 0 || index >= layers.size()) return false;
        layers.get(index).visible = !layers.get(index).visible;
        return true;
    }

    public void saveLayerBitmaps(File stepsDir) {
        saveLayerBitmaps(stepsDir, null);
    }

    public void saveLayerBitmaps(File stepsDir, String prefix) {
        if (stepsDir == null) return;
        if (!stepsDir.exists()) stepsDir.mkdirs();
        for (int i = 0; i < layers.size(); i++) {
            LayerItem l = layers.get(i);
            if (l.bitmap != null && !l.bitmap.isRecycled()) {
                try {
                    String fn = (prefix != null && prefix.length() > 0)
                        ? prefix + "_layer_" + i + ".png"
                        : "layer_" + i + ".png";
                    FileOutputStream fos = new FileOutputStream(new File(stepsDir, fn));
                    l.bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    fos.close();
                    if (prefix == null || prefix.length() == 0) l.imageFile = fn;
                } catch (Throwable e) {}
            }
        }
    }

    public String getSerializedString() {
        StringBuilder sb = new StringBuilder();
        sb.append("layer_count=").append(layers.size()).append("\n");
        for (int i = 0; i < layers.size(); i++) {
            LayerItem l = layers.get(i);
            String p = "layer_" + i + "_";
            sb.append(p).append("visible=").append(l.visible ? "1" : "0").append("\n");
            sb.append(p).append("alpha=").append(l.alpha).append("\n");
            sb.append(p).append("apply_filter=").append(l.applyFilter ? "1" : "0").append("\n");
            if (l.name != null) sb.append(p).append("name=").append(esc(l.name)).append("\n");
            if (l.imageFile != null) sb.append(p).append("image_file=").append(l.imageFile).append("\n");
        }
        return sb.toString();
    }

    public void deserializeFrom(Map<String, String> map, File stepsDir, int w, int h) {
        for (int i = 0; i < layers.size(); i++) {
            LayerItem old = layers.get(i);
            if (old.bitmap != null && !old.bitmap.isRecycled()) old.bitmap.recycle();
        }
        layers.clear();

        int count = 0;
        try { count = Integer.parseInt(map.get("layer_count")); } catch (Throwable e) {}
        for (int i = 0; i < count && i < MAX_LAYERS; i++) {
            String p = "layer_" + i + "_";
            LayerItem l = new LayerItem();
            l.visible = "1".equals(map.get(p + "visible"));
            try { l.alpha = Integer.parseInt(map.get(p + "alpha")); } catch (Throwable e) { l.alpha = 255; }
            if (l.alpha < 0) l.alpha = 0;
            if (l.alpha > 255) l.alpha = 255;
            l.applyFilter = !"0".equals(map.get(p + "apply_filter"));
            l.name = unesc(map.get(p + "name"));
            if (l.name == null) l.name = (i == 0) ? "主图" : ("图层 " + i);
            l.imageFile = map.get(p + "image_file");
            if (l.imageFile != null && stepsDir != null) {
                File f = new File(stepsDir, l.imageFile);
                if (f.exists()) {
                    Bitmap decoded = null;
                    try {
                        BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        opts.inMutable = true;
                        decoded = BitmapFactory.decodeFile(f.getAbsolutePath(), opts);
                    } catch (Throwable e) { decoded = null; }
                    if (decoded != null) {
                        Bitmap usable = null;
                        if (decoded.isMutable() && decoded.getConfig() == Bitmap.Config.ARGB_8888) {
                            usable = decoded;
                        } else {
                            try {
                                Bitmap mutable = decoded.copy(Bitmap.Config.ARGB_8888, true);
                                if (mutable != null && mutable != decoded) {
                                    usable = mutable;
                                    if (!decoded.isRecycled()) decoded.recycle();
                                } else {
                                    usable = decoded;
                                }
                            } catch (Throwable e) {
                                usable = decoded;
                            }
                        }
                        if (usable == null || !usable.isMutable() || usable.getConfig() != Bitmap.Config.ARGB_8888) {
                            int bw = (usable != null) ? usable.getWidth() : w;
                            int bh = (usable != null) ? usable.getHeight() : h;
                            if (bw <= 0) bw = w > 0 ? w : CANVAS_FALLBACK;
                            if (bh <= 0) bh = h > 0 ? h : CANVAS_FALLBACK;
                            Bitmap rebuilt = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
                            if (usable != null && !usable.isRecycled()) {
                                Canvas rc = new Canvas(rebuilt);
                                rc.drawBitmap(usable, 0, 0, null);
                                usable.recycle();
                            }
                            usable = rebuilt;
                        }
                        l.bitmap = usable;
                    }
                }
            }
            if (l.bitmap == null && w > 0 && h > 0) {
                l.bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            }
            if (l.bitmap != null) layers.add(l);
        }
        if (layers.isEmpty() && w > 0 && h > 0) ensureBaseLayer(w, h);
    }

    public void drawAll(Canvas canvas, float sx, float sy) {
        drawAll(canvas, sx, sy, null);
    }

    /** 绘制复用（图层多时每帧新建 Paint 会产生大量垃圾）。 */
    private final Paint drawPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Matrix drawMatrix = new Matrix();

    public void drawAll(Canvas canvas, float sx, float sy, ColorFilter filter) {
        if (globalAlpha <= 0) return;
        if (layers.isEmpty()) return;
        LayerItem baseLayer = layers.get(0);
        for (LayerItem l : layers) {
            if (!l.visible) continue;
            if (l.bitmap == null || l.bitmap.isRecycled()) continue;
            if (l == baseLayer) continue;
            Paint p = drawPaint;
            p.setAlpha(l.alpha * globalAlpha / 255);
            p.setColorFilter((filter != null && l.applyFilter) ? filter : null);
            if (sx == 1f && sy == 1f) {
                canvas.drawBitmap(l.bitmap, 0, 0, p);
            } else {
                drawMatrix.reset();
                drawMatrix.postScale(sx, sy);
                canvas.drawBitmap(l.bitmap, drawMatrix, p);
            }
        }
    }

    public void clear() {
        for (LayerItem l : layers) {
            if (l.bitmap != null && !l.bitmap.isRecycled()) l.bitmap.recycle();
        }
        layers.clear();
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\n", "\\n").replace("=", "\\=");
    }
    private String unesc(String s) {
        if (s == null) return null;
        return s.replace("\\n", "\n").replace("\\=", "=").replace("\\\\", "\\");
    }
}
