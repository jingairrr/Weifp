package com.sertrt.weifp;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Base64;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class HistoryManager {

    public static byte[] readBytesFromUri(Context context, Uri uri) {
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int len;
            while ((len = inputStream.read(buffer)) != -1) {
                byteBuffer.write(buffer, 0, len);
            }
            inputStream.close();
            return byteBuffer.toByteArray();
        } catch (Throwable e) { return null; }
    }

    public static String encodeToBase64(byte[] data) {
        if (data == null) return "";
        return Base64.encodeToString(data, Base64.NO_WRAP);
    }

    public static String getFileNameFromUri(Context context, Uri uri) {
        String result = null;
        if (uri.getScheme() != null && uri.getScheme().equals("content")) {
            Cursor cursor = null;
            try {
                cursor = context.getContentResolver().query(uri, null, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (index != -1) result = cursor.getString(index);
                }
            } catch (Exception e) {
            } finally {
                if (cursor != null) cursor.close();
            }
        }
        if (result == null) {
            result = uri.getPath();
            if (result != null) {
                int cut = result.lastIndexOf('/');
                if (cut != -1) result = result.substring(cut + 1);
            }
        }
        return result;
    }

    /**
     * 全局刷新标记：编辑页保存后置位，主页 onResume 时检查并刷新列表。
     * 因为保存现在不退出编辑页，主页收不到 Activity 回调，需要这个标记。
     */
    private static volatile boolean sNeedsRefresh = false;

    public static void markNeedsRefresh() {
        sNeedsRefresh = true;
    }

    /** 只读不消费（refreshHistoryGrid 内部用）。 */
    public static boolean consumeNeedsRefreshLazy() {
        return consumeNeedsRefresh();
    }

    public static boolean consumeNeedsRefresh() {
        boolean v = sNeedsRefresh;
        sNeedsRefresh = false;
        return v;
    }

    public static File getHistoryDir(Context context) {
        File dir = new File(context.getExternalFilesDir(null), "History");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static File getBaseDir(Context context) {
        File dir = new File(context.getExternalFilesDir(null), "WeifpBase");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static File getCoverDir(Context context) {
        File dir = new File(context.getExternalFilesDir(null), "WeifpCover");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static File getOriginalDir(Context context) {
        File dir = new File(context.getExternalFilesDir(null), "WeifpOriginal");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static File getOriginalFile(Context context, String histFileName) {
        return new File(getOriginalDir(context), histFileName);
    }

    public static void saveOriginalIfNotExists(Context context, String histFilePath, Bitmap bmp) {
        try {
            if (bmp == null || bmp.isRecycled()) return;
            File histFile = new File(histFilePath);
            File origFile = getOriginalFile(context, histFile.getName());
            if (origFile.exists() && origFile.length() > 0) return;
            FileOutputStream fos = new FileOutputStream(origFile);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
        } catch (Throwable e) {}
    }

    public static void saveCoverBitmap(Context context, String finalPath, Bitmap bakedBmp) {
        try {
            File histFile = new File(finalPath);
            File coverDir = getCoverDir(context);
            File coverFile = new File(coverDir, histFile.getName());
            FileOutputStream fos = new FileOutputStream(coverFile);
            bakedBmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
        } catch (Throwable e) {}
    }

    public static File getStepsDir(Context context, String fileName) {
        File dir = new File(context.getExternalFilesDir(null), "WeifpSteps/" + fileName.replace(".png", ""));
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static File getTempStepsDir(Context context) {
        File dir = new File(context.getExternalFilesDir(null), "WeifpSteps/temp_" + System.currentTimeMillis());
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static List<HistoryItem> getAllHistory(Context context) {
        File dir = getHistoryDir(context);
        File[] files = dir.listFiles();
        List<HistoryItem> list = new ArrayList<>();
        if (files != null) {
            List<File> fileList = new ArrayList<>(Arrays.asList(files));
            fileList.sort(new Comparator<File>() {
                    @Override public int compare(File f1, File f2) {
                        return Long.compare(f2.lastModified(), f1.lastModified());
                    }
                });
            for (File f : fileList) {
                if (f.isDirectory()) continue;
                if (f.getName().endsWith(".tmp") || f.length() == 0) continue;
                String name = f.getName();
                if (name.endsWith(".png")) name = name.substring(0, name.length() - 4);
                if (name.startsWith("Weifp_") || name.matches("\\d+")) name = "未命名图片";
                list.add(new HistoryItem(f, name));
            }
        }
        return list;
    }

    public static String generateUniqueFileName(Context context, String baseName) {
        File dir = getHistoryDir(context);
        String name = baseName;
        int count = 1;
        while (new File(dir, name + ".png").exists()) {
            name = baseName + " (" + count + ")";
            count++;
        }
        return name;
    }

    public static String saveToHistory(Context context, Bitmap bitmap, String targetFilePath) {
        try {
            File file;
            if (targetFilePath != null && !targetFilePath.isEmpty()) {
                file = new File(targetFilePath);
            } else {
                String name = generateUniqueFileName(context, "未命名图片");
                file = new File(getHistoryDir(context), name + ".png");
            }
            FileOutputStream fos = new FileOutputStream(file);
            boolean success = bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
            if (success && file.exists() && file.length() > 0) return file.getAbsolutePath();
            return null;
        } catch (Throwable e) { return null; }
    }

    public static boolean renameFile(Context context, File oldFile, String newName) {
        File dir = getHistoryDir(context);
        File newFile = new File(dir, newName + ".png");
        if (newFile.exists()) return false;

        boolean ok = oldFile.renameTo(newFile);
        if (ok) {
            File oldSteps = getStepsDir(context, oldFile.getName());
            File newSteps = getStepsDir(context, newFile.getName());
            if (oldSteps.exists() && oldSteps.isDirectory()) oldSteps.renameTo(newSteps);

            File oldBase = new File(getBaseDir(context), oldFile.getName());
            File newBase = new File(getBaseDir(context), newFile.getName());
            if (oldBase.exists()) oldBase.renameTo(newBase);

            File oldCover = new File(getCoverDir(context), oldFile.getName());
            File newCover = new File(getCoverDir(context), newFile.getName());
            if (oldCover.exists()) oldCover.renameTo(newCover);

            File oldOrig = new File(getOriginalDir(context), oldFile.getName());
            File newOrig = new File(getOriginalDir(context), newFile.getName());
            if (oldOrig.exists()) oldOrig.renameTo(newOrig);
        }
        return ok;
    }

    public static Bitmap decodeSampledBitmap(String filePath, int reqWidth, int reqHeight) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, options);
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try {
            return BitmapFactory.decodeFile(filePath, options);
        } catch (Throwable e) { return null; }
    }

    private static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    public static boolean copyHistoryItem(Context context, File srcFile, String newName) {
        try {
            File dir = getHistoryDir(context);
            File newFile = new File(dir, newName + ".png");
            if (newFile.exists()) return false;

            copyFile(srcFile, newFile);

            File srcBase = new File(getBaseDir(context), srcFile.getName());
            File destBase = new File(getBaseDir(context), newFile.getName());
            if (srcBase.exists()) {
                copyFile(srcBase, destBase);
            } else {
                copyFile(srcFile, destBase);
            }

            File srcCover = new File(getCoverDir(context), srcFile.getName());
            File destCover = new File(getCoverDir(context), newFile.getName());
            if (srcCover.exists()) {
                copyFile(srcCover, destCover);
            }

            File srcOrig = new File(getOriginalDir(context), srcFile.getName());
            File destOrig = new File(getOriginalDir(context), newFile.getName());
            if (srcOrig.exists()) {
                copyFile(srcOrig, destOrig);
            }

            File srcSteps = getStepsDir(context, srcFile.getName());
            File destSteps = getStepsDir(context, newFile.getName());
            if (srcSteps.exists() && srcSteps.isDirectory()) {
                File[] steps = srcSteps.listFiles();
                if (steps != null) for (File s : steps) copyFile(s, new File(destSteps, s.getName()));
            }

            SharedPreferences sp = context.getSharedPreferences("weifp_filters", Context.MODE_PRIVATE);
            String srcKey = srcFile.getAbsolutePath();
            String destKey = newFile.getAbsolutePath();
            Map<String, ?> allEntries = sp.getAll();
            SharedPreferences.Editor editor = sp.edit();
            String[] suffixList = {"_bright", "_cont", "_sat", "_shadow", "_high", "_temp", "_tint", "_sharp", "_lut_m", "_lut_r", "_lut_g", "_lut_b", "_pts_m", "_pts_r", "_pts_g", "_pts_b", "_vibrance", "_split_sh_hue", "_split_sh_sat", "_split_hi_hue", "_split_hi_sat"};
            for (String suffix : suffixList) {
                String sKey = srcKey + suffix;
                if (allEntries.containsKey(sKey)) {
                    Object val = allEntries.get(sKey);
                    if (val instanceof Float) editor.putFloat(destKey + suffix, (Float) val);
                    else if (val instanceof String) editor.putString(destKey + suffix, (String) val);
                }
            }
            String srcBalKey = srcKey + "_split_bal";
            if (allEntries.containsKey(srcBalKey) && allEntries.get(srcBalKey) instanceof Integer) {
                editor.putInt(destKey + "_split_bal", (Integer) allEntries.get(srcBalKey));
            }
            for (int i = 0; i < 8; i++) {
                String hk = srcKey + "_hsl_hue_" + i;
                String sk = srcKey + "_hsl_sat_" + i;
                String lk = srcKey + "_hsl_lum_" + i;
                if (allEntries.containsKey(hk)) editor.putFloat(destKey + "_hsl_hue_" + i, (Float) allEntries.get(hk));
                if (allEntries.containsKey(sk)) editor.putFloat(destKey + "_hsl_sat_" + i, (Float) allEntries.get(sk));
                if (allEntries.containsKey(lk)) editor.putFloat(destKey + "_hsl_lum_" + i, (Float) allEntries.get(lk));
            }
            if (sp.getBoolean(srcKey + "_has_wpb", false)) editor.putBoolean(destKey + "_has_wpb", true);
            if (sp.getBoolean(srcKey + "_is_raw", false)) editor.putBoolean(destKey + "_is_raw", true);

            editor.apply();
            return true;
        } catch (Throwable e) { return false; }
    }

    public static List<File> getSortedStepFiles(File stepsDir) {
        List<File> list = new ArrayList<>();
        if (stepsDir.exists() && stepsDir.isDirectory()) {
            File[] files = stepsDir.listFiles();
            if (files != null) {
                for (File f : files) {
                    if (f.isFile() && isStepImageName(f.getName())
                        && !f.getName().contains("_layer_")) {
                        list.add(f);
                    }
                }
                Collections.sort(list, new Comparator<File>() {
                        @Override public int compare(File f1, File f2) {
                            return Long.compare(f2.lastModified(), f1.lastModified());
                        }
                    });
            }
        }
        return list;
    }

    /** 步骤图名 -> 对应的 .wpb 名（兼容 .png 和 .webp）。 */
    public static String toWpbName(String stepFileName) {
        return stripStepExt(stepFileName) + ".wpb";
    }

    /** 去掉步骤图的扩展名（.png 或 .webp）。 */
    public static String stripStepExt(String name) {
        if (name == null) return "";
        if (name.endsWith(".webp")) return name.substring(0, name.length() - 5);
        if (name.endsWith(".png")) return name.substring(0, name.length() - 4);
        return name;
    }

    /** 步骤图文件名：.png（旧）或 .webp（新）都算。 */
    public static boolean isStepImageName(String name) {
        if (name == null || !name.startsWith("step_")) return false;
        return name.endsWith(".png") || name.endsWith(".webp");
    }

    public static boolean hasWpbSteps(Context context, String fileName) {
        File stepsDir = getStepsDir(context, fileName);
        if (!stepsDir.exists()) return false;
        File[] files = stepsDir.listFiles();
        if (files != null) {
            for (File f : files) if (f.getName().endsWith(".wpb")) return true;
        }
        return false;
    }

    public static void saveStepWpb(Context context, File stepsDir, String stepPngName,
                                   float bright, float cont, float sat,
                                   float shadow, float high, float temp, float tint, float sharp,
                                   String lutM, String lutR, String lutG, String lutB,
                                   String ptsM, String ptsR, String ptsG, String ptsB,
                                   float[] cropRatio, boolean isRaw,
                                   String layerData, String hslData) {
        try {
            if (stepsDir == null) return;
            if (!stepsDir.exists()) stepsDir.mkdirs();
            String wpbName = toWpbName(stepPngName);
            File wpbFile = new File(stepsDir, wpbName);
            StringBuilder sb = new StringBuilder();
            sb.append("bright=").append(bright).append("\n");
            sb.append("cont=").append(cont).append("\n");
            sb.append("sat=").append(sat).append("\n");
            sb.append("shadow=").append(shadow).append("\n");
            sb.append("high=").append(high).append("\n");
            sb.append("temp=").append(temp).append("\n");
            sb.append("tint=").append(tint).append("\n");
            sb.append("sharp=").append(sharp).append("\n");
            if (lutM != null) sb.append("lut_m=").append(lutM).append("\n");
            if (lutR != null) sb.append("lut_r=").append(lutR).append("\n");
            if (lutG != null) sb.append("lut_g=").append(lutG).append("\n");
            if (lutB != null) sb.append("lut_b=").append(lutB).append("\n");
            if (ptsM != null) sb.append("pts_m=").append(ptsM).append("\n");
            if (ptsR != null) sb.append("pts_r=").append(ptsR).append("\n");
            if (ptsG != null) sb.append("pts_g=").append(ptsG).append("\n");
            if (ptsB != null) sb.append("pts_b=").append(ptsB).append("\n");
            if (cropRatio != null && cropRatio.length == 4) {
                sb.append("crop_l=").append(cropRatio[0]).append("\n");
                sb.append("crop_t=").append(cropRatio[1]).append("\n");
                sb.append("crop_r=").append(cropRatio[2]).append("\n");
                sb.append("crop_b=").append(cropRatio[3]).append("\n");
            }
            sb.append("is_raw=").append(isRaw ? "1" : "0").append("\n");
            if (layerData != null && layerData.length() > 0) {
                sb.append(layerData);
                if (!layerData.endsWith("\n")) sb.append("\n");
            }
            if (hslData != null && hslData.length() > 0) {
                sb.append(hslData);
                if (!hslData.endsWith("\n")) sb.append("\n");
            }
            FileOutputStream fos = new FileOutputStream(wpbFile);
            fos.write(sb.toString().getBytes("UTF-8"));
            fos.close();
        } catch (Throwable e) {}
    }

    public static Map<String, String> readStepWpb(File stepsDir, String stepPngName) {
        Map<String, String> map = new HashMap<>();
        try {
            if (stepsDir == null) return map;
            String wpbName = toWpbName(stepPngName);
            File wpbFile = new File(stepsDir, wpbName);
            if (!wpbFile.exists()) return map;
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(wpbFile), "UTF-8"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=", 2);
                if (parts.length == 2) map.put(parts[0], parts[1]);
            }
            reader.close();
        } catch (Throwable e) {}
        return map;
    }

    public static boolean rollbackToVersion(Context context, String currentImagePath, File versionFile) {
        try {
            File currentImage = new File(currentImagePath);
            copyFile(versionFile, currentImage);

            File baseImage = new File(getBaseDir(context), currentImage.getName());
            copyFile(versionFile, baseImage);

            try {
                File coverFile = new File(getCoverDir(context), currentImage.getName());
                if (coverFile.exists()) coverFile.delete();
            } catch (Throwable e) {}

            SharedPreferences sp = context.getSharedPreferences("weifp_filters", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.remove(currentImagePath + "_bright")
                .remove(currentImagePath + "_cont").remove(currentImagePath + "_sat")
                .remove(currentImagePath + "_shadow").remove(currentImagePath + "_high")
                .remove(currentImagePath + "_temp").remove(currentImagePath + "_tint")
                .remove(currentImagePath + "_sharp").remove(currentImagePath + "_lut_m")
                .remove(currentImagePath + "_lut_r").remove(currentImagePath + "_lut_g")
                .remove(currentImagePath + "_lut_b").remove(currentImagePath + "_pts_m")
                .remove(currentImagePath + "_pts_r").remove(currentImagePath + "_pts_g")
                .remove(currentImagePath + "_pts_b").remove(currentImagePath + "_is_raw")
                .remove(currentImagePath + "_layer_data").remove(currentImagePath + "_vibrance")
                .remove(currentImagePath + "_split_sh_hue").remove(currentImagePath + "_split_sh_sat")
                .remove(currentImagePath + "_split_hi_hue").remove(currentImagePath + "_split_hi_sat")
                .remove(currentImagePath + "_split_bal").remove(currentImagePath + "_has_wpb")
                .remove(currentImagePath + "_current_layer");
            for (int i = 0; i < 8; i++) {
                editor.remove(currentImagePath + "_hsl_hue_" + i);
                editor.remove(currentImagePath + "_hsl_sat_" + i);
                editor.remove(currentImagePath + "_hsl_lum_" + i);
            }

            File stepsDir = getStepsDir(context, currentImage.getName());

            try {
                String stepPrefix = stripStepExt(versionFile.getName());
                File[] allFiles = stepsDir.listFiles();
                if (allFiles != null) {
                    for (File f : allFiles) {
                        String n = f.getName();
                        if (n.startsWith("layer_") && n.endsWith(".png")) {
                            f.delete();
                        }
                    }
                    for (File f : allFiles) {
                        String n = f.getName();
                        String marker = stepPrefix + "_layer_";
                        if (n.startsWith(marker) && n.endsWith(".png")) {
                            String newName = n.substring(stepPrefix.length() + 1);
                            copyFile(f, new File(stepsDir, newName));
                        }
                    }
                }
            } catch (Throwable e) {}

            Map<String, String> wpb = readStepWpb(stepsDir, versionFile.getName());
            if (!wpb.isEmpty()) {
                try { editor.putFloat(currentImagePath + "_bright", Float.parseFloat(wpb.get("bright"))); } catch (Throwable ignored) {}
                try { editor.putFloat(currentImagePath + "_cont", Float.parseFloat(wpb.get("cont"))); } catch (Throwable ignored) {}
                try { editor.putFloat(currentImagePath + "_sat", Float.parseFloat(wpb.get("sat"))); } catch (Throwable ignored) {}
                try { editor.putFloat(currentImagePath + "_shadow", Float.parseFloat(wpb.get("shadow"))); } catch (Throwable ignored) {}
                try { editor.putFloat(currentImagePath + "_high", Float.parseFloat(wpb.get("high"))); } catch (Throwable ignored) {}
                try { editor.putFloat(currentImagePath + "_temp", Float.parseFloat(wpb.get("temp"))); } catch (Throwable ignored) {}
                try { editor.putFloat(currentImagePath + "_tint", Float.parseFloat(wpb.get("tint"))); } catch (Throwable ignored) {}
                try { editor.putFloat(currentImagePath + "_sharp", Float.parseFloat(wpb.get("sharp"))); } catch (Throwable ignored) {}
                if (wpb.containsKey("lut_m")) editor.putString(currentImagePath + "_lut_m", wpb.get("lut_m"));
                if (wpb.containsKey("lut_r")) editor.putString(currentImagePath + "_lut_r", wpb.get("lut_r"));
                if (wpb.containsKey("lut_g")) editor.putString(currentImagePath + "_lut_g", wpb.get("lut_g"));
                if (wpb.containsKey("lut_b")) editor.putString(currentImagePath + "_lut_b", wpb.get("lut_b"));
                if (wpb.containsKey("pts_m")) editor.putString(currentImagePath + "_pts_m", wpb.get("pts_m"));
                if (wpb.containsKey("pts_r")) editor.putString(currentImagePath + "_pts_r", wpb.get("pts_r"));
                if (wpb.containsKey("pts_g")) editor.putString(currentImagePath + "_pts_g", wpb.get("pts_g"));
                if (wpb.containsKey("pts_b")) editor.putString(currentImagePath + "_pts_b", wpb.get("pts_b"));
                if ("1".equals(wpb.get("is_raw"))) editor.putBoolean(currentImagePath + "_is_raw", true);
                for (int i = 0; i < 8; i++) {
                    String hk = "hsl_hue_" + i, sk = "hsl_sat_" + i, lk = "hsl_lum_" + i;
                    try { if (wpb.containsKey(hk)) editor.putFloat(currentImagePath + "_hsl_hue_" + i, Float.parseFloat(wpb.get(hk))); } catch (Throwable ignored) {}
                    try { if (wpb.containsKey(sk)) editor.putFloat(currentImagePath + "_hsl_sat_" + i, Float.parseFloat(wpb.get(sk))); } catch (Throwable ignored) {}
                    try { if (wpb.containsKey(lk)) editor.putFloat(currentImagePath + "_hsl_lum_" + i, Float.parseFloat(wpb.get(lk))); } catch (Throwable ignored) {}
                }
                StringBuilder lb = new StringBuilder();
                for (Map.Entry<String, String> en : wpb.entrySet()) {
                    String k = en.getKey();
                    if (k.startsWith("layer_")) lb.append(k).append("=").append(en.getValue()).append("\n");
                }
                if (lb.length() > 0) editor.putString(currentImagePath + "_layer_data", lb.toString());
                editor.putBoolean(currentImagePath + "_has_wpb", true);
            }
            editor.apply();

            if (!stepsDir.exists()) stepsDir.mkdirs();
            File newStep = new File(stepsDir, "step_" + System.currentTimeMillis() + "_rollback.png");
            copyFile(versionFile, newStep);

            File srcWpb = new File(versionFile.getParent(), versionFile.getName().replace(".png", ".wpb"));
            if (srcWpb.exists()) {
                File dstWpb = new File(stepsDir, toWpbName(newStep.getName()));
                copyFile(srcWpb, dstWpb);
            }

            try {
                Bitmap stepBmp = BitmapFactory.decodeFile(versionFile.getAbsolutePath());
                if (stepBmp != null) {
                    Bitmap cover = applyFiltersToThumbnail(context, stepBmp, currentImagePath);
                    if (cover != null) {
                        saveCoverBitmap(context, currentImagePath, cover);
                    }
                    if (cover != null && cover != stepBmp && !cover.isRecycled()) cover.recycle();
                    if (!stepBmp.isRecycled()) stepBmp.recycle();
                }
            } catch (Throwable e) {}

            return true;
        } catch (Throwable e) { return false; }
    }

    public static boolean importWp(Context context, Uri uri, String defaultName) {
        try {
            String newName = generateUniqueFileName(context, defaultName);
            File destImage = new File(getHistoryDir(context), newName + ".png");
            File destBase = new File(getBaseDir(context), newName + ".png");
            File destCover = new File(getCoverDir(context), newName + ".png");
            File destSteps = getStepsDir(context, newName + ".png");

            SharedPreferences.Editor editor = context.getSharedPreferences("weifp_filters", Context.MODE_PRIVATE).edit();

            InputStream is = context.getContentResolver().openInputStream(uri);
            ZipInputStream zis = new ZipInputStream(is);
            ZipEntry entry;
            byte[] buffer = new byte[8192];

            while ((entry = zis.getNextEntry()) != null) {
                String entryName = entry.getName();
                if (entryName.equals("image.png")) {
                    FileOutputStream fos = new FileOutputStream(destImage);
                    int len; while ((len = zis.read(buffer)) > 0) fos.write(buffer, 0, len);
                    fos.close();
                } else if (entryName.equals("base.png")) {
                    FileOutputStream fos = new FileOutputStream(destBase);
                    int len; while ((len = zis.read(buffer)) > 0) fos.write(buffer, 0, len);
                    fos.close();
                } else if (entryName.equals("cover.png")) {
                    FileOutputStream fos = new FileOutputStream(destCover);
                    int len; while ((len = zis.read(buffer)) > 0) fos.write(buffer, 0, len);
                    fos.close();
                } else if (entryName.startsWith("steps/")
                        && (entryName.endsWith(".png") || entryName.endsWith(".webp")
                            || entryName.endsWith(".wpb"))) {
                    if (!destSteps.exists()) destSteps.mkdirs();
                    File stepFile = new File(destSteps, entryName.substring(6));
                    FileOutputStream fos = new FileOutputStream(stepFile);
                    int len; while ((len = zis.read(buffer)) > 0) fos.write(buffer, 0, len);
                    fos.close();
                } else if (entryName.equals("params.txt")) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(zis));
                    String line;
                    String destKey = destImage.getAbsolutePath();
                    while ((line = reader.readLine()) != null) {
                        String[] parts = line.split("=", 2);
                        if (parts.length == 2) {
                            try {
                                if (parts[0].startsWith("lut_") || parts[0].startsWith("pts_")) {
                                    editor.putString(destKey + "_" + parts[0], parts[1]);
                                } else {
                                    float val = Float.parseFloat(parts[1]);
                                    editor.putFloat(destKey + "_" + parts[0], val);
                                }
                            } catch (Throwable ignored) {}
                        }
                    }
                }
            }
            zis.close();
            is.close();
            editor.apply();
            return true;
        } catch (Throwable e) { return false; }
    }

    // ★ #2：主图数据图 + layer_data.txt + step 快照
    public static boolean importWpc(Context context, Uri uri, String defaultName) {
        try {
            String newName = generateUniqueFileName(context, defaultName);
            File destImage = new File(getHistoryDir(context), newName + ".png");
            File destBase = new File(getBaseDir(context), newName + ".png");
            File destSteps = getStepsDir(context, newName + ".png");
            if (!destSteps.exists()) destSteps.mkdirs();

            SharedPreferences.Editor editor = context.getSharedPreferences("weifp_filters", Context.MODE_PRIVATE).edit();

            InputStream is = context.getContentResolver().openInputStream(uri);
            ZipInputStream zis = new ZipInputStream(is);
            ZipEntry entry;
            byte[] buffer = new byte[8192];

            java.util.List<File> stepPngs = new java.util.ArrayList<File>();
            boolean hasMainImage = false;
            String layerData = null;

            while ((entry = zis.getNextEntry()) != null) {
                String entryName = entry.getName();

                if (entryName.equals("image.png")) {
                    FileOutputStream fos = new FileOutputStream(destImage);
                    int len; while ((len = zis.read(buffer)) > 0) fos.write(buffer, 0, len);
                    fos.close();
                    hasMainImage = true;
                    continue;
                }

                if (entryName.equals("layer_data.txt")) {
                    java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                    int len; while ((len = zis.read(buffer)) > 0) baos.write(buffer, 0, len);
                    layerData = baos.toString("UTF-8");
                    continue;
                }

                if (entryName.endsWith(".png") || entryName.endsWith(".jpg")
                        || entryName.endsWith(".webp") || entryName.endsWith(".wpb")) {
                    File f = new File(destSteps, entryName);
                    FileOutputStream fos = new FileOutputStream(f);
                    int len; while ((len = zis.read(buffer)) > 0) fos.write(buffer, 0, len);
                    fos.close();
                    if (isStepImageName(new File(entryName).getName())
                        && !entryName.contains("_layer_")) {
                        stepPngs.add(f);
                    }
                }
            }
            zis.close();
            is.close();

            java.util.Collections.sort(stepPngs, new java.util.Comparator<File>() {
                    @Override public int compare(File a, File b) { return a.getName().compareTo(b.getName()); }
                });

            if (!hasMainImage) {
                if (stepPngs.isEmpty()) return false;
                File latestStep = stepPngs.get(stepPngs.size() - 1);
                copyFile(latestStep, destImage);
                copyFile(latestStep, destBase);
            } else {
                copyFile(destImage, destBase);
            }

            try {
                File coverFile = new File(getCoverDir(context), newName + ".png");
                copyFile(destImage, coverFile);
            } catch (Throwable e) {}

            if (layerData != null && layerData.length() > 0) {
                editor.putString(destImage.getAbsolutePath() + "_layer_data", layerData);
            }

            try {
                if (!stepPngs.isEmpty()) {
                    String latestPrefix = stepPngs.get(stepPngs.size() - 1).getName().replace(".png", "");
                    File[] allFiles = destSteps.listFiles();
                    if (allFiles != null) {
                        for (File f : allFiles) {
                            if (f.getName().startsWith("layer_") && f.getName().endsWith(".png")) {
                                f.delete();
                            }
                        }
                        for (File f : allFiles) {
                            String n = f.getName();
                            String marker = latestPrefix + "_layer_";
                            if (n.startsWith(marker) && n.endsWith(".png")) {
                                String baseName = n.substring(latestPrefix.length() + 1);
                                copyFile(f, new File(destSteps, baseName));
                            }
                        }
                    }
                }
            } catch (Throwable e) {}

            editor.apply();
            return true;
        } catch (Throwable e) { return false; }
    }

    // ★ #2：打包主图数据图 + layer_data.txt + step
    public static File createTempWpc(Context context, File srcFile) {
        try {
            File stepsDir = getStepsDir(context, srcFile.getName());
            if (!stepsDir.exists() || stepsDir.listFiles() == null || stepsDir.listFiles().length == 0) return null;

            File tempFile = new File(context.getCacheDir(), srcFile.getName().replace(".png", ".wpc"));
            ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(tempFile));

            addFileToZip(zos, srcFile, "image.png");

            SharedPreferences sp = context.getSharedPreferences("weifp_filters", Context.MODE_PRIVATE);
            String layerData = sp.getString(srcFile.getAbsolutePath() + "_layer_data", null);
            if (layerData != null && layerData.length() > 0) {
                ZipEntry layerEntry = new ZipEntry("layer_data.txt");
                zos.putNextEntry(layerEntry);
                zos.write(layerData.getBytes("UTF-8"));
                zos.closeEntry();
            }

            File[] steps = stepsDir.listFiles();
            if (steps != null) {
                for (File step : steps) {
                    String name = step.getName();
                    boolean isStep = isStepImageName(name) || name.endsWith(".wpb");
                    if (isStep) {
                        addFileToZip(zos, step, name);
                    }
                }
            }
            zos.close();
            return tempFile;
        } catch (Throwable e) { return null; }
    }

    public static File createTempWp(Context context, File srcFile) {
        try {
            File tempFile = new File(context.getCacheDir(), srcFile.getName().replace(".png", ".wp"));
            ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(tempFile));
            zos.setLevel(Deflater.BEST_COMPRESSION);

            addFileToZip(zos, srcFile, "image.png");

            File baseFile = new File(getBaseDir(context), srcFile.getName());
            if (baseFile.exists()) addFileToZip(zos, baseFile, "base.png");

            File coverFile = new File(getCoverDir(context), srcFile.getName());
            if (coverFile.exists()) addFileToZip(zos, coverFile, "cover.png");

            SharedPreferences sp = context.getSharedPreferences("weifp_filters", Context.MODE_PRIVATE);
            StringBuilder sb = new StringBuilder();
            String pathKey = srcFile.getAbsolutePath();

            String[] floatKeys = {"bright", "cont", "sat", "shadow", "high", "temp", "tint", "sharp", "vibrance", "split_sh_hue", "split_sh_sat", "split_hi_hue", "split_hi_sat"};
            for (String key : floatKeys) {
                sb.append(key).append("=").append(sp.getFloat(pathKey + "_" + key, 0f)).append("\n");
            }
            String[] strKeys = {"lut_m", "lut_r", "lut_g", "lut_b", "pts_m", "pts_r", "pts_g", "pts_b"};
            for (String key : strKeys) {
                String val = sp.getString(pathKey + "_" + key, null);
                if (val != null) sb.append(key).append("=").append(val).append("\n");
            }

            ZipEntry entry = new ZipEntry("params.txt");
            zos.putNextEntry(entry);
            zos.write(sb.toString().getBytes());
            zos.closeEntry();

            File stepsDir = getStepsDir(context, srcFile.getName());
            File[] steps = stepsDir.listFiles();
            if (steps != null) {
                for (File step : steps) {
                    if (step.getName().startsWith("step_")
                        && (isStepImageName(step.getName()) || step.getName().endsWith(".wpb"))) {
                        addFileToZip(zos, step, "steps/" + step.getName());
                    }
                }
            }

            zos.close();
            return tempFile;
        } catch (Throwable e) { return null; }
    }

    public static void renameTempSteps(Context context, File tempDir, String newFilePath) {
        try {
            if (tempDir == null || !tempDir.exists() || !tempDir.isDirectory()) return;
            File dest = getStepsDir(context, new File(newFilePath).getName());
            if (tempDir.getAbsolutePath().equals(dest.getAbsolutePath())) return;

            File[] steps = tempDir.listFiles();
            if (steps != null) {
                for (File s : steps) {
                    if (s.isFile()) copyFile(s, new File(dest, s.getName()));
                }
            }
            if (steps != null) for (File s : steps) s.delete();
            tempDir.delete();
        } catch (Throwable e) {}
    }

    private static void copyFile(File src, File dst) throws Exception {
        FileInputStream in = new FileInputStream(src);
        FileOutputStream out = new FileOutputStream(dst);
        byte[] buf = new byte[8192];
        int len;
        while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
        in.close();
        out.close();
    }

    private static void addFileToZip(ZipOutputStream zos, File file, String entryName) throws Exception {
        FileInputStream fis = new FileInputStream(file);
        ZipEntry zipEntry = new ZipEntry(entryName);
        zos.putNextEntry(zipEntry);
        byte[] buf = new byte[8192];
        int len;
        while ((len = fis.read(buf)) > 0) zos.write(buf, 0, len);
        zos.closeEntry();
        fis.close();
    }

    public static Bitmap applyFiltersToThumbnail(Context context, Bitmap src, String filePath) {
        if (src == null || src.isRecycled()) return src;

        SharedPreferences sp = context.getSharedPreferences("weifp_filters", Context.MODE_PRIVATE);
        float brightness = sp.getFloat(filePath + "_bright", 0);
        float contrast = sp.getFloat(filePath + "_cont", 1);
        float saturation = sp.getFloat(filePath + "_sat", 1);
        float shadows = sp.getFloat(filePath + "_shadow", 0);
        float highlights = sp.getFloat(filePath + "_high", 0);
        float temperature = sp.getFloat(filePath + "_temp", 0);
        float tint = sp.getFloat(filePath + "_tint", 0);
        float vibrance = sp.getFloat(filePath + "_vibrance", 0);

        String lutM = sp.getString(filePath + "_lut_m", null);
        String lutR = sp.getString(filePath + "_lut_r", null);
        String lutG = sp.getString(filePath + "_lut_g", null);
        String lutB = sp.getString(filePath + "_lut_b", null);

        SplitToning st = new SplitToning();
        st.shadowHue = sp.getFloat(filePath + "_split_sh_hue", 0);
        st.shadowSat = sp.getFloat(filePath + "_split_sh_sat", 0);
        st.highlightHue = sp.getFloat(filePath + "_split_hi_hue", 0);
        st.highlightSat = sp.getFloat(filePath + "_split_hi_sat", 0);
        st.balance = sp.getInt(filePath + "_split_bal", 0);

        HslAdjust hsl = new HslAdjust();
        for (int i = 0; i < 8; i++) {
            hsl.hue[i] = sp.getFloat(filePath + "_hsl_hue_" + i, 0f);
            hsl.sat[i] = sp.getFloat(filePath + "_hsl_sat_" + i, 0f);
            hsl.lum[i] = sp.getFloat(filePath + "_hsl_lum_" + i, 0f);
        }
        hsl.isEmpty();

        String cubePath = sp.getString(filePath + "_cube_path", null);
        float cubeStrength = sp.getFloat(filePath + "_cube_strength", 1.0f);
        CubeLut cubeLut = null;
        if (cubePath != null) {
            File f = new File(cubePath);
            if (f.exists()) cubeLut = LutManager.loadLut(f);
        }

        boolean hasFilter = brightness != 0 || contrast != 1 || saturation != 1
            || shadows != 0 || highlights != 0 || temperature != 0 || tint != 0;
        boolean hasLut = lutM != null || lutR != null || lutG != null || lutB != null;
        boolean hasSplit = !st.isEmpty();
        boolean hasHsl = !hsl.isEmpty();
        boolean hasCube = cubeLut != null && cubeStrength > 0f;
        boolean hasVib = vibrance != 0f;

        if (!hasFilter && !hasLut && !hasSplit && !hasHsl && !hasCube && !hasVib) return src;

        try {
            Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(out);
            Paint p = new Paint();
            if (hasFilter) {
                ColorMatrix cm = new ColorMatrix();
                float bAdd = brightness * 2.55f;
                float bScale = 1.0f;
                if (brightness > 0) bScale = 1.0f + (brightness / 100.0f);
                float[] bm = {bScale, 0, 0, 0, bAdd, 0, bScale, 0, 0, bAdd, 0, 0, bScale, 0, bAdd, 0, 0, 0, 1, 0};
                cm.postConcat(new ColorMatrix(bm));
                float t = (1 - contrast) * 128;
                float[] cmx = {contrast, 0, 0, 0, t, 0, contrast, 0, 0, t, 0, 0, contrast, 0, t, 0, 0, 0, 1, 0};
                cm.postConcat(new ColorMatrix(cmx));
                float sr = (1 - saturation) * 0.3086f, sg = (1 - saturation) * 0.6094f, sb = (1 - saturation) * 0.0820f;
                float[] sm = {sr + saturation, sg, sb, 0, 0, sr, sg + saturation, sb, 0, 0, sr, sg, sb + saturation, 0, 0, 0, 0, 0, 1, 0};
                cm.postConcat(new ColorMatrix(sm));
                float so = shadows * 0.5f;
                float[] shm = {1, 0, 0, 0, so, 0, 1, 0, 0, so, 0, 0, 1, 0, so, 0, 0, 0, 1, 0};
                cm.postConcat(new ColorMatrix(shm));
                float ho = highlights * 0.5f;
                float[] hm = {1, 0, 0, 0, ho, 0, 1, 0, 0, ho, 0, 0, 1, 0, ho, 0, 0, 0, 1, 0};
                cm.postConcat(new ColorMatrix(hm));
                float tR = temperature * 0.5f, tB2 = -temperature * 0.5f;
                float[] tm = {1, 0, 0, 0, tR, 0, 1, 0, 0, 0, 0, 0, 1, 0, tB2, 0, 0, 0, 1, 0};
                cm.postConcat(new ColorMatrix(tm));
                float tG = -tint * 0.5f, tM = tint * 0.5f;
                float[] tim = {1, 0, 0, 0, tM, 0, 1, 0, 0, tG, 0, 0, 1, 0, tM, 0, 0, 0, 1, 0};
                cm.postConcat(new ColorMatrix(tim));
                p.setColorFilter(new ColorMatrixColorFilter(cm));
            }
            canvas.drawBitmap(src, 0, 0, p);

            if (hasLut || hasSplit || hasHsl || hasCube || hasVib) {
                int w = out.getWidth(), h = out.getHeight();
                int[] px = new int[w * h];
                out.getPixels(px, 0, w, 0, 0, w, h);
                int[] mArr = stringToLut(lutM), rArr = stringToLut(lutR), gArr = stringToLut(lutG), bArr = stringToLut(lutB);
                for (int i = 0; i < px.length; i++) {
                    int c = px[i];
                    int a = (c >> 24) & 0xFF;
                    int cr = (c >> 16) & 0xFF, cg = (c >> 8) & 0xFF, cb = c & 0xFF;
                    if (mArr != null) { cr = mArr[cr]; cg = mArr[cg]; cb = mArr[cb]; }
                    if (rArr != null) cr = rArr[cr];
                    if (gArr != null) cg = gArr[cg];
                    if (bArr != null) cb = bArr[cb];
                    if (vibrance != 0f) {
                        float vf = vibrance / 100f;
                        float rf2 = cr / 255f, gf2 = cg / 255f, bf2 = cb / 255f;
                        float mx = Math.max(rf2, Math.max(gf2, bf2));
                        float mn = Math.min(rf2, Math.min(gf2, bf2));
                        float sat = (mx > 0.001f) ? (mx - mn) / mx : 0f;
                        float boost = vf * (1f - sat);
                        float lum = 0.2126f * rf2 + 0.7152f * gf2 + 0.0722f * bf2;
                        rf2 = lum + (rf2 - lum) * (1f + boost);
                        gf2 = lum + (gf2 - lum) * (1f + boost);
                        bf2 = lum + (bf2 - lum) * (1f + boost);
                        int nr2 = (int)(rf2 * 255f), ng2 = (int)(gf2 * 255f), nb2 = (int)(bf2 * 255f);
                        if (nr2 < 0) nr2 = 0; if (nr2 > 255) nr2 = 255;
                        if (ng2 < 0) ng2 = 0; if (ng2 > 255) ng2 = 255;
                        if (nb2 < 0) nb2 = 0; if (nb2 > 255) nb2 = 255;
                        cr = nr2; cg = ng2; cb = nb2;
                    }
                    if (hasSplit) {
                        int o = st.applyPixel(cr, cg, cb);
                        cr = (o >> 16) & 0xFF; cg = (o >> 8) & 0xFF; cb = o & 0xFF;
                    }
                    if (hasHsl) {
                        int o = hsl.applyPixel(cr, cg, cb);
                        cr = (o >> 16) & 0xFF; cg = (o >> 8) & 0xFF; cb = o & 0xFF;
                    }
                    if (hasCube) {
                        int o = cubeLut.applyPixel(cr, cg, cb, cubeStrength);
                        cr = (o >> 16) & 0xFF; cg = (o >> 8) & 0xFF; cb = o & 0xFF;
                    }
                    px[i] = (a << 24) | (cr << 16) | (cg << 8) | cb;
                }
                out.setPixels(px, 0, w, 0, 0, w, h);
            }
            return out;
        } catch (Throwable e) { return src; }
    }
    
    // ★ 统一删除：文件 + SP 里的所有参数
    public static void deleteHistoryItem(Context context, File file) {
        if (file == null) return;
        String fileName = file.getName();
        String filePath = file.getAbsolutePath();

        if (file.exists()) file.delete();

        File baseFile = new File(getBaseDir(context), fileName);
        if (baseFile.exists()) baseFile.delete();

        File coverFile = new File(getCoverDir(context), fileName);
        if (coverFile.exists()) coverFile.delete();

        File origFile = new File(getOriginalDir(context), fileName);
        if (origFile.exists()) origFile.delete();

        File stepsDir = getStepsDir(context, fileName);
        if (stepsDir.exists() && stepsDir.isDirectory()) {
            File[] files = stepsDir.listFiles();
            if (files != null) for (File f : files) f.delete();
            stepsDir.delete();
        }

        // ★ 清理 SharedPreferences 里所有以 filePath + "_" 开头的键
        try {
            SharedPreferences sp = context.getSharedPreferences("weifp_filters", Context.MODE_PRIVATE);
            Map<String, ?> all = sp.getAll();
            String prefix = filePath + "_";
            SharedPreferences.Editor ed = sp.edit();
            boolean needApply = false;
            for (String key : all.keySet()) {
                if (key.startsWith(prefix)) {
                    ed.remove(key);
                    needApply = true;
                }
            }
            if (needApply) ed.apply();
        } catch (Throwable e) {}
    }
    
    
    

    private static int[] stringToLut(String str) {
        if (str == null) return null;
        try {
            byte[] bytes = Base64.decode(str, Base64.NO_WRAP);
            int[] lut = new int[bytes.length];
            for (int i = 0; i < bytes.length; i++) lut[i] = bytes[i] & 0xFF;
            return lut;
        } catch (Throwable e) { return null; }
    }
}
