package com.sertrt.weifp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

public class HistogramView extends View {
    private int[] rData = new int[256];
    private int[] gData = new int[256];
    private int[] bData = new int[256];
    private float sqrtMaxR = 1f, sqrtMaxG = 1f, sqrtMaxB = 1f;

    private Paint rLine, gLine, bLine;
    private Paint rFill, gFill, bFill;
    private Paint borderPaint, bgPaint;
    private int maxValue = 1;
    private boolean hasData = false;

    public HistogramView(Context context) {
        super(context);
        init();
    }

    public HistogramView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        // 线条画笔：增加圆角转折，彻底消除锯齿感
        rLine = new Paint(); rLine.setColor(Color.rgb(255, 80, 80)); rLine.setStyle(Paint.Style.STROKE); rLine.setStrokeWidth(2.5f); rLine.setAntiAlias(true); rLine.setStrokeJoin(Paint.Join.ROUND); rLine.setStrokeCap(Paint.Cap.ROUND);
        gLine = new Paint(); gLine.setColor(Color.rgb(80, 255, 80)); gLine.setStyle(Paint.Style.STROKE); gLine.setStrokeWidth(2.5f); gLine.setAntiAlias(true); gLine.setStrokeJoin(Paint.Join.ROUND); gLine.setStrokeCap(Paint.Cap.ROUND);
        bLine = new Paint(); bLine.setColor(Color.rgb(80, 80, 255)); bLine.setStyle(Paint.Style.STROKE); bLine.setStrokeWidth(2.5f); bLine.setAntiAlias(true); bLine.setStrokeJoin(Paint.Join.ROUND); bLine.setStrokeCap(Paint.Cap.ROUND);

        rFill = new Paint(); rFill.setColor(Color.argb(60, 255, 80, 80)); rFill.setStyle(Paint.Style.FILL); rFill.setAntiAlias(true);
        gFill = new Paint(); gFill.setColor(Color.argb(60, 80, 255, 80)); gFill.setStyle(Paint.Style.FILL); gFill.setAntiAlias(true);
        bFill = new Paint(); bFill.setColor(Color.argb(60, 80, 80, 255)); bFill.setStyle(Paint.Style.FILL); bFill.setAntiAlias(true);

        borderPaint = new Paint(); borderPaint.setColor(Color.argb(80, 255, 255, 255)); borderPaint.setStyle(Paint.Style.STROKE); borderPaint.setStrokeWidth(2f);
        bgPaint = new Paint(); bgPaint.setColor(Color.argb(230, 20, 20, 20)); 
    }

    public void setBitmap(final Bitmap bitmap) {
        if (bitmap == null) return;

        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        if(w == 0 || h == 0) return;

        int[] pixels = new int[w * h];
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h);

        for (int i = 0; i < 256; i++) { rData[i] = 0; gData[i] = 0; bData[i] = 0; }

        // ★ 均匀网格采样，而不是"按一维下标跳跃"。
        //   原来用 i += step 跳跃，step 恰好整除图片宽度时会永远采到同一列，
        //   那一列的颜色分布被放大，别处的分布被漏掉 —— 直方图上表现为断层。
        int total = w * h;
        final int TARGET = 40000;
        if (total <= TARGET) {
            for (int i = 0; i < total; i++) {
                int c = pixels[i];
                rData[(c >> 16) & 0xFF]++;
                gData[(c >> 8) & 0xFF]++;
                bData[c & 0xFF]++;
            }
        } else {
            // 二维网格：按目标样本数算出每边采样间隔，保证横竖都覆盖到
            int stepPx = Math.max(1, (int) Math.round(Math.sqrt((double) total / TARGET)));
            for (int y = 0; y < h; y += stepPx) {
                int rowBase = y * w;
                for (int x = 0; x < w; x += stepPx) {
                    int c = pixels[rowBase + x];
                    rData[(c >> 16) & 0xFF]++;
                    gData[(c >> 8) & 0xFF]++;
                    bData[c & 0xFF]++;
                }
            }
        }

        // ★ 核心：双重平滑，把折角彻底抹平
        smoothData(rData);
        smoothData(gData);
        smoothData(bData);

        int maxR = 1, maxG = 1, maxB = 1;
        for (int i = 0; i < 256; i++) { 
            if (rData[i] > maxR) maxR = rData[i];
            if (gData[i] > maxG) maxG = gData[i];
            if (bData[i] > maxB) maxB = bData[i];
        }

        // 按通道独立归一化：三色各自按自己的峰值缩放。
        // 之前用全局最大值，某个通道的尖峰会把其他通道压得很矮，
        // 看起来像在某个高度被"切了一刀"。
        maxR = Math.max(maxR, 1);
        maxG = Math.max(maxG, 1);
        maxB = Math.max(maxB, 1);
        maxValue = Math.max(maxR, Math.max(maxG, maxB));
        sqrtMaxR = (float) Math.sqrt(maxR);
        sqrtMaxG = (float) Math.sqrt(maxG);
        sqrtMaxB = (float) Math.sqrt(maxB);
        hasData = true;

        postInvalidate(); 
    }

    private void smoothData(int[] data) {
        // 用浮点累加做平滑，最后一次性取整。
        // 原来每一步都做整数除法，小计数会被舍成同一个值，
        // 表现为某个亮度段出现"断层"（尤其亮度 +14~15 这类轻微拉伸时）。
        float[] temp = new float[256];
        for (int i = 0; i < 256; i++) {
            float sum = 0;
            int count = 0;
            for (int j = -2; j <= 2; j++) {
                if (i + j >= 0 && i + j < 256) { sum += data[i + j]; count++; }
            }
            temp[i] = count > 0 ? sum / count : 0f;
        }
        float[] temp2 = new float[256];
        for (int i = 0; i < 256; i++) {
            float sum = 0;
            int count = 0;
            for (int j = -1; j <= 1; j++) {
                if (i + j >= 0 && i + j < 256) { sum += temp[i + j]; count++; }
            }
            temp2[i] = count > 0 ? sum / count : 0f;
        }
        for (int i = 0; i < 256; i++) {
            data[i] = Math.round(temp2[i]);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) return;

        canvas.drawRect(0, 0, w, h, bgPaint);
        canvas.drawRect(1, 1, w - 1, h - 1, borderPaint);

        if (!hasData) return;

        float drawH = h - 8f;
        float bottomY = h - 4f;

        Path pathR = new Path();
        Path pathG = new Path();
        Path pathB = new Path();

        pathR.moveTo(0, bottomY);
        pathG.moveTo(0, bottomY);
        pathB.moveTo(0, bottomY);

        for (int i = 0; i < 256; i++) {
            float x = (i / 255f) * w;

            float rH = (float) (Math.sqrt(rData[i]) / sqrtMaxR) * drawH;
            float gH = (float) (Math.sqrt(gData[i]) / sqrtMaxG) * drawH;
            float bH = (float) (Math.sqrt(bData[i]) / sqrtMaxB) * drawH;
            if (rH < 0 || Float.isNaN(rH)) rH = 0;
            if (gH < 0 || Float.isNaN(gH)) gH = 0;
            if (bH < 0 || Float.isNaN(bH)) bH = 0;

            pathR.lineTo(x, bottomY - rH);
            pathG.lineTo(x, bottomY - gH);
            pathB.lineTo(x, bottomY - bH);
        }

        pathR.lineTo(w, bottomY);
        pathG.lineTo(w, bottomY);
        pathB.lineTo(w, bottomY);

        canvas.drawPath(pathR, rFill);
        canvas.drawPath(pathG, gFill);
        canvas.drawPath(pathB, bFill);

        canvas.drawPath(pathR, rLine);
        canvas.drawPath(pathG, gLine);
        canvas.drawPath(pathB, bLine);
    }
}
