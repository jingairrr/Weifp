package com.sertrt.weifp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class AboutActivity extends Activity {

    private float density;

    private static final String AUTHOR_PLACEHOLDER = "Sertrt";
    private static final String EMAIL_PLACEHOLDER = "sertrtgx@outlook.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getBaseContext().getResources().updateConfiguration(
            LanguageManager.wrap(this).getResources().getConfiguration(),
            getBaseContext().getResources().getDisplayMetrics()
        );

        density = getResources().getDisplayMetrics().density;

        getWindow().setBackgroundDrawable(new ColorDrawable(ThemeManager.getBgColor(this)));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ScrollView.LayoutParams(
                                       ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.MATCH_PARENT));
        scrollView.setBackgroundColor(ThemeManager.getBgColor(this));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding((int)(30*density), (int)(80*density), (int)(30*density), (int)(30*density));
        root.setLayoutParams(new ScrollView.LayoutParams(
                                 ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        ImageView logo = new ImageView(this);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams((int)(120*density), (int)(120*density));
        logoLp.setMargins(0, 0, 0, (int)(20*density));
        logo.setLayoutParams(logoLp);
        logo.setImageResource(R.drawable.ic_launcher);
        root.addView(logo);

        TextView tvAppName = new TextView(this);
        tvAppName.setText("Weifp");
        tvAppName.setTextSize(28);
        tvAppName.setTypeface(null, Typeface.BOLD);
        tvAppName.setTextColor(ThemeManager.getTextColor(this));
        tvAppName.setGravity(Gravity.CENTER);
        root.addView(tvAppName);

        TextView tvVersion = new TextView(this);
        tvVersion.setText(AppVersion.VERSION_NAME);
        tvVersion.setTextSize(13);
        tvVersion.setTextColor(0xFFFFB615);
        tvVersion.setGravity(Gravity.CENTER);
        tvVersion.setPadding(0, (int)(6*density), 0, (int)(50*density));
        root.addView(tvVersion);

        // 作者
        LinearLayout authorRow = createInfoRow(
            LanguageManager.getString(this, R.string.info_author_label), AUTHOR_PLACEHOLDER);
        root.addView(authorRow);

        // 反馈邮箱
        LinearLayout emailRow = createInfoRow(
            LanguageManager.getString(this, R.string.info_email_label), EMAIL_PLACEHOLDER);
        LinearLayout.LayoutParams emailLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        emailLp.setMargins(0, (int)(12*density), 0, 0);
        emailRow.setLayoutParams(emailLp);
        root.addView(emailRow);

        // ★ 使用的开源项目（新加的）
        LinearLayout openSourceRow = createInfoRow(
            LanguageManager.getString(this, R.string.open_source_title), ">");
        LinearLayout.LayoutParams osLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        osLp.setMargins(0, (int)(12*density), 0, 0);
        openSourceRow.setLayoutParams(osLp);
        openSourceRow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(AboutActivity.this, OpenSourceActivity.class));
                }
            });
        root.addView(openSourceRow);

        // 更新日志标题
        TextView tvChangelogTitle = new TextView(this);
        tvChangelogTitle.setText(LanguageManager.getString(this, R.string.changelog_title));
        tvChangelogTitle.setTextSize(16);
        tvChangelogTitle.setTypeface(null, Typeface.BOLD);
        tvChangelogTitle.setTextColor(ThemeManager.getTextColor(this));
        tvChangelogTitle.setGravity(Gravity.START);
        LinearLayout.LayoutParams changelogTitleLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        changelogTitleLp.setMargins(0, (int)(40*density), 0, (int)(12*density));
        tvChangelogTitle.setLayoutParams(changelogTitleLp);
        root.addView(tvChangelogTitle);

        // 更新日志内容
        addChangelogBlock(root, "10an05", LanguageManager.getString(this, R.string.changelog_10an05));
        addChangelogBlock(root, "10an04", LanguageManager.getString(this, R.string.changelog_10an04));
        addChangelogBlock(root, "10an03", LanguageManager.getString(this, R.string.changelog_10an03));
        addChangelogBlock(root, "10an02", LanguageManager.getString(this, R.string.changelog_10an02));
        addChangelogBlock(root, "10an01", LanguageManager.getString(this, R.string.changelog_10an01));
        addChangelogBlock(root, "10an00", LanguageManager.getString(this, R.string.changelog_10an00));
        addChangelogBlock(root, "7.0", LanguageManager.getString(this, R.string.changelog_70));
        addChangelogBlock(root, "6.0", LanguageManager.getString(this, R.string.changelog_60));
        addChangelogBlock(root, "5.0", LanguageManager.getString(this, R.string.changelog_50));

        scrollView.addView(root);
        setContentView(scrollView);

        BackButtonHelper.addBackButton(this, null);
    }

    private void addChangelogBlock(LinearLayout parent, String version, String content) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding((int)(16*density), (int)(14*density), (int)(16*density), (int)(14*density));

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(UiSpec.dp(this, UiSpec.RADIUS_M));
        bg.setColor(ThemeManager.getButtonColor(this));
        block.setBackground(bg);

        TextView tvVer = new TextView(this);
        tvVer.setText(version);
        tvVer.setTextSize(14);
        tvVer.setTypeface(null, Typeface.BOLD);
        tvVer.setTextColor(0xFFFFB615);
        block.addView(tvVer);

        TextView tvContent = new TextView(this);
        tvContent.setText(content);
        tvContent.setTextSize(13);
        tvContent.setTextColor(ThemeManager.getTextColor(this));
        tvContent.setLineSpacing((int)(4*density), 1f);
        LinearLayout.LayoutParams contentLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        contentLp.topMargin = (int)(6*density);
        tvContent.setLayoutParams(contentLp);
        block.addView(tvContent);

        LinearLayout.LayoutParams blockLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        blockLp.setMargins(0, 0, 0, (int)(10*density));
        block.setLayoutParams(blockLp);

        parent.addView(block);
    }

    private LinearLayout createInfoRow(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding((int)(16*density), (int)(14*density), (int)(16*density), (int)(14*density));

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(UiSpec.dp(this, UiSpec.RADIUS_M));
        bg.setColor(ThemeManager.getButtonColor(this));
        row.setBackground(bg);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(14);
        tvLabel.setTextColor(ThemeManager.getTextColor(this));
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(tvLabel);

        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(14);
        tvValue.setTextColor(0xFFFFB615);
        tvValue.setGravity(Gravity.END);
        tvValue.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(tvValue);

        return row;
    }
}
