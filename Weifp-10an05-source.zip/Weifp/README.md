# Weifp

一个纯 Java 的 Android 图片编辑器，支持超分辨率放大、色度抠图、局部蒙版、RAW 全尺寸解码等功能。

## 功能

- **超分辨率放大**：2 倍 / 4 倍，Lanczos3 重采样 + USM 锐化
- **色度抠图**：吸管取色 + 灵敏度 + 羽化 + 溢色抑制
- **局部蒙版**：径向（可椭圆、可旋转）、画笔、颜色选择三种区域，带曝光/对比度/饱和度/色温/清晰度调整
- **RAW 支持**：通过 LibRaw 全尺寸解码（NEF / CR2 / ARW 等）
- **图层编辑**：多图层、可见性、透明度
- **涂鸦**：画笔、橡皮、填充、对称绘制
- **高级调整**：HSL、曲线、色阶、LUT、分色调、噪点
- **历史记录**：每步 / 保存时存档可切换
- **多语言**：简体中文、English、繁體中文（台湾 / 香港）

## 技术栈

- 纯 Java（无 Kotlin）
- minSdk 19 / compileSdk 33
- LibRaw（LGPL-2.1，动态链接）
- OpenMP 多线程

## 构建

用 Android Studio 或 AIDE 打开项目，直接构建即可。

```bash
./gradlew assembleDebug
```

## 开源声明

本项目使用了以下开源软件，详见 App 内「开源声明」页：

- [AndroidLibRaw](https://github.com/dburckh/AndroidLibRaw) — LGPL-2.1
- [OpenMP](https://www.openmp.org/) — Apache License 2.0
- [Android Open Source Project](https://source.android.com/) — Apache License 2.0

## 说明

本项目在开发过程中使用了 AI 辅助编写代码。

## 许可

MIT License
